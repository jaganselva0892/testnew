package com.trivent;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;

//@EnableJms
@SpringBootApplication
public class AalamApplication extends SpringBootServletInitializer{

	
	@SuppressWarnings("unused")
	@Autowired
	private BeanFactory springContextBeanFactory;
	
	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(AalamApplication.class);
	}
	
	/*@Bean
	public DefaultJmsListenerContainerFactory containerFactory(ConnectionFactory connectionFactory) {
		DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
		factory.setConnectionFactory(connectionFactory);
		factory.setDestinationResolver(new BeanFactoryDestinationResolver(springContextBeanFactory));
		factory.setConcurrency("3-10");
		return factory;
	}*/
	
	public static void main(String[] args) {
		SpringApplication.run(AalamApplication.class, args);
	}
}
