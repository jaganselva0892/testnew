package com.trivent.constants;

import org.springframework.data.domain.Sort;

public class AppConstants {
	
	public static final String GLOBALS = "GLOBALS";

	public static final String LOGIN_USER = "loginUser";

	public static final String ALL = "All";

	public static final String UI_MESSAGE = "message";

	public static final String UI_ERROR = "error";

	public static final String FORM_INPUT_CSS = "formInputCss";

	public static final String APP_FORM_INPUT_CSS = "application.form.input.css";

	public static final String BUTTON_CSS = "buttonCss";

	public static final String APP_BUTTON_CSS = "application.form.button.css";

	public static final Sort NAME_ORDER_BY_ASC = new Sort(Sort.Direction.ASC, "name");

	public static final Sort SEQ_NO_ORDER_BY_ASC = new Sort(Sort.Direction.ASC, "seqNo");

	public static final String DATE_FORMAT = "MM/dd/yyyy";

	public static final String DATE_TIME_FORMAT = "MM/dd/yyyy HH:mm:ss";

	public static final String FILE_SUFFIX_FORMAT = "yyyyMMddHHmmss";

	public static final String CURRENCY_SYMBOL = "$";

	public static final String FILE_DELETED_SUFFIX = "deleted";

	public static final String CODE_PATTERN_CASE = "%s%05d";

	public static final String CODE_PATTERN_ACCOUNT = "%s%s%04d";

	public static final String CODE_PATTERN_CLIENT = "%s%s%02d";

	public static final String ATTR_PROXY_URL = "proxyUrl";

	public static final String ATTR_DOWNLOAD_PROXY_URL = "downloadProxyUrl";

	public static final String ATTR_SESSION_DETAILS = "sessionInfo";

	public static final String FILE_STATUS = "status";

	public static final String SUCCESS = "Success";

	public static final String ERROR = "Error";

	public static final String SORT_PREF_ASC = "Asc";

	public static final String SORT_PREF_DESC = "Desc";

	public static final String SORT_SEQ_NO = "seqNo";

	public static final String FILTER_CRITERIA_AND = "and";

	public static final String FILTER_CRITERIA_OR = "or";

	public static final String DATA_TYPE_TEXT = "Text";

	public static final String UTF8 = "UTF-8";
	
	public static final String CALL_BACK_CASE_DETAILS = "caseDetails";

	public static final String CALL_BACK_TASK_LISTS = "tasks";

	public static final String CALL_BACK_QUERIES_LISTS = "queries";

	public static final char QUERY_SOURCE_PORTAL = 'P';

	public static final char QUERY_SOURCE_EMAIL = 'E';

	public static final char QUERY_SOURCE_TELEPHONE = 'T';

	public static final String TYPE_SYSTEM = "System";

	public static final String TYPE_TRIVENT = "Trivent";

	public static final String TYPE_CLIENT = "Client";

	public static final String USER_STATUS_LIST = "User Status List";

	public static final String DATA_UPDATED = "Data updated successfully!";

	public static final String DATA_DELETED = "Data deleted successfully!";

	public static final String DATA_DELETED_BRANCH = "Branch assigned to Client";

	public static final String STEP_ONE_COMPLETED = "Step 1 Completed";

	public static final String PAGE_COUNT_STATUS_SUCCESSFUL = "Successful";

	public static final String PAGE_COUNT_STATUS_PROTECTED = "Corrupted or password protected";

	public static final String PAGE_COUNT_STATUS_NOT_SUPPORTED = "Page count not supported";

	public static final String PAGE_COUNT_STATUS_MANUAL = "Manual count";

	public static final String SERVICE_ALREADY_EXISTS = "Service already exists!";

	public static final String MSG_FORGOT_PWD = "A link to reset your password has been sent to the email address you provided.";

	public static final String NOT_VALID_DIGEST = "The link is expired or not valid.";

	public static final String RESET_PWD_SUCCESS = "Your new password has been updated. Please login with your new password.";

	public static final String CURRENT_PWD_ERROR = "Your password is not valid!";

	public static final String MSG_ACCOUNT_NOT_ACTIVE = "Your account is not active. Please contact system admin.";

	public static final String PWD_EXISTS_IN_LAST_THREE = "Note: New password should not match with your last 3 passwords. To protect your account, keep your password confidential. You are responsible for the activity that happens on your account.";// "Your
																																																															// new
																																																															// doesn't
																																																															// meets
																																																															// our
																																																															// policy!";

	public static final String MSG_PASSWORD_EXPIRED = "Your password has expired! Please reset new password!";

	public static final String MSG_USER_NOT_FOUND = "Your account is not valid!";

	public static final String MSG_USER_ACC_PART_NOT_FOUND = "Your account or partner is not valid!";

	public static final String INVALID_LOGIN_USER = "Invalid User!";

	public static final String MSG_CASE_NAME_ALREADY_EXISTS = "Case name already exists. Please choose a different name.";

	public static final String MSG_SCREEN_NOT_CONFIGURED = "App UI Screen is not configured for this role.";

	public static final String MSG_VIEW_NOT_CONFIGURED = "View for this screen has not been configured.";

	public static final String MSG_FILTER_NOT_CONFIGURED = "Filter for this screen has not been configured.";

	public static final String MSG_CASE_SERVICE_NOT_SELECTED = "Requested Service not selected. Please Select any service for request.";

	public static final String APP_UI_SCREEN_ALREADY_EXISTS = "UI Screen already exists! Choose a unique UI Screen.";

	public static final String MSG_QUERIES_TASK_ONLY_LIST_SCREEN = "Only list screen can be configured for Queries and Tasks.";

	public static final String NAME_ALREADY_EXISTS = "Name already exists! Choose a unique name.";

	public static final String CODE_ALREADY_EXISTS = "Code already exists! Choose a unique code.";

	public static final String EMAIL_ALREADY_EXISTS = "Email already exists! Choose a unique email.";

	public static final String CUSTOMER_CODE_ALREADY_EXISTS = "Customer code already exists! Choose a unique code.";

	public static final String ACCOUNT_CODE_ALREADY_EXISTS = "Account code already exists! Choose a unique code.";

	public static final String CONTACT_ALREADY_EXISTS = "Contact already exists!";

	public static final String USER_STAGING_NEW = "Thank you for registering! We will setup an account and send you activation link shortly!";

	public static final String USER_STAGING_EXIST = "You have already registered with us! Use forgot password if you have forgot your password.";

	public static final String BC_MAINMENU = "MainMenu";

	public static final String BC_DASHBOARD = "Home";

	public static final String BC_PARTNERS = "Partners";

	public static final String BC_PARTNER_DETAILS = "Partner Details";

	public static final String BC_ACCOUNTS = "Accounts";

	public static final String BC_ACCOUNT_DETAILS = "Account Details";

	public static final String BC_DIVISIONS = "Divisions";

	public static final String BC_DIVISION_DETAILS = "Division Details";

	public static final String BC_TEAMS = "Teams";

	public static final String BC_TEAM_DETAILS = "Team Details";

	public static final String BC_ROLES = "Role";

	public static final String BC_ROLE_DETAILS = "Role Details";

	public static final String BC_USERS = "Users";

	public static final String BC_SETTINGS = "Settings";

	public static final String BC_USER_DETAILS = "User Details";

	public static final String BC_CLIENT = "Client";

	public static final String BC_CLIENT_DETAILS = "Client Details";

	public static final String BC_NEW_REGISTRAIONS = "New Registrations";

	public static final String BC_LISTS = "List & Items";

	public static final String BC_LIST_DETAILS = "List & Item Details";

	public static final String BC_SUB_ITEMS = "Sub Items";

	public static final String BC_UI_SCREENS = "UI Screens";

	public static final String BC_UI_SCREEN_DETAILS = "UI Screen Details";

	public static final String BC_APP_SERVICE = "App Service Description";

	public static final String BC_APP_SERVICE_DETAILS = "App Service Link";

	public static final String BC_APP_TABLES = "App Tables";

	public static final String BC_APP_TABLE_DETAILS = "App Table & Column Details";

	public static final String BC_CAPABILITIES = "Capabilities";

	public static final String BC_CAPABILITY_DETAILS = "Capability Details";

	public static final String BC_EMAIL_TEMPLATES = "Email Templates";

	public static final String BC_EMAIL_TEMPLATE_DETAILS = "Email Template Details";

	public static final String BC_ACTIVE_USERS = "Active Users";

	public static final String BC_EMAIL_QUEUE = "Email Queue";

	public static final String BC_ANNOUNCEMENTS = "Announcements";

	public static final String TOOLTIP_LATEST = "Set Latest";

	public static final String TOOLTIP_CLIENT_REQ_SPECIFICATION = "Client Requirement Specification";

	/* Dashboard UI changes */

	public static final Integer DB_CUSTOMER_LATEST_CASES_COUNT = 5;

	public static final String DB_CUSTOMER_ALL_CASES = "All Cases";

	public static final String DB_CUSTOMER_CLOSED_CASES = "Closed Cases";

	public static final String DB_CUSTOMER_DELIVERED_CASES = "Delivered Cases";

	public static final String DB_CUSTOMER_TOPCASES_FLAG = "TopCases";

	public static final String DB_CUSTOMER_DELIVEREDCASES_FLAG = "DeliveredCases";

	public static final String DB_CUSTOMER_ALLCASES_FLAG = "AllCases";

	public static final String BC_CASES = "Cases";

	public static final String BC_CASE_DETAILS = "Case Details";

	public static final String BC_QUERIES = "Messages";

	public static final String BC_QUERY_DETAIL = "Message Details";

	public static final String BC_TASKS = "Tasks";

	public static final String BC_JOBS = "Jobs";

	public static final String BC_JOB_DETAILS = "Job Details";

	public static final String BC_STATUS_FLOW_REFS = "Status Flow Refs";

	public static final String BC_STATUS_FLOW_REF_DETAILS = "Status Flow Ref Details";

	public static final String BC_REPORTS = "Reports";

	public static final String BC_REPORT_DETAILS = "Report Details";

	public static final String BC_INVOICES = "Invoices";

	public static final String BC_INVOICE_DETAILS = "Invoice Details";

	public static final String CASE_FILE_UPLOAD_PATH = "application.case.file.upload.path";

	public static final String CASE_RESULT_FILE_UPLOAD_PATH = "application.case.result.file.upload.path";

	public static final int ZERO = 0;

	public static final long NULL_ID = 0;

	public static final long MINUS_ONE = -1;

	public static final String PERCENTAGE = "%";

	public static final String SPACE_SEPARATOR = " ";

	public static final String DOT_SEPARATOR = ".";

	public static final String HYPEN_SEPARATOR = "-";

	public static final String COMMA_SEPARATOR = ",";

	public static final String UNDER_SCORE_SEPARATOR = "_";

	public static final String PIPE_SEPARATOR = "|";

	public static final String EMPTY_STRING = "";

	public static final String SEMI_COLON_SEPARATOR = ":";

	public static final String DOUBLE_PIPE_SEPARATOR = "/";

	public static final String SUFFIX_HOURS = " Hrs";

	public static final String SUFFIX_MINUTES = " Min";

	public static final String TOOLTIP_VIEW_DETAILS = "View Details";

	public static final String TOOLTIP_EDIT = "Edit";

	public static final String TOOLTIP_VIEW = "View";

	public static final String TOOLTIP_EDIT_NEW_TAB = "Open in New Tab";

	public static final String TOOLTIP_OPEN_CASE = "Open Case";

	public static final String TOOLTIP_DELETE = "Delete";

	public static final String TOOLTIP_DOWNLOAD = "Download Outer";

	public static final String TOOLTIP_SUB_ITEMS_CONFIG = "Congifure Sub Items";

	public static final String TOOLTIP_TOGGLE_VIEW = "Toggle View";

	public static final String TOOLTIP_NOTIFY_VIA_EMAIL = "Send Email";

	public static final String TOOLTIP_IP_RESTRICTED = "IP Restricted";

	public static final String TOOLTIP_IP_ACCESS_ANY_WHERE = "Access any where";

	public static final String FIELD_EMAIL = "Email";

	public static final String FIELD_INTERNAL = "Internal";

	public static final String FIELD_CUSTOMER = "Customer";

	public static final boolean BOO_YES = true;

	public static final char YES = 'Y';

	public static final char NO = 'N';

	public static final String STATUS_OPEN = "Open";

	public static final String STATUS_WIP = "Work In Progress";

	public static final String STATUS_CLOSED = "Closed";

	public static final String CASE_FILTER_ANY = "---Any---";

	public static final String DIRECTORY_SAVE_PREFIX = "basePath.save.prefix";

	public static final String DIRECTORY_SAVE_PREFIX_LENGTH = "basePath.save.prefix.length";

	public static final String DIRECTORY_RESULT_FILE_PREFIX = "basePath.file.result.prefix";

	public static final String DIRECTORY_SAVE_RESULT_FILE_LENGTH = "basePath.file.result.prefix.length";

	public static final String DATA_TYPE_PROPERTIES = "From Properties File";

	public static final String IS_INTERNAL_ALERTABLE = "Is Internal Alertable";

	public static final String IS_CLIENT_ALERTABLE = "Is Client Alertable";

	public static final String OBJECT_TYPE = "Status Object Types";

	public static final String CUSTOMER_STATUS_LIST = "Customer Status List";

	public static final String CS_STATUS_LIST = "Customer Service Status List";

	public static final String FILE_UPLOAD_SAVE_RESULT_FILE_PATH = "application.upload.save.result.file.path";

	public static final String FTP_DESTINATION_FILE_PATH = "case.file.replication.destination.basePath";

	public static final String FTP_DESTINATION_RESULT_FILE_PATH = "case.file.result.replication.destination.basePath";

	public static final String FTP_ACTION_UPLOAD = "UPLOAD";

	public static final String FTP_ACTION_RENAME = "RENAME";

	public static final String FTP_ACTION_DOWNLOAD = "DOWNLOAD";

	public static final String FTP_ACTION_RENAME_AND_UPLOAD = "RENAME&UPLOAD";

	public static final String FTP_ACTION_RENAME_AND_DOWNLOAD = "RENAME&DOWNLOAD";

	public static final String FTP_OBJECT_TYPE_CASE_FILES = "caseFile";

	public static final String FTP_OBJECT_TYPE_CASE_RESULT_FILES = "caseResultFile";

	public static final String CASE_FILE_DOWNLOAD_PATH = "case.file.download.path";

	public static final char TRUE = 'T';

	public static final char FALSE = 'F';

	public static final String EMAIL_TRUE = "true";

	public static final String FILE_FORMAT_ZIP = ".zip";

	public static final String RESPONSE_CONTENT_TYPE_ZIP = "application/zip";

	public static final String RESPONSE_HEADER_CONTENT_DISP = "Content-Disposition";

	public static final String RESPONSE_ATTACH_PREFIX = "attachment; filename=\"";

	public static final String RESPONSE_ATTACH_SUFFIX = "\";";

	public static final String RESPONSE_ATTACH_PREFIX_INLINE = "inline; filename=\"";

	public static final String INVOICE_TEMPLATE_TRIVENT = "Trivent";

	public static final String INVOICE_TEMPLATE_RR = "RR";

	public static final String FILE_TYPE_PDF = "pdf";

	public static final String FILE_TYPE_XLS = "xls";

	public static final String FILE_TYPE_DOCX = "rtf";

	public static final String LOGO_PATH = "/resources/images/trivent/trivent-logo.png";

	public static final String PARAM_LOGO_PATH = "logoPath";

	public static final String PARAM_CACHE_SERVICE = "cacheService";

	public static final String FILE_DOC_EXT = "doc";

	public static final String FILE_DOCX_EXT = "docx";

	public static final String FILE_PDF_EXT = "pdf";

	public static final String FILE_XLS_EXT = "xls";

	public static final String SCREEN_NAME_CASES = "Cases";

	public static final String SCREEN_NAME_TASKS = "Tasks";

	public static final String SCREEN_NAME_QUERIES = "Queries";

	public static final String SCREEN_NAME_CASE_SERVICE_REQ = "Case Service Req";

	public static final String SCREEN_TYPE_LIST = "List";

	public static final String SCREEN_TYPE_DETAIL = "Detail";

	public static final String SCREEN_TYPE_ADD = "Add";

	public static final String VALIDATION_TYPE_ALPHA_NUM = "alphanum";

	public static final String VALIDATION_TYPE_NUMBER = "integer";

	public static final String VALIDATION_TYPE_EMAIL = "email";

	public static final String UI_TYPE_TEXT_BOX = "Text Box";

	public static final String UI_TYPE_TEXT_AREA = "Text Area";

	public static final String UI_TYPE_DROP_DOWN = "Drop Down";

	public static final String UI_TYPE_RADIO_BUTTON = "Radio Button";

	public static final String UI_TYPE_CHECK_BOX = "Check Box";

	public static final String UI_TYPE_DATE = "Date";

	public static final String UI_TYPE_HOUR = "Hours";

	public static final String COLUMN_NAME_HOURS = "Hours";

	public static final String LOCAL_FILE_DOWNLOAD_URL = "local.file.download.url";

	public static final String COUNT_PAGES_OF_WORD_FILES = "count.pages.of.word.files";

	public static final String IP_RANGE_ALLOWED = "application.ip.allowed.list";

	public static final String PARAM_IP_ALLOWED_SET = "allowedIpSet";

	public static final String PRODUCTION = "Production";

	public static final String MANAGERS = "Managers";

	public static final String FINANCE = "Finance";

	public static final String US_CUSTOMER_SUPPORT = "USCustomerSupport";

	public static final String CASE_TASK = "CaseTask";

	public static final String CASE_QUERY = "CaseQuery";

	public static final String columnNamesForProdReport = "column.names.with.type.for.production.report";

	public static final String columnNamesForFinanceReport = "column.names.with.type.for.finance.report";

	public static final String columnNamesForUSCustomerSuportReport = "column.names.with.type.for.us.customer.support.team.report";

	public static final String assignedToTemplateCodeForCase = "application.assignedTo.template.code.for.case";

	public static final String assignedToTemplateCodeForCaseTask = "application.assignedTo.template.code.for.caseTask";

	public static final String assignedToTemplateCodeForCaseTaskStatus = "application.template.code.for.caseTask.status.change";

	public static final String assignedToTemplateCodeForCaseQuery = "application.assignedTo.template.code.for.caseQuery";

	public static final String columnNamesForCaseTask = "column.names.with.type.for.case.task";

	public static final String columnNamesForCaseQuery = "column.names.with.type.for.case.query";

	public static final String CLIENT_CASE_QUERY_EMAIL = "application.assignedTo.template.code.for.caseQueryEmail";

	public static final String CLIENT_CASE_QUERY_EMAIL_WITHOUT_CASE = "application.assignedTo.template.code.for.caseQueryEmailWithoutCase";

	public static final String FILE_DOWNLOAD_ERROR_MESSAGE = "File Download Error";

	public static final String FILE_UPLOAD_ERROR_MESSAGE = "File Upload Error..";

	public static final String FILE_UPLOAD_SUCCESS_MESSAGE = "File Uploaded Successfully...";

	public static final String FILE_UPLOADING_STATUS = "Uploading";

	public static final String EMPTY_APP_SCREEN_UI = "emptyAppScreen";

	public static final String EMPTY_APP_SCREEN_UI_MSG = "App UI Screen is not configured for your role. Please contact system admin.";

	public static final String EMPTY_USER_QUERY_TO = "No User In DataBase";

	public static final String CASE_STATUS_NOT_TO_SEND_EMAIL_FOR_NEW_FILES = "case.status.not.to.send.email.for.new.files";

	public static final String SUPRESS_EMAIL_MINUTES_FOR_NEW_FILE = "suppress.email.for.minutes.for.new.files";

	public static final String STATUS_BASED_EMAIL_FOR_NEW_CASE_FILE = "application.email.send.for.new.file.template.code";

	public static final String STATUS_BASED_EMAIL_TO_CLIENT_FOR_NEW_CASE_FILE = "application.email.send..toClient.for.new.file.template.code";

	public static final String NEW_STATUS = "New";

	public static final String PROCESSING_STATUS = "Processing";

	public static final String QUERY_CREATED_BY_CLIENT_EMAIL_TEMPLATE = "application.email.template.code.for.caseQueryByClient";

	public static final String QUERY_CREATED_BY_CLIENT_EMAIL_TEMPLATE_WITHOUT_CASE = "application.email.template.code.for.caseQueryByClient.withoutCase";

	public static final String CASE_FINAL_DELIVERY_DOWNLOAD_CONFIRMATION = "application.email.template.code.for.caseFinalDownload_confirmation";

	public static final String API_FORGOT_OTP = "application.email.template.api.forgot.code";

	public static final String LINK_EXPIRED_TIME = "link.expired.time.in.milliseconds";

	public static final Integer CASE_FILE_AUTO_REFRESH_AJAX = 20000;

	public static final Integer CASE_RESULT_FILE_AUTO_REFRESH_AJAX = 10000;

	/*
	 * 
	 * Type: New, Date: 01-11-2016, Description: Email Queue type
	 */

	public static final String EMAIL_QUEUE_TYPE_QUERY = "Query";

	public static final String CASE_QUERY_TYPE_FLAG = "Flag"; // Description:
	// Query

	public static final String BC_WORKLOG = "Master Worklog";

	public static final String ROLE_CUSTOMER = "Customer";

	public static final String ROLE_PRODUCTION = "Production";

	public static final String USER_STAGING_CLONED = "Cloned";

	public static final String QUERY_FLAG = "isQueryFlag";

	public static final String QUERY_OPEN = "isQueryOpen";

	// Product Version (Version.properties)

	public static final String VERSION_PRODUCT_NAME = "version.product.name";

	public static final String VERSION_PRODUCT = "version.product";

	public static final String VERSION_DESC = "version.product.description";

	public static final String VERSION_CONTEXT_PRODUCTNAME = "productName";

	public static final String VERSION_CONTEXT_PRODUCTVERSION = "versionProduct";

	public static final String VERSION_CONTEXT_PRODUCTVERSION_DESC = "versionDescription";

	// Database version

	public static final String BC_DB_VERSION = "DB Versions";

	public static final String MODEL_DBVERSION = "dbversion";

	// Account Page - Binding Values into Client Form

	public static final String AppConstant_id = "id";

	public static final String AppConstant_Addr1 = "address1";

	public static final String AppConstant_Addr2 = "address2";

	public static final String AppConstant_City = "city";

	public static final String AppConstant_State = "state";

	public static final String AppConstant_Zipcode = "zipcode";

	public static final String AppConstant_Phone = "phone";

	public static final String AppConstant_Account_Manager_Id = "accountManagerId";

	/*
	 * Archival Block
	 */

	public static final boolean ARCHIVAL_IS_CASE_FILE = true;

	public static final boolean ARCHIVAL_IS_RESULT_FILE = false;

	public static final String ARCHIVAL_FTP_ACTION_DELETE = "DELETE";

	public static final String ARCHIVAL_DOWNLOAD_CASE_FILE = "downloadcaseFile";

	public static final String ARCHIVAL_DOWNLOAD_RESULT_FILE = "downloadResultFile";

	public static final String ARCHIVAL_JSON_TREE_HEADER = "Archival";

	public static final String ARCHIVAL_JSON_TREE_ID = "id";

	public static final String ARCHIVAL_JSON_TREE_TEXT = "text";

	public static final String ARCHIVAL_JSON_TREE_SUB_HEAD1_TEXT = "subHead1";

	public static final String ARCHIVAL_JSON_TREE_SUB_HEAD2_TEXT = "subHead2";

	public static final String ARCHIVAL_JSON_TREE_SUB_HEAD3_TEXT = "subHead3";

	public static final String ARCHIVAL_JSON_TREE_PARENT = "parent";

	public static final String ARCHIVAL_JSON_TREE_ROOT_PARENT = "#";

	public static final String ARCHIVAL_JSON_TREE_ICON = "icon";

	public static final String ARCHIVAL_JSON_TREE_CASE_ID = "caseid";

	public static final String ARCHIVAL_JSON_TREE_FILE_ID = "fileid";

	public static final String ARCHIVAL_JSON_TREE_FILE_TYPE = "filetype";

	public static final String ARCHIVAL_JSON_TREE_IS_END = "isend";

	public static final String BC_ARCHIVAL = "Archival";

	public static final String ARCHIVAL_TYPE_CASE_FILES = "Case File";

	public static final String ARCHIVAL_TYPE_CASE_RESULT_FILES = "Result File";

	public static final String ARCHIVAL_HEADER_ICON = "fa fa-archive";

	public static final String ARCHIVAL_CASE_ICON = "fa fa-briefcase";

	public static final String ARCHIVAL_CASE_FILE_ICON = "fa fa-folder-o";

	public static final String ARCHIVAL_FILE_ICON = "fa fa-file-o";

	public static final String AUTO_REFRESH_CASE_FILES = "application.case.files.auto.refresh";

	public static final String AUTO_REFRESH_CASE_RESULT_FILES = "application.case.result.files.auto.refresh";

	public static final String APP_AUTO_REFRESH_CASE_FILES = "formAutoRefreshCaseFiles";

	public static final String APP_AUTO_REFRESH_CASE_RESULT_FILES = "formAutoRefreshCaseResultFiles";

	public static final String PARTNER = "Partner";

	public static final String CASE_SERVICES = "Case Services";

	public static final String APP_SERVICE_ID = "appServiceid";
	/*
	 * End Archival Block
	 */

	// Query attachment maximum size limit

	public static final String QUERY_ATTACHMENT_SIZE_LIMIT = "application.query.attachment.maximumFileSize";

	public static final String APP_QUERY_ATTACHMENT_SIZE_LIMIT = "queryAttachmentMaxFileSize";

	// Task attachment maximum size limit

	public static final String TASK_ATTACHMENT_SIZE_LIMIT = "application.task.attachment.maximumFileSize";

	public static final String APP_TASK_ATTACHMENT_SIZE_LIMIT = "taskAttachmentMaxFileSize";
	/*
	 * FTP Modified file single upload
	 */

	public static final String TOOLTIP_UPLOAD = "Upload";
	/*
	 * End FTP Modified file single upload
	 */

	/*
	 * Master Work Log
	 */
	// client - accountmanager

	public static final String MWL_CASE_FILEDS = "Partner~`~Partner Name,account~`~Account Name,caseCode~`~Case Code,name~`~Case Name,type~`~Type,client~`~Client Name,accountmanager~`~Account Manager,fileReceivedDate~`~File Received Date,csStatus~`~CS Status,fileDeliveryDate~`~File Delivery Date,prodDeliveryDate~`~Production Delivery Date,productionStatus~`~Production Status,completeProcess~`~Complete Percent,assignedTo~`~AssignedTo,csStatus~`~CS Status,requestCategory~`~Request Category,productionEstimateSendDate~`~Prod Estimate SendDate,cf_3_Date~`~Estimate SendDate,estApprovedDate~`~EstimateApprovedDate,revisedEstiamteSendDate~`~RevisedEstimateSendDate";
	// public static final String MWL_EXCEL_CASE_FILEDS = "caseCode~`~Case
	// Code,name~`~Case Name,type~`~Type,client~`~Client Name,account~`~Account
	// Name,job~`~Job,parentCase~`~Parent Case,assignedTo~`~Assigned
	// To,clientPriority~`~Client Priority,clientStatus~`~Client
	// Status,serviceRequestedShortCode~`~Service Requested Short
	// Code,csPriority~`~ CS Priority,csStatus~`~CS Status,contactName~`~Contact
	// Name,emailId~`~Email ID,subType~`~Case Sub-Type,pageCount~`~Page
	// Count,prodStartDate~`~Production Start Date,prodEndDate~`~Production End
	// Date,prodDeliveryDate~`~Production Delivery Date,fileReceivedDate~`~File
	// Received Date,expeditedDeliveryDate~`~Expedited Delivery
	// Date,fileDeliveryDate~`~File Delivery Date,fileMigrationDate~`~File
	// Migration Date,estimateHours~`~Estimate Hours,approvedHours~`~Approved
	// Hours,discountHours~`~Discount Hours,productionHours~`~Production
	// Hours,indirectHours~`~Indirect Hours,invoiceHours~`~Invoice
	// Hours,deviationHours~`~Deviation Hours,depsumPages~`~Sum
	// Pages,estimateRequest~`~Estimate Request,expeditedRequest~`~Expedited
	// Request,batesReference,pdfReference~`~PDF
	// Reference,isInvoiced,balanceDue~`~Balance
	// Due,isFileDownloaded,downloadedDateTime~`~Downloaded
	// DateTime,downloadCount~`~Download Count,caseOverview~`~Case
	// Overview,expeditedRequestReason~`~Expedited Request
	// Reason,description~`~Description,csNotes~`~CS Notes,delayReasons~`~Delay
	// Reasons,clientNotes~`~Client
	// Notes,cf_1_Text,cf_2_Text,cf_3_Text,cf_1_LongText,cf_2_LongText,cf_3_LongText,cf_1_YesNo,cf_2_YesNo,cf_3_YesNo,cf_1_Date,cf_2_Date,cf_3_Date,cf_1_Hours,cf_2_Hours,cf_3_Hours,cf_1_Number,cf_2_Number,cf_3_Number,isDemand,isCustomerDownloaded";

	public static final String MWL_EXCEL_CASE_FILEDS = "Partner~`~Partner Name,account~`~Account Name,accountmanager~`~Account Manager,type~`~Case Type,customerCode~`~Client Code,customempty~`~Client Type,client~`~Client,name~`~Case Name,pageCount~`~Pages,subType~`~Case Sub Type,description~`~Case Description,serviceRequestedShortCode~`~Services,batesReference~`~Addtional Services,clientNotes~`~Comments,expeditedRequest~`~Rush,fileReceivedDate~`~Received Date,customemptymonth~`~Month,customempty~`~TAT,customempty~`~Estimate_Chrono,customempty~`~Estimate_Opinion,customempty~`~Estimate_Add_Service,customempty~`~Estimate_Demand,customempty~`~Est_Depsum_Hours,customempty~`~Total_Estimate_Hours,customempty~`~Invoice_Chrono,customempty~`~Invoice_Opinion,customempty~`~Invoice_Add_Service,customempty~`~Invoice_DMD,customempty~`~Inv_Depsum_Hours,customempty~`~Total_Invoive,customempty~`~Differences,customempty~`~Chrono_Dir_Disc,customempty~`~Chorno_O,customempty~`~Add_Service_Dir_Disc,customempty~`~Chrono_InDir_Disc,customempty~`~Opinion_InDir_Disc,customempty~`~Add_Service_InDir_Disc,customempty~`~Project Managemnet Hours (%),customempty~`~Tentative_Delivery_Date,csStatus~`~Status,customisDemand~`~Demand Team,prodDeliveryDate~`~Production Delivery Date,fileDeliveryDate~`~File Delivery Date,productionStatus~`~Production Status,completeProcess~`~Complete Percent,assignedTo~`~AssignedTo,requestCategory~`~Request Category,productionEstimateSendDate~`~Prod Estimate SendDate,cf_3_Date~`~Estimate SendDate,estApprovedDate~`~EstimateApprovedDate,revisedEstiamteSendDate~`~RevisedEstimateSendDate,createdBy~`~Created By,createdDate~`~Created Date,lastModifiedDate~`~Modified Date,lastModifiedBy~`~Modified By,clientPriority~`~Client Priority,clientStatus~`~Client Status,estimateRequest~`~Estimate Request,type~`~Type,balanceDue~`~Balance Due,batesReference~`~Bates Reference,emailId~`~Contact Email,description~`~CSDescription,delayReasons~`~Delay Reason,depsumPages~`~Depsum Pages,expeditedDeliveryDate~`~Expedited Delivery,prodEndDate~`~Prod End Date,prodStartDate~`~Prod Start Date,deviationHours~`~Total Deviation Hours,discountHours~`~Total Discount Hours,indirectHours~`~Total Indirect Hours,invoiceHours~`~Total Invoice Hours,productionHours~`~Total Production Hours,downloadCount~`~Download Count,downloadedDateTime~`~Download Date Time,isFileDownloaded~`~Is File Downloaded,cf_1_YesNo~`~Custom Char1,cf_2_YesNo~`~Custom Char2,cf_3_YesNo~`~Custom Char3,cf_1_Date~`~Custom Date1,cf_2_Date~`~Custom Date2,cf_3_Date~`~Custom Date3,cf_4_Date~`~Custom Date4,cf_5_Date~`~Custom Date5,cf_6_Date~`~Custom Date6,cf_7_Date~`~Custom Date7,cf_8_Date~`~Custom Date8,cf_1_Hours~`~Custom Hours1,cf_2_Hours~`~Custom Hours2,cf_3_Hours~`~Custom Hours3,cf_1_Number~`~Custom Number1,cf_2_Number~`~Custom Number2,cf_3_Number~`~Custom Number3,cf_1_Text~`~Custom Text1,cf_2_Text~`~Custom Text2,cf_3_Text~`~Custom Text3,isDemand~`~Is Demand,isCustomerDownloaded~`~Is Customer Download,estProvisionDate~`~Estimate Provision Date,dateOfClarrification~`~Date Of Clarification,addRecordDate~`~Add Rec Date,caseOverview~`~Case OverView,contactName~`~Contact Name,expeditedRequestReason~`~Expedited Request Reason,fileMigrationDate~`~File Migration Date,isInvoiced~`~IsInvoiced,pdfReference~`~PDF Reference,approvedHours~`~Approved Hours,estimateHours~`~Estimate Hours";

	/*
	 * End Master Work Log
	 */

	/*
	 * Team Pointer Report
	 */

	public static final String TP_CASEQUERY_FILEDS = "customemptyDate~`~Date,Partner~`~Partner Name,account~`~Law Firm,customCasetype~`~Case Type,client~`~Client Name,customerCode~`~Client Code,accountCode~`~Account Code,customCasename~`~Case Name,customquery_type~`~Communication Category,customquery_details~`~Description,assignedTo~`~Task Owners,status~`~Status";

	public static final String TP_EXCEL_CASEQUERY_FILEDS = "customemptyDate~`~Date,Partner~`~Partner Name,account~`~Law Firm,customCasetype~`~Case Type,client~`~Client Name,customerCode~`~Client Code,accountCode~`~Account Code,customCasename~`~Case Name,customquery_type~`~Communication Category,customquery_details~`~Description,assignedTo~`~Task Owners,status~`~Status";

	/*
	 * End Team Pointer Report
	 */

	/*
	 * Constants for Production Module - Starts
	 */

	public static final String TREE_ICON_USERS = "fa fa-users";

	public static final String TREE_ICON_USER = "fa fa-user";

	public static final String TREE_HEADER_PARENT_CODE = "#";

	public static final String TREE_PARENT_PRODROLE_NAME = "Production Roles";

	public static final String BC_PRODUCTION_DASHBOARD = "Production Dashboard";

	public static final String BC_PRODUCTION_WORK = "Production";

	public static final String PRODUCTION_CASE_GRID_FIELDS = "caseCode,name,type,serviceRequestedShortCode,pageCount";

	public static final String PRODUCTION_CASE_GRID_PRODID = "ProductionId";

	public static final String PRODUCTION_CASE_GRID_PRODSTATUS = "ProductionStatus";

	public static final String PRODUCTION_CASE_ASSIGNED_BY = "Assigned By";

	public static final String PRODUCTION_CASE_ASSIGNED_TO = "Assigned To";

	public static final String PRODUCTION_CASE_GRID_AUDIT_SCORE = "Audit Score";

	public static final String PRODUCTION_CASE_TAB_PROD_MYCASE = "MyCase";

	public static final String PRODUCTION_CASE_TAB_PROD_ASSIGNEDCASE = "Assigned";

	public static final String PRODUCTION_CASE_TAB_PROD_NONASSIGNEDCASE = "NonAssigned";

	public static final String PRODUCTION_CASE_TAB_PROD_TYPE = "prodType";

	public static final String PRODUCTION_CASE_GRID_ENCRYPTID = "encryptid";

	public static final String CLIENT_TEMPLATE_LOCAL_FILE_UPLOAD_PATH = "application.client.file.upload.path";

	public static final String PRODUCTION_LOCAL_FILE_UPLOAD_PATH = "application.production.file.upload.path";

	public static final String TASK_ATTACHMENT_FILE_UPLOAD_PATH = "application.task.file.attachment.upload.path";

	public static final String PRODUCTION_COMMENT_FLAG_FILEUPLOAD = "File Upload";

	public static final String PRODUCTION_NEW_STATUS = "application.production.new.status";

	public static final String PRODUCTION_CLOSED_STATUS = "application.production.closed.status";

	public static final String PRODUCTION_STATUS_LABEL = "Production Status";

	public static final String PRODUCTION_COMPLETE_LABEL = "Production Complete (%)";

	public static final String PRODUCTION_CLIENT_DOC_UPLOAD = "Client Document Template Upload";

	public static final String ALL_CASE_STATUS_BASED_COUNT = "application.status.name";

	public static final String CASE_TEAM = "application.team.names";

	public static final String ROLE_NAME = "application.role.name";

	public static final String TOOLTIP_UNREAD_QUERIES = "Unread Queries";

	public static final String TOOLTIP_FILTER_BY_DATE = "Filter By Date";

	public static final String TOOLTIP_FILTER_BY_PARTNER = "Filter By Partner";

	public static final String TOOLTIP_FILTER_ = "Filter";

	public static final String TOOLTIP_QUICK_LINKS = "Quick Links";

	public static final String TOOLTIP_SUBMIT_NEW_CASE = "Submit New Case";

	public static final String TOOLTIP_ADD_ADDITIONAL_RECORDS = "Add Additional Records";

	/*
	 * Constants for Production Module - Ends
	 */

	/*
	 * Constants for Timer Control - Begin. On 15 Mar 2017
	 */

	public static final String TIMER_TASK_STATUS = "application.task.status";

	public static final String TIMER_PRODUCTION_STATUS = "application.production.time.close.status";

	public static final String TIMER_TASK_ENTITY = "task";

	public static final String TIMER_PRODUCTION_ENTITY = "production";

	public static final String TIMER_TOOLTIP_ADD_LOG = "Add Log Hours";

	/*
	 * Constants for Timer Control - Ends. On 15 Mar 2017
	 */

	public static final String QUERY_TYPE_FROM_EMAIL_GROUP = "Group";

	public static final String QUERY_TYPE_FROM_EMAIL_IND = "Ind";

	public static final String PRODUCTION_ASSIGNED_FROM_CS = "application.production.assignedFromCS.template.code";

	public static final String PRODUCTION_ASSIGNED_FROM_PROD = "application.production.assignedFromProd.template.code";

	public static final String PRODUCTION_PERCENTAGE_CHANGE = "application.production.percnentage.template.code";

	public static final String PRODUCTION_FILE_DELIVERED_STATUS = "Delivered";

	public static final String PRODUCTION_FILE_PARTIAL_DELIVERED_STATUS = "Partially Delivered";

	public static final String PRODUCTION_FILE_NOT_DELIVERED_STATUS = "Not Delivered";

	public static final String PRODUCTION_FILE_DOC_UPLOAD = "Production File Upload";

	public static final String PRODUCTION_DATA_MOVED = "File moved to final delivery!";

	public static final String PRODUCTION_DATA_NOT_MOVED = "File not moved!";

	public static final String PRODUCTION_REPORT_MAIL = "application.production.userreport.mail";

	public static final String PRODUCTION_REPORT_ROLES = "application.production.userreport.roles";

	public static final String PRODUCTION_QC_QCROLES = "application.production.qc.qcuser";

	public static final String PRODUCTION_QC_USERROLES = "application.production.qc.user";

	public static final String PRODUCTION_QC_QCROLES_LIST = "application.production.qc.qcuser.list";

	public static final String PRODUCTION_QC_USERROLES_LIST = "application.production.qc.user.list";

	public static final String USER_COMMENTS_ENTITY_PRODUCTION = "Production";

	public static final String COMMENTS_TYPE_PRODUCTION_QC_REVIEW = "application.production.comments.type.qcreview";

	public static final String COMMENTS_TYPE_PRODUCTION_MD_REVIEW = "application.production.comments.type.mdreview";

	public static final String COMMENTS_SEND_MAIL = "Send";

	public static final String COMMENTS_APPROVE_MAIL = "Approve";

	public static final String COMMENTS_TYPE_ESTIMATE_MAIL_SEND = "application.production.send.mail.estimate";

	public static final String COMMENTS_TYPE_REESTIMATE_MAIL_SEND = "application.production.send.mail.reestimate";

	public static final String COMMENTS_TYPE_DELIVERYNOTES_MAIL_SEND = "application.production.send.mail.deliveryNotes";

	public static final String COMMENTS_ESTIMATE_UI = "estimateUI";

	public static final String COMMENTS_REESTIMATE_UI = "reEstimateUI";

	public static final String COMMENTS_DELIVERYNOTES_UI = "deliveryNotesUI";

	public static final String PRODUCTION_MAIL_SEND = "Mail send successfully!";

	public static final String PRODUCTION_MAIL_SEND_ERROR = "Mail not send!";

	public static final String PRODUCTION_MAIL_APPROVED = "Approved Successfully!";

	public static final String PRODUCTION_MAIL_APPROVED_ERROR = "Not approved!";

	public static final String PRODUCTION_COMMENTS_APPROVE = "application.production.comments.approve.code";

	public static final String CS_FEEDBACK_NOTIFICATIOON = "application.email.template.code.for.feedback";

	public static final String DB_UNREAD_QUERIES_COUNT = "DB Unread Queries Count";

	/*
	 * Constants for Timer Control - Begin. On 12 Apr 2017
	 */

	public static final String APPROVAL_USERS_BASED_ON_ROLE = "application.approvalFlow.roles";

	public static final String BC_APPROVAL_USER = "Approval User";

	public static final String BC_APPROVAL_CONNFIG = "Approval Configuration";

	public static final String BC_APPROVAL_CONNFIG_DETAILS = "Approval Configuration Details";

	public static final String BC_APPROVAL_PENDING = "Approval Pending";

	public static final String APPROVAL_TYPE_ALL = "All";

	public static final String APPROVAL_TYPE_ANY = "Any";

	public static final String APPROVAL_TYPE_PENDING = "PENDING";

	public static final String APPROVAL_TYPE_APPROVED = "APPROVED";

	public static final String APPROVAL_TYPE_REJECTED = "REJECTED";

	public static final String APPROVAL_USER_TYPE = "USER";

	public static final String APPROVAL_ROLE_TYPE = "ROLE";

	public static final String APPROVAL_ENTITY_PRODUCTION = "PRODUCTION";

	public static final String APPROVAL_ENTITY_USER_COMMENTS = "USER COMMENTS";

	public static final String APPROVAL_ACCEPT = "Request Approved successfully!";

	public static final String APPROVAL_ACCEPT_ERROR = "Request not approved!";

	public static final String APPROVAL_REJECT = "Request rejected successfully!";

	public static final String APPROVAL_REJECT_ERROR = "Request not rejected!";

	public static final String TOOLTIP_REJECT = "Reject";

	public static final String TOOLTIP_ACCEPT = "Accept";

	public static final String APPROVAL_EMAIL_TEMPLATE = "application.production.approval.code";

	public static final String APPROVAL_REJECT_EMAIL_TEMPLATE = "application.production.approval.reject.code";

	/*
	 * Constants for Approval - End. On 12 Apr 2017
	 */

	public static final String CASES_IMPORTED_SESSION_COUNT = "casesImportedCount";

	public static final String BC_IMPORT_CASES = "Import Cases";

	public static final String TOOLTIP_EXPEDITE_CASE = "Expedite Case";

	public static final String TOOLTIP_ESTIMATE_CASE = "Estimated Delivery Case";

	public static final String EXPEDITE_ESTIMATE_DEADLINE_1 = "application.expediteEstimateCase.deadline.time.difference_one";

	public static final String EXPEDITE_ESTIMATE_DEADLINE_2 = "application.expediteEstimateCase.deadline.time.difference_two";

	public static final String SUBTASK_COLOR = "Green";

	public static final String PARENTTASK_COLOR = "blue";

	public static final String NEGATIVE_QUERY_COLOR = "#e39a96";

	public static final String APP_ITEM_QUERY_TYPE_LONG_NAME = "Negative";

	public static final int LOG_ERROR_SUPPORT_HOURS = 4;

	public static final String BC_LOG_ERROR = "Support";

	public static final String BC_LOG_FILE_STATUS = "File Status";

	public static final String BC_LOG_SUBSCRIPE = "Subcription";

	public static final String BC_LOG_SUBSCRIPE_DETAIL = "Subcription Detail";

	public static final String EMAIL_TEMPLATE_CODE_FILE_SATUS_ALERT = "application.fils.status.alert.template.code";

	public static final String LOG_ERROR_FILES_NOT_MOVED = "File(s) not send!";

	public static final String LOG_ERROR_FILES_MOVED = "File(s) successfully send!";

	public static final String TOOLTIP_SEND = "Send";

	public static final String TOOLTIP_TASK_INFO = "Task Details";

	public static final String TOTAL_PAGE_COUNT_SIZE = "application.total.page.count.limit.exceed";

	public static final String SER_REQ_APPROVE_STATUS_LIST = "application.production.ser.req.approve.status.list";

	public static final String RESEND_OPTION_FOR_FILE_STATUS = "application.resend.option.enable.for.file.status";

	public static final String APP_RESEND_OPTION_FOR_FILE_STATUS = "resendOptionForFileStatus";

	public static final String FILE_STATUS_NOT_TO_SHOW_COLOR = "application.not.to.show.color.for.csstatus";

	public static final String APP_JWT_HEADER = "Authorization";

	public static final String APP_JWT_SECRET = "my-very-secret-key";

	public static final String APP_JWT_DAYS_VALID_THURU = "15";

	public static final String APP_JWT_USER_LOGGEDIN = "Already user logged in other device";

	public static final String APP_JWT_USER_PASSWORD = "User password is changed";

	public static final String APP_JWT_DAYS_VALID_EXPIRE = "Auto Login expired";

	public static final String APP_JWT_WRONG_USER = "User or Password incorrect";

	public static final String APP_JWT_WRONG_TOKEN = "Token not generated";

	public static final String FILE_DOWNLOAD_ICON = "fileDownloadIcon";

	public static final String CALL_BACK_CASE_PRODUCTION = "Production";

	public static final String DATA_UPDATED_ERROR = "" + "Data not updated!";

	public static final String DATA_DELETED_ERROR_WORKLOG = "Data not deleted!";

	public static final String DATA_DELETED_ERROR = "Case moved to Production";

	public static final String CHECK_ESTIMATED_HOURS = "Data not updated! Check Estimated Hours";

	public static final String PAGE_COUNT_NEGATIVE_STATUS = "application.case.file.page.count.negative.status";

	public static final String APP_PAGE_COUNT_NEGATIVE_STATUS = "pageCountNegativeStatus";

	public static final String BC_PROD_CONFIG = "Production Configuration";

	public static final String BC_PROD_CONFIG_ADD = "Add Configuration";

	public static final String BC_PROD_CONFIG_EDIT = "Edit Configuration";

	public static final String BC_ALLOWEDIP_ADDRESSES = "Allowed IP Addresses";

	public static final String BC_PROD_STATUS_FLOW = "Production Status Flow Ref";

	public static final String BC_PROD_STATUS_FLOW_REF_DETAILS = "Production Status Flow Ref Details";

	public static final String BC_QC_FLOW = "QC Flow";

	public static final String BC_LABEL_DETAILS = "Label Details";

	public static final String BC_LABELS = "Labels";

	public static final String TOOLTIP_OPEN_CASE_PRODUCTION = "Open Production Case";

	public static final String TOOLTIP_ADD_SUB_TASKS = "Add Sub Task";

	public static final String TOOLTIP_OPEN_SUB_TASKS = "Open Sub Tasks";

	// Direct Downloads cookie names

	public static final String COOKIE_DIRECT_DOWNLOAD_ENABLE = "directdwload";

	public static final String COOKIE_CASE_DOWNLOAD_NAME = "casedwload";

	public static final String BC_APP_CONFIG = "App. Config.";

	public static final String BC_APP_CONFIG_IMPORT = "Data Import";

	public static final String BC_APP_MAIL_SEND_CONFIG = "Mail Config.";

	public static final String APP_CONFIG_IMPORT = "Data Import";

	public static final String APP_CONFIG_MAIL_SEND = "Mail Config.";

	public static final String APP_CONFIG_MAIL_SEND_PARTNER = "Partner Mail Config.";

	public static final String APP_CONFIG_MAIL_SEND_ACCOUNT = "Account Mail Config.";

	public static final String APP_CONFIG_MAIL_SEND_CLIENT = "Client Mail Config.";

	public static final String APP_CONFIG_CASE_MAIL = "Case Mail";

	public static final String APP_CONFIG_QUERY_MAIL = "Query Mail";

	public static final String APP_CONFIG_OTHER_MAIL = "Other Mail";

	public static final String APP_CONFIG_WELCOME_MAIL = "Welcome Mail";

	public static final String APP_CONFIG_MAIL_SEND_SYNC = "Mail Config. Sync";

	public static final int APP_CONFIG_PER_SECTION = 25;

	public static final String BC_APP_CONFIG_DATA = "Data Config.";

	public static final String BC_APP_CONFIG_DATA_CONFIGURATION = "Application Data Config.";

	public static final String APP_CONFIG_DATA = "Data Config.";

	public static final String UPLOAD_FILE_CASE_TYPE = "Case Files";

	public static final String UPLOAD_FILE_CASE_ADDTIONAL_TYPE = "Additional Case Files";

	public static final String UPLOAD_FILE_CASE_ADDTIONAL_TYPE_QUICK_LINK = "Additional Case Files QuickLink";

	public static final String UPLOAD_FILE_RESULT_TYPE = "Result Case Files";

	public static final String UPLOAD_FILE_QUERY_TYPE = "Query Files";

	public static final String UPLOAD_FILE_TASK_TYPE = "Task Files";

	public static final String ASSIGNED_SUCCESS = "Cases Assigned Successfully";

	public static final String ASSIGNED_FAIL = "Cases not Assigned";

	public static final String PARTNER_EMAIL_TYPE_EMAIL = "EMAIL";

	public static final String PARTNER_EMAIL_TYPE_TO = "TO";

	public static final String PARTNER_EMAIL_TYPE_CC = "CC";

	public static final String PARTNER_EMAIL_TYPE_BCC = "BCC";

	public static final String PARTNER_EMAIL_TYPE_SUBJECT = "SUBJECT";

	public static final String PARTNER_EMAIL_TYPE_MESSAGE = "MESSAGE";

	public static final String CONTACT_TYPE_ACC_USER = "user";

	public static final String CONTACT_TYPE_NON_ACC_USER = "nonuser";

	public static final String APP_LIST_CASE_TYPE = "Case Types";

	public static final String APP_LIST_CS_STATUS = "Customer Service Status List";

	public static final String APP_LIST_CUS_STATUS = "Customer Status List";

	public static final String LOGIN_IP_ADDRESS = "login_ip_address";

	public static final String CASE_STATUS_DELIVERY = "application.case.status.delivery";

	public static final String BRANCH_ALREADY_EXISTS = "Branch already exists!";

	public static final String CODE_PATTERN_BRANCH = "%s%03d";

	public static final String QUERY_NON_CATEGORY = "Non Category";

	public static final String UPLOAD_FILE_TYPE_ADD_QUERY_ATTACHMENT = "Add Query Attachment";

	public static final String APP_LIST_COMMUNICATION_TYPE = "Query Communication Type";

	public static final String GUEST = "Guest";

	public static final String ROLE_TYPE_CUSTOMER = "Customer";

	public static final String STATUS_ACTIVE = "A";

	public static final String USER_TYPE = "Client";

	public static final String USER_SIGNUP_NEW = "Thank you for registering with our portal. Please login with your credentials.";

	public static final String USERISASSIGNEDTOPRODUCTION = "User is Assigned in Production";

	public static final String USERISNOTASSIGNED = "User is not Assigned";

	public static final String USERISMAPPED = "User is Mapped";

	public static final String USERISNOTMAPPED = "User is not Mapped";

	public static final String USERISASSIGNEDTOCASE = "User is Assigned in Case";
	// 192.168.2.11:53030/parry/portal.git

	public static final String DOWNLOAD_URL_HTTP = "application.download_url_http";

	public static final String DOWNLOAD_URL_HTTPS = "application.download_url_https";

	public static final String SCREEN_NAME_EMAIL_QUEUE = "EmailQueue";

	public static final String SCREEN_NAME_USER = "User";

	public static final String EMPLOYEE = "Employee";

	public static final String CLIENT = "Client";

	public static final String ATTORNEYCODE = "Attorney Code";

	public static final String ACCOUNTNAME = "Account Name";

	public static final String SCREEN_NAME_TEAM = "Team";

	public static final String SCREEN_NAME_DIVISION = "Division";

	public static final String SCREEN_NAME_ARCHIVAL_HISTORY = "Archival History";

	public static final String APP_LOCAL_UPLOAD_FILE_OPEN_PATH = "localDownloadFileOpenPath";

	public static final String CASE_FILE = "CaseFile";

	public static final String CASE_RESULT_FILE = "CaseResultFile";

	public static final String ARCHIVAL_CASE_FILE = "ArchivalCaseFile";

	public static final String ARCHIVAL_QUERY = "Query";

	public static final String ARCHIVAL_TASK = "Task";

	public static final String ARCHIVAL_PROD_FILE = "ProductionFile";

	public static final String QUERY_SENT_TO_CHK_NULL = "application.query.to.address.check.null";

	public static final String PERSONAL_INJURY = "Personal Injury";

	public static final String MEDICAL_MALPRACTICE = "Medical Malpractice";

	public static final String PI_DEMAND_SERVICE = "PI - Demand Service";

	public static final String MASSTORT = "Masstort";

	public static final String SCREEN_NAME_REPORTS = "Reports";

	public static final String STATUS_SUCESS = "Sucess";

	public static final String ARCHIVAL_CASE = "Case";

	public static final String ENTITY = "entity";

	public static final String CLIENT_CASE = "clientCase";

	public static final String NEW_CASE_EMAIL_DETAILS = "application.case.fields.name";

	public static final String USER_IS_ACTIVE = "User Is Active. Can't Change Account Name";

	public static final String FTP_OBJECT_TYPE_PROD_FILES = "ProductionFile";

	public static final String FILE_TYPE = "fileType";

	public static final String FILE_NAME = "fileName";

	public static final String FILE_TRANSFER_INITIATED = "Initiated";

	public static final String FILE_TRANSFER_COMPLETED = "Completed";

	public static final String FILE_PAGE_COUNT_STATUS_APPTRACE = "application.page.count.status.names.apptrace";

	public static final String CASE_TASK_DOWNLOAD_FILE = "CaseTaskDownloadFile";

	public static final String CASE_SUB_TASK_DOWNLOAD_FILE = "CaseSubTaskDownloadFile";

	public static final String TRACE_FTP = "FTP";

	public static final String TRACE_AWS = "AWS";

	public static final String TRACE_NEW = "New";

	public static final String TRACE_SUCCESS = "Success";

	public static final String TRACE_FAILED = "Failed";

	public static final String TRACE_START = "START";

	public static final String TRACE_FILE_SIZE = "File Size MisMatch";

	public static final String TRACE_PROCESS = "Processing";

	public static final String TRACE_PROCESSED = "Processed";

	public static final String TRACE_MAIL = "Mail Process";

	public static final String TRACE_MAILED = "Mail Processed";

	public static final String ACCOUNTS_ACTIVE = "Could not delete Partner because Accounts Under this partner is active.";

	public static final String CLIENTS_ACTIVE = "Could not delete Account because Clients Under this Account is active.";

	public static final String CREATED_DATE = "createdDate";

	public static final String MODIFIED_DATE = "modifiedDate";

	public static final String FROM_DATE = "FromDate";

	public static final String TO_DATE = "ToDate";

	public static final String BC_ACCOUNT_PRIMARY_COMMUNICATION = "Priority Communications";

	public static final String FILE_DELIVERY = "File Delivery";

	public static final String ARCHIVAL_FTP_OBJECT_TYPE_BACKUP_FILE = "archivalBackupFile";

	public static final String ARCHIVAL_FTP_OBJECT_TYPE_REMOVE_FILES = "removeBackupFile";

	public static final String ARCHIVAL_ACTION_TYPE_GET_FILE = "getFiles";

	public static final String ARCHIVAL_ACTION_TYPE_SAVE_FILE = "saveFiles";

	public static final String ARCHIVAL_ACTION_TYPE_RESTORE_FILE = "restoreFiles";

	public static final String ARCHIVAL_FTP_ACTION_ARCHIVE = "ARCHIVE";

	public static final String ARCHIVAL_FTP_ACTION_BACKUP = "BACKUP";

	public static final String ARCHIVAL_FTP_ACTION_REMOVE = "REMOVE";

	public static final String BC_ARCHIVAL_MGMT = "Archival";

	public static final String BC_ARCHIVAL_MGMT_SUB_ARCHIVE = "Archival Records";

	public static final String BC_ARCHIVAL_MGMT_SUB_BACKUP = "Backup Records";

	public static final String BC_ARCHIVAL_MGMT_SUB_REMOVE = "Remove Records";

	public static final String REQUSET_CATEGORY_NEW = "New";

	public static final String REQUSET_CATEGORY_ADD_REC = "Additional Record";

	public static final String BC_ACCOUNT_MAP = "Account Map";

	public static final String FILTER_ANY = "Select Any";

	public static final int SHOW_TOP_FIVE_CASES = 5;

	public static final String BC_USERPROFILE = "Client User Profile";

	public static final String Non_Compliance = "Non-Compliance";

	/*
	 * User Profile Report
	 */

	public static final String TP_USERPROFILE_FILEDS = "customerCode~`~Client Code,accountCode~`~Account Code,account~`~Account Name,accountManager~`~Account Manager,customerRating~`~Customer Rating,firstName~`~Client Name,roles~`~Role,status~`~Status,company~`~Compay Name,email1~`~Email,email~`~Alternate Email,address1~`~Address1,address2~`~Address2,city~`~City,state~`~State,zipCode~`~zipCode,contactName~`~ContactName,contactEmail~`~ContactEmail,jobTitle~`~Title";
	public static final String TP_EXCEL_USERPROFILE_FILEDS = "customerCode~`~Client Code,accountCode~`~Account Code,account~`~Account Name,accountManager~`~Account Manager,customerRating~`~Customer Rating,firstName~`~Client Name,roles~`~Role,status~`~Status,company~`~Compay Name,email1~`~Email,email~`~Alternate Email,address1~`~Address1,address2~`~Address2,city~`~City,state~`~State,zipCode~`~zipCode,contactName~`~ContactName,contactEmail~`~ContactEmail,jobTitle~`~Title";

	/*
	 * User Profile Report
	 */

	public static final String TOOLTIP_CASE_NEW_TAB = "Open Case in New Tab";

	/*
	 * Report Module
	 */
	public static final String REMOTE_URL = "application.reportmodule.logstash.syn.api";
	public static final String REPORT_MODULE = "application.reportmodule.list.admin";
	public static final String REPORT_EMBER_KIBANA_URL = "application.reportmodule.admin.";

	public static final String BC_SYN_LOG = "Syn Process";
	public static final String BC_DASHBOARD_REPORT = "Dashboard Report";
	public static final String TOOLTIP_SYNLOG_DELETE = "Delete Syn Log Details";

	public static final String MESSAGE_SENT = "Message sent successfully";

	public static final String ACCOUNTMANAGERNAME_CASE = "Account Manager";

	public static final String TOOLTIP_PARENTCASE_NEW_TAB = "Open Parent Case in New Tab";

	public static final String CASELIST_ADDCOL_BASED_USER = "jagan.selvam@aalamsoft.com";

	public static final String DATE_TIME_FORMAT12 = "MM/dd/yyyy hh:mm:ss a";

	public static final String EMAIL_QUEUE_TYPE_CLIENT = "Req Add Rec";

	public static final String EMAIL_QUEUE_TYPE_CLIENT_ADD_REC = "Add Rec";

	public static final String ACC_NO_ONE = "No One";

	public static final String NEW_SIGNUP_USER_DETAILS = "application.signup.user.fields";

	public static final String LANGUAGE_ERROR = "Language Error";

	public static final String BC_REPORTING_TOOL = "Reporting Tool";

	public static final String COME_BACK_CUSTOMER = "Come-back Customer";

	public static final String EXISTING_CUSTOMER = "Existing Customer";

	public static final String DIS_CUSTOMER = "Dissatisfied Customer";

	public static final String NEW_CUSTOMER = "New Customer";

	public static final String SPECIAL_CUSTOMER = "Special Customer";

	public static final String DATE_FORMAT_API = "yyyy-MM-dd";

	public static final String BC_CHAT = "Chat";

	public static final String ACCOUNT_MANAGER = "Account Manager";

	public static final String STATUS_BASED_EMAIL_FOR_NEW_CASE_FILE_FOR_INTERNALUSER = "application.email.send.for.new.file.internaluser.template.code";

	public static final String NEW_CASE_EMAIL_DETAILS_FOR_INTERNALUSER = "application.case.internaluser.fields.name";

	public static final int EMAIL_ATTEMPT_COUNT = 1;

	public static final String ASSIGNED_FAIL_TIMER_RUNNING = "Cases not Assigned,Timer is running for this Case";

	public static final String QUERY_COMM_TYPES = "Query Communication Type";

	public static final char IN_ACTIVE_USERS = 'I';

	public static final String CODE_ERROR_STATUS_REPORT = "application.email.template.code.for.errorstatus_email_report";

	public static final String ALREADY_REGISTERED = "You are already registered into the new portal. If this is your first time logging in, please reset your password"; // password

	public static final String ALREADY_ADDED_USER = "Welcome! Please verify your existing details and update below for any changes."; // password

	public static final String ALREADY_ADDED_USER_PASSWORD = "A link has been sent to your email id in order to create your secure password.";

	public static final String ACCOUNT_NOT_MAPPED = "This User Is NotMapped For Account";

	public static final String ACCOUNT_MAPPED = "This User Is  already Mapped For Account";

	public static final String CLIENTMANAGER_MAPPED = "This User is already Mapped as ClientManager";

	public static final String CLIENTMANAGER_NOT_MAPPED = "This User is NotMapped as ClientManager";

	public static final String PRODUCTION_DATA_PARTIAL_NOT_MOVED = "File(s) that are in corrupted are not moved";

	public static final String DASHBOARD_FILE_PATH = "application.dashboard.file.path";

	public static final String QUERY_NEGATIVE = "isNegativeQuery";

	public static final String FIELD_QI = "QI";

	public static final String STATUS_BASED_EMAIL_FOR_QI_QUALITYMANGREMENT = "application.email.send.for.QI.QualityManagement";

	public static final String DATA_NOT_FILLED = "" + "Mandatory Fields are not updated!";
	

	public static final String STATUS_BASED_EMAIL_FOR_NONCOM_QUALITYMANGREMENT = "application.email.send.for.NONCOM.QualityManagement";
	
	
	public static final String FIELD_APPRECIATION = "Appreciation";
	
	public static final String STATUS_BASED_EMAIL_FOR_APPRECIATION_QUALITYMANGREMENT="application.email.send.for.Appreciation.QualityManagement";

	public static final Object ASCENDING = "ascending";

	/**
	 * [Constructor Method]
	 * 
	 * @DateAndTime : Feb 1, 2018 - 2:55:01 PM
	 * 
	 * @Author : Ramya
	 * 
	 * @Description : to initialize the object
	 * 
	 * @Tags :
	 * @Git_Config : name email
	 * 
	 */
	private AppConstants() {
		// private constructor to restrict instance creation.
	}
}
