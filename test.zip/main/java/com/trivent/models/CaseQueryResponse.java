package com.trivent.models;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.constants.AppConstants;
import com.trivent.models.base.BaseCaseQuery;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.entity
 * 
 * @FileName 	:
 *				CaseQueryResponse.java
 * @TypeName 	:
 * 				CaseQueryResponse
 * @DateAndTime :
 *				Feb 8, 2018 - 4:03:46 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description : To create , edit , save and view the CaseQueryResponse details by
 *              fetching each required columns in this entity
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Entity
@Table(name = "case_query_response")
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "case_query_response_id")) })
public class CaseQueryResponse extends BaseCaseQuery {

	private static final long serialVersionUID = -445863170408868970L;

	@Column(name = "query_details", length = 5000)
	private String queryDetails = null;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "case_id", foreignKey = @ForeignKey(name = "fk_case_query_response_1"))
	private Case clientCase = null;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "client_id", foreignKey = @ForeignKey(name = "fk_case_query_response_2"))
	private User client = null;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "account_id", foreignKey = @ForeignKey(name = "fk_case_query_response_3"))
	private Account account = null;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "case_query_id", foreignKey = @ForeignKey(name = "fk_case_query_response_4"))
	private CaseQuery caseQuery = null;

	@Column(name = "query_display", length = 300)
	private String queryDisplay = "";

	@Column(name = "task_id")
	private Long taskId = null;
	
	@Column(name = "is_qi_notify",nullable = false)
	private Character isQiNotify = AppConstants.NO;
	
	@Column(name = "is_appreciation_notify",nullable = false)
	private Character isAppreciationNotify = AppConstants.NO;

	

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		CaseQueryResponse other = (CaseQueryResponse) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public String getQueryDisplay() {
		return queryDisplay;
	}

	public void setQueryDisplay(String queryDisplay) {
		this.queryDisplay = queryDisplay;
	}

	public Case getClientCase() {
		return clientCase;
	}

	public void setClientCase(Case clientCase) {
		this.clientCase = clientCase;
	}

	public String getQueryDetails() {
		return queryDetails;
	}

	public void setQueryDetails(String queryDetails) {
		this.queryDetails = queryDetails;
	}

	public User getClient() {
		return client;
	}

	public void setClient(User client) {
		this.client = client;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public CaseQuery getCaseQuery() {
		return caseQuery;
	}

	public void setCaseQuery(CaseQuery caseQuery) {
		this.caseQuery = caseQuery;
	}

	public Long getTaskId() {
		return taskId;
	}

	public void setTaskId(Long taskId) {
		this.taskId = taskId;
	}
	public Character getIsQiNotify() {
		return isQiNotify;
	}

	public void setIsQiNotify(Character isQiNotify) {
		this.isQiNotify = isQiNotify;
	}
	public Character getIsAppreciationNotify() {
		return isAppreciationNotify;
	}

	public void setIsAppreciationNotify(Character isAppreciationNotify) {
		this.isAppreciationNotify = isAppreciationNotify;
	}
}