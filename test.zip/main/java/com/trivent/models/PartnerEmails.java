package com.trivent.models;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.models.base.BaseSoftDeletable;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.entity
 * 
 * @FileName 	:
 *				PartnerEmails.java
 * @TypeName 	:
 * 				PartnerEmails
 * @DateAndTime :
 *				Feb 8, 2018 - 4:09:41 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description : To create , edit , save and view the PartnerEmails details by
 *              fetching each required columns in this entity
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Entity
@Table(name = "partner_emails")
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "partner_email_id")) })
public class PartnerEmails extends BaseSoftDeletable {

	private static final long serialVersionUID = -8265237199085214444L;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "email_template_id", nullable = false, foreignKey = @ForeignKey(name = "fk_partner_emails_1"))
	private EmailTemplate emailTemplate;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "partner_id", nullable = false, foreignKey = @ForeignKey(name = "fk_partner_emails_2"))
	private Partner partner;

	@Column(name = "email_to_list", length = 2000)
	private String emailToList = null;

	@Column(name = "email_cc_list", length = 2000)
	private String emailCcList = null;

	@Column(name = "email_bcc_list", length = 2000)
	private String emailBccList = null;

	@Column(name = "type", length = 20)
	private String type = null;

	@Column(name = "subject", length = 200)
	private String lsPartnersubject;

	@Column(name = "message", length = 4000)
	private String lsPartnermessage;

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		PartnerEmails other = (PartnerEmails) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public EmailTemplate getEmailTemplate() {
		return emailTemplate;
	}

	public void setEmailTemplate(EmailTemplate emailTemplate) {
		this.emailTemplate = emailTemplate;
	}

	public Partner getPartner() {
		return partner;
	}

	public void setPartner(Partner partner) {
		this.partner = partner;
	}

	public String getEmailToList() {
		return emailToList;
	}

	public void setEmailToList(String emailToList) {
		this.emailToList = emailToList;
	}

	public String getEmailCcList() {
		return emailCcList;
	}

	public void setEmailCcList(String emailCcList) {
		this.emailCcList = emailCcList;
	}

	public String getEmailBccList() {
		return emailBccList;
	}

	public void setEmailBccList(String emailBccList) {
		this.emailBccList = emailBccList;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getLsPartnersubject() {
		return lsPartnersubject;
	}

	public void setLsPartnersubject(String lsPartnersubject) {
		this.lsPartnersubject = lsPartnersubject;
	}

	public String getLsPartnermessage() {
		return lsPartnermessage;
	}

	public void setLsPartnermessage(String lsPartnermessage) {
		this.lsPartnermessage = lsPartnermessage;
	}

}
