package com.trivent.models;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.models.base.BaseEntity;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.entity
 * 
 * @FileName 	:
 *				CaseTask2Service.java
 * @TypeName 	:
 * 				CaseTask2Service
 * @DateAndTime :
 *				Feb 8, 2018 - 4:05:21 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description :To create , edit , save and view the CaseTask2Service details by
 *              fetching each required columns in this entity 
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Entity
@Table(name = "case_task_2_services", uniqueConstraints = @UniqueConstraint(columnNames = { "case_id", "case_task_id",
    "case_service_req_id" }))
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "casetask2service_id")) })
public class CaseTask2Service extends BaseEntity {

  private static final long serialVersionUID = -445863170408868970L;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "case_id", nullable = false, foreignKey = @ForeignKey(name = "fk_casetask2service_1"))
  private Case clientCase = null;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "account_id", nullable = false, foreignKey = @ForeignKey(name = "fk_casetask2service_2"))
  private Account account = null;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "case_task_id", nullable = false, foreignKey = @ForeignKey(name = "fk_casetask2service_3"))
  private CaseTask caseTask = null;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "case_service_req_id", nullable = false, foreignKey = @ForeignKey(name = "fk_casetask2service_4"))
  private CaseServiceReq caseServiceReq = null;

  /********************** hashcode, and equals methods **********************/

  @Override
  public int hashCode() {
    return new HashCodeBuilder().append(this.getId()).hashCode();
  }

  @Override
  public boolean equals(Object obj) {
    if (obj == null || obj.getClass() != getClass()) {
      return false;
    }
    CaseTask2Service other = (CaseTask2Service) obj;
    return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
  }

  /********************** Getters and Setters **********************/

  public Case getClientCase() {
    return clientCase;
  }

  public void setClientCase(Case clientCase) {
    this.clientCase = clientCase;
  }

  public Account getAccount() {
    return account;
  }

  public void setAccount(Account account) {
    this.account = account;
  }

  public CaseTask getCaseTask() {
    return caseTask;
  }

  public void setCaseTask(CaseTask caseTask) {
    this.caseTask = caseTask;
  }

  public CaseServiceReq getCaseServiceReq() {
    return caseServiceReq;
  }

  public void setCaseServiceReq(CaseServiceReq caseServiceReq) {
    this.caseServiceReq = caseServiceReq;
  }

}