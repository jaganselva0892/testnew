package com.trivent.models;

import java.util.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.joda.time.DateTime;

import com.trivent.constants.AppConstants;
import com.trivent.models.base.BaseSoftDeletable;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.entity
 * 
 * @FileName 	:
 *				ArchivalHistory.java
 * @TypeName 	:
 * 				ArchivalHistory
 * @DateAndTime :
 *				Feb 8, 2018 - 4:00:21 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description :   To create , edit , save and view the ArchivalHistory details by
 *              fetching each required columns in this entity
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Entity
@Table(name = "archival_history", uniqueConstraints = @UniqueConstraint(columnNames = { "archival_id" }))
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "archival_id")) })
public class ArchivalHistory extends BaseSoftDeletable {

	private static final long serialVersionUID = 2343515641528628359L;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "case_id", foreignKey = @ForeignKey(name = "fk_archival_history_1"))
	private Case clientCase = null;

	@Column(name = "file_id", length = 10)
	private Long fileId = null;

	@Column(name = "entity_id", length = 10)
	private Long entityId = null;

	@Column(name = "entity", length = 20)
	private String entity = null;

	@Column(name = "file_type", length = 20)
	private String fileType = null;

	@Column(name = "del_status", length = 20)
	private String delStatus = null;

	@Column(name = "delete_date", nullable = false)
	private Date deletedDate;

	@Column(name = "is_archival")
	private Character archived = AppConstants.NO;

	@Column(name = "client_code")
	private String clientCode = null;

	@Column(name = "file_name")
	private String fileName = null;

	@Column(name = "backup_status", length = 20)
	private String backupStatus = null;

	@Column(name = "backup_date")
	private Date backupDate;

	@Column(name = "remove_status", length = 20)
	private String removeStatus = null;

	@Column(name = "remove_date")
	private Date removeDate;

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		ArchivalHistory other = (ArchivalHistory) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/
	public Case getClientCase() {
		return clientCase;
	}

	public void setClientCase(Case clientCase) {
		this.clientCase = clientCase;
	}

	public Long getFileId() {
		return fileId;
	}

	public void setfileId(Long fileId) {
		this.fileId = fileId;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public String getDelStatus() {
		return delStatus;
	}

	public void setDelStatus(String delStatus) {
		this.delStatus = delStatus;
	}

	public DateTime getDeletedDate() {
		return null == deletedDate ? null : new DateTime(deletedDate);
	}

	public void setDeletedDate(DateTime deletedDate) {
		this.deletedDate = null == deletedDate ? null : deletedDate.toDate();
	}

	// public DateTime getDeleteddate() {
	// return null == deletedDate ? null : new DateTime(deletedDate);
	// }
	//
	// public void setDeletedDate(final DateTime deletedDate) {
	// this.deletedDate = null == deletedDate ? null : deletedDate.toDate();
	// }

	public Long getEntityId() {
		return entityId;
	}

	public void setEntityId(Long entityId) {
		this.entityId = entityId;
	}

	public String getEntity() {
		return entity;
	}

	public void setEntity(String entity) {
		this.entity = entity;
	}

	public Character getArchived() {
		return archived;
	}

	public void setArchived(Character archived) {
		this.archived = archived;
	}

	public String getClientCode() {
		return clientCode;
	}

	public void setClientCode(String clientCode) {
		this.clientCode = clientCode;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public void setFileId(Long fileId) {
		this.fileId = fileId;
	}

	public String getBackupStatus() {

		return backupStatus;

	}

	public void setBackupStatus(String backupStatus) {

		this.backupStatus = backupStatus;

	}

	public DateTime getBackupDate() {

		return null == backupDate ? null : new DateTime(backupDate);

	}

	public void setBackupDate(DateTime backupDate) {

		this.backupDate = null == backupDate ? null : backupDate.toDate();

	}

	public String getRemoveStatus() {

		return removeStatus;

	}

	public void setRemoveStatus(String removeStatus) {

		this.removeStatus = removeStatus;

	}

	public DateTime getRemoveDate() {

		return null == removeDate ? null : new DateTime(removeDate);

	}

	public void setRemoveDate(DateTime removeDate) {

		this.removeDate = null == removeDate ? null : removeDate.toDate();

	}

}
