package com.trivent.models;

import java.util.Calendar;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

import com.trivent.constants.AppConstants;
import com.trivent.models.base.BaseContact;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.entity
 * 
 * @FileName 	:
 *				UserProfile.java
 * @TypeName 	:
 * 				UserProfile
 * @DateAndTime :
 *				Feb 8, 2018 - 5:03:24 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description : To create , edit , save and view the User Profile  by
 *              fetching each required columns in this entity
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Entity
@Table(name = "user_profiles")
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "user_profile_id")) })
@GenericGenerator(name = "user-primarykey", strategy = "foreign", parameters = {
		@Parameter(name = "property", value = "user") })
public class UserProfile extends BaseContact /*implements AuditLog*/ {

	

	/**
	 * 
	 */
	private static final long serialVersionUID = -7788650037826912026L;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_id", nullable = false, foreignKey = @ForeignKey(name = "fk_user_profiles_1"))
	private User user;

	@Column(name = "customer_code", length = 30)
	private String customerCode;

	@Column(name = "customer_rating", length = 5)
	private String customerRating;

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "client_manager_id", foreignKey = @ForeignKey(name = "fk_user_profiles_2"))
	private User clientManager;

	@Column(name = "password_reset_request_time")
	private Calendar lastPasswordResetRequest;

	@Column(name = "last_password_chagned_time")
	private Calendar lastPasswordChanged;

	@Column(name = "login_failure_count", nullable = false)
	private Integer loginFailureCount = AppConstants.ZERO;

	@Column(name = "display_welcome_screen", nullable = false)
	private Character displayWelcomeScreen = AppConstants.YES;

	@Column(name = "is_account_manager", nullable = false)
	private Character isAccountManager = AppConstants.NO;

	@Column(name = "is_client_manager", nullable = false)
	private Character isClientManager = AppConstants.NO;

	@Column(name = "ip_restriction", nullable = false)
	private Character ipRestriction = AppConstants.NO;
	
	@Column(name = "timezone_location_id")
	private String timeZoneLocationId;
	
	@Column(name = "timezone_format")
	private String timeZoneFormat;

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		UserProfile other = (UserProfile) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Audit Log methods **********************/

	/*@Override
	public String getAuditLogDetails() {
		StringBuilder sb = new StringBuilder();
		sb.append(getFirstName()).append(" ").append(getLastName()).append(" [").append(getUser().getLoginId())
				.append("]");
		return sb.toString();
	}*/

	/********************** Getters and Setters **********************/

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Calendar getLastPasswordResetRequest() {
		return lastPasswordResetRequest;
	}

	public void setLastPasswordResetRequest(Calendar lastPasswordResetRequest) {
		this.lastPasswordResetRequest = lastPasswordResetRequest;
	}

	public Calendar getLastPasswordChanged() {
		return lastPasswordChanged;
	}

	public void setLastPasswordChanged(Calendar lastPasswordChanged) {
		this.lastPasswordChanged = lastPasswordChanged;
	}

	public Integer getLoginFailureCount() {
		return loginFailureCount;
	}

	public void setLoginFailureCount(Integer loginFailureCount) {
		this.loginFailureCount = loginFailureCount;
	}

	public Character getDisplayWelcomeScreen() {
		return displayWelcomeScreen;
	}

	public void setDisplayWelcomeScreen(Character displayWelcomeScreen) {
		this.displayWelcomeScreen = displayWelcomeScreen;
	}

	public String getCustomerCode() {
		return customerCode;
	}

	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}

	public User getClientManager() {
		return clientManager;
	}

	public void setClientManager(User clientManager) {
		this.clientManager = clientManager;
	}

	public Character getIsAccountManager() {
		return isAccountManager;
	}

	public void setIsAccountManager(Character isAccountManager) {
		this.isAccountManager = isAccountManager;
	}

	public Character getIsClientManager() {
		return isClientManager;
	}

	public void setIsClientManager(Character isClientManager) {
		this.isClientManager = isClientManager;
	}

	public String getCustomerRating() {
		return customerRating;
	}

	public void setCustomerRating(String customerRating) {
		this.customerRating = customerRating;
	}

	public Character getIpRestriction() {
		return ipRestriction;
	}

	public void setIpRestriction(Character ipRestriction) {
		this.ipRestriction = ipRestriction;
	}

	public String getTimeZoneLocationId() {
		return timeZoneLocationId;
	}

	public void setTimeZoneLocationId(String timeZoneLocationId) {
		this.timeZoneLocationId = timeZoneLocationId;
	}

	public String getTimeZoneFormat() {
		return timeZoneFormat;
	}

	public void setTimeZoneFormat(String timeZoneFormat) {
		this.timeZoneFormat = timeZoneFormat;
	}

}
