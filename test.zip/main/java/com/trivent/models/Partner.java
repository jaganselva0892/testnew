package com.trivent.models;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.models.base.BaseContact;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.entity
 * 
 * @FileName 	:
 *				Partner.java
 * @TypeName 	:
 * 				Partner
 * @DateAndTime :
 *				Feb 8, 2018 - 4:09:24 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description : To create , edit , save and view the Partner details by
 *              fetching each required columns in this entity
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Entity
@Table(name = "partners")
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "partner_id")) })
public class Partner extends BaseContact {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7572431988492260689L;

	public static final int NAME_MAX_LENGTH = 150;

	@Column(name = "name", nullable = false, length = 150, unique = true)
	private String name;

	@Column(name = "partner_type", nullable = false, length = 30)
	private String partnerType = Contact.TYPE_INDIVIDUAL;

	@Column(name = "partner_code", nullable = false, length = 4)
	private String partnerCode;

	@Column(name = "video_link", length = 4)
	private String videoLink;

	@Column(name = "invoice_template", nullable = false, length = 10)
	private String invoiceTemplate;
	
	@Column(name = "partner_domain")
	private String partnerDomain;

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		Partner other = (Partner) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPartnerType() {
		return partnerType;
	}

	public void setPartnerType(String partnerType) {
		this.partnerType = partnerType;
	}

	public String getPartnerCode() {
		return partnerCode;
	}

	public void setPartnerCode(String partnerCode) {
		this.partnerCode = partnerCode;
	}

	public String getInvoiceTemplate() {
		return invoiceTemplate;
	}

	public void setInvoiceTemplate(String invoiceTemplate) {
		this.invoiceTemplate = invoiceTemplate;
	}

	public String getVideoLink() {
		return videoLink;
	}

	public void setVideoLink(String videoLink) {
		this.videoLink = videoLink;
	}

	public String getPartnerDomain() {
		return partnerDomain;
	}

	public void setPartnerDomain(String partnerDomain) {
		this.partnerDomain = partnerDomain;
	}
	
}
