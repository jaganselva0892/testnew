package com.trivent.models;

import java.util.Calendar;
import java.util.Set;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.models.base.BaseSoftDeletable;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.entity
 * 
 * @FileName 	:
 *				CaseTask.java
 * @TypeName 	:
 * 				CaseTask
 * @DateAndTime :
 *				Feb 8, 2018 - 4:04:59 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description :  To create , edit , save and view the CaseTask details by
 *              fetching each required columns in this entity
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Entity
@Table(name = "case_tasks", uniqueConstraints = @UniqueConstraint(columnNames = { "case_id", "name" }))
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "case_task_id")) })
public class CaseTask extends BaseSoftDeletable {

	private static final long serialVersionUID = -445863170408868970L;

	public static final String PROPERTY_STATUS = "status";

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "case_id", foreignKey = @ForeignKey(name = "fk_case_task_1"))
	private Case clientCase = null;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "client_id", foreignKey = @ForeignKey(name = "fk_case_task_2"))
	private User client = null;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "account_id", foreignKey = @ForeignKey(name = "fk_case_task_3"))
	private Account account = null;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "assigned_to", foreignKey = @ForeignKey(name = "fk_case_task_4"))
	private User assignedTo = null;

	@Column(name = "name", nullable = false, length = 150)
	private String name = null;

	@Column(name = "description", length = 1000)
	private String description = null;

	@Column(name = "notes", length = 2000)
	private String notes = null;

	@Column(name = "seq_no")
	private Integer seqNo = null;

	@Column(name = "status", length = 80)
	private String status = null;

	@Column(name = "start_date")
	private Calendar startDate = null;

	@Column(name = "completed_date")
	private Calendar completedDate = null;

	@Column(name = "estimate_hours")
	private Integer estimateHours = null;

	@Column(name = "total_hours")
	private Integer totalHours = null;

	@OneToMany(fetch = FetchType.LAZY)
	@JoinColumn(name = "case_task_id")
	private Set<CaseTask2Service> caseTask2Services;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "production_id", foreignKey = @ForeignKey(name = "fk_prod_id_2"))
	private Production productionId = null;

	@Column(name = "parent_task")
	private Long parentTask = null;

	@Column(name = "partner_code")
	private String partnerCode = null;

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		CaseTask other = (CaseTask) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public Case getClientCase() {
		return clientCase;
	}

	public void setClientCase(Case clientCase) {
		this.clientCase = clientCase;
	}

	public User getClient() {
		return client;
	}

	public void setClient(User client) {
		this.client = client;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public User getAssignedTo() {
		return assignedTo;
	}

	public void setAssignedTo(User assignedTo) {
		this.assignedTo = assignedTo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public Integer getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(Integer seqNo) {
		this.seqNo = seqNo;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Calendar getStartDate() {
		return startDate;
	}

	public void setStartDate(Calendar startDate) {
		this.startDate = startDate;
	}

	public Calendar getCompletedDate() {
		return completedDate;
	}

	public void setCompletedDate(Calendar completedDate) {
		this.completedDate = completedDate;
	}

	public Integer getEstimateHours() {
		return estimateHours;
	}

	public void setEstimateHours(Integer estimateHours) {
		this.estimateHours = estimateHours;
	}

	public Integer getTotalHours() {
		return totalHours;
	}

	public void setTotalHours(Integer totalHours) {
		this.totalHours = totalHours;
	}

	public Set<CaseTask2Service> getCaseTask2Services() {
		return caseTask2Services;
	}

	public void setCaseTask2Services(Set<CaseTask2Service> caseTask2Services) {
		this.caseTask2Services = caseTask2Services;
	}

	public Production getProduction() {
		return productionId;
	}

	public void setProduction(Production productionId) {
		this.productionId = productionId;
	}

	public Long getParentTask() {
		return parentTask;
	}

	public void setParentTask(Long parentTask) {
		this.parentTask = parentTask;
	}

	public String getPartnerCode() {
		return partnerCode;
	}

	public void setPartnerCode(String partnerCode) {
		this.partnerCode = partnerCode;
	}

}