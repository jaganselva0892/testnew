package com.trivent.models;

import java.util.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.joda.time.DateTime;

import com.trivent.models.base.BaseSoftDeletable;



@Entity
@Table(name = "user_auth")
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "auth_id")) })
public class UserAuth extends BaseSoftDeletable {
	
	

	/**
	 * 
	 */
	private static final long serialVersionUID = -4796163947527306601L;

	@Column(name = "login_id", length = 80, nullable = false, unique = true)
	private String loginId;

	@Column(name = "token", unique = true)
	private String token = null;

	@Column(name = "otp", unique = true)
	private String otp = null;

	@Column(name = "user_id")
	private Long userId;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "token_valid_thuru")
	private Date tokenValidThuru;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "otp_valid_thuru")
	private Date otpValidThuru;

	public Long getuserId() {
		return userId;
	}

	public void setuserId(Long userId) {
		this.userId = userId;
	}

	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public String gettoken() {
		return token;
	}

	public void settoken(String token) {
		this.token = token;
	}

	public String getOTP() {
		return otp;
	}

	public void setOTP(String otp) {
		this.otp = otp;
	}

	public DateTime gettokenValidThuru() {
		return null == tokenValidThuru ? null : new DateTime(tokenValidThuru);
	}

	public void settokenValidThuru(final DateTime tokenValidThuru) {
		this.tokenValidThuru = null == tokenValidThuru ? null : tokenValidThuru.toDate();
	}

	public DateTime getotpValidThuru() {
		return null == otpValidThuru ? null : new DateTime(otpValidThuru);
	}

	public void setotpValidThuru(final DateTime otpValidThuru) {
		this.otpValidThuru = null == otpValidThuru ? null : otpValidThuru.toDate();
	}
}
