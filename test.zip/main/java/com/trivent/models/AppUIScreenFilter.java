package com.trivent.models;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.models.base.BaseEntity;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.entity
 * 
 * @FileName 	:
 *				AppUIScreenFilter.java
 * @TypeName 	:
 * 				AppUIScreenFilter
 * @DateAndTime :
 *				Feb 8, 2018 - 3:58:41 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description : To create , edit , save and view the AppUIScreenFilter details by
 *              fetching each required columns in this entity 
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Entity
@Table(name = "app_ui_screen_filters")
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "ui_screen_filter_id")) })
public class AppUIScreenFilter extends BaseEntity {

  

  /**
	 * 
	 */
  private static final long serialVersionUID = -647244463116813166L;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "ui_screen_id", nullable = false, foreignKey = @ForeignKey(name = "fk_app_ui_screen_filter_1"))
  private AppUIScreen appUiScreen = null;

  @Column(name = "filter_name", length = 120, nullable = false)
  private String filterName = null;

  @Column(name = "db_table_name", length = 120, nullable = false)
  private String dbTableName = null;

  @Column(name = "db_field_name", length = 120, nullable = false)
  private String dbFieldName = null;

  @Column(name = "filter_datatype", length = 40, nullable = false)
  private String filterDataType = null;

  @Column(name = "filter_seq", nullable = false)
  private Integer filterSeq = null;

  /********************** hashcode, and equals methods **********************/

  @Override
  public int hashCode() {
    return new HashCodeBuilder().append(this.getId()).hashCode();
  }

  @Override
  public boolean equals(Object obj) {
    if (obj == null || obj.getClass() != getClass()) {
      return false;
    }
    AppUIScreenFilter other = (AppUIScreenFilter) obj;
    return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
  }

  /********************** Getters and Setters **********************/

  public AppUIScreen getAppUiScreen() {
    return appUiScreen;
  }

  public void setAppUiScreen(AppUIScreen appUiScreen) {
    this.appUiScreen = appUiScreen;
  }

  public String getFilterName() {
    return filterName;
  }

  public void setFilterName(String filterName) {
    this.filterName = filterName;
  }

  public String getDbTableName() {
    return dbTableName;
  }

  public void setDbTableName(String dbTableName) {
    this.dbTableName = dbTableName;
  }

  public String getDbFieldName() {
    return dbFieldName;
  }

  public void setDbFieldName(String dbFieldName) {
    this.dbFieldName = dbFieldName;
  }

  public String getFilterDataType() {
    return filterDataType;
  }

  public void setFilterDataType(String filterDataType) {
    this.filterDataType = filterDataType;
  }

  public Integer getFilterSeq() {
    return filterSeq;
  }

  public void setFilterSeq(Integer filterSeq) {
    this.filterSeq = filterSeq;
  }

}
