package com.trivent.models;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.models.base.BaseEntity;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.entity
 * 
 * @FileName 	:
 *				EmailTemplate.java
 * @TypeName 	:
 * 				EmailTemplate
 * @DateAndTime :
 *				Feb 8, 2018 - 4:07:26 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description :  To create , edit , save and view the EmailTemplate details by
 *              fetching each required columns in this entity
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Entity
@Table(name = "email_templates")
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "email_template_id")) })
public class EmailTemplate extends BaseEntity {

	

	/**
	 * 
	 */
	private static final long serialVersionUID = -4514421717142087267L;
	/* Standard Names */
	public static final String CODE_FORGOT_PASSWORD = "ET001";
	public static final String CODE_NEW_USER_ACTIVATION = "ET002";
	public static final String CODE_ACKNOWLEDGE = "ET003";
	public static final String CODE_ESTIMATE_APPROVAL = "ET004";
	public static final String CODE_STATUS_PROACTIVE = "ET005";
	public static final String CODE_STATUS_REACTIVE = "ET006";
	public static final String CODE_DELIVERY = "ET007";
	public static final String CODE_ACKNOWLEDGE_ES = "ET003ES";
	public static final String CODE_ACKNOWLEDGE_EX = "ET003EX"; 
	public static final String CODE_ACKNOWLEDGE_EE = "ET003EE";
	

	public static final String CODE_NEW_USER_REGISTRATION = "ET008";
	
	public static final String CODE_ADD_NEW_SERVICE_BY_CUSTOMER="ET009";
	
	public static final String CODE_CASE_SERVICE_CHANGE_NOTIFICATION="ET010";
	
	public static final String CODE_FILE_TRANSFER_TRACE_NOTIFICATION="ET00FT1";
	
	
	
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "partner_id", nullable = false, foreignKey = @ForeignKey(name = "fk_email_templates_1"))
	private Partner partner;

	@Column(name = "name", nullable = false, length = 80, unique = true)
	private String name;

	@Column(name = "code", nullable = false, length = 10, unique = true)
	private String code;

	@Column(name = "subject", length = 200)
	private String subject;

	@Column(name = "message", length = 4000)
	private String message;

	@Column(name = "int_email_to_list", length = 500)
	private String intEmailToList = null;

	@Column(name = "int_email_cc_list", length = 500)
	private String intEmailCcList = null;

	@Column(name = "int_email_bcc_list", length = 500)
	private String intEmailBccList = null;

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		EmailTemplate other = (EmailTemplate) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public Partner getPartner() {
		return partner;
	}

	public void setPartner(Partner partner) {
		this.partner = partner;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getIntEmailToList() {
		return intEmailToList;
	}

	public void setIntEmailToList(String intEmailToList) {
		this.intEmailToList = intEmailToList;
	}

	public String getIntEmailCcList() {
		return intEmailCcList;
	}

	public void setIntEmailCcList(String intEmailCcList) {
		this.intEmailCcList = intEmailCcList;
	}

	public String getIntEmailBccList() {
		return intEmailBccList;
	}

	public void setIntEmailBccList(String intEmailBccList) {
		this.intEmailBccList = intEmailBccList;
	}

}