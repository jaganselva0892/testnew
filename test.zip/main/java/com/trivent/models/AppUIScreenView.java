package com.trivent.models;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.constants.AppConstants;
import com.trivent.models.base.BaseEntity;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.entity
 * 
 * @FileName 	:
 *				AppUIScreenView.java
 * @TypeName 	:
 * 				AppUIScreenView
 * @DateAndTime :
 *				Feb 8, 2018 - 3:59:01 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description :  To create , edit , save and view the AppUIScreenView details by
 *              fetching each required columns in this entity
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Entity
@Table(name = "app_ui_screen_views")
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "ui_screen_view_id")) })
public class AppUIScreenView extends BaseEntity {

  

  /**
	 * 
	 */
 private static final long serialVersionUID = -8306904295624440980L;
 // All Cases
  public static final String VIEW_ALL = "All";
  // Cases Assigned to me
  public static final String VIEW_ASSIGNED = "Assigned";
  // Cases Assigned to my team
  public static final String VIEW_TEAM = "Team";
  // Cases Created by Me
  public static final String VIEW_CREATED = "Created";
  // Cases belongs to the logged in client
  public static final String VIEW_CLIENT = "Client";
  // Cases belongs to the account for which the logged in user is manager
  public static final String VIEW_ACCOUNT_MANAGER = "Account Manager";

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "ui_screen_id", nullable = false, foreignKey = @ForeignKey(name = "fk_app_ui_screen_view_1"))
  private AppUIScreen appUiScreen = null;

  @Column(name = "view_name", length = 60, nullable = false)
  private String viewName = null;

  @Column(name = "view_entity", length = 60, nullable = false)
  private String viewEntity = null;

  @Column(name = "view_type", length = 60, nullable = false)
  private String viewType = null;

  @Column(name = "seq_no", nullable = false)
  private Integer seqNo = null;

  @Column(name = "is_default", nullable = false)
  private Character isDefault = AppConstants.NO;

  @Column(name = "is_visible", nullable = false)
  private Character isVisible = AppConstants.NO;

  /********************** hashcode, and equals methods **********************/

  @Override
  public int hashCode() {
    return new HashCodeBuilder().append(this.getId()).hashCode();
  }

  @Override
  public boolean equals(Object obj) {
    if (obj == null || obj.getClass() != getClass()) {
      return false;
    }
    AppUIScreenView other = (AppUIScreenView) obj;
    return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
  }

  /********************** Getters and Setters **********************/

  public AppUIScreen getAppUiScreen() {
    return appUiScreen;
  }

  public void setAppUiScreen(AppUIScreen appUiScreen) {
    this.appUiScreen = appUiScreen;
  }

  public String getViewName() {
    return viewName;
  }

  public void setViewName(String viewName) {
    this.viewName = viewName;
  }

  public String getViewType() {
    return viewType;
  }

  public void setViewType(String viewType) {
    this.viewType = viewType;
  }

  public Integer getSeqNo() {
    return seqNo;
  }

  public void setSeqNo(Integer seqNo) {
    this.seqNo = seqNo;
  }

  public Character getIsDefault() {
    return isDefault;
  }

  public void setIsDefault(Character isDefault) {
    this.isDefault = isDefault;
  }

  public Character getIsVisible() {
    return isVisible;
  }

  public void setIsVisible(Character isVisible) {
    this.isVisible = isVisible;
  }

  public String getViewEntity() {
    return viewEntity;
  }

  public void setViewEntity(String viewEntity) {
    this.viewEntity = viewEntity;
  }

}
