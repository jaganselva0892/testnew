package com.trivent.models;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.constants.AppConstants;
import com.trivent.models.base.BaseEntity;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.entity
 * 
 * @FileName 	:
 *				AppDBTable.java
 * @TypeName 	:
 * 				AppDBTable
 * @DateAndTime :
 *				Feb 8, 2018 - 3:46:04 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description : To create , edit , save and view the AppDBTable details by
 *              fetching each required columns in this entity 
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Entity
@Table(name = "app_db_tables")
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "app_db_table_id")) })
public class AppDBTable extends BaseEntity {

  

  /**
	 * 
	 */
private static final long serialVersionUID = -1906148773931071771L;

@Column(name = "name", nullable = false, length = 80)
  private String name = null;

  @OneToMany(mappedBy = "dbTable", fetch = FetchType.LAZY)
  @OrderBy("seqNo")
  private List<AppDBTableColumn> appDBTableColumns = null;

  @Column(name = "seqNo", nullable = false)
  private Integer seqNo = null;

  @Column(name = "display_label", nullable = false, length = 80)
  private String displayLabel = null;

  @Column(name = "available_for_app_ui_screens", nullable = false)
  private Character availableForAppUIScreen = AppConstants.NO;

  @Column(name = "available_for_reports", nullable = false)
  private Character availableForReport = AppConstants.NO;

  /********************** Custom methods **********************/

  public Map<Long, String> getAppDBTableColumnsAsMap() {
    if (CollectionUtils.isEmpty(getAppDBTableColumns())) {
      return null;
    }
    Map<Long, String> map = new HashMap<Long, String>(getAppDBTableColumns().size());
    for (AppDBTableColumn appDBTableColumn : getAppDBTableColumns()) {
      map.put(appDBTableColumn.getId(), appDBTableColumn.getName());
    }
    return map;
  }

  public List<String> getAppDBTableColumnNames() {
    List<String> names = new ArrayList<>(getAppDBTableColumns().size());
    for (AppDBTableColumn appDBTableColumn : getAppDBTableColumns()) {
      names.add(appDBTableColumn.getName());
    }
    return names;
  }

  /********************** hashcode, and equals methods **********************/

  @Override
  public int hashCode() {
    return new HashCodeBuilder().append(this.getId()).hashCode();
  }

  @Override
  public boolean equals(Object obj) {
    if (obj == null || obj.getClass() != getClass()) {
      return false;
    }
    AppDBTable other = (AppDBTable) obj;
    return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
  }

  /********************** Getters and Setters **********************/

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public List<AppDBTableColumn> getAppDBTableColumns() {
    return appDBTableColumns;
  }

  public void setAppDBTableColumns(List<AppDBTableColumn> appDBTableColumns) {
    this.appDBTableColumns = appDBTableColumns;
  }

  public Character getAvailableForAppUIScreen() {
    return availableForAppUIScreen;
  }

  public void setAvailableForAppUIScreen(Character availableForAppUIScreen) {
    this.availableForAppUIScreen = availableForAppUIScreen;
  }

  public Character getAvailableForReport() {
    return availableForReport;
  }

  public void setAvailableForReport(Character availableForReport) {
    this.availableForReport = availableForReport;
  }

  public String getDisplayLabel() {
    return displayLabel;
  }

  public void setDisplayLabel(String displayLabel) {
    this.displayLabel = displayLabel;
  }

  public Integer getSeqNo() {
    return seqNo;
  }

  public void setSeqNo(Integer seqNo) {
    this.seqNo = seqNo;
  }

}
