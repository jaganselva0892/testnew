package com.trivent.models;

import java.util.Calendar;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.models.base.BaseSoftDeletable;

/**
 * @ProjectName : trivent
 * @PackageName : com.trivent.entity
 * 
 * @FileName : CaseServiceReq.java
 * @TypeName : CaseServiceReq
 * @DateAndTime : Feb 8, 2018 - 4:04:46 PM
 * 
 * @Author : seetha
 * 
 * @Description : To create , edit , save and view the CaseServiceReq details by
 *              fetching each required columns in this entity
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
@Entity
@Table(name = "case_service_req", uniqueConstraints = @UniqueConstraint(columnNames = { "case_id", "service_name" }))
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "case_service_req_id")) })
public class CaseServiceReq extends BaseSoftDeletable {

	

	/**
	 * 
	 */
	private static final long serialVersionUID = 2078954980811582157L;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "case_id", nullable = false, foreignKey = @ForeignKey(name = "fk_case_service_req_1"))
	private Case clientCase = null;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "client_id", nullable = false, foreignKey = @ForeignKey(name = "fk_case_service_req_2"))
	private User client = null;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "account_id", nullable = false, foreignKey = @ForeignKey(name = "fk_case_service_req_3"))
	private Account account = null;

	@Column(name = "service_name", nullable = false, length = 150)
	private String serviceName = null;

	@Column(name = "service_name_short_code", nullable = false, length = 40)
	private String serviceNameShortCode = null;

	@Column(name = "seq_no", nullable = false)
	private Integer seqNo = null;

	@Column(name = "notes", length = 2000)
	private String notes = null;

	@Column(name = "estimate_hours")
	private Integer estimateHours = 0;

	@Column(name = "production_hours")
	private Integer productionHours = 0;

	@Column(name = "approved_hours")
	private Integer approvedHours = 0;

	@Column(name = "discount_hours")
	private Integer discountHours = 0;

	@Column(name = "indirect_hours")
	private Integer indirectHours = 0;

	@Column(name = "invoice_hours")
	private Integer invoiceHours = 0;

	@Column(name = "deviation_hours")
	private Integer deviationHours = 0;

	@Column(name = "quality_score")
	private Float qualityScore = 0F;

	@Column(name = "approved_date")
	private Calendar approvedDate = null;

	@Column(name = "deliver_date")
	private Calendar deliverDate = null;

	@Column(name = "estimate_date")
	private Calendar estimateDate = null;

	@Column(name = "estimateon_hours")
	private Integer estimateonHours = 0;

	@Column(name = "reestimate_hours")
	private Integer reestimateHours = 0;

	@Column(name = "audit_score")
	private Float auditScore = 0F;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "approve_status", nullable = true, foreignKey = @ForeignKey(name = "fk_case_service_req_appitem"))
	private AppItem approveStatus = null;

	@Column(name = "itemId")
	private Long subItemId;

	@Column(name = "additional_rec_id")
	private Long additionalRecId;

	/********************** hashcode, and equals methods **********************/
	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		CaseServiceReq other = (CaseServiceReq) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public Case getClientCase() {
		return clientCase;
	}

	public void setClientCase(Case clientCase) {
		this.clientCase = clientCase;
	}

	public User getClient() {
		return client;
	}

	public void setClient(User client) {
		this.client = client;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public Integer getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(Integer seqNo) {
		this.seqNo = seqNo;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public Integer getEstimateHours() {
		return estimateHours;
	}

	public void setEstimateHours(Integer estimateHours) {
		this.estimateHours = estimateHours;
	}

	public Integer getProductionHours() {
		return productionHours;
	}

	public void setProductionHours(Integer productionHours) {
		this.productionHours = productionHours;
	}

	public Integer getApprovedHours() {
		return approvedHours;
	}

	public void setApprovedHours(Integer approvedHours) {
		this.approvedHours = approvedHours;
	}

	public Integer getDiscountHours() {
		return discountHours;
	}

	public void setDiscountHours(Integer discountHours) {
		this.discountHours = discountHours;
	}

	public Integer getIndirectHours() {
		return indirectHours;
	}

	public void setIndirectHours(Integer indirectHours) {
		this.indirectHours = indirectHours;
	}

	public Integer getInvoiceHours() {
		return invoiceHours;
	}

	public void setInvoiceHours(Integer invoiceHours) {
		this.invoiceHours = invoiceHours;
	}

	public Integer getDeviationHours() {
		return deviationHours;
	}

	public void setDeviationHours(Integer deviationHours) {
		this.deviationHours = deviationHours;
	}

	public Float getQualityScore() {
		return qualityScore;
	}

	public void setQualityScore(Float qualityScore) {
		this.qualityScore = qualityScore;
	}

	public String getServiceNameShortCode() {
		return serviceNameShortCode;
	}

	public void setServiceNameShortCode(String serviceNameShortCode) {
		this.serviceNameShortCode = serviceNameShortCode;
	}

	public Calendar getApprovedDate() {
		return approvedDate;
	}

	public void setApprovedDate(Calendar approvedDate) {
		this.approvedDate = approvedDate;
	}

	public Calendar getDeliverDate() {
		return deliverDate;
	}

	public void setDeliverDate(Calendar deliverDate) {
		this.deliverDate = deliverDate;
	}

	public Calendar getEstimateDate() {
		return estimateDate;
	}

	public void setEstimateDate(Calendar estimateDate) {
		this.estimateDate = estimateDate;
	}

	public Integer getEstimateonHours() {
		return estimateonHours;
	}

	public void setEstimateonHours(Integer estimateonHours) {
		this.estimateonHours = estimateonHours;
	}

	public Integer getReestimateHours() {
		return reestimateHours;
	}

	public void setReestimateHours(Integer reestimateHours) {
		this.reestimateHours = reestimateHours;
	}

	public AppItem getApproveStatus() {
		return approveStatus;
	}

	public void setApproveStatus(AppItem approveStatus) {
		this.approveStatus = approveStatus;
	}

	public Float getAuditScore() {
		return auditScore;
	}

	public void setAuditScore(Float auditScore) {
		this.auditScore = auditScore;
	}

	public Long getSubItemId() {
		return subItemId;
	}

	public void setSubItemId(Long subItemId) {
		this.subItemId = subItemId;
	}

	public Long getAdditionalRecId() {
		return additionalRecId;
	}

	public void setAdditionalRecId(Long additionalRecId) {
		this.additionalRecId = additionalRecId;
	}
}