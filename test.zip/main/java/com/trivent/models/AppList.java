package com.trivent.models;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.constants.AppConstants;
import com.trivent.models.base.BaseSoftDeletable;

/**
 * @ProjectName : trivent
 * @PackageName : com.trivent.entity
 * 
 * @FileName : AppList.java
 * @TypeName : AppList
 * @DateAndTime : Feb 8, 2018 - 3:51:27 PM
 * 
 * @Author : seetha
 * 
 * @Description : To create , edit , save and view the AppList details by
 *              fetching each required columns in this entity
 * @Tags :
 * @Git_Config : name email
 * 
 */
@Entity
@Table(name = "app_lists")
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "list_id")) })
public class AppList extends BaseSoftDeletable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2438165484058039474L;

	public static final int NAME_MAX_LENGTH = 80;

	public static final String US_STATES = "US States";
	public static final String COUNTRY_LIST = "Country List";
	public static final String YESNO_LIST = "YesNo List";
	public static final String INVOICE_STATUS = "Invoice Status";
	public static final String INVOICE_TERMS = "Invoice Terms";
	public static final String INVOICE_CURRENCY = "Invoice Currency";

	public static final String CASE_SERVICES = "Case Services";
	public static final String CASE_TYPES = "Case Types";
	public static final String CASE_PRIORITY_CS = "Client Service Priority";
	public static final String CASE_PRIORITY_CLIENT = "Client Case Priority";
	public static final String CASE_TASK = "Case Task";

	public static final String QUERY_COMMUNICATION_TYPE = "Query Communication Type";
	public static final String USER_DESIGNATION_TYPE = "Designations";
	public static final String PRODUCTION_STATUS = "Production Status";
	public static final String Non_Compliance = "Non Compliance";
	public static final String CATEGORY = "Category";
	public static final String PROVIDED_BY = "Provided By";
	public static final String PRODUCTION_COMMENTS_TYPE = "Production Comments Type";
	public static final String CASE_TASK_QM = "CaseTaskStatusForQM";
	public static final String QM_CASE_TYPES = "QM Case Types";

	@Column(name = "name", length = 80, nullable = false, unique = true)
	private String name = null;

	@Column(name = "description", length = 150)
	private String description = null;

	@Column(name = "sort_preference", length = 20)
	private String sortPreference = AppConstants.SORT_PREF_ASC;

	@Column(name = "datatype", length = 30)
	private String dataType = AppConstants.DATA_TYPE_TEXT;

	@Column(name = "has_sub_items")
	private Character hasSubItems = AppConstants.NO;

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		AppList other = (AppList) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getSortPreference() {
		return sortPreference;
	}

	public void setSortPreference(String sortPreference) {
		this.sortPreference = sortPreference;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public Character getHasSubItems() {
		return hasSubItems;
	}

	public void setHasSubItems(Character hasSubItems) {
		this.hasSubItems = hasSubItems;
	}

}
