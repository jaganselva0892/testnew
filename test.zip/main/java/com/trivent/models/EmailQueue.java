package com.trivent.models;

import java.util.Map;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.constants.AppConstants;
import com.trivent.models.base.BaseSoftDeletable;
import com.trivent.utils.CommonUtils;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.entity
 * 
 * @FileName 	:
 *				EmailQueue.java
 * @TypeName 	:
 * 				EmailQueue
 * @DateAndTime :
 *				Feb 8, 2018 - 4:07:08 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description : To create , edit , save and view the EmailQueue details by
 *              fetching each required columns in this entity
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Entity
@Table(name = "email_queue")
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "email_queue_id")) })
public class EmailQueue extends BaseSoftDeletable {

	private static final long serialVersionUID = 7962728830672013690L;

	public static final String STATUS_NEW = "New";
	public static final String STATUS_SENT = "Sent";
	public static final String STATUS_ERROR = "Error";
	public static final String STATUS_PERMISSION = "No Permission (Client Mail).";
	public static final String STATUS_RECIPIENT = "Mail Recipient Empty";
	public static final String PROPERTY_STATUS = "status";

	@Column(name = "to_email", length = 2000)
	private String toEmailIds;

	@Column(name = "cc_email", length = 2000)
	private String ccEmailIds;

	@Column(name = "bcc_email", length = 2000)
	private String bccEmailIds;

	@Column(name = "attempt_count")
	private Integer attemptCount;

	@Column(name = "subject", nullable = false)
	private String subject;

	@Column(name = "status", nullable = false, length = 80)
	private String status = STATUS_NEW;

	@Column(name = "error_message", length = 1000)
	private String errorMsg;

	@Column(name = "event", length = 80)
	private String event;

	@Column(name = "body", length = 20000)
	private String body;

	/*
	 * Type:New, Date:01Nov2016, Desc:To new columns added for attachment purpose
	 */

	@Column(name = "email_queue_type", length = 12)
	private String emailQueueType;

	@Column(name = "email_queue_desc", length = 24)
	private String emailQueueDesc;

	@Column(name = "from_email", length = 20000)
	private String fromEmail;

	@Column(name = "type_email", length = 10)
	private String typeEmail = AppConstants.QUERY_TYPE_FROM_EMAIL_GROUP;

	/* Email From has to be mandatory */
	@Column(name = "email_out_bean", length = 2000)
	private String emailOutBean;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "account_id", nullable = false, foreignKey = @ForeignKey(name = "fk_email_queue_1"))
	private Account account;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_id", nullable = false, foreignKey = @ForeignKey(name = "fk_email_queue_2"))
	private User user;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "case_id", foreignKey = @ForeignKey(name = "fk_email_queue_3"))
	private Case appCase;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "invoice_id", foreignKey = @ForeignKey(name = "fk_email_queue_4"))
	private Invoice invoice;

	@Transient
	private Map<String, Object> modelMap;

	public EmailQueue() {
	}

	public EmailQueue(String toEmailIds, String ccEmailIds, String subject, String body) {
		this.setToEmailIds(toEmailIds);
		this.setCcEmailIds(ccEmailIds);
		if (StringUtils.isEmpty(toEmailIds)) {
			this.setToEmailIds(ccEmailIds);
			this.setCcEmailIds("");
		}
		this.setSubject(subject);
		this.setBody(body);
	}

	public void populate(User user, Account account, Case appCase, Map<String, Object> modelMap) {
		this.setUser(user);
		this.setAccount(account);
		this.setAppCase(appCase);
		this.setModelMap(modelMap);
	}

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if ((obj == null) || (obj.getClass() != this.getClass())) {
			return false;
		}
		EmailQueue other = (EmailQueue) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/**********************
	 * Transient Getters and Setters
	 **********************/

	public Map<String, Object> getModelMap() {
		return this.modelMap;
	}

	public void setModelMap(Map<String, Object> modelMap) {
		this.modelMap = modelMap;
	}

	/********************** Getters and Setters **********************/

	public String getEmailOutBeanPrefix() {
		return this.emailOutBean;
	}

	public void setEmailOutBeanPrefix(String emailOutBean) {
		this.emailOutBean = emailOutBean;
	}

	public String getToEmailIds() {
		return this.toEmailIds;
	}

	public void setToEmailIds(String toEmailIds) {
		this.toEmailIds = toEmailIds;
	}

	public String getCcEmailIds() {
		return this.ccEmailIds;
	}

	public void setCcEmailIds(String ccEmailIds) {
		this.ccEmailIds = ccEmailIds;
	}

	public Integer getAttemptCount() {
		return this.attemptCount;
	}

	public void setAttemptCount(Integer attemptCount) {
		this.attemptCount = attemptCount;
	}

	public String getBccEmailIds() {
		return this.bccEmailIds;
	}

	public void setBccEmailIds(String bccEmailIds) {
		this.bccEmailIds = bccEmailIds;
	}

	public String getSubject() {
		return this.subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getErrorMsg() {
		return this.errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getEvent() {
		return this.event;
	}

	public void setEvent(String event) {
		this.event = event;
	}

	public String getBody() {
		return this.body;
	}

	public void setBody(String body) {
		this.body = CommonUtils.uniCodeToString(body);
	}

	public Account getAccount() {
		return this.account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Case getAppCase() {
		return this.appCase;
	}

	public void setAppCase(Case appCase) {
		this.appCase = appCase;
	}

	public Invoice getInvoice() {
		return this.invoice;
	}

	public void setInvoice(Invoice invoice) {
		this.invoice = invoice;
	}

	/*
	 * Type:New, Date:01Nov2016, Desc:File attachments from portal in email
	 */
	public String getEmailQueueType() {
		return this.emailQueueType;
	}

	public void setEmailQueueType(String emailQueueType) {
		this.emailQueueType = emailQueueType;
	}

	public String getEmailQueueDesc() {
		return this.emailQueueDesc;
	}

	public void setEmailQueueDesc(String emailQueueDesc) {
		this.emailQueueDesc = emailQueueDesc;
	}

	/*
	 * Date:21Mar2016, Desc:Altered in email queue table for custom from email id
	 * (which should be same domain as configured smtp)
	 */
	public String getFromEmail() {
		return this.fromEmail;
	}

	public void setFromEmail(String fromEmail) {
		this.fromEmail = fromEmail;
	}

	public String getTypeEmail() {
		return this.typeEmail;
	}

	public void setTypeEmail(String typeEmail) {
		this.typeEmail = typeEmail;
	}
}
