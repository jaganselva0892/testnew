package com.trivent.models;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import com.trivent.models.base.BaseSoftDeletable;

/**
 * @ProjectName : trivent
 * @PackageName : com.trivent.entity
 * 
 * @FileName : CaseFilesChangeHistory.java
 * @TypeName : CaseFilesChangeHistory
 * @DateAndTime : Feb 8, 2018 - 4:02:33 PM
 * 
 * @Author : karthik
 * 
 * @Description : To create , edit , save and view the CaseFilesChangeHistory
 *              details by fetching each required columns in this entity
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
@Entity
@Table(name = "case_files_change_history")
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "case_files_chng_hist_id")) })
public class CaseFilesChangeHistory extends BaseSoftDeletable {

	private static final long serialVersionUID = -3371839081242677844L;

	@Column(name = "case_id", nullable = false)
	private Long caseId;

	@Column(name = "case_file_id", nullable = false, length = 2000)
	private String caseFileId;

	@Column(name = "instruction", nullable = true, length = 20000)
	private String instruction;

	@Column(name = "service_requested")
	private String serviceRequested;

	@Column(name = "additional_rec_code")
	private String additionalRecCode;


	@Column(name = "sub_case_id")
	private Long subCaseId;


	/********************** HashCode, and equals methods **********************/
	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		CaseFilesChangeHistory other = (CaseFilesChangeHistory) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public Long getCaseid() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public String getCasefileid() {
		return caseFileId;
	}

	public void setCaseFileId(String caseFileId) {
		this.caseFileId = caseFileId;
	}

	public String getInstruction() {
		return instruction;
	}

	public void setInstruction(String instruction) {
		this.instruction = instruction;
	}

	public String getServiceRequested() {
		return serviceRequested;
	}

	public void setServiceRequested(String serviceRequested) {
		this.serviceRequested = serviceRequested;
	}

	public String getAdditionalRecCode() {
		return additionalRecCode;
	}

	public void setAdditionalRecCode(String additionalRecCode) {
		this.additionalRecCode = additionalRecCode;
	}


	public Long getSubCaseId() {
		return subCaseId;
	}

	public void setSubCaseId(Long subCaseId) {
		this.subCaseId = subCaseId;
	}

}