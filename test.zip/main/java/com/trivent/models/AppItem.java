package com.trivent.models;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.constants.AppConstants;
import com.trivent.models.base.BaseEntity;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.entity
 * 
 * @FileName 	:
 *				AppItem.java
 * @TypeName 	:
 * 				AppItem
 * @DateAndTime :
 *				Feb 8, 2018 - 3:49:59 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description : To create , edit , save and view the AppItem details by
 *              fetching each required columns in this entity
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Entity
@Table(name = "app_items")
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "item_id")) })
public class AppItem extends BaseEntity {

  

  /**
	 * 
	 */
	private static final long serialVersionUID = -9093362011630913160L;

@ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "list_id", nullable = false, foreignKey = @ForeignKey(name = "fk_app_items_1"))
  private AppList appList;

  @Column(name = "short_name", nullable = false, length = 80)
  private String shortName;

  @Column(name = "long_name", nullable = false, length = 250)
  private String longName;

  @Column(name = "seq_no", nullable = false)
  private Integer seqNo;

  @Column(name = "is_default", nullable = false)
  private Character defaultItem = AppConstants.NO;
  
  @Column(name = "partner")
  private String partner;

  /********************** hashcode, and equals methods **********************/

  @Override
  public int hashCode() {
    return new HashCodeBuilder().append(this.getId()).hashCode();
  }

  @Override
  public boolean equals(Object obj) {
    if (obj == null || obj.getClass() != getClass()) {
      return false;
    }
    AppItem other = (AppItem) obj;
    return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
  }

  /********************** Getters and Setters **********************/

  public boolean isDefault() {
    return defaultItem == AppConstants.YES;
  }

  public AppList getAppList() {
    return appList;
  }

  public void setAppList(AppList appList) {
    this.appList = appList;
  }

  public String getShortName() {
    return shortName;
  }

  public void setShortName(String shortName) {
    this.shortName = shortName;
  }

  public String getLongName() {
    return longName;
  }

  public void setLongName(String longName) {
    this.longName = longName;
  }

  public Integer getSeqNo() {
    return seqNo;
  }

  public void setSeqNo(Integer seqNo) {
    this.seqNo = seqNo;
  }

  public Character getDefaultItem() {
    return defaultItem;
  }

  public void setDefaultItem(Character defaultItem) {
    this.defaultItem = defaultItem;
  }
  
  public String getPartner() {
		return partner;
  }

  public void setPartner(String partner) {
		this.partner = partner;
  }

}
