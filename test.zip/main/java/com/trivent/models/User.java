package com.trivent.models;

import java.util.Calendar;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.ForeignKey;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.models.base.BaseSoftDeletable;

/**
 * @ProjectName : trivent
 * @PackageName : com.trivent.entity
 * 
 * @FileName : User.java
 * @TypeName : User
 * @DateAndTime : Feb 8, 2018 - 5:01:20 PM
 * 
 * @Author : seetha
 * 
 * @Description : To create , edit , save and view the Users by fetching each
 *              required columns in this entity
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
@Entity
@Table(name = "users")
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "user_id")) })
public class User extends BaseSoftDeletable {

	private static final long serialVersionUID = -1356665353204227792L;
	public static final int NAME_MAX_LENGTH = 80;

	public static final char ACTIVE = 'A';
	public static final char INACTIVE = 'I';
	public static final char LOCKED = 'L';
	public static final char CHANGEPASSWORD = 'X';
	public static final char LASTLOGIN = 'N';

	public static final String USER_TYPE_TRIVENT = "Trivent";
	public static final String USER_TYPE_CLIENT = "Client";

	public static final int MAX_LOGIN_FAILURE = 3;

	public static final String PROPERTY_STATUS = "status";

	@Column(name = "login_id", length = 80, nullable = false, unique = true)
	private String loginId;

	@Column(name = "type", length = 20)
	private String type;

	@Column(name = "password", length = 80)
	private String password;

	@Column(name = "status", nullable = false)
	private Character status = ACTIVE;

	@Column(name = "alias_name", length = 40)
	private String aliasName;

	@Column(name = "date_lastlogin")
	private Calendar lastLogin;

	@Column(name = "last_view_page", length = 80)
	private String lastViewedPage;

	@Column(name = "designation_id")
	private Long designationId;

	@Column(name = "client_role", length = 20)
	private String clientRole;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "account_id", nullable = false, foreignKey = @ForeignKey(name = "fk_users_1"))
	private Account account;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "role_id", nullable = false, foreignKey = @ForeignKey(name = "fk_users_2"))
	private Role role;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "team_id", foreignKey = @ForeignKey(name = "fk_users_4"))
	private Team team;

	@OneToOne(mappedBy = "user")
	private UserProfile userProfile;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "last_view_case_id", foreignKey = @ForeignKey(name = "fk_users_3"))
	private Case lastViewedCase;

	
	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		User other = (User) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Character getStatus() {
		return status;
	}

	public void setStatus(Character status) {
		this.status = status;
	}

	public Calendar getLastLogin() {
		return lastLogin;
	}

	public void setLastLogin(Calendar lastLogin) {
		this.lastLogin = lastLogin;
	}

	
	

	public String getAliasName() {
		return this.aliasName;
		// return this.userProfile.getFirstName() + " " +
		// this.userProfile.getLastName();
	}

	public void setAliasName(String aliasName) {
		this.aliasName = aliasName;
	}

	

	

	public String getLastViewedPage() {
		return lastViewedPage;
	}

	public void setLastViewedPage(String lastViewedPage) {
		this.lastViewedPage = lastViewedPage;
	}

	
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Long getDesignationId() {
		return designationId;
	}

	public void setDesignationId(Long designationId) {
		this.designationId = designationId;
	}

	public String getClientRole() {
		return clientRole;
	}

	public void setClientRole(String clientRole) {
		this.clientRole = clientRole;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public Team getTeam() {
		return team;
	}

	public void setTeam(Team team) {
		this.team = team;
	}

	public UserProfile getUserProfile() {
		return userProfile;
	}

	public void setUserProfile(UserProfile userProfile) {
		this.userProfile = userProfile;
	}

	public Case getLastViewedCase() {
		return lastViewedCase;
	}

	public void setLastViewedCase(Case lastViewedCase) {
		this.lastViewedCase = lastViewedCase;
	}
	

}
