package com.trivent.models;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.models.base.BaseEntity;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.entity
 * 
 * @FileName 	:
 *				FileAttachments.java
 * @TypeName 	:
 * 				FileAttachments
 * @DateAndTime :
 *				Feb 8, 2018 - 4:08:00 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description :  To create , edit , save and view the FileAttachments details by
 *              fetching each required columns in this entity
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Entity
@Table(name = "file_attachments")
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "file_attachment_id")) })
public class FileAttachments extends BaseEntity {
	private static final long serialVersionUID = 8723229798136236091L;

	@Column(name = "ref_id")
	private Long refId;

	@Column(name = "file_name", length = 200)
	private String fileName;

	@Column(name = "file_extension", length = 10)
	private String fileExtension;

	@Column(name = "file_directory", length = 2000)
	private String fileDirectory;

	@Column(name = "is_deleted", length = 1)
	private Character isDeleted = 'N';

	@Column(name = "type", length = 10)
	private String type;

	@Column(name = "file_size")
	private Long fileSize;

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		FileAttachments other = (FileAttachments) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/************************** Getters and Setters ***************************/

	public Long getRefId() {
		return refId;
	}

	public void setRefId(Long refId) {
		this.refId = refId;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFileExtension() {
		return fileExtension;
	}

	public void setFileExtension(String fileExtension) {
		this.fileExtension = fileExtension;
	}

	public String getFileDirectory() {
		return fileDirectory;
	}

	public void setFileDirectory(String fileDirectory) {
		this.fileDirectory = fileDirectory;
	}

	public Character getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Character isDeleted) {
		this.isDeleted = isDeleted;
	}

	public String geType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Long getFileSize() {
		return fileSize;
	}

	public void setFileSize(Long fileSize) {
		this.fileSize = fileSize;
	}

}
