package com.trivent.models;

import java.util.List;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.models.base.BaseEntity;

/**
 * @ProjectName : trivent
 * @PackageName : com.trivent.entity
 * 
 * @FileName : Role.java
 * @TypeName : Role
 * @DateAndTime : Feb 8, 2018 - 4:59:18 PM
 * 
 * @Author : seetha
 * 
 * @Description : To create , edit , save and view the Role of each login users
 *              by fetching each required columns in this entity
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
@Entity
@Table(name = "roles")
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "role_id")) })
public class Role extends BaseEntity {

	private static final long serialVersionUID = -206769723617430971L;

	public static final String ROLE_TYPE_ADMIN_ROLES = "Admin";
	public static final String ROLE_TYPE_CUSTOMER = "Customer";
	public static final String ROLE_TYPE_CS_ROLES = "Customer Support";
	public static final String ROLE_TYPE_OTHER_ROLES = "Others";

	public static final String ROLE_SUPER_ADMIN = "Super Admin";
	public static final String ROLE_CUSTOMER = "Customer";

	public static final String ROLE_PRODUCTION_STAFF = "Production Staff";

	@Column(name = "name", nullable = false, length = 40, unique = true)
	private String name;

	@Column(name = "role_type", nullable = false, length = 40)
	private String type;

	@Column(name = "case_cs_status")
	private String CaseCsStatus;

	@OneToMany(mappedBy = "role", fetch = FetchType.LAZY)
	@OrderBy("id")
	private List<Permission> permissions;
	
	public static final String ROLE_MD_LEAD = "MD Lead";

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		Role other = (Role) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public List<Permission> getPermissions() {
		return permissions;
	}

	public void setPermissions(List<Permission> permissions) {
		this.permissions = permissions;
	}

	public String getCaseCsStatus() {
		return CaseCsStatus;
	}

	public void setCaseCsStatus(String caseCsStatus) {
		CaseCsStatus = caseCsStatus;
	}

}
