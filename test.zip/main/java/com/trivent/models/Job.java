package com.trivent.models;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.models.base.BaseSoftDeletable;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.entity
 * 
 * @FileName 	:
 *				Job.java
 * @TypeName 	:
 * 				Job
 * @DateAndTime :
 *				Feb 8, 2018 - 4:08:48 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description :  To create , edit , save and view the jobsdetails by
 *              fetching each required columns in this entity
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Entity
@Table(name = "jobs", uniqueConstraints = @UniqueConstraint(columnNames = { "client_id", "name" }))
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "job_id")) })
public class Job extends BaseSoftDeletable {

  
  /**
	 * 
	 */
 private static final long serialVersionUID = 1430214119458785078L;

 public static final int NAME_MAX_LENGTH = 80;

  @Column(name = "name", nullable = false, length = 80)
  private String name = null;

  @Column(name = "description", length = 150)
  private String description = null;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "client_id", foreignKey = @ForeignKey(name = "fk_jobs_1"))
  private User client = null;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "account_id", foreignKey = @ForeignKey(name = "fk_jobs_2"))
  private Account account = null;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "partner_id", foreignKey = @ForeignKey(name = "fk_jobs_3"))
  private Partner partner = null;

  /********************** hashcode, and equals methods **********************/

  @Override
  public int hashCode() {
    return new HashCodeBuilder().append(this.getId()).hashCode();
  }

  @Override
  public boolean equals(Object obj) {
    if (obj == null || obj.getClass() != getClass()) {
      return false;
    }
    Job other = (Job) obj;
    return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
  }

  /********************** Getters and Setters **********************/

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public User getClient() {
    return client;
  }

  public void setClient(User client) {
    this.client = client;
  }

  public Account getAccount() {
    return account;
  }

  public void setAccount(Account account) {
    this.account = account;
  }

  public Partner getPartner() {
    return partner;
  }

  public void setPartner(Partner partner) {
    this.partner = partner;
  }

}
