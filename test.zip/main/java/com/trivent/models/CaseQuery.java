package com.trivent.models;

import java.io.Serializable;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.constants.AppConstants;
import com.trivent.models.base.BaseCaseQuery;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.entity
 * 
 * @FileName 	:
 *				CaseQuery.java
 * @TypeName 	:
 * 				CaseQuery
 * @DateAndTime :
 *				Feb 8, 2018 - 4:03:11 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description : To create , edit , save and view the CaseQuery details by
 *              fetching each required columns in this entity
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Entity
@Table(name = "case_query")
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "case_query_id")) })
public class CaseQuery extends BaseCaseQuery implements Serializable{

	private static final long serialVersionUID = -445863170408868970L;
	public static final String QUERY_SUBJECT = "querySubject";

	@Column(name = "query_subject", length = 150)
	private String querySubject = null;

	@Column(name = "status", length = 40)
	private String status = AppConstants.STATUS_OPEN;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "case_id", foreignKey = @ForeignKey(name = "fk_case_query_1"))
	private Case clientCase = null;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "client_id", foreignKey = @ForeignKey(name = "fk_case_query_2"))
	private User client = null;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "account_id", foreignKey = @ForeignKey(name = "fk_case_query_3"))
	private Account account = null;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "assigned_to", foreignKey = @ForeignKey(name = "fk_case_query_4"))
	private User assignedTo = null;

	@Column(name = "is_query_open", nullable = false)
	private Character isQueryOpen = AppConstants.NO;
	
	@Column(name = "query_partner_bean", length = 10)
	private String queryPartnerBean = null;
	
	@Column(name = "query_type")
	private String query_type = null;
	
	@Column(name = "query_sub_type")
	private String querySubtype = null;
	
	

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		CaseQuery other = (CaseQuery) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public Case getClientCase() {
		return clientCase;
	}

	public void setClientCase(Case clientCase) {
		this.clientCase = clientCase;
	}

	public String getQuerySubject() {
		return querySubject;
	}

	public void setQuerySubject(String querySubject) {
		this.querySubject = querySubject;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public User getClient() {
		return client;
	}

	public void setClient(User client) {
		this.client = client;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public User getAssignedTo() {
		return assignedTo;
	}

	public void setAssignedTo(User assignedTo) {
		this.assignedTo = assignedTo;
	}

	public Character getIsQueryOpen() {
		return isQueryOpen;
	}

	public void setIsQueryOpen(Character isQueryOpen) {
		this.isQueryOpen = isQueryOpen;
	}
	
	public String getQueryPartnerBean() {
		return queryPartnerBean;
	}

	public void setQueryPartnerBean(String queryPartnerBean) {
		this.queryPartnerBean = queryPartnerBean;
	}
	
	public String getQueryType() {
		return query_type;
	}

	public void setQueryType(String query_type) {
		this.query_type = query_type;
	}
	
	public String getQuerySubType() {
		return querySubtype;
	}

	public void setQuerySubType(String querySubtype) {
		this.querySubtype = querySubtype;
	}
}