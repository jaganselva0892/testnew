package com.trivent.models;

import java.util.Calendar;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.models.base.BaseEntity;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.entity
 * 
 * @FileName 	:
 *				InvoiceItem.java
 * @TypeName 	:
 * 				InvoiceItem
 * @DateAndTime :
 *				Feb 8, 2018 - 4:08:30 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description :  To create , edit , save and view the Invoice Items details by
 *              fetching each required columns in this entity
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Entity
@Table(name = "invoice_items")
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "invoice_item_id")) })
public class InvoiceItem extends BaseEntity {

  private static final long serialVersionUID = 4736889811341325732L;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "client_id", foreignKey = @ForeignKey(name = "fk_invoice_items_1"))
  private User client;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "account_id", foreignKey = @ForeignKey(name = "fk_invoice_items_2"))
  private Account account;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "invoice_id", foreignKey = @ForeignKey(name = "fk_invoice_items_3"))
  private Invoice invoice;

  @Column(name = "item_seq_no", nullable = false)
  private Integer seqNo;

  @Column(name = "item_name", length = 30, nullable = false)
  private String name;

  @Column(name = "description", length = 1000)
  private String description;

  @Column(name = "service_date")
  private Calendar serviceDate;

  @Column(name = "ref_ids", length = 255)
  private String refIds;

  @Column(name = "item_hours")
  private Integer hours = 0;

  @Column(name = "item_rate", scale = 10, precision = 2)
  private Float rate;

  @Column(name = "item_amount", scale = 10, precision = 2)
  private Float amount;

  /********************** hashcode, and equals methods **********************/

  @Override
  public int hashCode() {
    return new HashCodeBuilder().append(this.getId()).hashCode();
  }

  @Override
  public boolean equals(Object obj) {
    if (obj == null || obj.getClass() != getClass()) {
      return false;
    }
    InvoiceItem other = (InvoiceItem) obj;
    return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
  }

  /********************** Getters and Setters **********************/

  public User getClient() {
    return client;
  }

  public void setClient(User client) {
    this.client = client;
  }

  public Account getAccount() {
    return account;
  }

  public void setAccount(Account account) {
    this.account = account;
  }

  public Invoice getInvoice() {
    return invoice;
  }

  public void setInvoice(Invoice invoice) {
    this.invoice = invoice;
  }

  public Integer getSeqNo() {
    return seqNo;
  }

  public void setSeqNo(Integer seqNo) {
    this.seqNo = seqNo;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public Calendar getServiceDate() {
    return serviceDate;
  }

  public void setServiceDate(Calendar serviceDate) {
    this.serviceDate = serviceDate;
  }

  public String getRefIds() {
    return refIds;
  }

  public void setRefIds(String refIds) {
    this.refIds = refIds;
  }

  public Integer getHours() {
    return hours;
  }

  public void setHours(Integer hours) {
    this.hours = hours;
  }

  public Float getRate() {
    return rate;
  }

  public void setRate(Float rate) {
    this.rate = rate;
  }

  public Float getAmount() {
    return amount;
  }

  public void setAmount(Float amount) {
    this.amount = amount;
  }

}
