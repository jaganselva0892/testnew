package com.trivent.models;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.constants.AppConstants;
import com.trivent.models.base.BaseSoftDeletable;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.entity
 * 
 * @FileName 	:
 *				StatusFlowRef.java
 * @TypeName 	:
 * 				StatusFlowRef
 * @DateAndTime :
 *				Feb 8, 2018 - 5:00:08 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description :To create , edit , save and view the Status Flow Reference  by
 *              fetching each required columns in this entity 
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Entity
@Table(name = "status_flow_ref", uniqueConstraints = @UniqueConstraint(columnNames = { "object_type", "cs_status" }))
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "status_flow_ref_id")) })
public class StatusFlowRef extends BaseSoftDeletable {

  
  /**
	 * 
	 */
  private static final long serialVersionUID = 6449377280976024959L;

  public static final int STATUS_MAX_LENGTH = 80;

  public static final String OBJ_TYPE_CASE = "Case";
  public static final String OBJ_TYPE_TASK = "Task";

  public static final String CS_STATUS_FILE_DELIVERY = "File Delivery";

  @Column(name = "customer_status", nullable = false, length = 80)
  private String customerStatus = null;

  @Column(name = "cs_status", nullable = false, length = 80, unique = true)
  private String customerSupportStatus = null;

  @Column(name = "seq_no", nullable = false)
  private Integer seqNo = null;

  @Column(name = "is_client_alertable", nullable = false)
  private Character isClientAlertable = AppConstants.NO;

  @Column(name = "is_internal_alertable", nullable = false)
  private Character isInternalAlertable = AppConstants.NO;

  @Column(name = "object_type", nullable = false, length = 80)
  private String objectType = null;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "external_email_template_id", foreignKey = @ForeignKey(name = "fk_status_flow_ref_1"))
  private EmailTemplate extEmailTemplate = null;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "internal_email_template_id", foreignKey = @ForeignKey(name = "fk_status_flow_ref_2"))
  private EmailTemplate intEmailTemplate = null;

  @Column(name = "ext_email_cc_list", length = 1000)
  private String extEmailCcList = null;

  @Column(name = "int_email_cc_list", length = 1000)
  private String intEmailCcList = null;

  /********************** hashcode, and equals methods **********************/

  @Override
  public int hashCode() {
    return new HashCodeBuilder().append(this.getId()).hashCode();
  }

  @Override
  public boolean equals(Object obj) {
    if (obj == null || obj.getClass() != getClass()) {
      return false;
    }
    StatusFlowRef other = (StatusFlowRef) obj;
    return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
  }

  /********************** Getters and Setters **********************/

  public String getCustomerStatus() {
    return customerStatus;
  }

  public void setCustomerStatus(String customerStatus) {
    this.customerStatus = customerStatus;
  }

  public Integer getSeqNo() {
    return seqNo;
  }

  public void setSeqNo(Integer seqNo) {
    this.seqNo = seqNo;
  }

  public String getCustomerSupportStatus() {
    return customerSupportStatus;
  }

  public void setCustomerSupportStatus(String customerSupportStatus) {
    this.customerSupportStatus = customerSupportStatus;
  }

  public Character getIsClientAlertable() {
    return isClientAlertable;
  }

  public void setIsClientAlertable(Character isClientAlertable) {
    this.isClientAlertable = isClientAlertable;
  }

  public Character getIsInternalAlertable() {
    return isInternalAlertable;
  }

  public void setIsInternalAlertable(Character isInternalAlertable) {
    this.isInternalAlertable = isInternalAlertable;
  }

  public String getObjectType() {
    return objectType;
  }

  public void setObjectType(String objectType) {
    this.objectType = objectType;
  }

  public EmailTemplate getExtEmailTemplate() {
    return extEmailTemplate;
  }

  public void setExtEmailTemplate(EmailTemplate extEmailTemplate) {
    this.extEmailTemplate = extEmailTemplate;
  }

  public EmailTemplate getIntEmailTemplate() {
    return intEmailTemplate;
  }

  public void setIntEmailTemplate(EmailTemplate intEmailTemplate) {
    this.intEmailTemplate = intEmailTemplate;
  }

  public String getExtEmailCcList() {
    return extEmailCcList;
  }

  public void setExtEmailCcList(String extEmailCcList) {
    this.extEmailCcList = extEmailCcList;
  }

  public String getIntEmailCcList() {
    return intEmailCcList;
  }

  public void setIntEmailCcList(String intEmailCcList) {
    this.intEmailCcList = intEmailCcList;
  }

}