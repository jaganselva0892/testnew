package com.trivent.models;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.constants.AppConstants;
import com.trivent.models.base.BaseSoftDeletable;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.entity
 * 
 * @FileName 	:
 *				AppConfig.java
 * @TypeName 	:
 * 				AppConfig
 * @DateAndTime :
 *				Feb 8, 2018 - 3:45:05 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description : To create , edit , save and view the AppConfig details by
 *              fetching each required columns in this entity
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Entity
@Table(name = "app_config")
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "app_config_id")) })
public class AppConfig extends BaseSoftDeletable /*implements AuditLog */{

	

	/**
	 * 
	 */
	private static final long serialVersionUID = -7634437717070734674L;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ref_appconfig_id", foreignKey = @ForeignKey(name = "fk_app_config_id"))
	private AppConfig appRefConfig;

	@Column(name = "name", nullable = false, length = 100)
	private String name;

	@Column(name = "is_menu")
	private Character menu = AppConstants.NO;

	@Column(name = "link_url")
	private String linkUrl;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "capability_id", foreignKey = @ForeignKey(name = "fk_caability_id"))
	private Capability capability;

	@Column(name = "screen")
	private String screen = null;

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		AppConfig other = (AppConfig) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/*@Override
	public String getAuditLogDetails() {
		return "Id : " + this.getId().toString() + ", Name : " + this.getLastModifiedBy();
	}*/

	/********************** Getters and Setters **********************/

	public AppConfig getAppRefConfig() {
		return appRefConfig;
	}

	public void setAppRefConfig(AppConfig appRefConfig) {
		this.appRefConfig = appRefConfig;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isMenu() {
		return menu == AppConstants.YES;
	}

	public void setMenu(Character menu) {
		this.menu = menu;
	}

	public String getLinkUrl() {
		return linkUrl;
	}

	public void setLinkUrl(String linkUrl) {
		this.linkUrl = linkUrl;
	}

	public Capability getCapability() {
		return capability;
	}

	public void setCapability(Capability capability) {
		this.capability = capability;
	}

	public String getScreen() {
		return screen;
	}

	public void setScreen(String screen) {
		this.screen = screen;
	}

}
