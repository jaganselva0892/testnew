package com.trivent.models;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.constants.AppConstants;
import com.trivent.models.base.BaseEntity;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.entity
 * 
 * @FileName 	:
 *				AppSubItem.java
 * @TypeName 	:
 * 				AppSubItem
 * @DateAndTime :
 *				Feb 8, 2018 - 3:56:59 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description : To create , edit , save and view the AppSubItem  details by
 *              fetching each required columns in this entity
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Entity
@Table(name = "app_sub_items")
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "sub_item_id")) })
public class AppSubItem extends BaseEntity {

	

	/**
	 * 
	 */
	private static final long serialVersionUID = -1627597608953065346L;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "list_id", nullable = false, foreignKey = @ForeignKey(name = "fk_app_sub_items_1"))
	private AppList appList;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "item_id", nullable = false, foreignKey = @ForeignKey(name = "fk_app_sub_items_2"))
	private AppItem appItem;

	@Column(name = "short_name", nullable = false, length = 80)
	private String shortName;

	@Column(name = "long_name", nullable = false, length = 250)
	private String longName;

	@Column(name = "seq_no", nullable = false)
	private Integer seqNo;

	@Column(name = "is_default", nullable = false)
	private Character defaultItem = AppConstants.NO;
	// Added on 12/07/2016 for services tooltips/url
	@Column(name = "tool_tip", nullable = false)
	private String toolTip = null;

	@Column(name = "service_link", nullable = true)
	private String serviceLink = null;

	@Column(name = "partner")
	private String partner;
	  
	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		AppSubItem other = (AppSubItem) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public boolean isDefault() {
		return defaultItem == AppConstants.YES;
	}

	public AppList getAppList() {
		return appList;
	}

	public void setAppList(AppList appList) {
		this.appList = appList;
	}

	public String getShortName() {
		return shortName;
	}

	public void setShortName(String shortName) {
		this.shortName = shortName;
	}

	public String getLongName() {
		return longName;
	}

	public void setLongName(String longName) {
		this.longName = longName;
	}

	public Integer getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(Integer seqNo) {
		this.seqNo = seqNo;
	}

	public Character getDefaultItem() {
		return defaultItem;
	}

	public void setDefaultItem(Character defaultItem) {
		this.defaultItem = defaultItem;
	}

	public AppItem getAppItem() {
		return appItem;
	}

	public void setAppItem(AppItem appItem) {
		this.appItem = appItem;
	}

	// Added on 12/07/2016 for services tooltips/url get/set
	public String getToolTip() {
		return toolTip;
	}

	public void setToolTip(String toolTip) {
		this.toolTip = toolTip;
	}

	public String getServiceLink() {
		return serviceLink;
	}

	public void setServiceLink(String serviceLink) {
		this.serviceLink = serviceLink;
	}

	public String getPartner() {
		return partner;
	}

	public void setPartner(String partner) {
		this.partner = partner;
	}
	
	
}
