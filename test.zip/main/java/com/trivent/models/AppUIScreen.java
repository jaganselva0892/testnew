package com.trivent.models;

import java.util.List;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.models.base.BaseSoftDeletable;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.entity
 * 
 * @FileName 	:
 *				AppUIScreen.java
 * @TypeName 	:
 * 				AppUIScreen
 * @DateAndTime :
 *				Feb 8, 2018 - 3:57:21 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description : To create , edit , save and view the AppUIScreen  details by
 *              fetching each required columns in this entity
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Entity
@Table(name = "app_ui_screens", uniqueConstraints = @UniqueConstraint(columnNames = { "screen_name", "screen_type",
		"role_id" }))
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "ui_screen_id")) })
public class AppUIScreen extends BaseSoftDeletable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 256970555363871713L;

	public static final int NAME_MAX_LENGTH = 120;

	@Column(name = "screen_name", length = 120)
	private String screenName = null;

	@Column(name = "screen_type", length = 80, nullable = false)
	private String screenType = null;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "role_id", nullable = false, foreignKey = @ForeignKey(name = "fk_app_ui_screen_1"))
	private Role role = null;

	@OneToMany(mappedBy = "appUiScreen", fetch = FetchType.LAZY)
	@OrderBy("attributeUIColumn, attributeSeq")
	private List<AppUIScreenField> appUIScreenFields;

	@OneToMany(mappedBy = "appUiScreen", fetch = FetchType.LAZY)
	@OrderBy("filterSeq")
	private List<AppUIScreenFilter> appUIScreenFilters;

	@OneToMany(mappedBy = "appUiScreen", fetch = FetchType.LAZY)
	@OrderBy("seqNo")
	private List<AppUIScreenView> appUIScreenViews;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "screen_name_id", foreignKey = @ForeignKey(name = "fk_app_ui_screen_2"))
	private AppDBTable appDbScreenName = null;

	
	@Column(name = "partner")
	private String partner;
	
	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		AppUIScreen other = (AppUIScreen) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public String getScreenName() {
		return screenName;
	}

	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}

	public String getScreenType() {
		return screenType;
	}

	public void setScreenType(String screenType) {
		this.screenType = screenType;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public List<AppUIScreenField> getAppUIScreenFields() {
		return appUIScreenFields;
	}

	public void setAppUIScreenFields(List<AppUIScreenField> appUIScreenFields) {
		this.appUIScreenFields = appUIScreenFields;
	}

	public List<AppUIScreenFilter> getAppUIScreenFilters() {
		return appUIScreenFilters;
	}

	public void setAppUIScreenFilters(List<AppUIScreenFilter> appUIScreenFilters) {
		this.appUIScreenFilters = appUIScreenFilters;
	}

	public List<AppUIScreenView> getAppUIScreenViews() {
		return appUIScreenViews;
	}

	public void setAppUIScreenViews(List<AppUIScreenView> appUIScreenViews) {
		this.appUIScreenViews = appUIScreenViews;
	}

	public AppDBTable getAppDbScreenName() {
		return appDbScreenName;
	}

	public void setAppDbScreenName(AppDBTable appDbScreenName) {
		this.appDbScreenName = appDbScreenName;
	}

	public String getPartner() {
		return partner;
	}

	public void setPartner(String partner) {
		this.partner = partner;
	}
	
	
}
