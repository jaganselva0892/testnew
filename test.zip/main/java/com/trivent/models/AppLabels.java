package com.trivent.models;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.models.base.BaseSoftDeletable;

@Entity
@Table(name="app_labels")
@AttributeOverrides({@AttributeOverride(name="id", column=@Column(name="app_label_id"))})
public class AppLabels extends BaseSoftDeletable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -395632916617410506L;
	
	@Column(name="title",nullable=false)
	private String title;
	
	@Column(name="description", nullable=false)
	private String description;
	
	@Column(name="color", nullable=false)
	private String color;
	
	/********************** hashcode, and equals methods **********************/

	  @Override
	  public int hashCode() {
	    return new HashCodeBuilder().append(this.getId()).hashCode();
	  }

	  @Override
	  public boolean equals(Object obj) {
	    if (obj == null || obj.getClass() != getClass()) {
	      return false;
	    }
	    AppLabels other = (AppLabels) obj;
	    return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	  }
	  
	  /********************** Getters and Setters **********************/
	  
	  public String getTitle(){
		  return title;
	  }
	  
	  public void setTitle(String title){
		  this.title=title;
	  }
	  
	  public String getDescription(){
		  return description;
	  }
	  
	  public void setDescription(String description){
		  this.description=description;
	  }
	  
	  public String getColor(){
		  return color;
	  }
	  
	  public void setColor(String color){
		  this.color=color;
	  }
}
