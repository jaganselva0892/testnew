package com.trivent.models;

import java.util.Calendar;
import java.util.List;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.models.base.BaseSoftDeletable;

/**
 * @ProjectName : trivent
 * @PackageName : com.trivent.entity
 * 
 * @FileName : Invoice.java
 * @TypeName : Invoice
 * @DateAndTime : Feb 8, 2018 - 4:08:16 PM
 * 
 * @Author : seetha
 * 
 * @Description : To create , edit , save and view the Invoice details by
 *              fetching each required columns in this entity
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
@Entity
@Table(name = "invoices")
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "invoice_id")) })
public class Invoice extends BaseSoftDeletable {

	private static final long serialVersionUID = -8510039786351838283L;

	public static final int DEFAULT_DUE_DATE = 10;
	public static final int MAX_END_DUE_DATE = 45;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "client_id", foreignKey = @ForeignKey(name = "fk_invoices_1"))
	private User client;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "account_id", foreignKey = @ForeignKey(name = "fk_invoices_2"))
	private Account account;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "job_id", foreignKey = @ForeignKey(name = "fk_invoices_3"))
	private Job job;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "billto_contact_id", foreignKey = @ForeignKey(name = "fk_invoices_4"))
	private Contact billToContact;

	@Column(name = "invoice_number", length = 20, nullable = false, unique = true)
	private String invoiceNumber;

	@Column(name = "description", length = 1000)
	private String description;

	@Column(name = "notes", length = 2000)
	private String notes;

	@Column(name = "invoice_status", length = 80, nullable = false)
	private String status;

	@Column(name = "invoice_term", length = 80, nullable = false)
	private String term;

	@Column(name = "invoice_date")
	private Calendar date;

	@Column(name = "invoice_due_date")
	private Calendar dueDate;

	@Column(name = "po_number", length = 20)
	private String poNumber;

	@Column(name = "so_number", length = 20)
	private String soNumber;

	@Column(name = "invoice_rep", length = 120)
	private String invoiceRep;

	@Column(name = "currency", length = 4, nullable = false)
	private String currency;

	@Column(name = "invoice_amount", scale = 10, precision = 2)
	private Float invoiceAmount = 0F;

	@Column(name = "payment_made", scale = 10, precision = 2)
	private Float paymentMadeAmount = 0F;

	@Column(name = "credit_available", scale = 10, precision = 2)
	private Float creditAvailableAmount = 0F;

	@Column(name = "due_amount", scale = 10, precision = 2)
	private Float dueAmount = 0F;

	@OneToMany(mappedBy = "invoice", fetch = FetchType.LAZY)
	@OrderBy("seqNo")
	private List<InvoiceItem> invoiceItems = null;

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		Invoice other = (Invoice) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public User getClient() {
		return client;
	}

	public void setClient(User client) {
		this.client = client;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public Job getJob() {
		return job;
	}

	public void setJob(Job job) {
		this.job = job;
	}

	public Contact getBillToContact() {
		return billToContact;
	}

	public void setBillToContact(Contact billToContact) {
		this.billToContact = billToContact;
	}

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTerm() {
		return term;
	}

	public void setTerm(String term) {
		this.term = term;
	}

	public Calendar getDate() {
		return date;
	}

	public void setDate(Calendar date) {
		this.date = date;
	}

	public Calendar getDueDate() {
		return dueDate;
	}

	public void setDueDate(Calendar dueDate) {
		this.dueDate = dueDate;
	}

	public String getPoNumber() {
		return poNumber;
	}

	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}

	public String getSoNumber() {
		return soNumber;
	}

	public void setSoNumber(String soNumber) {
		this.soNumber = soNumber;
	}

	public String getInvoiceRep() {
		return invoiceRep;
	}

	public void setInvoiceRep(String invoiceRep) {
		this.invoiceRep = invoiceRep;
	}

	public List<InvoiceItem> getInvoiceItems() {
		return invoiceItems;
	}

	public void setInvoiceItems(List<InvoiceItem> invoiceItems) {
		this.invoiceItems = invoiceItems;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public Float getInvoiceAmount() {
		return invoiceAmount;
	}

	public void setInvoiceAmount(Float invoiceAmount) {
		this.invoiceAmount = invoiceAmount;
	}

	public Float getPaymentMadeAmount() {
		return paymentMadeAmount;
	}

	public void setPaymentMadeAmount(Float paymentMadeAmount) {
		this.paymentMadeAmount = paymentMadeAmount;
	}

	public Float getCreditAvailableAmount() {
		return creditAvailableAmount;
	}

	public void setCreditAvailableAmount(Float creditAvailableAmount) {
		this.creditAvailableAmount = creditAvailableAmount;
	}

	public Float getDueAmount() {
		return dueAmount;
	}

	public void setDueAmount(Float dueAmount) {
		this.dueAmount = dueAmount;
	}

}
