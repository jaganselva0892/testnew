package com.trivent.models;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.models.base.BaseEntity;

/**
 * @ProjectName : trivent
 * @PackageName : com.trivent.entity
 * 
 * @FileName : Capability.java
 * @TypeName : Capability
 * @DateAndTime : Feb 8, 2018 - 4:01:09 PM
 * 
 * @Author : seetha
 * 
 * @Description : To create , edit , save and view the Capability details by
 *              fetching each required columns in this entity
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
@Entity
@Table(name = "capability")
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "capability_id")) })
public class Capability extends BaseEntity {

	

	/**
	 * 
	 */
	private static final long serialVersionUID = -1929656308736245026L;
	public static final String PER_TYPE_VISIBLE_ONLY = "Visible Only";
	public static final String PER_TYPE_CRUD_ONLY = "CRUD Only";
	public static final String PER_TYPE_VISIBLE_N_CRUD = "Visible And CRUD";

	public static final String UI_MENU = "Menu";
	public static final String UI_SUB_MENU = "Sub Menu";
	public static final String UI_TAB = "Tab";
	public static final String UI_LINK = "Link";
	public static final String UI_MISC = "Miscellaneous";

	public static final String DASHBOARD = "Dashboard";

	public static final String APP_MANAGEMENT = "App Management";
	public static final String PARTNERS = "Partners";
	public static final String ACCOUNTS = "Accounts";
	public static final String DIVISIONS = "Divisions";
	public static final String TEAMS = "Teams";
	public static final String USERS = "Users";
	public static final String CLIENTS = "Clients";
	public static final String ROLES_PERMISSIONS = "Roles & Permissions";
	public static final String LIST_ITEMS = "List & Items";
	public static final String UI_SCREEN_FIELDS = "UI Screens & Fields";
	public static final String APP_SERVICE_LINKS = "App Service Links";
	public static final String ALLOWED_IP_ADDRESS = "Allowed IP Address";
	public static final String PROD_STATUS_FLOW = "Production Status Flow Ref";
	public static final String QC_FLOW = "QC Flow";
	public static final String NEW_REGISTRATION = "New Registrations";

	public static final String CASE_MANAGEMENT = "Case Management";
	public static final String CASES_AT_FIRST_LEVEL = "Cases at First Level";
	public static final String CASES = "Cases";

	public static final String CASE_FILE = "Case File";
	public static final String CASE_FILE_DOWNLOAD = "Case File Download";

	public static final String CASE_FILE_LOCAL_UPLOAD = "Case File Local Upload";
	public static final String CASE_RESULT_FILE_LOCAL_UPLOAD = "Case Result File Local Upload";
	public static final String CASE_FILE_MERGE = "Case File Merge";

	public static final String CASE_FILE_LOCAL_DOWNLOAD = "Case File Local Download";
	public static final String CASE_FILE_LOCAL_DOWNLOAD_LINK = "Case File Local Download Link";
	public static final String CASE_RESULT_FILE = "Case Result File";
	public static final String CASE_RESULT_FILE_DOWNLOAD = "Case Result File Download";
	public static final String CASE_RESULT_FILE_LOCAL_DOWNLOAD = "Case Result Local File Download";

	public static final String CASE_SERVICE_REQUESTED = "Case Service Requested";
	public static final String CASE_QUERY = "Case Query";
	public static final String CASE_TASK = "Case Task";
	public static final String CASE_SLA = "Case SLA";

	public static final String CASE_JOBS = "Case Jobs";

	public static final String INVOICE_N_PAYMENTS = "Invoice & Payments";
	public static final String INVOICES = "Invoices";
	public static final String INVOICE_VIEW = "Invoice View";
	public static final String INVOICE_DOWNLOAD = "Invoice Download";

	public static final String REPORTS_N_STATISTICS = "Reports & Statistics";
	public static final String REPORTS = "Reports";
	public static final String WORK_LOG = "Master Worklog";
	public static final String TEAM_POINTER = "Team Pointer";
	public static final String REPORT_RUN_DOWNLOAD = "Report Run/Download";
	public static final String EMAIL_QUEUE = "Email Queue";

	public static final String CONTACTS = "Contacts";
	public static final String STATUS_FLOW_REFS = "Status Flow Ref";
	public static final String FINANCE_REPORT = "Finance Report";
	public static final String CUSTOMER_SUPPORT_REPORT = "Customer Support Report";
	public static final String CASE_QUERY_REPORT = "Case Query Report";
	public static final String CASE_TASK_REPORT = "Case Task Report";

	public static final String CASE_PRODUCTION_FILES = "Case Production Files";
	public static final String CASE_PRODUCTION_FILE_DOWNLOAD = "Case Production File Download";
	public static final String CASE_PRODUCTION_FILE_LOCAL_DOWNLOAD_LINK = "Case Production File Local Download Link";
	public static final String CASE_PRODUCTION_FILE_LOCAL_UPLOAD = "Case Production File Local Upload";

	public static final String PRODUCTION_TEAM_STRUCTURE_VIEW = "Team Structure View";

	public static final String ARCHIVAL = "Archival";

	public static final String CASE_IMPORT_CASES = "Import Cases";

	public static final String CASE_PRODUCTION = "Production";

	public static final String COMMENTS_APPROVE = "Comments Approve";

	public static final String DB_UNREAD_QUERIES_COUNT = "DB unread Queries Count";

	public static final String APPROVAL_MANAGEMENT = "Approval Management";
	public static final String APPROVAL_USERS = "Approval Users";
	public static final String APPROVAL_CONFIG = "Approval Config";
	public static final String APPROVAL_PENDING = "Approval Pending";
	public static final String PROD_USER_COMMENTS = "Prod User Comments";

	public static final String EXPEDITE_COLOR_CODE = "Expedite Color Code";

	public static final String LOG_ERROR = "Support";
	public static final String LOG_FILE_STATUS = "File Status";
	public static final String LOG_FILE_SUBSCRIPE = "Subscription";

	public static final String CREATE_LABELS = "Create Labels";

	public static final String DATE_OF_CLARIFICATION = "Date Of Clarification";
	public static final String DATE_OF_CLARIFICATION_MANDATORY = "Date Of Clarification Mandatory";

	public static final String CUSTOMER_FEEDBACK = "Feedback";

	public static final String QUERY_COMMUNICATION_TYPE = "Query Communication Type";

	public static final String QUERY_COMMUNICATION_SUB_TYPE = "Query Communication Sub Type";

	public static final String CASE_ASSIGN_TO = "AssignedTo";

	public static final String HISTORY = "History";

	public static final String LOG_HOURS = "Log Hours";

	public static final String APP_CONFIGURATION_MENU = "Application Configuration Menu";

	public static final String APP_CONFIG_IMPORT = "Application Configuration Data Import";

	public static final String CASE_FILE_DOWNLOAD_OUTER_NETWORK = "Case File Download Outer Network";

	public static final String PROD_COMMENTS = "Comments";

	public static final String MANAGEMENT_STRUCTURE_VIEW = "Management Structure View";

	public static final String LOG_HOURS_TASK_OWN = "My Task Track";
	public static final String LOG_HOURS_TASK_ALL = "All Task Track";

	public static final String MY_CASES = "My Cases";

	public static final String ASSIGNED_TO = "Assigned To";

	public static final String ASSIGNED_CASES = "Assigned Cases";

	public static final String NON_ASSIGNED_CASES = "Non Assigned Cases";

	public static final String MULTI_ASSIGNEE = "Multiple Assignee";

	public static final String PARTNER_BASED_DB = "Partner Based Dashboard";

	public static final String CASE_QUERY_MAIL = "Case Query MailIds";

	public static final String CASE_FILES_ARCHIVE = "Case Files Archive";

	public static final String CASE_RESULT_FILES_ARCHIVE = "Case Result Files Archive";

	public static final String CASE_FILES_ARCHIVE_SELECT = "Selected Case Files Archive";

	public static final String CASE_RESULT_FILES_ARCHIVE_SELECT = "Selected  Case Result Files Archive";

	public static final String CLIENT_NAME_WITH_CODE = "Client Name with Code";

	public static final String ACCOUNT_NAME_WITH_CODE = "Account Name With Code";

	public static final String ADMINSETUP = "Admin SetUp";

	public static final String PRODUCTION_MULTIPLE_ASSIGN = "Production Multiple Assignee";

	public static final String PRODUCTION_ASSIGN_TO_LIST = "Production Assigned To List";

	public static final String ADDADDITIONALRECORD = "Add Additional Record";

	public static final String METADATA = "Meta Data";

	public static final String CAPABILITIES = "Capabilities";

	public static final String EMAILTEMPLATE = "Email Template";

	public static final String ACTIVEUSERS = "Active Users";

	public static final String STATUSFLOWREF = "Status Flow Ref";

	public static final String APPDBTABLESCOLUMNS = "AppDB Tables & Columns";

	public static final String ANNOUNCEMENTS = "Announcements";

	public static final String PRODUCTIONCONFIG = "Production Config";

	public static final String DBVERSION = "DB Version";

	public static final String CLEARCACHE = "Clear Cache";

	public static final String REQUEST_ADDITIONAL_SERVICES = "Request Additional Services";

	public static final String APP_CONFIG_DATA_CONFIG = "Application Data Configuration";

	public static final String PRODUCTION_FILES_TAB = "Production Files Tab";

	public static final String DELIVERABLES = "Deliverables";

	public static final String APP_CUSTOMER_VERSION_TOUR = "Customer Version Tour";

	public static final String USER_DETAILS = "User Details";

	public static final String USER_ACTIVITY = "User Activity";

	public static final String CASE_DETAILS = "Case Details";

	public static final String USER_ACCESS_HISTORY = "User Access History";

	public static final String TASK_ATTACH_DOWNLOAD = "TaskAttachDownload";

	public static final String QUERY_ATTACH_DOWNLOAD = "QueryAttachDownload";

	public static final String ACCOUNT_MANAGEMENT = "Account Management";
	public static final String ACCOUNT_MANAGEMENT_ACCOUNT_SUMMARY = "Account Summary";
	public static final String ACCOUNT_MANAGEMENT_PRIMARY_COMMUNICATION = "Priority Communications";

	public static final String ARCHIVAL_MENU = "Archival Menu";

	public static final String ARCHIVAL_SUB_MENU_ARCHIVE = "Archival Records";
	public static final String ARCHIVAL_SUB_MENU_BACKUP = "Backup Records";
	public static final String ARCHIVAL_SUB_MENU_REMOVE = "Remove Records";

	public static final String CASE_RESULT_FILE_DOWNLOAD_OUTER_NETWORK = "Case Result File Download Outer Network";

	public static final String ACCOUNT_MANAGEMENT_ACCOUNT_MAPPING = "Account Map";
	public static final String WORK_LOG_IN_REPORTS = "Worklog";

	public static final String CLIENT_USER_PROFILE_REPORTS = "Client User Profile";

	public static final String QUERY_MESSAGE_EDIT = "Edit";
	public static final String QUERY_MESSAGE_VIEW = "View";

	public static final String SYN_LOG = "Syn Log";
	public static final String DASHBOARD_REPORT = "Dashboard Report";

	public static final String MANAGEMENT_DASHBOARD = "Management Dashboard";

	public static final String CsStatusCaseListPage = "CsStatusCaseListPage";

	public static final String CaseNameSearch = "CaseNameSearch";

	public static final String CASES_STATUS_LIST = "Case Status Based List";

	public static final String ACCOUNT_MANAGEMENR_CASELIST = "Account Manager Case List";

	public static final String PARENTCASE = "Parent Case";

	public static final String CASE_REPORT_USER = "Case Report User";

	public static final String ACCOUNTMANAGER_REPORTING_TOOL = "AccountManager Reporting Tool";

	public static final String CLIENT_TYPE = "Client Type";

	public static final String QUALITY_MANAGEMENT = "Quality Management";

	public static final String CHAT = "Chat";

	public static final String QUALITY_TYPE = "Quality Type";

	public static final String QUALITY_MGMT = "Quality Mgmt";

	public static final String MASTER_TYPE = "Master Type";

	public static final String MASTER_LIST = "Master List";

	public static final String PARAMETER = "Parameter";

	public static final String ADD_PARAMETER = "Add Parameter";

	public static final String LIST_PARAMETER = "List Parameter";

	public static final String SCORE = "Score";

	public static final String REPORT = "Report";

	public static final String SAVE_PARAMETER = "Save Parameter";

	public static final String SAVE_FTE = "Save FTE";

	public static final String SAVE_LCP = "Save LCP";

	public static final String SAVE_MD = "Save MD";

	public static final String SAVE_NON_COMPLIANCE = "Save NonCompliance";

	public static final String FILTER_FTE = "Filter FTE";

	public static final String FILTER_LCP = "Filter LCP";

	public static final String FILTER_MD = "Filter MD";

	public static final String FILTER_NON_COMPLIANCE = "Filter NonCompliance";

	public static final String LANGUAGE_ERROR = "Language Error";

	public static final String LANGUAGE_ERROR_SAVE = "Language Error Save";

	public static final String MENU_NON_COMPLIANCE = "NonCompliance";

	public static final String SUB_MENU_INDIVIDUAL_SCORE = "Individual Score";

	public static final String QUERY_NAME_SEARCH = "QueryNameSearch";

	public static final String CASE_DETAILS_PROD_STAFF = "CaseDetails Page Production Staff";

	public static final String CASE_DETAILS_PROD_LEAD = "CaseDetails Page Production Lead";

	public static final String CASE_DETAILS_MD = "CaseDetails Page MD";

	public static final String CASE_DETAILS_QC = "CaseDetails Page QC";

	public static final String SUPPORT_TEMPLATE = "Support Template";

	public static final String CASES_TEMPLATE = "Cases Template";

	public static final String ROLE_BASED_QM_DASHBOARD = "Role Based QM Dashboard";

	public static final String ADD_REC_HEADER = "Additional Record Header";

	public static final String ADD_REC_SIDE_MENU = "Additional Record Side Menu";
	
	public static final String TASK_REPORT = "Task Report";
	
	public static final String SUPPORT_REPORT = "Support Report";

	public static final String IS_QI_NOTIFY = "IS QI Notify";

	public static final String SCORE_PARAM = "Score Param";

	public static final String FILTER_QI = "Filter QI";

	public static final String ADD_QI_LIST = "Add QI List";

	public static final String ADD_QI_REPORT = "Add QI Report";

	public static final String ADD_QI = "Add QI";
	

	public static final String  ADD_APPRECIATION = "Add Appreciation";
	public static final String  ADD_APPRECIATION_LIST = "Add Appreciation List";
    public static final String   ADD_APPRECIATION_REPORTS = "Add Appreciation Reports";
    
    public static  final String SAVE_APPRECIATION = "Save Appreciation";
    public static  final String FILTER_APPRECIATION = "Filter Appreciation";

	public static final String IS_APPRECIATION_NOTIFY = "IS Appreciation Notify";


	@Column(name = "name", nullable = false, length = 40, unique = true)
	private String name;

	@Column(name = "description", length = 80)
	private String description;

	@Column(name = "permission_type", length = 40)
	private String permissionType;

	@Column(name = "seq_no", nullable = false)
	private Integer seqNo;

	@Column(name = "ui_type", nullable = false, length = 40)
	private String uiType;

	@OneToMany(mappedBy = "capability", fetch = FetchType.LAZY)
	@OrderBy("id")
	private List<Permission> permissions;

	public Capability() {
	}

	public Capability(String name, String permissionType, String uiType) {
		this.name = name;
		this.permissionType = permissionType;
		this.uiType = uiType;
	}

	public static List<Capability> getDefaultCapabilities() {
		List<Capability> capabilities = new ArrayList<>();
		capabilities.add(new Capability(DASHBOARD, PER_TYPE_VISIBLE_ONLY, UI_MENU));

		capabilities.add(new Capability(APP_MANAGEMENT, PER_TYPE_VISIBLE_ONLY, UI_MENU));

		capabilities.add(new Capability(PARTNERS, PER_TYPE_VISIBLE_N_CRUD, UI_SUB_MENU));
		capabilities.add(new Capability(ACCOUNTS, PER_TYPE_VISIBLE_N_CRUD, UI_SUB_MENU));
		capabilities.add(new Capability(DIVISIONS, PER_TYPE_VISIBLE_N_CRUD, UI_SUB_MENU));
		capabilities.add(new Capability(TEAMS, PER_TYPE_VISIBLE_N_CRUD, UI_SUB_MENU));
		capabilities.add(new Capability(USERS, PER_TYPE_VISIBLE_N_CRUD, UI_SUB_MENU));
		capabilities.add(new Capability(CLIENTS, PER_TYPE_VISIBLE_N_CRUD, UI_SUB_MENU));
		capabilities.add(new Capability(ROLES_PERMISSIONS, PER_TYPE_VISIBLE_N_CRUD, UI_SUB_MENU));
		capabilities.add(new Capability(LIST_ITEMS, PER_TYPE_VISIBLE_N_CRUD, UI_SUB_MENU));
		capabilities.add(new Capability(UI_SCREEN_FIELDS, PER_TYPE_VISIBLE_N_CRUD, UI_SUB_MENU));
		capabilities.add(new Capability(APP_SERVICE_LINKS, PER_TYPE_VISIBLE_N_CRUD, UI_SUB_MENU));

		capabilities.add(new Capability(CASE_MANAGEMENT, PER_TYPE_VISIBLE_ONLY, UI_MENU));
		capabilities.add(new Capability(CASES_AT_FIRST_LEVEL, PER_TYPE_VISIBLE_ONLY, UI_MENU));
		capabilities.add(new Capability(CASES, PER_TYPE_VISIBLE_N_CRUD, UI_SUB_MENU));

		capabilities.add(new Capability(CASE_FILE, PER_TYPE_VISIBLE_N_CRUD, UI_TAB));
		capabilities.add(new Capability(CASE_FILE_DOWNLOAD, PER_TYPE_VISIBLE_ONLY, UI_LINK));

		capabilities.add(new Capability(CASE_FILE_LOCAL_UPLOAD, PER_TYPE_VISIBLE_ONLY, UI_LINK));
		capabilities.add(new Capability(CASE_RESULT_FILE_LOCAL_UPLOAD, PER_TYPE_VISIBLE_ONLY, UI_LINK));

		capabilities.add(new Capability(CASE_FILE_LOCAL_DOWNLOAD, PER_TYPE_VISIBLE_ONLY, UI_LINK));
		capabilities.add(new Capability(CASE_RESULT_FILE, PER_TYPE_VISIBLE_N_CRUD, UI_TAB));
		capabilities.add(new Capability(CASE_RESULT_FILE_DOWNLOAD, PER_TYPE_VISIBLE_ONLY, UI_LINK));
		capabilities.add(new Capability(CASE_RESULT_FILE_LOCAL_DOWNLOAD, PER_TYPE_VISIBLE_ONLY, UI_LINK));
		capabilities.add(new Capability(CASE_SERVICE_REQUESTED, PER_TYPE_VISIBLE_N_CRUD, UI_TAB));
		capabilities.add(new Capability(CASE_QUERY, PER_TYPE_VISIBLE_N_CRUD, UI_TAB));
		capabilities.add(new Capability(CASE_TASK, PER_TYPE_VISIBLE_N_CRUD, UI_TAB));
		capabilities.add(new Capability(CASE_SLA, PER_TYPE_VISIBLE_N_CRUD, UI_TAB));
		capabilities.add(new Capability(PRODUCTION_TEAM_STRUCTURE_VIEW, PER_TYPE_VISIBLE_ONLY, UI_TAB));

		capabilities.add(new Capability(CASE_JOBS, PER_TYPE_VISIBLE_N_CRUD, UI_SUB_MENU));

		capabilities.add(new Capability(INVOICE_N_PAYMENTS, PER_TYPE_VISIBLE_ONLY, UI_MENU));
		capabilities.add(new Capability(INVOICES, PER_TYPE_VISIBLE_N_CRUD, UI_SUB_MENU));
		capabilities.add(new Capability(INVOICE_VIEW, PER_TYPE_VISIBLE_ONLY, UI_LINK));
		capabilities.add(new Capability(INVOICE_DOWNLOAD, PER_TYPE_VISIBLE_ONLY, UI_LINK));

		capabilities.add(new Capability(REPORTS_N_STATISTICS, PER_TYPE_VISIBLE_ONLY, UI_MENU));
		capabilities.add(new Capability(REPORTS, PER_TYPE_VISIBLE_N_CRUD, UI_SUB_MENU));
		capabilities.add(new Capability(REPORT_RUN_DOWNLOAD, PER_TYPE_VISIBLE_ONLY, UI_LINK));
		capabilities.add(new Capability(EMAIL_QUEUE, PER_TYPE_VISIBLE_N_CRUD, UI_SUB_MENU));

		capabilities.add(new Capability(CONTACTS, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));
		capabilities.add(new Capability(STATUS_FLOW_REFS, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));
		capabilities.add(new Capability(FINANCE_REPORT, PER_TYPE_VISIBLE_ONLY, UI_SUB_MENU));
		capabilities.add(new Capability(CUSTOMER_SUPPORT_REPORT, PER_TYPE_VISIBLE_ONLY, UI_SUB_MENU));
		capabilities.add(new Capability(CASE_QUERY_REPORT, PER_TYPE_VISIBLE_ONLY, UI_SUB_MENU));
		capabilities.add(new Capability(CASE_TASK_REPORT, PER_TYPE_VISIBLE_ONLY, UI_SUB_MENU));

		capabilities.add(new Capability(CASE_PRODUCTION_FILES, PER_TYPE_VISIBLE_N_CRUD, UI_TAB));
		capabilities.add(new Capability(CASE_PRODUCTION_FILE_DOWNLOAD, PER_TYPE_VISIBLE_ONLY, UI_LINK));
		capabilities.add(new Capability(CASE_PRODUCTION_FILE_LOCAL_DOWNLOAD_LINK, PER_TYPE_VISIBLE_ONLY, UI_LINK));
		capabilities.add(new Capability(CASE_PRODUCTION_FILE_LOCAL_UPLOAD, PER_TYPE_VISIBLE_ONLY, UI_LINK));

		capabilities.add(new Capability(ARCHIVAL, PER_TYPE_VISIBLE_ONLY, UI_SUB_MENU));

		capabilities.add(new Capability(CASE_PRODUCTION, PER_TYPE_VISIBLE_ONLY, UI_SUB_MENU));

		capabilities.add(new Capability(COMMENTS_APPROVE, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(DB_UNREAD_QUERIES_COUNT, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(APPROVAL_MANAGEMENT, PER_TYPE_VISIBLE_N_CRUD, UI_MENU));
		capabilities.add(new Capability(APPROVAL_USERS, PER_TYPE_VISIBLE_N_CRUD, UI_SUB_MENU));
		capabilities.add(new Capability(APPROVAL_CONFIG, PER_TYPE_VISIBLE_N_CRUD, UI_SUB_MENU));
		capabilities.add(new Capability(APPROVAL_PENDING, PER_TYPE_VISIBLE_N_CRUD, UI_SUB_MENU));

		capabilities.add(new Capability(PROD_USER_COMMENTS, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(EXPEDITE_COLOR_CODE, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(CREATE_LABELS, PER_TYPE_VISIBLE_N_CRUD, UI_SUB_MENU));

		capabilities.add(new Capability(DATE_OF_CLARIFICATION, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(DATE_OF_CLARIFICATION_MANDATORY, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(CUSTOMER_FEEDBACK, PER_TYPE_VISIBLE_N_CRUD, UI_TAB));

		capabilities.add(new Capability(QUERY_COMMUNICATION_TYPE, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(CASE_ASSIGN_TO, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(HISTORY, PER_TYPE_VISIBLE_ONLY, UI_TAB));

		capabilities.add(new Capability(LOG_HOURS, PER_TYPE_VISIBLE_N_CRUD, UI_TAB));

		capabilities.add(new Capability(APP_CONFIGURATION_MENU, PER_TYPE_VISIBLE_N_CRUD, UI_MENU));

		capabilities.add(new Capability(APP_CONFIG_IMPORT, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(PROD_COMMENTS, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(MY_CASES, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(ASSIGNED_CASES, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(NON_ASSIGNED_CASES, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(MANAGEMENT_STRUCTURE_VIEW, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(LOG_HOURS_TASK_OWN, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(LOG_HOURS_TASK_ALL, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(MULTI_ASSIGNEE, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(CASE_QUERY_MAIL, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(CASE_FILES_ARCHIVE, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(CASE_RESULT_FILES_ARCHIVE, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(CASE_FILES_ARCHIVE_SELECT, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(CASE_RESULT_FILES_ARCHIVE_SELECT, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(CLIENT_NAME_WITH_CODE, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(ACCOUNT_NAME_WITH_CODE, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(ASSIGNED_TO, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(ADMINSETUP, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(PRODUCTION_MULTIPLE_ASSIGN, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(PRODUCTION_ASSIGN_TO_LIST, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(REQUEST_ADDITIONAL_SERVICES, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(APP_CONFIG_DATA_CONFIG, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(APP_CUSTOMER_VERSION_TOUR, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(ADDADDITIONALRECORD, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(METADATA, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(CAPABILITIES, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(EMAILTEMPLATE, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(ACTIVEUSERS, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(STATUSFLOWREF, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(APPDBTABLESCOLUMNS, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(ANNOUNCEMENTS, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(PRODUCTIONCONFIG, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(DBVERSION, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(CLEARCACHE, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(PRODUCTION_FILES_TAB, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(DELIVERABLES, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(USER_DETAILS, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(USER_ACTIVITY, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(CASE_DETAILS, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(USER_ACCESS_HISTORY, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(TASK_ATTACH_DOWNLOAD, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(QUERY_ATTACH_DOWNLOAD, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(ACCOUNT_MANAGEMENT, PER_TYPE_VISIBLE_N_CRUD, UI_MENU));

		capabilities.add(new Capability(ACCOUNT_MANAGEMENT_ACCOUNT_SUMMARY, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(ACCOUNT_MANAGEMENT_PRIMARY_COMMUNICATION, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(ARCHIVAL_MENU, PER_TYPE_VISIBLE_N_CRUD, UI_MENU));

		capabilities.add(new Capability(ARCHIVAL_SUB_MENU_ARCHIVE, PER_TYPE_VISIBLE_N_CRUD, UI_SUB_MENU));

		capabilities.add(new Capability(ARCHIVAL_SUB_MENU_BACKUP, PER_TYPE_VISIBLE_N_CRUD, UI_SUB_MENU));

		capabilities.add(new Capability(ARCHIVAL_SUB_MENU_REMOVE, PER_TYPE_VISIBLE_N_CRUD, UI_SUB_MENU));

		capabilities.add(new Capability(ACCOUNT_MANAGEMENT_ACCOUNT_MAPPING, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(WORK_LOG_IN_REPORTS, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(CLIENT_USER_PROFILE_REPORTS, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(QUERY_MESSAGE_EDIT, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(QUERY_MESSAGE_VIEW, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(CASE_FILE_MERGE, PER_TYPE_VISIBLE_ONLY, UI_LINK));

		capabilities.add(new Capability(CASE_RESULT_FILE_DOWNLOAD_OUTER_NETWORK, PER_TYPE_VISIBLE_ONLY, UI_LINK));

		capabilities.add(new Capability(SYN_LOG, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(DASHBOARD_REPORT, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(MANAGEMENT_DASHBOARD, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(CsStatusCaseListPage, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(CaseNameSearch, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(CASES_STATUS_LIST, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(ACCOUNT_MANAGEMENR_CASELIST, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(PARENTCASE, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(CASE_REPORT_USER, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(ACCOUNTMANAGER_REPORTING_TOOL, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(CLIENT_TYPE, PER_TYPE_VISIBLE_N_CRUD, UI_MISC));

		capabilities.add(new Capability(QUALITY_MANAGEMENT, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(QUALITY_TYPE, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(QUALITY_MGMT, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(MASTER_TYPE, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(MASTER_LIST, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(PARAMETER, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(ADD_PARAMETER, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(LIST_PARAMETER, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(SCORE, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(REPORT, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(SAVE_PARAMETER, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(SAVE_FTE, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(SAVE_LCP, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(SAVE_MD, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(SAVE_NON_COMPLIANCE, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(FILTER_FTE, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(FILTER_LCP, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(FILTER_MD, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(FILTER_NON_COMPLIANCE, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(LANGUAGE_ERROR, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(LANGUAGE_ERROR_SAVE, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(MENU_NON_COMPLIANCE, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(SUB_MENU_INDIVIDUAL_SCORE, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(CHAT, PER_TYPE_VISIBLE_ONLY, UI_MENU));

		capabilities.add(new Capability(QUERY_NAME_SEARCH, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(CASE_DETAILS_PROD_STAFF, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(CASE_DETAILS_PROD_LEAD, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(CASE_DETAILS_MD, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(CASE_DETAILS_QC, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(SUPPORT_TEMPLATE, PER_TYPE_VISIBLE_ONLY, UI_SUB_MENU));

		capabilities.add(new Capability(ROLE_BASED_QM_DASHBOARD, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(ADD_REC_HEADER, PER_TYPE_VISIBLE_ONLY, UI_MENU));

		capabilities.add(new Capability(ADD_REC_SIDE_MENU, PER_TYPE_VISIBLE_ONLY, UI_MENU));
		
		capabilities.add(new Capability(TASK_REPORT, PER_TYPE_VISIBLE_N_CRUD, UI_TAB));

		capabilities.add(new Capability(SUPPORT_REPORT, PER_TYPE_VISIBLE_N_CRUD, UI_TAB));

		capabilities.add(new Capability(IS_QI_NOTIFY, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(SCORE_PARAM, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(FILTER_QI, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(ADD_QI_LIST, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(ADD_QI_REPORT, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(ADD_QI, PER_TYPE_VISIBLE_ONLY, UI_MISC));
		

		capabilities.add(new Capability(ADD_APPRECIATION, PER_TYPE_VISIBLE_ONLY, UI_MISC));
		
		capabilities.add(new Capability(ADD_APPRECIATION_LIST, PER_TYPE_VISIBLE_ONLY, UI_MISC));
		
		capabilities.add(new Capability(ADD_APPRECIATION_REPORTS, PER_TYPE_VISIBLE_ONLY, UI_MISC));
		
		capabilities.add(new Capability(FILTER_APPRECIATION, PER_TYPE_VISIBLE_ONLY, UI_MISC));
		
		capabilities.add(new Capability(SAVE_APPRECIATION, PER_TYPE_VISIBLE_ONLY, UI_MISC));

		capabilities.add(new Capability(IS_APPRECIATION_NOTIFY, PER_TYPE_VISIBLE_ONLY, UI_MISC));
		


		return capabilities;
	}

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		Capability other = (Capability) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPermissionType() {
		return permissionType;
	}

	public void setPermissionType(String permissionType) {
		this.permissionType = permissionType;
	}

	public List<Permission> getPermissions() {
		return permissions;
	}

	public void setPermissions(List<Permission> permissions) {
		this.permissions = permissions;
	}

	public Integer getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(Integer seqNo) {
		this.seqNo = seqNo;
	}

	public String getUiType() {
		return uiType;
	}

	public void setUiType(String uiType) {
		this.uiType = uiType;
	}
}