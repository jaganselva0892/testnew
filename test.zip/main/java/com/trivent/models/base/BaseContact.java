package com.trivent.models.base;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.entity.base
 * 
 * @FileName 	:
 *				BaseContact.java
 * @TypeName 	:
 * 				BaseContact
 * @DateAndTime :
 *				Feb 8, 2018 - 5:06:03 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description : To maintain common info of user details  (Global Maintaining)
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@MappedSuperclass
public class BaseContact extends BaseSoftDeletable  {

	private static final long serialVersionUID = -1421527807926868953L;

	@Column(name = "first_name", length = 80)
	private String firstName = null;

	@Column(name = "last_name", length = 80)
	private String lastName = null;

	@Column(name = "company", length = 120)
	private String company = null;

	@Column(name = "job_title", length = 120)
	private String jobTitle = null;

	@Column(name = "address1", length = 150)
	private String address1 = null;

	@Column(name = "address2", length = 150)
	private String address2 = null;

	@Column(name = "city", length = 80)
	private String city = null;

	@Column(name = "state", length = 80)
	private String state = null;

	@Column(name = "zipcode", length = 12)
	private String zipCode = null;

	@Column(name = "phone", length = 20)
	private String phone = null;

	@Column(name = "phone_extn", length = 5)
	private String extn = null;

	@Column(name = "fax", length = 20)
	private String fax = null;

	@Column(name = "email", length = 80)
	private String email = null;

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		BaseContact other = (BaseContact) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getExtn() {
		return extn;
	}

	public void setExtn(String extn) {
		this.extn = extn;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

}
