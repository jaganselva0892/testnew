package com.trivent.models.base;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.constants.AppConstants;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.entity.base
 * 
 * @FileName 	:
 *				BaseCaseQuery.java
 * @TypeName 	:
 * 				BaseCaseQuery
 * @DateAndTime :
 *				Feb 8, 2018 - 5:04:37 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description : To have common necessary details of query (email)related Info (Global Maintaining)
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@MappedSuperclass
public class BaseCaseQuery extends BaseSoftDeletable {

	private static final long serialVersionUID = -445863170408868970L;

	@Column(name = "query_from", length = 150)
	private String queryFrom = null;

	@Column(name = "query_to", length = 1000)
	private String queryTo = null;

	@Column(name = "query_cc", length = 1000)
	private String queryCc = null;

	@Column(name = "seq_no")
	private Integer seqNo = null;

	@Column(name = "is_internal")
	private Character isInternal = AppConstants.NO;

	@Column(name = "is_client_viewable")
	private Character isVisible2Client = AppConstants.NO;

	@Column(name = "is_email_notify")
	private Character isEmailNotify = AppConstants.NO;

	@Column(name = "is_new_query")
	private Character isNewQuery = AppConstants.NO;

	@Column(name = "query_source")
	private Character querySource = AppConstants.QUERY_SOURCE_PORTAL;

	@Column(name = "owner_role_type", nullable = false, length = 40)
	private String ownerRoleType = null;

	@Column(name = "query_bcc", length = 1000)
	private String queryBcc = null;
	
	

	

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		BaseCaseQuery other = (BaseCaseQuery) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public String getQueryFrom() {
		return queryFrom;
	}

	public void setQueryFrom(String queryFrom) {
		this.queryFrom = queryFrom;
	}

	public String getQueryTo() {
		return queryTo;
	}

	public void setQueryTo(String queryTo) {
		this.queryTo = queryTo;
	}

	public String getQueryCc() {
		return queryCc;
	}

	public void setQueryCc(String queryCc) {
		this.queryCc = queryCc;
	}

	public Integer getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(Integer seqNo) {
		this.seqNo = seqNo;
	}

	public Character getIsInternal() {
		return isInternal;
	}

	public void setIsInternal(Character isInternal) {
		this.isInternal = isInternal;
	}

	public Character getIsVisible2Client() {
		return isVisible2Client;
	}

	public void setIsVisible2Client(Character isVisible2Client) {
		this.isVisible2Client = isVisible2Client;
	}

	public Character getIsEmailNotify() {
		return isEmailNotify;
	}

	public void setIsEmailNotify(Character isEmailNotify) {
		this.isEmailNotify = isEmailNotify;
	}

	public String getOwnerRoleType() {
		return ownerRoleType;
	}

	public void setOwnerRoleType(String ownerRoleType) {
		this.ownerRoleType = ownerRoleType;
	}

	public Character getQuerySource() {
		return querySource;
	}

	public void setQuerySource(Character querySource) {
		this.querySource = querySource;
	}

	public Character getIsNewQuery() {
		return isNewQuery;
	}

	public void setIsNewQuery(Character isNewQuery) {
		this.isNewQuery = isNewQuery;
	}

	public String getQueryBcc() {
		return queryBcc;
	}

	public void setQueryBcc(String queryBcc) {
		this.queryBcc = queryBcc;
	}
	
	
}