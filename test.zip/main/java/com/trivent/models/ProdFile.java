package com.trivent.models;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.constants.AppConstants;
import com.trivent.models.base.BaseSoftDeletable;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.entity
 * 
 * @FileName 	:
 *				ProdFile.java
 * @TypeName 	:
 * 				ProdFile
 * @DateAndTime :
 *				Feb 8, 2018 - 4:55:33 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description : To create , edit , save and view the Production File for users by
 *              fetching each required columns in this entity 
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Entity
@Table(name = "prod_files", uniqueConstraints = @UniqueConstraint(columnNames = { "prod_file_id" }))
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "prod_file_id")) })
public class ProdFile extends BaseSoftDeletable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8471743359392204077L;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "production_id", nullable = false, foreignKey = @ForeignKey(name = "FK_case_production_1"))
	private Production productionId = null;

	@Column(name = "file_content_type", nullable = false, length = 80)
	private String fileContentType = null;

	@Column(name = "file_description", length = 1000)
	private String fileDescription = null;

	@Column(name = "file_extension", nullable = false, length = 10)
	private String fileExtension = null;

	@Column(name = "file_location", nullable = false, length = 500)
	private String fileLocation = null;

	@Column(name = "file_name", nullable = false, length = 150)
	private String fileName = null;

	@Column(name = "file_page_count")
	private Integer filePageCount = 0;

	@Column(name = "file_seq_no", nullable = false)
	private Integer fileSeqNo = null;

	@Column(name = "is_zipped", nullable = false)
	private Character fileZipped = AppConstants.NO;

	@Column(name = "root_path", length = 1000)
	private String rootPath = null;

	@Column(name = "file_size", nullable = false)
	private Long fileSize = null;

	@Column(name = "version")
	private Integer version = null;

	@Column(name = "is_latest", length = 1)
	private Character isLatest = AppConstants.YES;

	@Column(name = "is_deliverable", length = 1)
	private Character isDeliverable = AppConstants.NO;

	@Column(name = "is_delivered", length = 1)
	private Character isDelivered = AppConstants.NO;

	@Column(name = "is_archival")
	private Character archived = AppConstants.NO;
	
	@Column(name = "is_backup")
	private Character backup = AppConstants.NO;
	
	@Column(name = "is_remove")
	private Character removed = AppConstants.NO;

	/************************ Audit Log *********************/
	// @Override
	// public String getAuditLogDetails() {
	// StringBuilder sb = new StringBuilder();
	// sb.append("Production Id : ").append(productionId.getId()).append(",
	// Production File Id : ").append(getId())
	// .append(", File Name : ").append(fileName);
	// return sb.toString();
	// }
	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		ProdFile other = (ProdFile) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public Production getProduction() {
		return productionId;
	}

	public void setProduction(Production productionId) {
		this.productionId = productionId;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFileExtension() {
		return fileExtension;
	}

	public void setFileExtension(String fileExtension) {
		this.fileExtension = fileExtension;
	}

	public String getFileContentType() {
		return fileContentType;
	}

	public void setFileContentType(String fileContentType) {
		this.fileContentType = fileContentType;
	}

	public Character getFileZipped() {
		return fileZipped;
	}

	public void setFileZipped(Character fileZipped) {
		this.fileZipped = fileZipped;
	}

	public Integer getSeqNo() {
		return fileSeqNo;
	}

	public void setSeqNo(Integer fileSeqNo) {
		this.fileSeqNo = fileSeqNo;
	}

	public String getFileDescription() {
		return fileDescription;
	}

	public void setFileDescription(String fileDescription) {
		this.fileDescription = fileDescription;
	}

	public String getFileLocation() {
		return fileLocation;
	}

	public void setFileLocation(String fileLocation) {
		this.fileLocation = fileLocation;
	}

	public String getRootPath() {
		return rootPath;
	}

	public void setRootPath(String rootPath) {
		this.rootPath = rootPath;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public Integer getFilePageCount() {
		return filePageCount;
	}

	public void setFilePageCount(Integer filePageCount) {
		this.filePageCount = filePageCount;
	}

	public Character getIsLatest() {
		return isLatest;
	}

	public void setIsLatest(Character isLatest) {
		this.isLatest = isLatest;
	}

	public Long getFileSize() {
		return fileSize;
	}

	public void setFileSize(Long fileSize) {
		this.fileSize = fileSize;
	}

	public Character getIsDeliverable() {
		return isDeliverable;
	}

	public void setIsDeliverable(Character isDeliverable) {
		this.isDeliverable = isDeliverable;
	}

	public Character getIsDelivered() {
		return isDelivered;
	}

	public void setIsDelivered(Character isDelivered) {
		this.isDelivered = isDelivered;
	}

	public Character getArchived() {
		return archived;
	}

	public void setArchived(Character archived) {
		this.archived = archived;
	}

	public Character getBackup() {
		return backup;
	}

	public void setBackup(Character backup) {
		this.backup = backup;
	}

	public Character getRemoved() {
		return removed;
	}

	public void setRemoved(Character removed) {
		this.removed = removed;
	}

	
}
