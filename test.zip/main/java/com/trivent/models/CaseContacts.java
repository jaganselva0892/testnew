package com.trivent.models;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import com.trivent.models.base.BaseSoftDeletable;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.entity
 * 
 * @FileName 	:
 *				CaseContacts.java
 * @TypeName 	:
 * 				CaseContacts
 * @DateAndTime :
 *				Feb 8, 2018 - 4:02:04 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description : To create , edit , save and view the CaseContacts details by
 *              fetching each required columns in this entity
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Entity
@Table(name = "case_contacts")
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "case_contact_id")) })
public class CaseContacts extends BaseSoftDeletable {

	


	/**
	 * 
	 */
	private static final long serialVersionUID = -7780139096868541306L;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "case_id", nullable = false, foreignKey = @ForeignKey(name = "fk_case_cc_1"))
	private Case caseId;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_id", foreignKey = @ForeignKey(name = "fk_user_cc_1"))
	private User userId;
	
	@Column(name = "name", nullable = false, length=200)
	private String name;
	
	@Column(name = "email_id", nullable = false, length=1000)
	private String emailId;
	
	@Column(name = "contact_id")
	private Long contactId;
	
	@Column(name = "contact_type", length = 10)
	private String contactType = null;
	
	/********************** HashCode, and equals methods **********************/
	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		CaseContacts other = (CaseContacts) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/
	
	public Case getCaseid() {
		return caseId;
	}

	public void setCaseId(Case caseId) {
		this.caseId = caseId;
	}
	
	public User getUserid() {
		return userId;
	}

	public void setUserId(User userId) {
		this.userId = userId;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public Long getContactId() {
		return contactId;
	}

	public void setContactId(Long contactId) {
		this.contactId = contactId;
	}

	public String getContactType() {
		return contactType;
	}

	public void setContactType(String contactType) {
		this.contactType = contactType;
	}
	
	
	
	
}
