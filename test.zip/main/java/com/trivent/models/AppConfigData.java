package com.trivent.models;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.models.base.BaseSoftDeletable;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.entity
 * 
 * @FileName 	:
 *				AppConfigData.java
 * @TypeName 	:
 * 				AppConfigData
 * @DateAndTime :
 *				Feb 8, 2018 - 3:45:37 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description :To create , edit , save and view the AppConfigData details by
 *              fetching each required columns in this entity 
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Entity
@Table(name = "app_config_data")
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "app_config_data_id")) })
public class AppConfigData extends BaseSoftDeletable /*implements AuditLog*/ {

	

	/**
	 * 
	 */
	private static final long serialVersionUID = 6537419554436069417L;

	@Column(name = "app_config_data_name", nullable = false, length = 100)
	private String name;

	@Column(name = "app_config_data_value")
	private String dataValue;

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		AppConfigData other = (AppConfigData) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/*@Override
	public String getAuditLogDetails() {
		return "Id : " + this.getId().toString() + ", Name : " + this.getLastModifiedBy();
	}*/

	/********************** Getters and Setters **********************/

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDataValue() {
		return dataValue;
	}

	public void setDataValue(String dataValue) {
		this.dataValue = dataValue;
	}

}
