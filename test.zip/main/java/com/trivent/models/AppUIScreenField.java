package com.trivent.models;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.constants.AppConstants;
import com.trivent.models.base.BaseEntity;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.entity
 * 
 * @FileName 	:
 *				AppUIScreenField.java
 * @TypeName 	:
 * 				AppUIScreenField
 * @DateAndTime :
 *				Feb 8, 2018 - 3:57:43 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description :  To create , edit , save and view the AppUIScreenField  details by
 *              fetching each required columns in this entity
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Entity
@Table(name = "app_ui_screen_fields")
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "ui_screen_field_id")) })
public class AppUIScreenField extends BaseEntity {

  

  /**
	 * 
	 */
 private static final long serialVersionUID = -2821959068287187500L;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "ui_screen_id", nullable = false, foreignKey = @ForeignKey(name = "fk_app_ui_screen_field_1"))
  private AppUIScreen appUiScreen = null;

  @Column(name = "attribute_name", length = 120, nullable = false)
  private String attributeName = null;

  @Column(name = "db_table_name", length = 120)
  private String dbTableName = null;

  @Column(name = "db_field_name", length = 120)
  private String dbFieldName = null;

  @Column(name = "attribute_size")
  private Integer attributeSize = null;

  @Column(name = "attribute_datatype", length = 40)
  private String attributeDataType = null;

  @Column(name = "attribute_validation", length = 120)
  private String attributeValidation = null;

  @Column(name = "attribute_hint", length = 120)
  private String attributeHint = null;

  @Column(name = "attribute_ui_column")
  private Integer attributeUIColumn = null;

  @Column(name = "attribute_seq")
  private Integer attributeSeq = null;

  @Column(name = "attribute_required", nullable = false)
  private Character attributeRequired = AppConstants.NO;

  @Column(name = "is_displayable", nullable = false)
  private Character displayable = AppConstants.YES;

  @Column(name = "read_only", length = 1)
  private Character readOnly = AppConstants.NO;

  @Column(name = "list_name")
  private String listName = null;

  /********************** Custom methods **********************/

  public boolean isDisplayable() {
    return displayable == AppConstants.YES;
  }

  public boolean isReadOnly() {
    return readOnly == AppConstants.YES;
  }

  public boolean isAttributeRequired() {
    return attributeRequired == AppConstants.YES;
  }

  /********************** hashcode, and equals methods **********************/

  @Override
  public int hashCode() {
    return new HashCodeBuilder().append(this.getId()).hashCode();
  }

  @Override
  public boolean equals(Object obj) {
    if (obj == null || obj.getClass() != getClass()) {
      return false;
    }
    AppUIScreenField other = (AppUIScreenField) obj;
    return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
  }

  /********************** Getters and Setters **********************/

  public AppUIScreen getAppUiScreen() {
    return appUiScreen;
  }

  public void setAppUiScreen(AppUIScreen appUiScreen) {
    this.appUiScreen = appUiScreen;
  }

  public String getAttributeName() {
    return attributeName;
  }

  public void setAttributeName(String attributeName) {
    this.attributeName = attributeName;
  }

  public String getDbTableName() {
    return dbTableName;
  }

  public void setDbTableName(String dbTableName) {
    this.dbTableName = dbTableName;
  }

  public String getDbFieldName() {
    return dbFieldName;
  }

  public void setDbFieldName(String dbFieldName) {
    this.dbFieldName = dbFieldName;
  }

  public Integer getAttributeSize() {
    return attributeSize;
  }

  public void setAttributeSize(Integer attributeSize) {
    this.attributeSize = attributeSize;
  }

  public String getAttributeDataType() {
    return attributeDataType;
  }

  public void setAttributeDataType(String attributeDataType) {
    this.attributeDataType = attributeDataType;
  }

  public String getAttributeValidation() {
    return attributeValidation;
  }

  public void setAttributeValidation(String attributeValidation) {
    this.attributeValidation = attributeValidation;
  }

  public Character getAttributeRequired() {
    return attributeRequired;
  }

  public void setAttributeRequired(Character attributeRequired) {
    this.attributeRequired = attributeRequired;
  }

  public String getAttributeHint() {
    return attributeHint;
  }

  public void setAttributeHint(String attributeHint) {
    this.attributeHint = attributeHint;
  }

  public Integer getAttributeUIColumn() {
    return attributeUIColumn;
  }

  public void setAttributeUIColumn(Integer attributeUIColumn) {
    this.attributeUIColumn = attributeUIColumn;
  }

  public Integer getAttributeSeq() {
    return attributeSeq;
  }

  public void setAttributeSeq(Integer attributeSeq) {
    this.attributeSeq = attributeSeq;
  }

  public Character getDisplayable() {
    return displayable;
  }

  public void setDisplayable(Character displayable) {
    this.displayable = displayable;
  }

  public Character getReadOnly() {
    return readOnly;
  }

  public void setReadOnly(Character readOnly) {
    this.readOnly = readOnly;
  }

  public String getListName() {
    return listName;
  }

  public void setListName(String listName) {
    this.listName = listName;
  }

}
