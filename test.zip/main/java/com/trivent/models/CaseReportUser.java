package com.trivent.models;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.models.base.BaseSoftDeletable;

/**
 * @ProjectName : trivent
 * @PackageName : com.trivent.entity
 * 
 * @FileName : CaseReportUser.java
 * @TypeName : CaseReportUser
 * @DateAndTime : April 19, 2018 - 3:25:02 PM
 * 
 * @Author : Boopathi P S
 * 
 * @Description : To create , edit , save and view the CaseReportUser details by
 *              fetching each required columns in this entity
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
@Entity
@Table(name = "case_report_users")
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "case_report_user_id")) })
public class CaseReportUser extends BaseSoftDeletable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3767710841434471443L;

	public static final int NAME_MAX_LENGTH = 150;

	@Column(name = "prod_user", nullable = true)
	private String prodUser;
	
	@Column(name = "prod_lead", nullable = true)
	private String prodLead;
	
	@Column(name = "prod_md", nullable = true)
	private String prodMd;
	
	@Column(name = "prod_qc", nullable = true)
	private String prodQc;
	
	@Column(name = "case_id", nullable = false)
	private Long caseId;
	
	@Column(name = "client_type", nullable = true)
	private Long clientType = null;

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		CaseReportUser other = (CaseReportUser) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public String getProdUser() {
		return prodUser;
	}

	public void setProdUser(String prodUser) {
		this.prodUser = prodUser;
	}

	public String getProdLead() {
		return prodLead;
	}

	public void setProdLead(String prodLead) {
		this.prodLead = prodLead;
	}

	public String getProdMd() {
		return prodMd;
	}

	public void setProdMd(String prodMd) {
		this.prodMd = prodMd;
	}

	public String getProdQc() {
		return prodQc;
	}

	public void setProdQc(String prodQc) {
		this.prodQc = prodQc;
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public Long getClientType() {
		return clientType;
	}

	public void setClientType(Long clientType) {
		this.clientType = clientType;
	}

	
	

}
