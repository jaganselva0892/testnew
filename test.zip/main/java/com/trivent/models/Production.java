package com.trivent.models;

import java.util.Calendar;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.constants.AppConstants;
import com.trivent.models.base.BaseSoftDeletable;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.entity
 * 
 * @FileName 	:
 *				Production.java
 * @TypeName 	:
 * 				Production
 * @DateAndTime :
 *				Feb 8, 2018 - 4:57:01 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description :  To create , edit , save and view the Production for users by
 *              fetching each required columns in this entity
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Entity
@Table(name = "case_production")
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "production_id")) })
public class Production extends BaseSoftDeletable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2583379885083819487L;

	@Column(name = "case_id")
	private Long caseId = null;

	@Column(name = "production_status")
	private Long productionStatus;

	@Column(name = "complete_process")
	private int completeProcess;

	@Column(name = "is_active")
	private Character isActive = AppConstants.YES;

	@Column(name = "isDeliver")
	private String isDeliver = AppConstants.PRODUCTION_FILE_NOT_DELIVERED_STATUS;

	@Column(name = "date_of_clarification")
	private Calendar dateOfClarification = null;

	@Column(name = "review_status")
	private Character reviewStatus = AppConstants.NO;
	
	@Column(name = "prod_delivery_date")
	private Calendar prodDeliveryDate = null;

	/********************** Audit Log methods **********************/

	// @Override
	// public String getAuditLogDetails() {
	// StringBuilder sb = new StringBuilder();
	// sb.append("Production ID : ").append(getId()).append(", Production Status
	// : ").append(productionStatus);
	// return sb.toString();
	// }

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		Production other = (Production) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public Long getProductionStatus() {
		return productionStatus;
	}

	public void setProductionStatus(Long productionStatus) {
		this.productionStatus = productionStatus;
	}

	public int getCompleteProcess() {
		return completeProcess;
	}

	public void setCompleteProcess(int completeProcess) {
		this.completeProcess = completeProcess;
	}

	public Character getIsActive() {
		return isActive;
	}

	public void setIsActive(Character isActive) {
		this.isActive = isActive;
	}

	public String getIsDeliver() {
		return isDeliver;
	}

	public void setIsDeliver(String isDeliver) {
		this.isDeliver = isDeliver;
	}

	public Calendar getDateOfClarification() {
		return dateOfClarification;
	}

	public void setDateOfClarification(Calendar dateOfClarification) {
		this.dateOfClarification = dateOfClarification;
	}

	public Character getReviewStatus() {
		return reviewStatus;
	}

	public void setReviewStatus(Character reviewStatus) {
		this.reviewStatus = reviewStatus;
	}
	public Calendar getprodDeliveryDate() {
		return prodDeliveryDate;
	}

	public void setprodDeliveryDate(Calendar prodDeliveryDate) {
		this.prodDeliveryDate = prodDeliveryDate;
	}
}
