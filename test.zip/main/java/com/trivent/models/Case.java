package com.trivent.models;

import java.util.Calendar;
import java.util.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.constants.AppConstants;
import com.trivent.models.base.BaseSoftDeletable;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.entity
 * 
 * @FileName 	:
 *				Case.java
 * @TypeName 	:
 * 				Case
 * @DateAndTime :
 *				Feb 8, 2018 - 4:01:24 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description :  To create , edit , save and view the Case details by
 *              fetching each required columns in this entity
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Entity
@Table(name = "cases", uniqueConstraints = @UniqueConstraint(columnNames = { "case_id" }))
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "case_id")) })
public class Case extends BaseSoftDeletable /*implements AuditLog*/ {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6170175009233835630L;

	public static final int NAME_MAX_LENGTH = 150;

	public static final String TYPE_PERSONAL = "Personal";
	public static final String TYPE_INJURY = "Injury";
	public static final String TYPE_MEDMAL = "MedMAL";

	public static final String CS_STATUS_NEW = "New";
	public static final String CLIENT_STATUS_NEW = "New";

	public static final String PROPERTY_CS_STATUS = "csStatus";
	public static final String PROPERTY_CLIENT_STATUS = "clientStatus";
	public static final String PROPERTY_CS_PRIORITY = "csPriority";
	public static final String PROPERTY_CLIENT_PRIORITY = "clientPriority";
	public static final String PROPERTY_ASSIGNED_TO = "assignedTo";
	public static final String PROPERTY_TYPE = "type";
	public static final String PROPERTY_NAME = "name";

	public static final String PROPERTY_PRODUCTION_STATUS = "productionStatus";

	@Column(name = "name", nullable = false)
	private String name = null;

	@Column(name = "case_code", nullable = false, length = 50)
	private String caseCode = null;

	@Column(name = "type", nullable = false, length = 80)
	private String type = null;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "client_id", nullable = false, foreignKey = @ForeignKey(name = "fk_cases_1"))
	private User client = null;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "account_id", nullable = false, foreignKey = @ForeignKey(name = "fk_cases_2"))
	private Account account = null;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "job_id", foreignKey = @ForeignKey(name = "fk_cases_3"))
	private Job job = null;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "parent_case_id", foreignKey = @ForeignKey(name = "fk_cases_4"))
	private Case parentCase = null;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "assigned_to", foreignKey = @ForeignKey(name = "fk_cases_5"))
	private User assignedTo = null;

	@Column(name = "client_priority", length = 20)
	private String clientPriority = null;

	@Column(name = "client_status", length = 20, nullable = false)
	private String clientStatus = CLIENT_STATUS_NEW;

	@Column(name = "service_requested_shortcode", length = 250)
	private String serviceRequestedShortCode = null;

	@Column(name = "cs_priority", length = 20)
	private String csPriority = null;

	@Column(name = "cs_status", length = 20, nullable = false)
	private String csStatus = CS_STATUS_NEW;

	@Column(name = "case_contact_name", length = 80)
	private String contactName = null;

	@Column(name = "case_contact_email_id", length = 1000)
	private String emailId = null;

	@Column(name = "case_sub_type", length = 80)
	private String subType = null;

	@Column(name = "case_total_page_count", length = 5)
	private Integer pageCount = null;

	@Column(name = "production_start_date")
	private Calendar prodStartDate = null;

	@Column(name = "production_end_date")
	private Calendar prodEndDate = null;

	@Column(name = "production_delivery_date")
	private Calendar prodDeliveryDate = null;

	@Column(name = "file_received_date")
	private Calendar fileReceivedDate = null;

	@Column(name = "expedited_delivery_date")
	private Calendar expeditedDeliveryDate = null;

	@Column(name = "file_delivery_date")
	private Calendar fileDeliveryDate = null;

	@Column(name = "file_migration_date")
	private Calendar fileMigrationDate = null;

	// Always stored in Minutes. Convert Hours and Minutes when displayed.
	@Column(name = "total_estimate_hours")
	private Integer estimateHours = 0;

	@Column(name = "total_approved_hours")
	private Integer approvedHours = 0;

	@Column(name = "total_discount_hours")
	private Integer discountHours = 0;

	@Column(name = "total_production_hours")
	private Integer productionHours = 0;

	@Column(name = "total_indirect_hours")
	private Integer indirectHours = 0;

	@Column(name = "total_invoice_hours")
	private Integer invoiceHours = 0;

	@Column(name = "total_deviation_hours")
	private Integer deviationHours = 0;

	@Column(name = "depsum_pages", length = 5)
	private Integer depsumPages = null;

	@Column(name = "estimate_request", nullable = false)
	private Character estimateRequest = AppConstants.NO;

	@Column(name = "expedited_request", nullable = false)
	private Character expeditedRequest = AppConstants.NO;

	@Column(name = "bates_reference", nullable = false)
	private Character batesReference = AppConstants.NO;

	@Column(name = "pdf_reference", nullable = false)
	private Character pdfReference = AppConstants.NO;

	@Column(name = "is_invoiced", nullable = false)
	private Character isInvoiced = AppConstants.NO;

	@Column(name = "balance_due", scale = 10, precision = 2)
	private Float balanceDue = null;

	@Column(name = "is_file_downloaded", nullable = false)
	private Character isFileDownloaded = AppConstants.NO;

	@Column(name = "downloaded_date_time")
	private Calendar downloadedDateTime = null;

	@Column(name = "download_count")
	private Integer downloadCount = null;

	// Long Text In Database. Length 5000 will create it as long text.

	@Column(name = "case_overview", length = 5000)
	private String caseOverview = null;

	@Column(name = "expedited_request_reason", length = 5000)
	private String expeditedRequestReason = null;

	@Column(name = "cs_description", length = 5000)
	private String description = null;

	@Column(name = "cs_notes", length = 5000)
	private String csNotes = null;

	@Column(name = "delay_reasons", length = 5000)
	private String delayReasons = null;

	@Column(name = "client_notes", length = 5000)
	private String clientNotes = null;

	// Custom Fields

	@Column(name = "custom_text_1", length = 1000)
	private String cf_1_Text = null;

	@Column(name = "custom_text_2", length = 250)
	private String cf_2_Text = null;

	@Column(name = "custom_text_3", length = 250)
	private String cf_3_Text = null;

	@Column(name = "custom_long_text_1", length = 5000)
	private String cf_1_LongText = null;

	@Column(name = "custom_long_text_2", length = 5000)
	private String cf_2_LongText = null;

	@Column(name = "custom_long_text_3", length = 5000)
	private String cf_3_LongText = null;

	@Column(name = "custom_char_1")
	private Character cf_1_YesNo = AppConstants.NO;

	@Column(name = "custom_char_2")
	private Character cf_2_YesNo = AppConstants.NO;

	@Column(name = "custom_char_3")
	private Character cf_3_YesNo = AppConstants.NO;

	@Column(name = "custom_date_1")
	private Calendar cf_1_Date = null;

	@Column(name = "custom_date_2")
	private Calendar cf_2_Date = null;

	@Column(name = "custom_date_3")
	private Calendar cf_3_Date = null;

	@Column(name = "custom_date_4")
	private Calendar cf_4_Date = null;

	@Column(name = "custom_date_5")
	private Calendar cf_5_Date = null;

	@Column(name = "custom_date_6")
	private Calendar cf_6_Date = null;

	@Column(name = "custom_date_7")
	private Calendar cf_7_Date = null;

	@Column(name = "custom_date_8")
	private Calendar cf_8_Date = null;

	@Column(name = "custom_hours_1")
	private Integer cf_1_Hours = 0;

	@Column(name = "custom_hours_2")
	private Integer cf_2_Hours = 0;

	@Column(name = "custom_hours_3")
	private Integer cf_3_Hours = 0;

	@Column(name = "custom_number_1")
	private Integer cf_1_Number = null;

	@Column(name = "custom_number_2")
	private Integer cf_2_Number = null;

	@Column(name = "custom_number_3")
	private Integer cf_3_Number = null;

	// Added on 11/07/2016 Demand column
	@Column(name = "is_demand")
	private Character isDemand = AppConstants.NO;

	// Added on 13/07/2016 Customer Final Download Confirmation Column
	@Column(name = "is_customer_downloaded")
	private Character isCustomerDownloaded = AppConstants.NO;

	// Added on 24/04/2017 Production Status in case Table
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "production_status", nullable = true, foreignKey = @ForeignKey(name = "fk_app_item_id"))
	private AppItem productionStatus = null;

	@Column(name = "estimate_provision_date")
	private Calendar estProvisionDate = null;

	@Column(name = "estimate_approved_date")
	private Calendar estApprovedDate = null;

	@Column(name = "date_of_clarrification")
	private Calendar dateOfClarrification = null;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "add_rec_date")
	private Date addRecordDate = null;

	@Column(name = "cs_delivery_date")
	private Calendar csDeliveryDate = null;

	@Column(name = "cs_estimate_send_date")
	private Calendar csEstimateSendDate = null;

	@Column(name = "production_estimate_send_date")
	private Calendar productionEstimateSendDate = null;

	@Column(name = "estimate_approval_received_date")
	private Calendar estimateApprovalReceivedDate = null;

	@Column(name = "revised_estimate_send_date")
	private Calendar revisedEstiamteSendDate = null;

	/********************** Audit Log methods **********************/

	/*@Override
	public String getAuditLogDetails() {
		StringBuilder sb = new StringBuilder();
		sb.append("Case Id : ").append(getId()).append(", Case Name : ").append(name).append(", Case Type : ")
				.append(type);
		return sb.toString();
	}*/

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		Case other = (Case) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCaseCode() {
		return caseCode;
	}

	public void setCaseCode(String caseCode) {
		this.caseCode = caseCode;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public User getClient() {
		return client;
	}

	public void setClient(User client) {
		this.client = client;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public Job getJob() {
		return job;
	}

	public void setJob(Job job) {
		this.job = job;
	}

	public Case getParentCase() {
		return parentCase;
	}

	public void setParentCase(Case parentCase) {
		this.parentCase = parentCase;
	}

	public User getAssignedTo() {
		return assignedTo;
	}

	public void setAssignedTo(User assignedTo) {
		this.assignedTo = assignedTo;
	}

	public Character getExpeditedRequest() {
		return expeditedRequest;
	}

	public void setExpeditedRequest(Character expeditedRequest) {
		this.expeditedRequest = expeditedRequest;
	}

	public String getCaseOverview() {
		return caseOverview;
	}

	public void setCaseOverview(String caseOverview) {
		this.caseOverview = caseOverview;
	}

	public String getClientPriority() {
		return clientPriority;
	}

	public void setClientPriority(String clientPriority) {
		this.clientPriority = clientPriority;
	}

	public String getClientNotes() {
		return clientNotes;
	}

	public void setClientNotes(String clientNotes) {
		this.clientNotes = clientNotes;
	}

	public String getClientStatus() {
		return clientStatus;
	}

	public void setClientStatus(String clientStatus) {
		this.clientStatus = clientStatus;
	}

	public String getCsPriority() {
		return csPriority;
	}

	public void setCsPriority(String csPriority) {
		this.csPriority = csPriority;
	}

	public String getCsNotes() {
		return csNotes;
	}

	public void setCsNotes(String csNotes) {
		this.csNotes = csNotes;
	}

	public String getCsStatus() {
		return csStatus;
	}

	public void setCsStatus(String csStatus) {
		this.csStatus = csStatus;
	}

	public String getContactName() {
		return contactName;
	}

	public void setContactName(String contactName) {
		this.contactName = contactName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public Integer getPageCount() {
		return pageCount;
	}

	public void setPageCount(Integer pageCount) {
		this.pageCount = pageCount;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Calendar getProdStartDate() {
		return prodStartDate;
	}

	public void setProdStartDate(Calendar prodStartDate) {
		this.prodStartDate = prodStartDate;
	}

	public Calendar getProdEndDate() {
		return prodEndDate;
	}

	public void setProdEndDate(Calendar prodEndDate) {
		this.prodEndDate = prodEndDate;
	}

	public Calendar getProdDeliveryDate() {
		return prodDeliveryDate;
	}

	public void setProdDeliveryDate(Calendar prodDeliveryDate) {
		this.prodDeliveryDate = prodDeliveryDate;
	}

	public Calendar getFileReceivedDate() {
		return fileReceivedDate;
	}

	public void setFileReceivedDate(Calendar fileReceivedDate) {
		this.fileReceivedDate = fileReceivedDate;
	}

	public Calendar getExpeditedDeliveryDate() {
		return expeditedDeliveryDate;
	}

	public void setExpeditedDeliveryDate(Calendar expeditedDeliveryDate) {
		this.expeditedDeliveryDate = expeditedDeliveryDate;
	}

	public Calendar getFileDeliveryDate() {
		return fileDeliveryDate;
	}

	public void setFileDeliveryDate(Calendar fileDeliveryDate) {
		this.fileDeliveryDate = fileDeliveryDate;
	}

	public Calendar getFileMigrationDate() {
		return fileMigrationDate;
	}

	public void setFileMigrationDate(Calendar fileMigrationDate) {
		this.fileMigrationDate = fileMigrationDate;
	}

	public Integer getEstimateHours() {
		return estimateHours;
	}

	public void setEstimateHours(Integer estimateHours) {
		this.estimateHours = estimateHours;
	}

	public Integer getApprovedHours() {
		return approvedHours;
	}

	public void setApprovedHours(Integer approvedHours) {
		this.approvedHours = approvedHours;
	}

	public Integer getDiscountHours() {
		return discountHours;
	}

	public void setDiscountHours(Integer discountHours) {
		this.discountHours = discountHours;
	}

	public Integer getProductionHours() {
		return productionHours;
	}

	public void setProductionHours(Integer productionHours) {
		this.productionHours = productionHours;
	}

	public Integer getIndirectHours() {
		return indirectHours;
	}

	public void setIndirectHours(Integer indirectHours) {
		this.indirectHours = indirectHours;
	}

	public Integer getInvoiceHours() {
		return invoiceHours;
	}

	public void setInvoiceHours(Integer invoiceHours) {
		this.invoiceHours = invoiceHours;
	}

	public Integer getDeviationHours() {
		return deviationHours;
	}

	public void setDeviationHours(Integer deviationHours) {
		this.deviationHours = deviationHours;
	}

	public String getDelayReasons() {
		return delayReasons;
	}

	public void setDelayReasons(String delayReasons) {
		this.delayReasons = delayReasons;
	}

	public Integer getDepsumPages() {
		return depsumPages;
	}

	public void setDepsumPages(Integer depsumPages) {
		this.depsumPages = depsumPages;
	}

	public Character getBatesReference() {
		return batesReference;
	}

	public void setBatesReference(Character batesReference) {
		this.batesReference = batesReference;
	}

	public Character getPdfReference() {
		return pdfReference;
	}

	public void setPdfReference(Character pdfReference) {
		this.pdfReference = pdfReference;
	}

	public Character getIsInvoiced() {
		return isInvoiced;
	}

	public void setIsInvoiced(Character isInvoiced) {
		this.isInvoiced = isInvoiced;
	}

	public Float getBalanceDue() {
		return balanceDue;
	}

	public void setBalanceDue(Float balanceDue) {
		this.balanceDue = balanceDue;
	}

	public String getExpeditedRequestReason() {
		return expeditedRequestReason;
	}

	public void setExpeditedRequestReason(String expeditedRequestReason) {
		this.expeditedRequestReason = expeditedRequestReason;
	}

	public Character getEstimateRequest() {
		return estimateRequest;
	}

	public void setEstimateRequest(Character estimateRequest) {
		this.estimateRequest = estimateRequest;
	}

	public String getServiceRequestedShortCode() {
		return serviceRequestedShortCode;
	}

	public void setServiceRequestedShortCode(String serviceRequestedShortCode) {
		this.serviceRequestedShortCode = serviceRequestedShortCode;
	}

	public Character getIsFileDownloaded() {
		return isFileDownloaded;
	}

	public void setIsFileDownloaded(Character isFileDownloaded) {
		this.isFileDownloaded = isFileDownloaded;
	}

	public Calendar getDownloadedDateTime() {
		return downloadedDateTime;
	}

	public void setDownloadedDateTime(Calendar downloadedDateTime) {
		this.downloadedDateTime = downloadedDateTime;
	}

	public Integer getDownloadCount() {
		return downloadCount;
	}

	public void setDownloadCount(Integer downloadCount) {
		this.downloadCount = downloadCount;
	}

	public String getCf_1_Text() {
		return cf_1_Text;
	}

	public void setCf_1_Text(String cf_1_Text) {
		this.cf_1_Text = cf_1_Text;
	}

	public String getCf_2_Text() {
		return cf_2_Text;
	}

	public void setCf_2_Text(String cf_2_Text) {
		this.cf_2_Text = cf_2_Text;
	}

	public String getCf_3_Text() {
		return cf_3_Text;
	}

	public void setCf_3_Text(String cf_3_Text) {
		this.cf_3_Text = cf_3_Text;
	}

	public String getCf_1_LongText() {
		return cf_1_LongText;
	}

	public void setCf_1_LongText(String cf_1_LongText) {
		this.cf_1_LongText = cf_1_LongText;
	}

	public String getCf_2_LongText() {
		return cf_2_LongText;
	}

	public void setCf_2_LongText(String cf_2_LongText) {
		this.cf_2_LongText = cf_2_LongText;
	}

	public String getCf_3_LongText() {
		return cf_3_LongText;
	}

	public void setCf_3_LongText(String cf_3_LongText) {
		this.cf_3_LongText = cf_3_LongText;
	}

	public Character getCf_1_YesNo() {
		return cf_1_YesNo;
	}

	public void setCf_1_YesNo(Character cf_1_YesNo) {
		this.cf_1_YesNo = cf_1_YesNo;
	}

	public Character getCf_2_YesNo() {
		return cf_2_YesNo;
	}

	public void setCf_2_YesNo(Character cf_2_YesNo) {
		this.cf_2_YesNo = cf_2_YesNo;
	}

	public Character getCf_3_YesNo() {
		return cf_3_YesNo;
	}

	public void setCf_3_YesNo(Character cf_3_YesNo) {
		this.cf_3_YesNo = cf_3_YesNo;
	}

	public Calendar getCf_1_Date() {
		return cf_1_Date;
	}

	public void setCf_1_Date(Calendar cf_1_Date) {
		this.cf_1_Date = cf_1_Date;
	}

	public Calendar getCf_2_Date() {
		return cf_2_Date;
	}

	public void setCf_2_Date(Calendar cf_2_Date) {
		this.cf_2_Date = cf_2_Date;
	}

	public Calendar getCf_3_Date() {
		return cf_3_Date;
	}

	public void setCf_3_Date(Calendar cf_3_Date) {
		this.cf_3_Date = cf_3_Date;
	}

	public Integer getCf_1_Hours() {
		return cf_1_Hours;
	}

	public void setCf_1_Hours(Integer cf_1_Hours) {
		this.cf_1_Hours = cf_1_Hours;
	}

	public Integer getCf_2_Hours() {
		return cf_2_Hours;
	}

	public void setCf_2_Hours(Integer cf_2_Hours) {
		this.cf_2_Hours = cf_2_Hours;
	}

	public Integer getCf_3_Hours() {
		return cf_3_Hours;
	}

	public void setCf_3_Hours(Integer cf_3_Hours) {
		this.cf_3_Hours = cf_3_Hours;
	}

	public Integer getCf_1_Number() {
		return cf_1_Number;
	}

	public void setCf_1_Number(Integer cf_1_Number) {
		this.cf_1_Number = cf_1_Number;
	}

	public Integer getCf_2_Number() {
		return cf_2_Number;
	}

	public void setCf_2_Number(Integer cf_2_Number) {
		this.cf_2_Number = cf_2_Number;
	}

	public Integer getCf_3_Number() {
		return cf_3_Number;
	}

	public void setCf_3_Number(Integer cf_3_Number) {
		this.cf_3_Number = cf_3_Number;
	}

	// Added on 11/07/2016 for Demand get,set
	public Character getIsDemand() {
		return isDemand;
	}

	public void setIsDemand(Character isDemand) {
		this.isDemand = isDemand;
	}

	// Added on 13/07/2016 for Customer Final Download Confirmation
	public Character getIsCustomerDownload() {
		return isCustomerDownloaded;
	}

	public void setIsCustomerDownload(Character isCustomerDownloaded) {
		this.isCustomerDownloaded = isCustomerDownloaded;
	}

	// Added on 24/04/2017 Production Status in case Table
	public AppItem getProductionStatus() {
		return productionStatus;
	}

	public void setProductionStatus(AppItem productionStatus) {
		this.productionStatus = productionStatus;
	}

	// Added on 18/05/2017 estimated provision and estimated approved date in
	// case table
	public Calendar getEstProvisionDate() {
		return estProvisionDate;
	}

	public void setEstProvisionDate(Calendar estProvisionDate) {
		this.estProvisionDate = estProvisionDate;
	}

	public Calendar getEstApprovedDate() {
		return estApprovedDate;
	}

	public void setEstApprovedDate(Calendar estApprovedDate) {
		this.estApprovedDate = estApprovedDate;
	}

	public Calendar getDateOfClarrification() {
		return dateOfClarrification;
	}

	public void setDateOfClarrification(Calendar dateOfClarrification) {
		this.dateOfClarrification = dateOfClarrification;
	}

	public Date getAddRecordDate() {
		return addRecordDate;
	}

	public void setAddRecordDate(Date addRecordDate) {
		this.addRecordDate = addRecordDate;
	}

	public Calendar getCf_4_Date() {
		return cf_4_Date;
	}

	public void setCf_4_Date(Calendar cf_4_Date) {
		this.cf_4_Date = cf_4_Date;
	}

	public Calendar getCf_5_Date() {
		return cf_5_Date;
	}

	public void setCf_5_Date(Calendar cf_5_Date) {
		this.cf_5_Date = cf_5_Date;
	}

	public Calendar getCf_6_Date() {
		return cf_6_Date;
	}

	public void setCf_6_Date(Calendar cf_6_Date) {
		this.cf_6_Date = cf_6_Date;
	}

	public Calendar getCf_7_Date() {
		return cf_7_Date;
	}

	public void setCf_7_Date(Calendar cf_7_Date) {
		this.cf_7_Date = cf_7_Date;
	}

	public Calendar getCf_8_Date() {
		return cf_8_Date;
	}

	public void setCf_8_Date(Calendar cf_8_Date) {
		this.cf_8_Date = cf_8_Date;
	}

	public Calendar getCsDeliveryDate() {
		return csDeliveryDate;
	}

	public void setCsDeliveryDate(Calendar csDeliveryDate) {
		this.csDeliveryDate = csDeliveryDate;
	}

	public Calendar getCsEstimateSendDate() {
		return csEstimateSendDate;
	}

	public void setCsEstimateSendDate(Calendar csEstimateSendDate) {
		this.csEstimateSendDate = csEstimateSendDate;
	}

	public Calendar getProductionEstimateSendDate() {
		return productionEstimateSendDate;
	}

	public void setProductionEstimateSendDate(Calendar productionEstimateSendDate) {
		this.productionEstimateSendDate = productionEstimateSendDate;
	}

	public Calendar getEstimateApprovalReceivedDate() {
		return estimateApprovalReceivedDate;
	}

	public void setEstimateApprovalReceivedDate(Calendar estimateApprovalReceivedDate) {
		this.estimateApprovalReceivedDate = estimateApprovalReceivedDate;
	}

	public Calendar getRevisedEstiamteSendDate() {
		return revisedEstiamteSendDate;
	}

	public void setRevisedEstiamteSendDate(Calendar revisedEstiamteSendDate) {
		this.revisedEstiamteSendDate = revisedEstiamteSendDate;
	}
}