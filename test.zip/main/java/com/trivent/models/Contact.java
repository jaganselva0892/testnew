package com.trivent.models;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.models.base.BaseContact;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.entity
 * 
 * @FileName 	:
 *				Contact.java
 * @TypeName 	:
 * 				Contact
 * @DateAndTime :
 *				Feb 8, 2018 - 4:06:19 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description : To create , edit , save and view the Contact details by
 *              fetching each required columns in this entity
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Entity
@Table(name = "contacts")
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "contact_id")) })
public class Contact extends BaseContact {

	

	/**
	 * 
	 */
	private static final long serialVersionUID = 7110472164827423617L;
	public static final String ENTITY_PARTNER = "Partner";
	public static final String ENTITY_ACCOUNT = "Account";
	public static final String ENTITY_USER = "User";

	public static final String TYPE_INDIVIDUAL = "Individual";
	public static final String TYPE_ORGANIZATION = "Organization";
	public static final String TYPE_GUEST = "Guest";

	@Column(name = "entity_id", nullable = false)
	private Long entityId = null;

	@Column(name = "entity", length = 30, nullable = false)
	private String entity = null;

	@Column(name = "seq_no", nullable = false)
	private Integer seqNo;

	@Column(name = "type", length = 30, nullable = false)
	private String type = Contact.TYPE_INDIVIDUAL;
	
	@Column(name = "user_id")
	private Long userId = null;
	
	@Column(name = "contact_type", length = 10)
	private String contactType = null;

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		Contact other = (Contact) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public Long getEntityId() {
		return entityId;
	}

	public void setEntityId(Long entityId) {
		this.entityId = entityId;
	}

	public String getEntity() {
		return entity;
	}

	public void setEntity(String entity) {
		this.entity = entity;
	}

	public Integer getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(Integer seqNo) {
		this.seqNo = seqNo;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getContactType() {
		return contactType;
	}

	public void setContactType(String contactType) {
		this.contactType = contactType;
	}
	
	

}