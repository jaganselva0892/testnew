package com.trivent.models;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.constants.AppConstants;
import com.trivent.models.base.BaseEntity;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.entity
 * 
 * @FileName 	:
 *				ReportField.java
 * @TypeName 	:
 * 				ReportField
 * @DateAndTime :
 *				Feb 8, 2018 - 4:58:15 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description : To create , edit , save and view the Report Field Details for users by
 *              fetching each required columns in this entity
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Entity
@Table(name = "report_fields")
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "report_field_id")) })
public class ReportField extends BaseEntity {

  private static final long serialVersionUID = -206769723617430971L;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "report_id", nullable = false)
  private Report report = null;

  @Column(name = "seq_no")
  private Integer seqNo = null;

  @Column(name = "column_name", length = 150)
  private String columnName = null;

  @Column(name = "is_mandatory")
  private Character mandatory = AppConstants.NO;

  @Column(name = "default_value", length = 150)
  private String defaultValue = null;

  @Column(name = "data_type", length = 50)
  private String dataType = null;

  @Column(name = "look_up_column", length = 150)
  private String lookUpColumn = null;

  @Column(name = "sort_by", length = 20)
  private String sortBy = null;

  @Column(name = "comparision_operator", length = 20)
  private String comparisionOperator = null;

  @Column(name = "rhs_field_value", length = 100)
  private String rhsFieldValue = null;

  /********************** hashcode, and equals methods **********************/

  @Override
  public int hashCode() {
    return new HashCodeBuilder().append(this.getId()).hashCode();
  }

  @Override
  public boolean equals(Object obj) {
    if (obj == null || obj.getClass() != getClass()) {
      return false;
    }
    ReportField other = (ReportField) obj;
    return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
  }

  /********************** Getters and Setters **********************/

  public Report getReport() {
    return report;
  }

  public void setReport(Report report) {
    this.report = report;
  }

  public Integer getSeqNo() {
    return seqNo;
  }

  public void setSeqNo(Integer seqNo) {
    this.seqNo = seqNo;
  }

  public String getColumnName() {
    return columnName;
  }

  public void setColumnName(String columnName) {
    this.columnName = columnName;
  }

  public Character getMandatory() {
    return mandatory;
  }

  public void setMandatory(Character mandatory) {
    this.mandatory = mandatory;
  }

  public String getDefaultValue() {
    return defaultValue;
  }

  public void setDefaultValue(String defaultValue) {
    this.defaultValue = defaultValue;
  }

  public String getLookUpColumn() {
    return lookUpColumn;
  }

  public void setLookUpColumn(String lookUpColumn) {
    this.lookUpColumn = lookUpColumn;
  }

  public String getSortBy() {
    return sortBy;
  }

  public void setSortBy(String sortBy) {
    this.sortBy = sortBy;
  }

  public String getComparisionOperator() {
    return comparisionOperator;
  }

  public void setComparisionOperator(String comparisionOperator) {
    this.comparisionOperator = comparisionOperator;
  }

  public String getRhsFieldValue() {
    return rhsFieldValue;
  }

  public void setRhsFieldValue(String rhsFieldValue) {
    this.rhsFieldValue = rhsFieldValue;
  }

  public String getDataType() {
    return dataType;
  }

  public void setDataType(String dataType) {
    this.dataType = dataType;
  }

}
