package com.trivent.models;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.constants.AppConstants;
import com.trivent.models.base.BaseEntity;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.entity
 * 
 * @FileName 	:
 *				Permission.java
 * @TypeName 	:
 * 				Permission
 * @DateAndTime :
 *				Feb 8, 2018 - 4:10:14 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description :To create , edit , save and view the Permissions for users by
 *              fetching each required columns in this entity 
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Entity
@Table(name = "permissions", uniqueConstraints = @UniqueConstraint(columnNames = { "role_id", "capability_id" }))
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "permission_id")) })
public class Permission extends BaseEntity {

  

  /**
	 * 
	 */
  private static final long serialVersionUID = 6047525004630083838L;
  public static final String VISIBLE = "visible";
  public static final String CREATE = "create";
  public static final String READ = "read";
  public static final String UPDATE = "update";
  public static final String DELETE = "delete";

  public static final String SAVE = "save";

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "role_id", nullable = false, foreignKey = @ForeignKey(name = "fk_permission_1"))
  private Role role;

  @ManyToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "capability_id", nullable = false, foreignKey = @ForeignKey(name = "fk_permission_2"))
  private Capability capability;

  @Column(name = "is_visible", nullable = false)
  private Character visible = AppConstants.NO;

  @Column(name = "is_create", nullable = false)
  private Character create = AppConstants.NO;

  @Column(name = "is_read", nullable = false)
  private Character read = AppConstants.NO;

  @Column(name = "is_update", nullable = false)
  private Character update = AppConstants.NO;

  @Column(name = "is_delete", nullable = false)
  private Character delete = AppConstants.NO;

  public Permission() {
  }

  public Permission(Role role, Capability capability) {
    this.role = role;
    this.capability = capability;
  }

  /********************** hashcode, and equals methods **********************/

  @Override
  public int hashCode() {
    return new HashCodeBuilder().append(this.getId()).hashCode();
  }

  @Override
  public boolean equals(Object obj) {
    if (obj == null || obj.getClass() != getClass()) {
      return false;
    }
    Permission other = (Permission) obj;
    return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
  }

  /********************** Custom methods **********************/

  public boolean isVisible() {
    return visible == AppConstants.YES;
  }

  public boolean isCreate() {
    return create == AppConstants.YES;
  }

  public boolean isRead() {
    return read == AppConstants.YES;
  }

  public boolean isUpdate() {
    return update == AppConstants.YES;
  }

  public boolean isDelete() {
    return delete == AppConstants.YES;
  }

  /********************** Getters and Setters **********************/

  public Role getRole() {
    return role;
  }

  public void setRole(Role role) {
    this.role = role;
  }

  public Capability getCapability() {
    return capability;
  }

  public void setCapability(Capability capability) {
    this.capability = capability;
  }

  public Character getVisible() {
    return visible;
  }

  public void setVisible(Character visible) {
    this.visible = visible;
  }

  public Character getCreate() {
    return create;
  }

  public void setCreate(Character create) {
    this.create = create;
  }

  public Character getRead() {
    return read;
  }

  public void setRead(Character read) {
    this.read = read;
  }

  public Character getUpdate() {
    return update;
  }

  public void setUpdate(Character update) {
    this.update = update;
  }

  public Character getDelete() {
    return delete;
  }

  public void setDelete(Character delete) {
    this.delete = delete;
  }

}