package com.trivent.models;

import java.util.Calendar;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.constants.AppConstants;
import com.trivent.models.base.BaseSoftDeletable;

/**
 * @ProjectName : trivent
 * @PackageName : com.trivent.entity
 * 
 * @FileName : CaseFile.java
 * @TypeName : CaseFile
 * @DateAndTime : Feb 8, 2018 - 4:02:19 PM
 * 
 * @Author : seetha
 * 
 * @Description : To create , edit , save and view the CaseFile details by
 *              fetching each required columns in this entity
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
@Entity
@Table(name = "case_files"/*, uniqueConstraints = @UniqueConstraint(columnNames = { "case_id", "name" })*/)
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "case_file_id")) })
public class CaseFile extends BaseSoftDeletable {

	

	/**
	 * 
	 */
	private static final long serialVersionUID = -5977823631644779161L;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "case_id", nullable = false, foreignKey = @ForeignKey(name = "fk_case_file_1"))
	private Case clientCase = null;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "client_id", nullable = false, foreignKey = @ForeignKey(name = "fk_case_file_2"))
	private User client = null;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "account_id", nullable = false, foreignKey = @ForeignKey(name = "fk_case_file_3"))
	private Account account = null;

	@Column(name = "name", nullable = false, length = 500)
	private String name = null;

	@Column(name = "file_extension", nullable = false, length = 10)
	private String fileExtension = null;

	@Column(name = "file_content_type", nullable = false, length = 80)
	private String fileContentType = null;

	@Column(name = "is_zipped", nullable = false)
	private Character fileZipped = AppConstants.NO;

	@Column(name = "seq_no", nullable = false)
	private Integer seqNo = null;

	@Column(name = "file_description", length = 1000)
	private String fileDescription = null;

	@Column(name = "file_location", nullable = false, length = 500)
	private String fileLocation = null;

	@Column(name = "file_size", nullable = false)
	private Long fileSize = null;

	@Column(name = "notes", length = 2000)
	private String notes = null;

	@Column(name = "is_latest", length = 1)
	private Character isLatest = AppConstants.YES;

	@Column(name = "replicated_file_location", length = 1000)
	private String replicatedFileLocation = null;

	@Column(name = "replicated_date")
	private Calendar replicatedDate = null;

	@Column(name = "replicated_type", length = 10)
	private String replicatedType = null;

	@Column(name = "replicated_path", length = 1000)
	private String replicatedPath = null;

	@Column(name = "root_path", length = 1000)
	private String rootPath = null;

	@Column(name = "version")
	private Integer version = null;

	@Column(name = "file_page_count")
	private Integer filePageCount = 0;

	@Column(name = "page_count_status", length = 50)
	private String pageCountStatus;

	@Column(name = "upload_remotely")
	private Character uploadRemotely = AppConstants.NO;

	@Column(name = "file_type")
	private Integer fileType = 1;

	@Column(name = "source_case_file_id")
	private Long sourceCaseFileId;

	@Column(name = "is_archival")
	private Character archived = AppConstants.NO;

	@Column(name = "cur_status")
	private String curStatus = AppConstants.TRACE_NEW;

	@Column(name = "cus_msg")
	private String curMsg = null;

	@Column(name = "file_from")
	private String fileFrom = AppConstants.TRACE_AWS;

	@Column(name = "is_backup")
	private Character backup = AppConstants.NO;

	@Column(name = "is_remove")
	private Character removeFile = AppConstants.NO;

	@Column(name = "additional_rec_id")
	private Long additionalRecId;

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		CaseFile other = (CaseFile) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public Case getClientCase() {
		return clientCase;
	}

	public void setClientCase(Case clientCase) {
		this.clientCase = clientCase;
	}

	public User getClient() {
		return client;
	}

	public void setClient(User client) {
		this.client = client;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFileExtension() {
		return fileExtension;
	}

	public void setFileExtension(String fileExtension) {
		this.fileExtension = fileExtension;
	}

	public String getFileContentType() {
		return fileContentType;
	}

	public void setFileContentType(String fileContentType) {
		this.fileContentType = fileContentType;
	}

	public Character getFileZipped() {
		return fileZipped;
	}

	public void setFileZipped(Character fileZipped) {
		this.fileZipped = fileZipped;
	}

	public Integer getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(Integer seqNo) {
		this.seqNo = seqNo;
	}

	public String getFileDescription() {
		return fileDescription;
	}

	public void setFileDescription(String fileDescription) {
		this.fileDescription = fileDescription;
	}

	public String getFileLocation() {
		return fileLocation;
	}

	public void setFileLocation(String fileLocation) {
		this.fileLocation = fileLocation;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public String getReplicatedFileLocation() {
		return replicatedFileLocation;
	}

	public void setReplicatedFileLocation(String replicatedFileLocation) {
		this.replicatedFileLocation = replicatedFileLocation;
	}

	public Calendar getReplicatedDate() {
		return replicatedDate;
	}

	public void setReplicatedDate(Calendar replicatedDate) {
		this.replicatedDate = replicatedDate;
	}

	public String getReplicatedType() {
		return replicatedType;
	}

	public void setReplicatedType(String replicatedType) {
		this.replicatedType = replicatedType;
	}

	public String getReplicatedPath() {
		return replicatedPath;
	}

	public void setReplicatedPath(String replicatedPath) {
		this.replicatedPath = replicatedPath;
	}

	public String getRootPath() {
		return rootPath;
	}

	public void setRootPath(String rootPath) {
		this.rootPath = rootPath;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public Integer getFilePageCount() {
		return filePageCount;
	}

	public void setFilePageCount(Integer filePageCount) {
		this.filePageCount = filePageCount;
	}

	public Character getIsLatest() {
		return isLatest;
	}

	public void setIsLatest(Character isLatest) {
		this.isLatest = isLatest;
	}

	public Long getFileSize() {
		return fileSize;
	}

	public void setFileSize(Long fileSize) {
		this.fileSize = fileSize;
	}

	public String getPageCountStatus() {
		return pageCountStatus;
	}

	public void setPageCountStatus(String pageCountStatus) {
		this.pageCountStatus = pageCountStatus;
	}

	public Character getUploadRemotely() {
		return uploadRemotely;
	}

	public void setUploadRemotely(Character uploadRemotely) {
		this.uploadRemotely = uploadRemotely;
	}

	public Integer getFileType() {
		return fileType;
	}

	public void setFileType(Integer fileType) {
		this.fileType = fileType;
	}

	public Long getSourceCaseFileId() {
		return sourceCaseFileId;
	}

	public void setSourceCaseFileId(Long sourceCaseFileId) {
		this.sourceCaseFileId = sourceCaseFileId;
	}

	/********************** boolean getters **********************/

	public boolean isDeleted() {
		return archived == AppConstants.YES;
	}

	/********************** Getters and Setters **********************/

	public Character getArchived() {
		return archived;
	}

	public void setArchived(Character archived) {
		this.archived = archived;
	}

	public String getCurStatus() {
		return curStatus;
	}

	public void setCurStatus(String curStatus) {
		this.curStatus = curStatus;
	}

	public String getCurMsg() {
		return curMsg;
	}

	public void setCurMsg(String curMsg) {
		this.curMsg = curMsg;
	}

	public String getFileFrom() {
		return fileFrom;
	}

	public void setFileFrom(String fileFrom) {
		this.fileFrom = fileFrom;
	}

	public Character getBackup() {
		return backup;
	}

	public void setBackup(Character backup) {
		this.backup = backup;
	}

	public Character getRemoveFile() {
		return removeFile;
	}

	public void setRemoveFile(Character removeFile) {
		this.removeFile = removeFile;
	}

	public Long getAdditionalRecId() {
		return additionalRecId;
	}

	public void setAdditionalRecId(Long additionalRecId) {
		this.additionalRecId = additionalRecId;
	}
}