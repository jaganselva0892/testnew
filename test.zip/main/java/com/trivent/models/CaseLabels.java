package com.trivent.models;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.models.base.BaseSoftDeletable;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.entity
 * 
 * @FileName 	:
 *				CaseLabels.java
 * @TypeName 	:
 * 				CaseLabels
 * @DateAndTime :
 *				Feb 8, 2018 - 4:02:53 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description : To create , edit , save and view the CaseLabels details by
 *              fetching each required columns in this entity
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Entity
@Table(name = "case_labels")
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "case_label_id")) })
public class CaseLabels extends BaseSoftDeletable {

	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1374916186918705548L;

	@Column(name = "app_label_id", nullable = false)
	private Long appLabelId = null;

	@Column(name = "caseId", nullable = false)
	private Long caseId = null;

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		CaseLabels other = (CaseLabels) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public Long getAppLabelId() {
		return appLabelId;
	}

	public void setAppLabelId(Long appLabelId) {
		this.appLabelId = appLabelId;
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}
}
