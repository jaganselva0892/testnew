package com.trivent.models;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.models.base.BaseSoftDeletable;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.entity
 * 
 * @FileName 	:
 *				AppServiceDesc.java
 * @TypeName 	:
 * 				AppServiceDesc
 * @DateAndTime :
 *				Feb 8, 2018 - 3:56:25 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description : To create , edit , save and view the Approval Service Description  details by
 *              fetching each required columns in this entity
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Entity
@Table(name = "app_service_desc")
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "app_service_id")) })
public class AppServiceDesc extends BaseSoftDeletable {

	

	/**
	 * 
	 */
	private static final long serialVersionUID = 3108956946872512096L;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "partner_code", nullable = false, foreignKey = @ForeignKey(name = "fk_partercode"))
	private Partner partnerCode;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "main_service", nullable = false, foreignKey = @ForeignKey(name = "fk_main_service"))
	private AppItem mainService;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "sub_service", nullable = false, foreignKey = @ForeignKey(name = "fk_sub_service"))
	private AppSubItem subService;

	@Column(name = "tool_tip", nullable = false, length = 350)
	private String toolTip;

	@Column(name = "service_link", nullable = false)
	private String serviceLink;

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		AppServiceDesc other = (AppServiceDesc) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/
	public Partner getPartnerCode() {
		return partnerCode;
	}

	public void setPartnerCode(Partner partnerCode) {
		this.partnerCode = partnerCode;
	}

	public AppItem getMainService() {
		return mainService;
	}

	public void setMainService(AppItem mainService) {
		this.mainService = mainService;
	}

	public AppSubItem getSubService() {
		return subService;
	}

	public void setSubService(AppSubItem subService) {
		this.subService = subService;
	}

	public String getToolTip() {
		return toolTip;
	}

	public void setToolTip(String toolTip) {
		this.toolTip = toolTip;
	}

	public String getServiceLink() {
		return serviceLink;
	}

	public void setServiceLink(String serviceLink) {
		this.serviceLink = serviceLink;
	}
}
