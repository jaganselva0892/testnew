package com.trivent.models;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.models.base.BaseEntity;

/**
 * @ProjectName : trivent
 * @PackageName : com.trivent.entity
 * 
 * @FileName : AppSequenceRef.java
 * @TypeName : AppSequenceRef
 * @DateAndTime : Feb 8, 2018 - 3:55:27 PM
 * 
 * @Author : seetha
 * 
 * @Description : To create , edit , save and view the Approval Sequence
 *              Reference details by fetching each required columns in this
 *              entity
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
@Entity
@Table(name = "app_sequence_ref", uniqueConstraints = @UniqueConstraint(columnNames = { "object_type", "object_code" }))
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "app_sequence_ref_id")) })
public class AppSequenceRef extends BaseEntity {

	

	/**
	 * 
	 */
	private static final long serialVersionUID = -4781253411424553412L;
	public static final String OBJECT_TYPE_ACCOUNT = "Account";
	public static final String OBJECT_TYPE_USER = "User";
	public static final String OBJECT_TYPE_CASE = "Case";
	public static final String OBJECT_TYPE_BRANCH = "Branch";
	public static final String OBJECT_TYPE_ADD_ADDITIONAL_REC = "AddAdditionalRec";

	@Column(name = "object_type", nullable = false, length = 20)
	private String objType;

	@Column(name = "object_code", nullable = false, length = 20)
	private String objCode;

	@Column(name = "object_code_sequence", nullable = false)
	private Integer objCodeSeq;

	public AppSequenceRef() {
	}

	public AppSequenceRef(String objType, String objCode, Integer objCodeSeq) {
		this.setObjType(objType);
		this.setObjCode(objCode);
		this.setObjCodeSeq(objCodeSeq);
	}

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		AppSequenceRef other = (AppSequenceRef) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public String getObjType() {
		return objType;
	}

	public void setObjType(String objType) {
		this.objType = objType;
	}

	public String getObjCode() {
		return objCode;
	}

	public void setObjCode(String objCode) {
		this.objCode = objCode;
	}

	public Integer getObjCodeSeq() {
		return objCodeSeq;
	}

	public void setObjCodeSeq(Integer objCodeSeq) {
		this.objCodeSeq = objCodeSeq;
	}

}
