package com.trivent.models;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.models.base.BaseSoftDeletable;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.entity
 * 
 * @FileName 	:
 *				Team.java
 * @TypeName 	:
 * 				Team
 * @DateAndTime :
 *				Feb 8, 2018 - 5:00:28 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description : To create , edit , save and view the Team of Trivent Users  by
 *              fetching each required columns in this entity
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Entity
@Table(name = "teams")
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "team_id")) })
public class Team extends BaseSoftDeletable {

  
  /**
	 * 
	 */
  private static final long serialVersionUID = -7124044871096441595L;

  public static final int NAME_MAX_LENGTH = 150;

  @Column(name = "name", nullable = false, length = 150, unique = true)
  private String name = null;

  @Column(name = "description", nullable = false, length = 500)
  private String description = null;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "division_id", nullable = false, foreignKey = @ForeignKey(name = "fk_teams_1"))
  private Division division;

  /********************** hashcode, and equals methods **********************/

  @Override
  public int hashCode() {
    return new HashCodeBuilder().append(this.getId()).hashCode();
  }

  @Override
  public boolean equals(Object obj) {
    if (obj == null || obj.getClass() != getClass()) {
      return false;
    }
    Team other = (Team) obj;
    return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
  }

  /********************** Getters and Setters **********************/

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public Division getDivision() {
    return division;
  }

  public void setDivision(Division division) {
    this.division = division;
  }

}
