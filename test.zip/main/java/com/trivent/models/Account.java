package com.trivent.models;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.constants.AppConstants;
import com.trivent.models.base.BaseContact;

/**
 * @ProjectName : trivent
 * @PackageName : com.trivent.entity
 * 
 * @FileName : Account.java
 * @TypeName : Account
 * @DateAndTime : Nov 21, 2018 - 3:25:02 PM
 * 
 * @Author : karthi
 * 
 * @Description : To create , edit , save and view the account details by
 *              fetching each required columns in this entity
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
@Entity
@Table(name = "accounts", uniqueConstraints = @UniqueConstraint(columnNames = { "partner_id", "name" }))
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "account_id")) })
public class Account extends BaseContact  {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6340295200494312203L;

	public static final int NAME_MAX_LENGTH = 150;

	@Column(name = "name", nullable = false, length = 150)
	private String name;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "partner_id", nullable = false, foreignKey = @ForeignKey(name = "fk_accounts_1"))
	private Partner partner;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "account_manager_id", nullable = false, foreignKey = @ForeignKey(name = "fk_accounts_2"))
	private User accountManager;

	@Column(name = "account_type", nullable = false, length = 30)
	private String accountType = Contact.TYPE_INDIVIDUAL;

	@Column(name = "account_code", nullable = false, length = 20)
	private String accountCode;

	@Column(name = "display_welcome_screen", nullable = false)
	private Character displayWelcomeScreen = AppConstants.YES;

	@Column(name = "display_account_cases", nullable = false)
	private Character displayAccountCases = AppConstants.YES;

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		Account other = (Account) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Partner getPartner() {
		return partner;
	}

	public void setPartner(Partner partner) {
		this.partner = partner;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public Character getDisplayWelcomeScreen() {
		return displayWelcomeScreen;
	}

	public void setDisplayWelcomeScreen(Character displayWelcomeScreen) {
		this.displayWelcomeScreen = displayWelcomeScreen;
	}

	public Character getDisplayAccountCases() {
		return displayAccountCases;
	}

	public void setDisplayAccountCases(Character displayAccountCases) {
		this.displayAccountCases = displayAccountCases;
	}

	public User getAccountManager() {
		return accountManager;
	}

	public void setAccountManager(User accountManager) {
		this.accountManager = accountManager;
	}

	public String getAccountCode() {
		return accountCode;
	}

	public void setAccountCode(String accountCode) {
		this.accountCode = accountCode;
	}

}
