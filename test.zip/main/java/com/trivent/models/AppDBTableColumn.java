package com.trivent.models;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.constants.AppConstants;
import com.trivent.models.base.BaseEntity;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.entity
 * 
 * @FileName 	:
 *				AppDBTableColumn.java
 * @TypeName 	:
 * 				AppDBTableColumn
 * @DateAndTime :
 *				Feb 8, 2018 - 3:48:58 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description : To create , edit , save and view the AppDBTableColumn details by
 *              fetching each required columns in this entity 
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Entity
@Table(name = "app_db_table_columns")
@AttributeOverrides({ @AttributeOverride(name = "id", column = @Column(name = "app_db_table_Column_id")) })
public class AppDBTableColumn extends BaseEntity {

  

  /**
	 * 
	 */
	private static final long serialVersionUID = 4766777447360199125L;

@ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "app_db_table_id", foreignKey = @ForeignKey(name = "fk_dbTable_1"))
  private AppDBTable dbTable = null;

  @Column(name = "name", nullable = false, length = 80)
  private String name = null;

  @Column(name = "reference_Table", length = 80)
  private String referenceTable = null;

  @Column(name = "reference_Table_Column", length = 80)
  private String referenceTableColumn = null;

  @Column(name = "size", nullable = false, length = 80)
  private Integer size = null;

  @Column(name = "data_type", nullable = false, length = 80)
  private String dataType = null;

  @Column(name = "seqNo", nullable = false)
  private Integer seqNo = null;

  @Column(name = "display_label", nullable = false, length = 80)
  private String displayLabel = null;

  @Column(name = "available_for_app_ui_screens", nullable = false)
  private Character availableForAppUIScreen = AppConstants.NO;

  @Column(name = "available_for_reports", nullable = false)
  private Character availableForReport = AppConstants.NO;

  /********************** hashcode, and equals methods **********************/

  @Override
  public int hashCode() {
    return new HashCodeBuilder().append(this.getId()).hashCode();
  }

  @Override
  public boolean equals(Object obj) {
    if (obj == null || obj.getClass() != getClass()) {
      return false;
    }
    AppDBTableColumn other = (AppDBTableColumn) obj;
    return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
  }

  /********************** Getters and Setters **********************/

  public AppDBTable getDbTable() {
    return dbTable;
  }

  public void setDbTable(AppDBTable dbTable) {
    this.dbTable = dbTable;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getReferenceTable() {
    return referenceTable;
  }

  public void setReferenceTable(String referenceTable) {
    this.referenceTable = referenceTable;
  }

  public String getReferenceTableColumn() {
    return referenceTableColumn;
  }

  public void setReferenceTableColumn(String referenceTableColumn) {
    this.referenceTableColumn = referenceTableColumn;
  }

  public Integer getSize() {
    return size;
  }

  public void setSize(Integer size) {
    this.size = size;
  }

  public String getDataType() {
    return dataType;
  }

  public void setDataType(String dataType) {
    this.dataType = dataType;
  }

  public String getDisplayLabel() {
    return displayLabel;
  }

  public void setDisplayLabel(String displayLabel) {
    this.displayLabel = displayLabel;
  }

  public Character getAvailableForAppUIScreen() {
    return availableForAppUIScreen;
  }

  public void setAvailableForAppUIScreen(Character availableForAppUIScreen) {
    this.availableForAppUIScreen = availableForAppUIScreen;
  }

  public Character getAvailableForReport() {
    return availableForReport;
  }

  public void setAvailableForReport(Character availableForReport) {
    this.availableForReport = availableForReport;
  }

  public Integer getSeqNo() {
    return seqNo;
  }

  public void setSeqNo(Integer seqNo) {
    this.seqNo = seqNo;
  }

}
