package com.trivent.models;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.models.base.BaseSoftDeletable;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.entity
 * 
 * @FileName 	:
 *				CaseQueryFlag.java
 * @TypeName 	:
 * 				CaseQueryFlag
 * @DateAndTime :
 *				Feb 8, 2018 - 4:03:32 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description :To create , edit , save and view the CaseQueryFlag details by
 *              fetching each required columns in this entity 
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Entity
@Table(name="case_query_flag")
@AttributeOverrides({@AttributeOverride(name="id", column=@Column(name="case_query_flag_id"))})
public class CaseQueryFlag extends BaseSoftDeletable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -2389027942296102635L;

	@Column(name="case_query_id",nullable=false)
	private Long caseQueryId;
	
	@Column(name="case_query_flag_type", nullable=false)
	private String caseQueryFlagType;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_id", foreignKey = @ForeignKey(name = "fk_case_query_flag_2"))
	private User client = null;
	
	  /********************** hashcode, and equals methods **********************/

	  @Override
	  public int hashCode() {
	    return new HashCodeBuilder().append(this.getId()).hashCode();
	  }

	  @Override
	  public boolean equals(Object obj) {
	    if (obj == null || obj.getClass() != getClass()) {
	      return false;
	    }
	    CaseQueryFlag other = (CaseQueryFlag) obj;
	    return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	  }

	  /********************** Getters and Setters **********************/
	  
	public Long getCasequeryid()
	{
		return caseQueryId;
	}
	public void setCaseQueryId(Long caseQueryId)
	{
		this.caseQueryId=caseQueryId;
	}
	public String getCaseQueryFlagType()
	{
		return caseQueryFlagType;
	}
	public void setCaseQueryFlagType(String caseQueryFlagType)
	{
		this.caseQueryFlagType=caseQueryFlagType;
	}
	
	public User getClient() {
		return client;
	}

	public void setClient(User client) {
		this.client = client;
	}

}
