package com.trivent.utils;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import org.apache.commons.lang3.StringUtils;
import org.jasypt.encryption.StringEncryptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.trivent.constants.AppConstants;
import com.trivent.logging.LogManager;
import com.trivent.logging.Logger;
@Component
public class EncryptionUtils {

	private static final Logger LOGGER = LogManager.getLogger();
	private static final String CLASS_NAME = EncryptionUtils.class.getName();
	private static final String METHOD_SET_ENCRYPTED_ID = "setEncryptedId";

	private static StringEncryptor stringEncryptor;

	/*
	 * Method to decrypt the string
	 */
	public static Long decryptId(String encryptedString) {
		if (StringUtils.isBlank(encryptedString)) {
			return null;
		}
		return Long.valueOf(stringEncryptor.decrypt(encryptedString));
	}

	/*
	 * Method to encrypt the string
	 */
	public static String encryptId(Long id) {
		String encryptedId = AppConstants.EMPTY_STRING;
		if (id != null) {
			try {
				encryptedId = URLEncoder.encode(stringEncryptor.encrypt(String.valueOf(id)), AppConstants.UTF8);
			} catch (UnsupportedEncodingException ex) {
				LOGGER.error(CLASS_NAME, METHOD_SET_ENCRYPTED_ID, ex);
			}
		}
		return encryptedId;
	}

	/*
	 * Method to set the encrypted string
	 */
	@Autowired
	public void setStringEncryptor(StringEncryptor stringEncryptor) {
		EncryptionUtils.stringEncryptor = stringEncryptor;
	}
}
