package com.trivent.utils;


import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.TimeZone;
import java.util.stream.Collectors;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.domain.Specifications;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.trivent.constants.AppConstants;
import com.trivent.dto.AppUIScreenFilterVO;
import com.trivent.dto.AppUIScreenViewVO;
import com.trivent.dto.RowVO;
import com.trivent.dto.ScreenListFilterVO;
import com.trivent.exceptions.TriventException;
import com.trivent.logging.LogManager;
import com.trivent.logging.Logger;
import com.trivent.models.Account;
import com.trivent.models.AppDBTable;
import com.trivent.models.AppItem;
import com.trivent.models.AppList;
import com.trivent.models.AppUIScreen;
import com.trivent.models.AppUIScreenField;
import com.trivent.models.AppUIScreenFilter;
import com.trivent.models.AppUIScreenView;
import com.trivent.models.ArchivalHistory;
import com.trivent.models.Capability;
import com.trivent.models.Case;
import com.trivent.models.CaseContacts;
import com.trivent.models.CaseFile;
import com.trivent.models.CaseFilesChangeHistory;
import com.trivent.models.CaseQuery;
import com.trivent.models.CaseResultFile;
import com.trivent.models.CaseServiceReq;
import com.trivent.models.CaseTask;
import com.trivent.models.Division;
import com.trivent.models.FileAttachments;
import com.trivent.models.Partner;
import com.trivent.models.Permission;
import com.trivent.models.ProdFile;
import com.trivent.models.Production;
import com.trivent.models.Role;
import com.trivent.models.Team;
import com.trivent.models.User;
import com.trivent.models.UserBranches;
import com.trivent.models.UserPartners;
import com.trivent.models.UserProfile;
import com.trivent.models.base.BaseEntity;
import com.trivent.repository.AccountRepository;
import com.trivent.repository.AppDBTableRepository;
import com.trivent.repository.AppItemRepository;
import com.trivent.repository.CapabilityRepository;
import com.trivent.repository.CaseContactsRepository;
import com.trivent.repository.CaseFileRepository;
import com.trivent.repository.CaseFilesChangeHistoryRepository;
import com.trivent.repository.CaseQueryRepository;
import com.trivent.repository.CaseRepository;
import com.trivent.repository.CaseResultFileReprository;
import com.trivent.repository.CaseTaskRepository;
import com.trivent.repository.FileAttachmentsRepository;
import com.trivent.repository.PartnerRepository;
import com.trivent.repository.PermissionRepository;
import com.trivent.repository.ProductionRepository;
import com.trivent.repository.RoleRepository;
import com.trivent.repository.UserBranchesRepository;
import com.trivent.repository.UserRepository;
import com.trivent.repository.specifications.GenericSpecifications;
import com.trivent.service.CacheService;
import com.trivent.service.CaseFileService;
import com.trivent.service.CaseQueryService;
import com.trivent.service.CaseService;
import com.trivent.service.PartnerService;
import com.trivent.service.UserPartnersService;
import com.trivent.service.UserService;

/**
 * @FileName : FilterUtils.java
 * @ClassName : FilterUtils
 * @DateAndTime : Nov 21, 2018 - 2:35:48 PM
 * 
 * @Author : karthi
 * 
 * @Description : Filter Utils is Common Function & Filters are Implementing
 *              this class. Implementing the code reusability Populating the
 *              Case & Case Result File Details
 * 
 * @Tags :
 * @param <T>
 * @Git_Config : name email
 * 
 */
@Component
public class FilterUtils<T> {

	private static final Logger LOGGER = LogManager.getLogger();

	private static final String CLASS_NAME = FilterUtils.class.getName();

	@Autowired
	GenericSpecifications<T> genericSpecifications;

	@Autowired
	AccountRepository accountRepository;

	@Autowired
	UserService userService;

	@Autowired
	AppItemRepository appItemRepository;

	@Autowired
	private RoleRepository roleRepository;

	@Autowired
	private CapabilityRepository capabilityRepository;

	@Autowired
	private PermissionRepository permissionRepository;

	@Autowired
	private PartnerService partnerService;

	@Autowired
	GenericSpecifications<User> genericSpecificationsUser;

	@Autowired
	PartnerRepository partnerRepostory;

	@Autowired
	AppDBTableRepository appDBTableRepository;

	@Autowired
	GenericSpecifications<CaseFile> genericSpecificationsCaseFile;


	@Autowired
	private UserPartnersService userPartnersService;

	@Autowired
	UserRepository userRepository;
	
	@Autowired
	CaseContactsRepository caseContactsRepository;	
	
	@Autowired
	CacheService cacheService;	
	
	@Autowired
	CaseTaskRepository caseTaskRepository;

	@Autowired
	FileAttachmentsRepository fileAttachmentsRepository;
	
	@Autowired
	ProductionRepository productionRepository;
	
	@Autowired
	CaseFileService caseFileService;
	
	@Autowired
	CaseFileRepository caseFileRepository;
	
	@Autowired
	CaseResultFileReprository caseResultFileRepository;
	
	@Autowired
	private Properties applicationProperties;
	
	@Autowired
	CaseFilesChangeHistoryRepository caseFilesChangeHistoryRepository;
	
	@Autowired
	CaseRepository caseRepository;
	
	@Autowired
	CaseService caseService;
	
	@Autowired
	CaseQueryRepository caseQueryRepository;
	
	@Autowired
	CaseQueryService caseQueryService;
	
	@Autowired
	UserBranchesRepository userBranchesRepository;
	
	
	@Transactional(readOnly = true)
	public List<Account> hasAccountFilter(User loginUser) {
		List<Account> accounts = new ArrayList<>();
		try {
			if (loginUser != null) {
				loginUser = this.userService.getUserById(loginUser.getId());
				if (loginUser.getType().equalsIgnoreCase(User.USER_TYPE_CLIENT)) {
					accounts.add(loginUser.getAccount());
				} else {
					boolean isEnabled = false;
					if (loginUser != null) {
						User actUser = this.userService.getUserById(loginUser.getId());
						if ((actUser != null) && (actUser.getRole() != null)) {
							Role role = this.roleRepository.findOne(actUser.getRole().getId());
							if (role != null) {
								Capability capability = this.capabilityRepository
										.findByName(Capability.PARTNER_BASED_DB);
								if (capability != null) {
									Permission permission = this.permissionRepository.getByCapabilityId(role.getId(),
											capability.getId());
									if (permission != null) {
										Character isVisible = permission.getVisible();
										if (isVisible.equals(AppConstants.YES)) {
											isEnabled = true;
										}
									}
								}
							}
						}
					}

					List<Partner> partnerList = this.hasPartnerFilter(loginUser);

					if (partnerList.size() > 0) {
						for (Partner partner : partnerList) {
							List<Account> laccounts = this.accountRepository.findAccountByPartner(partner,AppConstants.NO);
							if (laccounts.size() > 0) {
								accounts.addAll(laccounts);
							}
						}
					} else if (!isEnabled) {
						accounts = this.accountRepository.listAccounts(AppConstants.NO);
					}
				}

			}
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "hasAccountFilter", e);
		} finally {

		}
		return accounts;
	}
	
	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Nov 21, 2018 - 2:35:48 PM
	 * 
	 * @Author : karthi
	 * 
	 * @Description : Partner Filter By Login User
	 * 
	 * @Tags :
	 * @param loginUser
	 *            input as Login User Entity
	 * @return List<Partner>
	 * @Git_Config : name email
	 * 
	 */
	@Transactional(readOnly = true)
	public List<Partner> hasPartnerFilter(User loginUser) {
		List<Partner> partnerList = new ArrayList<>();
		try {
			if (loginUser != null) {
				loginUser = this.userService.getUserById(loginUser.getId());
				if (loginUser.getType().equalsIgnoreCase(User.USER_TYPE_CLIENT)) {
					partnerList.add(loginUser.getAccount().getPartner());
				} else {
					boolean isEnabled = false;
					if (loginUser != null) {
						User actUser = this.userService.getUserById(loginUser.getId());
						if ((actUser != null) && (actUser.getRole() != null)) {
							Role role = this.roleRepository.findOne(actUser.getRole().getId());
							if (role != null) {
								Capability capability = this.capabilityRepository
										.findByName(Capability.PARTNER_BASED_DB);
								if (capability != null) {
									Permission permission = this.permissionRepository.getByCapabilityId(role.getId(),
											capability.getId());
									if (permission != null) {
										Character isVisible = permission.getVisible();
										if (isVisible.equals(AppConstants.YES)) {
											isEnabled = true;
										}
									}
								}
							}
						}
					}

					List<UserPartners> userPartnersList = this.userPartnersService.getByUser(loginUser);
					for (UserPartners userPartners : userPartnersList) {
						if (userPartners.getDeleted().equals(AppConstants.NO) && !isEnabled) {
							partnerList.add(userPartners.getPartner());
						}
						if (isEnabled) {
							Partner partner = this.partnerService.getCurrentSessionPartner();
							if (userPartners.getPartner().getId().equals(partner.getId())) {
								partnerList.add(userPartners.getPartner());
							}
						}
					}
					if ((partnerList.size() == 0) && !isEnabled) {
						partnerList = this.partnerRepostory.listPartners(AppConstants.NO);
					} else if ((partnerList.size() == 0) && isEnabled) {
						Partner partner = this.partnerService.getCurrentSessionPartner();
						partnerList.add(partner);
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "hasPartnerFilter", e);
		} finally {

		}
		return partnerList;
	}
	
	
	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Feb 1, 2018 - 2:35:48 PM
	 * 
	 * @Author : karthi
	 * 
	 * @Description : Populated CaseView Specifications depends upon
	 *              screenListFilterVO & Login User. Display Logic Specifications
	 *              View all cases. No Specifications required. Added on 23-08-2017
	 *              Description: If the loginUser is client don't need to add
	 *              specifications because specifications added in listQueries
	 *              function.
	 * 
	 * @Tags :
	 * @param screenListFilterVO
	 *            input as custom class contains Screen fields and list.
	 * @param loginUser
	 *            input as login user entity
	 * @param specifications
	 *            input as defined specification.
	 * @return
	 * @Git_Config : name email
	 * 
	 */
	public Specifications<T> populateCaseViewSpecifications(ScreenListFilterVO screenListFilterVO, User loginUsers,
			Specifications<T> specifications) {
		Specification<T> specification = null;
		Specifications<T> updatedSpecifications = specifications;
		User loginUser = this.userService.getCurrentUser(null);
		if (screenListFilterVO.getSelectedViewType().equals(AppUIScreenView.VIEW_ASSIGNED)) {
			specification = this.genericSpecifications.dataTypeUser("assignedTo", loginUser);
		} else if (screenListFilterVO.getSelectedViewType().equals(AppUIScreenView.VIEW_TEAM)) {
			List<User> teamUsers = this.userRepository.listTeamMembers(AppConstants.TYPE_TRIVENT,
					loginUser.getTeam().getId(), AppConstants.NO);
			specification = this.genericSpecifications.anyUsers("assignedTo", teamUsers);
		} else if (screenListFilterVO.getSelectedViewType().equals(AppUIScreenView.VIEW_CREATED)) {
			specification = this.genericSpecifications.dataTypeUser("createdBy", loginUser);
		} else if (screenListFilterVO.getSelectedViewType().equals(AppUIScreenView.VIEW_CLIENT)) {
			if (loginUser.getClientRole() != null) {
				if (loginUser.getClientRole().equals("Attorney")) {
					if (loginUser.getAccount() != null) {
						List<Account> accounts = new ArrayList<>();
						accounts.add(loginUser.getAccount());
						specification = this.genericSpecifications.dataTypeAccount("account", accounts);
					} else {
						specification = this.genericSpecifications.dataTypeUser("client", loginUser);
					}
				} else {
					specification = this.genericSpecifications.dataTypeUser("client", loginUser);
				}
			} else {
				specification = this.genericSpecifications.dataTypeUser("client", loginUser);
			}
		} else if (screenListFilterVO.getSelectedViewType().equals(AppUIScreenView.VIEW_ACCOUNT_MANAGER)) {
			List<Account> accounts = this.accountRepository.findAccountsByManager(loginUser.getId(), AppConstants.NO);
			if (accounts.isEmpty()) {
				Account account = loginUser.getAccount();
				accounts.add(account);
			}
			specification = this.genericSpecifications.anyAccount("account", accounts);
		}
		boolean isCaseView = false;
		List<AppUIScreenViewVO> appUIScreenViewVOs = screenListFilterVO.getAppUIScreenViewVOs();
		if ((appUIScreenViewVOs != null) && (appUIScreenViewVOs.size() > 0)) {
			for (AppUIScreenViewVO appUIScreenViewVO : appUIScreenViewVOs) {
				if (appUIScreenViewVO.getViewEntity() != null) {
					if (appUIScreenViewVO.getViewEntity().equals(AppConstants.SCREEN_NAME_CASES)) {
						isCaseView = true;
						break;
					}
				}
			}

		}

		if (specification != null) {
			if (screenListFilterVO.getSelectedViewType().equals(AppUIScreenView.VIEW_CLIENT)) {
				if (loginUser.getClientRole() != null) {
					if (!loginUser.getClientRole().equals("Attorney")) {
					}
				} else {
				}

			} else {
				updatedSpecifications = specifications.and(specification);
			}

			if (isCaseView) {
				if (screenListFilterVO.getSelectedViewType().equals(AppUIScreenView.VIEW_CLIENT)) {
					List<Long> caseIds = new ArrayList<>();
					List<CaseContacts> caseContacts = this.caseContactsRepository
							.listCaseContactsByLoginUser(AppConstants.NO, loginUser);
					for (CaseContacts caseContact : caseContacts) {
						Long ccCaseID = caseContact.getCaseid().getId();
						caseIds.add(ccCaseID);
					}
					if (caseIds.size() > 0) {
						specification = this.genericSpecifications.dataTypeLongList("id", caseIds);
						updatedSpecifications = updatedSpecifications.or(specification);
					}
				}
			}
		}
		return updatedSpecifications;
	}
	
	@SuppressWarnings("deprecation")
	public List<RowVO> listScreenDetails(Long screenName, String screenType, List<?> objList) throws TriventException {
		User loginUser = this.userService.getCurrentUser(null);
		List<RowVO> rowVOs = new ArrayList<>(objList.size());
		AppUIScreen appUIScreen = this.cacheService.findByScreenNameTypeRole(screenName, screenType,
				loginUser.getRole().getId());
		if (appUIScreen == null) {
			throw new TriventException(AppConstants.MSG_SCREEN_NOT_CONFIGURED);
		}
		List<AppUIScreenField> appUIScreenFields = this.cacheService.findFieldsByAppUIScreenId(appUIScreen.getId());
		//AppDBTable appDbTable = this.appDBTableRepository.findOne(screenName);
		/*if (appDbTable.getName().equals("EmailQueue")) {
			for (AppUIScreenField appUIScreenField : appUIScreenFields) {
				if (appUIScreenField.getDbFieldName().equals("body")) {
					appUIScreenFields.remove(appUIScreenField);
				}
			}
		}*/

		RowVO rowVO = new RowVO();
		rowVO.setHeader(true);
		List<String> columns = new ArrayList<>(appUIScreenFields.size());
		for (AppUIScreenField appUIScreenField : appUIScreenFields) {
			columns.add(appUIScreenField.getAttributeName());
		}

		rowVO.setColumns(columns);
		rowVOs.add(rowVO);

		List<String> dataTypes = new ArrayList<>(appUIScreenFields.size());
		if (!objList.isEmpty()) {
			Object obj = objList.get(0);
			Class<?> propertyClass = null;
			try {
				for (AppUIScreenField appUIScreenField : appUIScreenFields) {
					propertyClass = PropertyUtils.getPropertyType(obj, appUIScreenField.getDbFieldName());
					dataTypes.add(propertyClass.getName());
				}
			} catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException ex) {
				LOGGER.error(CLASS_NAME, "listScreenDetails", ex);
			}
		}
		try {
			int size = appUIScreenFields.size();
			StringBuilder caseEncryptedId = new StringBuilder();
			for (Object obj : objList) {
				columns = new ArrayList<>(appUIScreenFields.size());
				caseEncryptedId.setLength(0);
				for (int i = 0; i < size; i++) {
					//AppDBTable appDbTableName = this.appDBTableRepository.findOne(screenName);
					AppDBTable appDbTableName = new AppDBTable();
					appDbTableName.setName("Case");
					if (appDbTableName.getName().equals("ProdFile") || appDbTableName.getName().equals("CaseFile")
							|| appDbTableName.getName().equals("CaseResultFile")) {
						this.populateAppUIScreenColumnForFiles(appUIScreenFields, columns, dataTypes, obj, i,
								caseEncryptedId);
					} else {
						this.populateAppUIScreenColumn(appUIScreenFields, columns, dataTypes, obj, i, caseEncryptedId);
					}
				}
				BaseEntity be = (BaseEntity) obj;
				rowVO = new RowVO(be.getId(), EncryptionUtils.encryptId(be.getId()), caseEncryptedId, columns);

				try {
					if (be.getId() != null) {
						Map<String, String> caseDetailsMap = new HashMap<>();
						switch (obj.getClass().getSimpleName()) {
						case "CaseFile":

							Long caseFileId = rowVO.getId();
							if (caseFileId != null) {

								CaseFile caseFile = this.caseFileService.getCaseFileData(caseFileId);

								String strCaseId = ((caseFile.getClientCase() != null)
										&& (caseFile.getClientCase().getId() != null)) ? "Y" : "N";
								caseDetailsMap.put("strCaseId", strCaseId);

								caseDetailsMap.put("caseId", caseFile.getClientCase().getId().toString());
								String strAccountId = ((caseFile.getClientCase() != null)
										&& (caseFile.getClientCase().getAccount() != null)
										&& (caseFile.getClientCase().getAccount().getId() != null)) ? "Y" : "N";
								caseDetailsMap.put("strAccountId", strAccountId);
								caseDetailsMap.put("accountId",
										caseFile.getClientCase().getAccount().getId().toString());
								String strClientId = ((caseFile.getClientCase() != null)
										&& (caseFile.getClientCase().getClient() != null)
										&& (caseFile.getClientCase().getClient().getId() != null)) ? "Y" : "N";
								caseDetailsMap.put("strClientId", strClientId);
								caseDetailsMap.put("clientId", caseFile.getClientCase().getClient().getId().toString());
								String strloginUser = (loginUser != null) ? "Y" : "N";
								caseDetailsMap.put("strloginUser", strloginUser);
								caseDetailsMap.put("loginUser", loginUser.getId().toString());
								String roleType = loginUser.getRole().getName();
								String roleName = (roleType.equalsIgnoreCase("Customer")) ? "Y" : "N";
								caseDetailsMap.put("loginUserRole", roleName);

								caseDetailsMap.put("isArchieved", caseFile.getArchived().toString());
								caseDetailsMap.put("isSuccessStatus", caseFile.getCurStatus().toString());
								String strRepFileLoc = (caseFile.getReplicatedFileLocation() != null) ? "Y" : "N";
								caseDetailsMap.put("strRepFileLoc", strRepFileLoc);
								caseDetailsMap.put("replicatedFileLoc", caseFile.getReplicatedFileLocation());
								rowVO.setValueMap(caseDetailsMap);
								caseDetailsMap.put("uploadRemotely", caseFile.getUploadRemotely().toString());
								caseDetailsMap.put("pageCountStatus", caseFile.getPageCountStatus());
								caseDetailsMap.put("caseFileName", caseFile.getName());
								caseDetailsMap.put("contentType", caseFile.getFileContentType());
								caseDetailsMap.put("fileExtension", caseFile.getFileExtension());
								caseDetailsMap.put("fileType", caseFile.getFileType().toString());
								
								String pageCountOne = (caseFile.getFilePageCount() != null) ? "Y" : "N";
								caseDetailsMap.put("pageCountOne", pageCountOne);
								caseDetailsMap.put("pageCount",
										pageCountOne == "Y" ? caseFile.getFilePageCount().toString() : "");
								String pageCountNegativeStatus = this.applicationProperties
										.getProperty(AppConstants.PAGE_COUNT_NEGATIVE_STATUS);
								String[] tempNegativeStatus = pageCountNegativeStatus.split(",");

								if (ArrayUtils.contains(tempNegativeStatus, caseFile.getPageCountStatus())) {
									caseDetailsMap.put("isNegativeStatus", "Y");
								} else {
									caseDetailsMap.put("isNegativeStatus", "N");
								}
								caseDetailsMap.put("isFailed",
										caseFile.getPageCountStatus().equals(AppConstants.FILE_UPLOADING_STATUS)
												|| caseFile.getPageCountStatus().equals(AppConstants.PROCESSING_STATUS)
												|| caseFile.getPageCountStatus().equals(AppConstants.NEW_STATUS)
												|| caseFile.getCurStatus().equals(AppConstants.TRACE_FAILED) ? "Y"
														: "N");
								caseDetailsMap.put("FileLocation", caseFile.getFileLocation());

								rowVO.setValueMap(caseDetailsMap);
							}
							break;
						case "CaseResultFile":

							Long caseResultFileId = rowVO.getId();
							if (caseResultFileId != null) {

								CaseResultFile caseResultFile = this.caseFileService
										.getCaseResultFileData(caseResultFileId);

								String strCaseId = ((caseResultFile.getClientCase() != null)
										&& (caseResultFile.getClientCase().getId() != null)) ? "Y" : "N";
								caseDetailsMap.put("strCaseId", strCaseId);
								String strAccountId = ((caseResultFile.getClientCase() != null)
										&& (caseResultFile.getClientCase().getAccount() != null)
										&& (caseResultFile.getClientCase().getAccount().getId() != null)) ? "Y" : "N";
								caseDetailsMap.put("strAccountId", strAccountId);
								caseDetailsMap.put("accountId",
										strAccountId == "Y"
												? caseResultFile.getClientCase().getAccount().getId().toString()
												: "");
								String strClientId = ((caseResultFile.getClientCase() != null)
										&& (caseResultFile.getClientCase().getClient() != null)
										&& (caseResultFile.getClientCase().getClient().getId() != null)) ? "Y" : "N";
								caseDetailsMap.put("strClientId", strClientId);
								caseDetailsMap.put("clientId",
										strClientId == "Y"
												? caseResultFile.getClientCase().getClient().getId().toString()
												: "");
								String strloginUser = (loginUser != null) ? "Y" : "N";
								caseDetailsMap.put("strloginUser", strloginUser);
								caseDetailsMap.put("loginUser", loginUser.getId().toString());
								String roleType = loginUser.getRole().getName();
								String roleName = (roleType == "Customer") ? "Y" : "N";
								caseDetailsMap.put("loginUserRole", roleName);

								caseDetailsMap.put("isArchieved", caseResultFile.getArchived().toString());
								caseDetailsMap.put("isSuccessStatus", caseResultFile.getCurStatus().toString());
								String strRepFileLoc = (caseResultFile.getReplicatedFileLocation() != null) ? "Y" : "N";
								caseDetailsMap.put("strRepFileLoc", strRepFileLoc);
								caseDetailsMap.put("replicatedFileLoc", caseResultFile.getReplicatedFileLocation());
								rowVO.setValueMap(caseDetailsMap);
								caseDetailsMap.put("uploadRemotely", caseResultFile.getUploadRemotely().toString());
								caseDetailsMap.put("pageCountStatus", caseResultFile.getPageCountStatus());
								caseDetailsMap.put("caseFileName", caseResultFile.getName());
								caseDetailsMap.put("contentType", caseResultFile.getFileContentType());
								caseDetailsMap.put("fileExtension", caseResultFile.getFileExtension());
								caseDetailsMap.put("fileType", caseResultFile.getFileContentType().toString());
								
								String pageCountOne = (caseResultFile.getFilePageCount() != null) ? "Y" : "N";
								caseDetailsMap.put("pageCountOne", pageCountOne);
								caseDetailsMap.put("pageCount",
										pageCountOne == "Y" ? caseResultFile.getFilePageCount().toString() : "");
								String pageCountNegativeStatus = this.applicationProperties
										.getProperty(AppConstants.PAGE_COUNT_NEGATIVE_STATUS);
								String[] tempNegativeStatus = pageCountNegativeStatus.split(",");

								if (ArrayUtils.contains(tempNegativeStatus, caseResultFile.getPageCountStatus())) {
									caseDetailsMap.put("isNegativeStatus", "Y");
								} else {
									caseDetailsMap.put("isNegativeStatus", "N");
								}

								caseDetailsMap.put("isProductionFile", caseResultFile.getIsProductionFile().toString());
								caseDetailsMap.put("loginUserRoleType", loginUser.getRole().getType());
								caseDetailsMap.put("isCustomerDownloaded",
										caseResultFile.getIsFileDownloaded().toString());
								caseDetailsMap.put("caseId",
										((caseResultFile.getClientCase() != null)
												&& (caseResultFile.getClientCase().getId() != null))
														? caseResultFile.getClientCase().getId().toString()
														: "");

								caseDetailsMap.put("isFailed",
										caseResultFile.getPageCountStatus().equals(AppConstants.FILE_UPLOADING_STATUS)
												|| caseResultFile.getPageCountStatus()
														.equals(AppConstants.PROCESSING_STATUS)
												|| caseResultFile.getPageCountStatus().equals(AppConstants.NEW_STATUS)
												|| caseResultFile.getCurStatus().equals(AppConstants.TRACE_FAILED) ? "Y"
														: "N");
								caseDetailsMap.put("FileLocation", caseResultFile.getFileLocation());

								rowVO.setValueMap(caseDetailsMap);
							}
							break;
						case "ProdFile":
							Map<String, String> prodDetailsMap = new HashMap<>();
							Long prodFileId = rowVO.getId();
							if (prodFileId != null) {
								ProdFile prodFile = this.caseFileService.getProdFileData(prodFileId);
								String fileDescription = (prodFile.getFileDescription() != null) ? "Y" : "N";
								prodDetailsMap.put("fileDescription", fileDescription);
								prodDetailsMap.put("productionId", prodFile.getProduction().getId().toString());
								prodDetailsMap.put("fileLoc", prodFile.getFileLocation());
								prodDetailsMap.put("fileName", prodFile.getFileName());
								prodDetailsMap.put("Deliverable(s)", prodFile.getIsDeliverable().toString());
								if (prodFile.getIsDelivered() != null) {
									prodDetailsMap.put("Delivered", prodFile.getIsDelivered().toString());
								}
								caseDetailsMap.put("caseFileName", prodFile.getFileName());

								caseDetailsMap.put("contentType", prodFile.getFileContentType());
								caseDetailsMap.put("fileExtension", prodFile.getFileExtension());
								caseDetailsMap.put("fileType", prodFile.getFileContentType().toString());

								rowVO.setValueMap(prodDetailsMap);
							}
							break;
						case "Case":

							Long caseId = rowVO.getId();
							if (caseId != null) {
								Map<String, String> expediteMap = new HashMap<>();
								Case appCase = (Case) obj;
								
								expediteMap.put("uicsstatus", appCase.getCsStatus());
							
								String expeditedDeliveryCase = (appCase.getExpeditedDeliveryDate() != null) ? "Y" : "N";

								expediteMap.put("ExpeditedDeliveryDateCase", expeditedDeliveryCase);
								String estimatedDeliveryCase = (appCase.getCf_1_Date() != null) ? "Y" : "N";
								expediteMap.put("estimatedDeliveryDateCase", estimatedDeliveryCase);
								String expediteAndEstimateCase = ((appCase.getExpeditedDeliveryDate() != null)
										&& (appCase.getCf_1_Date() != null)) ? "Y" : "N";
								expediteMap.put("expediteAndEstimateDateCase", expediteAndEstimateCase);
								
								String fileStatus = this.applicationProperties
										.getProperty(AppConstants.FILE_STATUS_NOT_TO_SHOW_COLOR);
								String[] tempFileStatus = fileStatus.split(",");
								for (String tempStatus : tempFileStatus) {
									if ((appCase.getExpeditedDeliveryDate() != null)
											&& (appCase.getFileDeliveryDate() == null)
											&& !appCase.getCsStatus().equals(tempStatus)) {
										SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
										Date calDate = appCase.getExpeditedDeliveryDate().getTime();
										calDate = new Date(formatter.format(calDate));

										Date currentDate = new Date(formatter.format(DateTime.now().toDate()));
										long diff = calDate.getTime() - currentDate.getTime();
										long diffDays = diff / (24 * 60 * 60 * 1000);
										String expediteCurrentDate = "N";
										if (calDate.equals(currentDate)) {
											expediteCurrentDate = "Y";
										}
										String expeditebeforeDay = "N";
										if (diffDays <= Long.parseLong(this.applicationProperties
												.getProperty(AppConstants.EXPEDITE_ESTIMATE_DEADLINE_1))) {
											expeditebeforeDay = "Y";
										}
										expediteMap.put("expeditebeforeDay", expeditebeforeDay);
										String expeditebefore2Day = "N";
										if ((diffDays > Long.parseLong(this.applicationProperties
												.getProperty(AppConstants.EXPEDITE_ESTIMATE_DEADLINE_1)))
												&& (diffDays <= Long.parseLong(this.applicationProperties
														.getProperty(AppConstants.EXPEDITE_ESTIMATE_DEADLINE_2)))) {
											expeditebefore2Day = "Y";
										}
										expediteMap.put("expeditebefore2Day", expeditebefore2Day);

										expediteMap.put("expediteCurrentDate", expediteCurrentDate);
									}

								}
								for (String tempStatus : tempFileStatus) {
									if ((appCase.getCf_1_Date() != null) && (appCase.getFileDeliveryDate() == null)
											&& !appCase.getCsStatus().equals(tempStatus)) {
										SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
										Date estDate = appCase.getCf_1_Date().getTime();
										estDate = new Date(formatter.format(estDate));
										Date currentDate = new Date(formatter.format(DateTime.now().toDate()));
										long diff = estDate.getTime() - currentDate.getTime();
										long diffDays = diff / (24 * 60 * 60 * 1000);
										String estimateBeforeDay = "N";
										if (diffDays <= Long.parseLong(this.applicationProperties
												.getProperty(AppConstants.EXPEDITE_ESTIMATE_DEADLINE_1))) {
											estimateBeforeDay = "Y";
										}
										expediteMap.put("estimateBeforeDay", estimateBeforeDay);
										String estimatebefore2Day = "N";
										if ((diffDays > Long.parseLong(this.applicationProperties
												.getProperty(AppConstants.EXPEDITE_ESTIMATE_DEADLINE_1)))
												&& (diffDays <= Long.parseLong(this.applicationProperties
														.getProperty(AppConstants.EXPEDITE_ESTIMATE_DEADLINE_2)))) {
											estimatebefore2Day = "Y";
										}
										expediteMap.put("estimatebefore2Day", estimatebefore2Day);
										String estimateCurrentDate = "N";
										if (estDate.equals(currentDate)) {
											estimateCurrentDate = "Y";
										}
										expediteMap.put("estimateCurrentDate", estimateCurrentDate);
									}
								}


								if (loginUser.getLoginId().toString()
										.equalsIgnoreCase((this.applicationProperties
												.getProperty("application.configuration.case.addcolumnBasedOnUser"))
														.trim())) {
									if (appCase.getSubType() != null && StringUtils.isNoneEmpty(appCase.getSubType()))
										expediteMap.put("caseSubType", appCase.getSubType());
									else
										expediteMap.put("caseSubType", "");
									
								}

								rowVO.setValueMap(expediteMap);
								/*rowVO.setValueMap1(labelNamesMap);*/
							}

							break;
						case "CaseQuery":
							Map<String, String> queryFlagMap = new HashMap<>();
							
							final Long appItem = this.appItemRepository
									.findAppItemIDByLongName(AppConstants.APP_ITEM_QUERY_TYPE_LONG_NAME);
							Character negativeQuery = AppConstants.NO;
							CaseQuery lcqCaseQuery = (CaseQuery) obj;
							if(lcqCaseQuery.getQueryType() != null && StringUtils.isNotBlank(lcqCaseQuery.getQueryType()) && StringUtils.isNotEmpty(lcqCaseQuery.getQueryType()))
							{
								String[] lcqCaseQueryListType = lcqCaseQuery.getQueryType().split(",");
								try
								{
									List<String> llcqCaseQueryListType = Arrays.stream(lcqCaseQueryListType).parallel().filter(p -> p != null && p.equalsIgnoreCase(appItem.toString())).sequential()
											.map(p -> p).collect(Collectors.toCollection(ArrayList::new));
									if(llcqCaseQueryListType != null && !llcqCaseQueryListType.isEmpty() && llcqCaseQueryListType.size() > 0)
									{
										negativeQuery = AppConstants.YES;
									}
								}
								catch (Exception e) {
									LOGGER.error(CLASS_NAME, "listScreenDetails", "llcqCaseQueryListType");
								}
							}
							queryFlagMap.put("negativeQuery", negativeQuery.toString());
							rowVO.setValueMap(queryFlagMap);
							break;

						case "CaseTask":
							Long taskId = rowVO.getId();
							if (taskId != null) {
								Map<String, String> caseTaskMap = new HashMap<>();

								CaseTask caseTask = this.caseTaskRepository.findOne(taskId);

								Object objDowloadIcon = this.caseTaskRepository.findChildTasksById(taskId);
								if (objDowloadIcon != null) {
									String fileDownloadIcon = objDowloadIcon.toString();
									fileDownloadIcon = fileDownloadIcon.concat(",").concat(taskId.toString());
									if (fileDownloadIcon != null) {
										String[] str = fileDownloadIcon.split(",");
										for (String strId : str) {
											Long id = Long.parseLong(strId);
											List<FileAttachments> fileAttachmentsList = this.fileAttachmentsRepository
													.findAllAttachmentByTaskId(id);
											if (fileAttachmentsList.size() > 0) {
												caseTaskMap.put(AppConstants.CASE_TASK_DOWNLOAD_FILE, "Y");
											}
										}

									}
								} else {
									List<FileAttachments> fileAttachmentsList = this.fileAttachmentsRepository
											.findAllAttachmentByTaskId(taskId);
									if (fileAttachmentsList.size() > 0) {
										caseTaskMap.put(AppConstants.CASE_TASK_DOWNLOAD_FILE, "Y");
									}
								}

								String productionCase = ((caseTask != null) && (caseTask.getProduction() != null)) ? "Y"
										: "N";

								caseTaskMap.put("prodCase", productionCase);
								List<FileAttachments> fileAttachments = this.fileAttachmentsRepository
										.findAllAttachmentByTaskId(taskId);
								String fileDownload = (fileAttachments.size() > 0) ? "Y" : "N";
								caseTaskMap.put(AppConstants.FILE_DOWNLOAD_ICON, fileDownload);
								caseTaskMap.put("productionId",
										productionCase == "Y" ? caseTask.getProduction().getId().toString() : "");

								String subTasks = (caseTask.getParentTask() != null) ? "Y" : "N";
								if (subTasks == "Y") {
									CaseTask caseTaskone = this.caseTaskRepository.findOne(caseTask.getParentTask());
									caseTaskMap.put("parentTaskId",
											subTasks == "Y"
													? caseTask.getParentTask().toString() + "-" + caseTaskone.getName()
													: "");

								}
								String parentTasks = (caseTask.getParentTask() == null) ? "Y" : "N";
								caseTaskMap.put("parentTasks", parentTasks);
								caseTaskMap.put("subTask", subTasks);
								List<CaseTask> noOfSubTasks = this.caseTaskRepository.findSumOfEstimateHrs(taskId,
										AppConstants.NO);
								String openSubTasks = (noOfSubTasks.size() > 0) ? "Y" : "N";
								caseTaskMap.put("openSubTasks", openSubTasks);
								if (caseTask.getClientCase() != null) {
									if (caseTask.getClientCase().getId() != null) {
										List<CaseTask> subTaskByCaseIds = this.caseTaskRepository.findSubTasksByCaseId(
												caseTask.getClientCase().getId(), AppConstants.NO);
										if (subTaskByCaseIds != null) {
											for (CaseTask subTaskByCaseId : subTaskByCaseIds) {
												Production prodSubTasks = this.productionRepository
														.getProductionPercentageupdate(
																subTaskByCaseId.getClientCase().getId(),
																AppConstants.NO);
												String productionSubTasks = (prodSubTasks != null) ? "Y" : "N";
												caseTaskMap.put("productionSubTasks", productionSubTasks);
											}
										}
									}
								}

								if (caseTask.getClientCase() != null) {
									if (caseTask.getClientCase().getId() != null) {
										List<CaseTask> parentTaskByCaseIds = this.caseTaskRepository
												.findParentTasksByCaseId(caseTask.getClientCase().getId(),
														AppConstants.NO);

										if (parentTaskByCaseIds != null) {
											for (CaseTask parentTaskByCaseId : parentTaskByCaseIds) {
												Production prodTasks = this.productionRepository
														.getProductionPercentageupdate(
																parentTaskByCaseId.getClientCase().getId(),
																AppConstants.NO);
												String prodParentTasks = (prodTasks != null) ? "Y" : "N";
												caseTaskMap.put("prodParentTasks", prodParentTasks);
											}
										}

									}
								}

								rowVO.setValueMap(caseTaskMap);
							}
							break;

						default:
							break;
						}

					}
				} catch (Exception e) {

				}

				rowVOs.add(rowVO);
			}
		} catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException ex) {
			LOGGER.error(CLASS_NAME, "listScreenDetails", ex);
		}
		return rowVOs;
	}

	
	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Feb 1, 2018 - 2:35:48 PM
	 * 
	 * @Author : karthi
	 * 
	 * @Description : Populate Application UIScreen Column For Files
	 * 
	 * @Tags :
	 * @param appUIScreenFields
	 *            input as appUIScreenFields custom class
	 * @param columns
	 *            input as list of column in String
	 * @param dataTypes
	 *            input as String DataType for column DataType
	 * @param obj
	 *            input as Object
	 * @param i
	 *            input as int
	 * @param caseEncryptedId
	 *            input as Encrypted Case Id
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 * @throws NoSuchMethodException
	 * @Git_Config : name email
	 * 
	 */
	private void populateAppUIScreenColumnForFiles(List<AppUIScreenField> appUIScreenFields, List<String> columns,
			List<String> dataTypes, Object obj, int i, StringBuilder caseEncryptedId)
			throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
		Object value;
		String dataType;
		Long additionalRecId = null;
		AppUIScreenField appUIScreenField = appUIScreenFields.get(i);
		dataType = dataTypes.get(i);
		value = PropertyUtils.getSimpleProperty(obj, appUIScreenField.getDbFieldName());
		if (value != null) {
			if (dataType.equals(Calendar.class.getName())) {
				columns.add(CommonUtils.calendarToString((Calendar) value));
			} else if (dataType.equals(DateTime.class.getName()) || dataType.equals(Date.class.getName())) {
				try {
					SimpleDateFormat tzFormat = this.getUserTimeZoneId();
					columns.add(tzFormat.format(new DateTime(value).toDate()));
				} catch (Exception e) {
					columns.add(CommonUtils.dateTimeToString(new DateTime(value)));
				}
			} else if (dataType.equals(Long.class.getName()) && appUIScreenField.getDbFieldName().equals("fileSize")) {
				Long fileSize = (Long) value;
				columns.add(fileSize + AppConstants.SPACE_SEPARATOR + "kb");
			} else if (dataType.equals(Character.class.getName())
					&& appUIScreenField.getDbFieldName().equals("isDeliverable")) {
				this.populateForFiles(columns, obj, value, appUIScreenField);
			} else if (dataType.equals(Character.class.getName())
					&& appUIScreenField.getDbFieldName().equals("isDelivered")) {
				if (appUIScreenField.getDbFieldName().equals("isDelivered") && value.equals('Y') && (value != null)) {
					columns.add("Delivered");
				} else {
					columns.add(AppConstants.EMPTY_STRING);
				}
			} else if (dataType.equals(Account.class.getName())) {
				this.populateForAccount(columns, obj, value, appUIScreenField);
			} else if (dataType.equals(Case.class.getName())) {
				this.populateForCase(columns, obj, caseEncryptedId, value, appUIScreenField);
			} else if (dataType.equals(User.class.getName())) {
				this.populateForUser(columns, obj, value, appUIScreenField);
			} else if (dataType.equals(AppItem.class.getName())) {
				this.populateForAppItem(columns, obj, value, appUIScreenField);
			} else if (dataType.equals(Role.class.getName())) {
				this.populateForRole(columns, obj, value, appUIScreenField);
			} else if (dataType.equals(Team.class.getName())) {
				this.populateForTeam(columns, obj, value, appUIScreenField);
			} else if (dataType.equals(UserProfile.class.getName())) {
				this.populateForUserProfile(columns, obj, value, appUIScreenField);
			} else if (dataType.equals(Partner.class.getName())) {
				this.populateForPartner(columns, obj, value, appUIScreenField);
			} else if (dataType.equals(CaseFile.class.getName())) {
				this.populateForCaseFile(columns, obj, caseEncryptedId, value, appUIScreenField);
			} else if (dataType.equals(CaseResultFile.class.getName())) {
				this.populateForCaseResultFile(columns, obj, caseEncryptedId, value, appUIScreenField);
			} else if (dataType.equals(Division.class.getName())) {
				this.populateForDivision(columns, obj, value, appUIScreenField);
			} else if (dataType.equals(Long.class.getName())
					&& appUIScreenField.getDbFieldName().equalsIgnoreCase("additionalRecId")) {
				if (obj instanceof CaseServiceReq) {
					CaseServiceReq caseServiceReq = (CaseServiceReq) obj;
					additionalRecId = caseServiceReq.getAdditionalRecId();
					if (additionalRecId != null) {
						this.populateForAdditionalRecService(columns, obj, caseEncryptedId, value, appUIScreenField);
					}
				} else if (obj instanceof CaseResultFile) {
					CaseResultFile caseResultFile = (CaseResultFile) obj;
					additionalRecId = caseResultFile.getAdditionalRecId();
					if (additionalRecId != null) {
						this.populateForAdditionalRecService(columns, obj, caseEncryptedId, value, appUIScreenField);
					}
				} else if (obj instanceof CaseFile) {
					CaseFile caseFile = (CaseFile) obj;
					additionalRecId = caseFile.getAdditionalRecId();
					if (additionalRecId != null) {
						this.populateForAdditionalRecService(columns, obj, caseEncryptedId, value, appUIScreenField);
					}
				}
			} else {
				columns.add(String.valueOf(value));
			}
		} else {
			columns.add(AppConstants.EMPTY_STRING);
		}

	}
	
	public SimpleDateFormat getUserTimeZoneId() {

		TimeZone tz = TimeZone.getDefault();
		String psTimeZoneId = tz.getID();
		String psTimeZoneFormat = AppConstants.DATE_TIME_FORMAT;

		try {
			User loginUser = userService.getCurrentUser(null);
			psTimeZoneId = loginUser.getUserProfile().getTimeZoneLocationId();
			if (StringUtils.isBlank(psTimeZoneId) || StringUtils.isEmpty(psTimeZoneId)) {
				psTimeZoneId = tz.getID();
			}
			psTimeZoneFormat = loginUser.getUserProfile().getTimeZoneFormat();
			if (StringUtils.isBlank(psTimeZoneFormat) || StringUtils.isEmpty(psTimeZoneFormat)) {
				psTimeZoneFormat = AppConstants.DATE_TIME_FORMAT;
			}
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "getUserTimeZoneId", e);
		}
		SimpleDateFormat tzFormat = new SimpleDateFormat(psTimeZoneFormat);
		tz = TimeZone.getTimeZone(psTimeZoneId);
		tzFormat.setTimeZone(tz);
		return tzFormat;
	}
	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Feb 1, 2018 - 2:35:48 PM
	 * 
	 * @Author : karthi
	 * 
	 * @Description : Populate Configured Application UIScreen Column
	 * 
	 * @Tags :
	 * @param appUIScreenFields
	 *            input as appUIScreenFields custom class
	 * @param columns
	 *            input as list of column in String
	 * @param dataTypes
	 *            input as String DataType for column DataType
	 * @param obj
	 *            input as Object
	 * @param i
	 *            input as int
	 * @param caseEncryptedId
	 *            input as Encrypted Case Id
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 * @throws NoSuchMethodException
	 * @throws UnsupportedEncodingException
	 * @Git_Config : name email
	 * 
	 */
	private void populateAppUIScreenColumn(List<AppUIScreenField> appUIScreenFields, List<String> columns,
			List<String> dataTypes, Object obj, int i, StringBuilder caseEncryptedId)
			throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
		Object value;
		String dataType;
		String entity = null;
		Long additionalRecId = null;
		AppUIScreenField appUIScreenField = appUIScreenFields.get(i);
		dataType = dataTypes.get(i);

		value = PropertyUtils.getSimpleProperty(obj, appUIScreenField.getDbFieldName());
		if (value != null) {

			if (dataType.equals(Calendar.class.getName())) {
				columns.add(CommonUtils.calendarToString((Calendar) value));
			} else if (dataType.equals(DateTime.class.getName()) || dataType.equals(Date.class.getName())) {
				if (appUIScreenField.getDbFieldName().equals("lastModifiedDate")
						&& appUIScreenField.getDbTableName().equalsIgnoreCase("CaseQuery")) {
					if (value != null) {
						if (obj != null) {
							if (obj instanceof CaseQuery) {
								CaseQuery caseQuery = (CaseQuery) obj;
								Long queryId = caseQuery.getId();
								if (queryId != null) {
									DateTime caseQueryResponse = this.caseQueryService
											.updateCaseQueryModifiedDate(queryId);
									if (caseQueryResponse != null) {
										try {
											SimpleDateFormat tzFormat = this.getUserTimeZoneId();
											columns.add(tzFormat.format(new DateTime(caseQueryResponse).toDate()));
										} catch (Exception e) {
											columns.add(CommonUtils.dateTimeToString(new DateTime(value)));
										}
									}

								}
							}

						}
					}
				} else {
					try {
					
						SimpleDateFormat tzFormat = this.getUserTimeZoneId();
						columns.add(tzFormat.format(new DateTime(value).toDate()));
					} catch (Exception e) {
						columns.add(CommonUtils.dateTimeToString(new DateTime(value)));
					}
				}
			} else if (dataType.equals(Integer.class.getName())
					&& appUIScreenField.getDbFieldName().endsWith(AppConstants.COLUMN_NAME_HOURS)) {
				Integer totalHours = (Integer) value;
				columns.add(CommonUtils.getHourPartofTotalHours(totalHours) + AppConstants.SUFFIX_HOURS
						+ AppConstants.SPACE_SEPARATOR + CommonUtils.getMinutesPartofTotalHours(totalHours)
						+ AppConstants.SUFFIX_MINUTES);
			} else if (dataType.equals(Account.class.getName())) {
				this.populateForAccount(columns, obj, value, appUIScreenField);
			} else if (dataType.equals(Case.class.getName())) {
				this.populateForCase(columns, obj, caseEncryptedId, value, appUIScreenField);
			} else if (dataType.equals(User.class.getName())) {
				this.populateForUser(columns, obj, value, appUIScreenField);
			} else if (dataType.equals(AppItem.class.getName())) {
				this.populateForAppItem(columns, obj, value, appUIScreenField);
			} else if (dataType.equals(Role.class.getName())) {
				this.populateForRole(columns, obj, value, appUIScreenField);
			} else if (dataType.equals(Team.class.getName())) {
				this.populateForTeam(columns, obj, value, appUIScreenField);
			} else if (dataType.equals(UserProfile.class.getName())) {
				this.populateForUserProfile(columns, obj, value, appUIScreenField);
			} else if (dataType.equals(Partner.class.getName())) {
				this.populateForPartner(columns, obj, value, appUIScreenField);
			} else if (dataType.equals(CaseFile.class.getName())) {
				this.populateForCaseFile(columns, obj, caseEncryptedId, value, appUIScreenField);
			} else if (dataType.equals(CaseResultFile.class.getName())) {
				this.populateForCaseResultFile(columns, obj, caseEncryptedId, value, appUIScreenField);
			} else if (dataType.equals(Division.class.getName())) {
				this.populateForDivision(columns, obj, value, appUIScreenField);
			} else if (dataType.equals(Long.class.getName())
					&& appUIScreenField.getDbFieldName().equalsIgnoreCase("fileId")) {
				this.populateForCaseFileName(columns, obj, caseEncryptedId, value, appUIScreenField);
			} else if (dataType.equals(Long.class.getName())
					&& appUIScreenField.getDbFieldName().equalsIgnoreCase("entityId")) {
				if (obj instanceof ArchivalHistory) {
					ArchivalHistory archivalHistory = (ArchivalHistory) obj;
					entity = archivalHistory.getEntity();
					if (entity != null) {
						if (entity.equalsIgnoreCase("Query")) {
							this.populateForArchivalQueryName(columns, obj, caseEncryptedId, value, appUIScreenField);
						} else {
							this.populateForArchivalTaskName(columns, obj, caseEncryptedId, value, appUIScreenField);
						}
					}
				}
			} else if (dataType.equals(String.class.getName())
					&& appUIScreenField.getDbFieldName().equals("contactName")) {
				this.populateForCaseContactName(columns, obj, caseEncryptedId, value, appUIScreenField);
			} else if (dataType.equals(Long.class.getName()) && appUIScreenField.getDbFieldName().equals("fileSize")) {
				Long fileSize = (Long) value;
				columns.add(fileSize + AppConstants.SPACE_SEPARATOR + "kb");
			} else if (dataType.equals(String.class.getName())
					&& appUIScreenField.getDbFieldName().equals("toEmailIds")) {
				String[] arrEmailIds = value.toString().split(",");
				columns.add(arrEmailIds[0]);
			} else if (dataType.equals(Long.class.getName())
					&& appUIScreenField.getDbFieldName().equalsIgnoreCase("additionalRecId")) {
				if (obj instanceof CaseServiceReq) {
					CaseServiceReq caseServiceReq = (CaseServiceReq) obj;
					additionalRecId = caseServiceReq.getAdditionalRecId();
					if (additionalRecId != null) {
						this.populateForAdditionalRecService(columns, obj, caseEncryptedId, value, appUIScreenField);
					}
				}
			} else if (dataType.equals(String.class.getName()) && appUIScreenField.getDbFieldName().equals("name")
					&& appUIScreenField.getDbTableName().equalsIgnoreCase("case")) {
				if (value != null) {
					try {
						value = URLEncoder.encode(String.valueOf(value), "UTF-8").replaceAll("\\+", "%20");
						columns.add(String.valueOf(value));
					} catch (UnsupportedEncodingException e) {
						e.printStackTrace();
					}
				}
			} else if (dataType.equals(String.class.getName()) && appUIScreenField.getDbFieldName().equals("subject")
					&& appUIScreenField.getDbTableName().equalsIgnoreCase("EmailQueue")) {
				if (value != null) {
					try {
						value = URLEncoder.encode(String.valueOf(value), "UTF-8").replaceAll("\\+", "%20");
						columns.add(String.valueOf(value));
					} catch (UnsupportedEncodingException e) {
						e.printStackTrace();
					}
				}

			} // Update ChildCase Status to ParentCase
			else if (dataType.equals(String.class.getName()) && appUIScreenField.getDbFieldName().equals("clientStatus")
					&& appUIScreenField.getDbTableName().equalsIgnoreCase("case")) {
				if (value != null) {
					User loginUser = this.userService.getCurrentUser(null);
					if (loginUser.getRole().getType().equalsIgnoreCase(Role.ROLE_CUSTOMER)) {
						if (obj != null) {
							if (obj instanceof Case) {
								Case appCasee = (Case) obj;
								Long caseId = appCasee.getId();
								if (caseId != null) {
									List<Case> subCaseList = this.caseRepository.findByParentId(caseId);
									if (subCaseList.size() != 0) {
										Case clientStaus = this.caseService.updateClientStausByChildCase(caseId);
										if (clientStaus != null) {
											String status = clientStaus.getClientStatus();
											if (StringUtils.isNotBlank(status) && StringUtils.isNotEmpty(status)) {
												columns.add(String.valueOf(status));
											}
										}
									} else {
										columns.add(String.valueOf(value));
									}
								}
							}
						}
					}
				}

			} else {
				columns.add(String.valueOf(value));
			}
		} else {
			columns.add(AppConstants.EMPTY_STRING);
		}

	}
	
	public Pageable constructPageSpecification(ScreenListFilterVO screenListFilterVO) {
		Direction sortDirection = null;
		if (screenListFilterVO.getSortOrder().equals(AppConstants.SORT_PREF_ASC)) {
			sortDirection = Sort.Direction.ASC;
		} else {
			sortDirection = Sort.Direction.DESC;
		}
		Sort sortOption = new Sort(sortDirection, screenListFilterVO.getSortByField());
		int pageNo = screenListFilterVO.getPageNo() - 1;

		return new PageRequest(pageNo, screenListFilterVO.getRecordsPerPage(), sortOption);
	}
	
	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Feb 1, 2018 - 2:35:48 PM
	 * 
	 * @Author : karthi
	 * 
	 * @Description : Populated For Files Details
	 * 
	 * @Tags :
	 * @param columns
	 *            input as list of column names
	 * @param obj
	 *            input as object
	 * @param caseEncryptedId
	 *            input as encrypted Case Id
	 * @param value
	 *            input as object value
	 * @param appUIScreenField
	 *            input as custom class
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 * @throws NoSuchMethodException
	 * @Git_Config : name email
	 * 
	 */
	private void populateForFiles(List<String> columns, Object obj, Object value, AppUIScreenField appUIScreenField)
			throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
		if (appUIScreenField.getDbFieldName().equals("isDeliverable") && value.equals('N') && (value != null)) {
			String isDeliverable = String.valueOf(value);
			columns.add(isDeliverable + AppConstants.SPACE_SEPARATOR + "chkboxTikFalse");
		} else {
			String isDeliverable = String.valueOf(value);
			columns.add(isDeliverable + AppConstants.SPACE_SEPARATOR + "chkboxTikTrue");
		}

	}

	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Feb 1, 2018 - 2:35:48 PM
	 * 
	 * @Author : karthi
	 * 
	 * @Description : Populated For Partner Information. added on 13-09-2017 get
	 *              partner name from Partner Entity
	 * 
	 * @Tags :
	 * @param columns
	 *            input as list of column names
	 * @param obj
	 *            input as object
	 * @param caseEncryptedId
	 *            input as encrypted Case Id
	 * @param value
	 *            input as object value
	 * @param appUIScreenField
	 *            input as custom class
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 * @throws NoSuchMethodException
	 * @Git_Config : name email
	 * 
	 */
	private void populateForPartner(List<String> columns, Object obj, Object value, AppUIScreenField appUIScreenField)
			throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
		try {
			if (value != null) {
				String partnerName = (String) PropertyUtils.getNestedProperty(obj,
						appUIScreenField.getDbFieldName() + ".name");
				columns.add(partnerName);
			} else {
				columns.add(AppConstants.EMPTY_STRING);
			}
		} catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException ex) {
			columns.add(AppConstants.EMPTY_STRING);
		}
	}

	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Feb 1, 2018 - 2:35:48 PM
	 * 
	 * @Author : karthi
	 * 
	 * @Description : Populated For Role Details
	 * 
	 * @Tags :
	 * @param columns
	 *            input as list of column names
	 * @param obj
	 *            input as object
	 * @param caseEncryptedId
	 *            input as encrypted Case Id
	 * @param value
	 *            input as object value
	 * @param appUIScreenField
	 *            input as custom class
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 * @throws NoSuchMethodException
	 * @Git_Config : name email
	 * 
	 */
	private void populateForRole(List<String> columns, Object obj, Object value, AppUIScreenField appUIScreenField)
			throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
		if (value != null) {
			String longName = (String) PropertyUtils.getNestedProperty(obj,
					appUIScreenField.getDbFieldName() + ".name");
			columns.add(longName);
		} else {
			columns.add(AppConstants.EMPTY_STRING);
		}
	}

	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Feb 1, 2018 - 2:35:48 PM
	 * 
	 * @Author : karthi
	 * 
	 * @Description : Populated For Team Details
	 * 
	 * @Tags :
	 * @param columns
	 *            input as list of column names
	 * @param obj
	 *            input as object
	 * @param caseEncryptedId
	 *            input as encrypted Case Id
	 * @param value
	 *            input as object value
	 * @param appUIScreenField
	 *            input as custom class
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 * @throws NoSuchMethodException
	 * @Git_Config : name email
	 * 
	 */
	private void populateForTeam(List<String> columns, Object obj, Object value, AppUIScreenField appUIScreenField)
			throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
		if (value != null) {
			String longName = (String) PropertyUtils.getNestedProperty(obj,
					appUIScreenField.getDbFieldName() + ".name");
			columns.add(longName);
		} else {
			columns.add(AppConstants.EMPTY_STRING);
		}
	}

	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Feb 1, 2018 - 2:35:48 PM
	 * 
	 * @Author : karthi
	 * 
	 * @Description : Populated For User Details in portal
	 * 
	 * @Tags :
	 * @param columns
	 *            input as list of column names
	 * @param obj
	 *            input as object
	 * @param caseEncryptedId
	 *            input as encrypted Case Id
	 * @param value
	 *            input as object value
	 * @param appUIScreenField
	 *            input as custom class
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 * @throws NoSuchMethodException
	 * @Git_Config : name email
	 * 
	 */
	private void populateForUser(List<String> columns, Object obj, Object value, AppUIScreenField appUIScreenField)
			throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {

		if (value != null) {
			try {
				String firstName = (String) PropertyUtils.getNestedProperty(obj,
						appUIScreenField.getDbFieldName() + ".userProfile.firstName");
				String lastName = (String) PropertyUtils.getNestedProperty(obj,
						appUIScreenField.getDbFieldName() + ".userProfile.lastName");
				columns.add(firstName + AppConstants.SPACE_SEPARATOR + lastName);
			} catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException ex) {
				columns.add(AppConstants.EMPTY_STRING);
				LOGGER.error(CLASS_NAME, "populateForUser", ex);
			}
		} else {
			columns.add(AppConstants.EMPTY_STRING);
		}
	}

	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Feb 1, 2018 - 2:35:48 PM
	 * 
	 * @Author : karthi
	 * 
	 * @Description : Populated For UserProfile Details
	 * 
	 * @Tags :
	 * @param columns
	 *            input as list of column names
	 * @param obj
	 *            input as object
	 * @param caseEncryptedId
	 *            input as encrypted Case Id
	 * @param value
	 *            input as object value
	 * @param appUIScreenField
	 *            input as custom class
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 * @throws NoSuchMethodException
	 * @Git_Config : name email
	 * 
	 */
	private void populateForUserProfile(List<String> columns, Object obj, Object value,
			AppUIScreenField appUIScreenField)
			throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
		try {
			if (value != null) {
				String longName = (String) PropertyUtils.getNestedProperty(obj,
						appUIScreenField.getDbFieldName() + ".customerCode");
				columns.add(longName);
			} else {
				columns.add(AppConstants.EMPTY_STRING);
			}

		} catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException ex) {
			columns.add(AppConstants.EMPTY_STRING);
		}
	}

	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Feb 1, 2018 - 2:35:48 PM
	 * 
	 * @Author : karthi
	 * 
	 * @Description : Populated Production StatusMap. Populating the role name
	 *              according to datatype , coded by sita
	 * 
	 * @Tags :
	 * @param appUIScreenFilter
	 *            input as appUIScreenFilter
	 * @Git_Config : name email
	 * 
	 */
	public void populateProductionStatusMap(AppUIScreenFilterVO appUIScreenFilter) {
		AppList caseTypeList = this.cacheService.findByAppListName(AppList.PRODUCTION_STATUS);
		List<AppItem> caseTypeItems = this.cacheService.findByListId(caseTypeList.getId());
		Map<String, String> productionstatusMap = new LinkedHashMap<>(caseTypeItems.size());
		productionstatusMap.put(AppConstants.EMPTY_STRING, AppConstants.CASE_FILTER_ANY);
		for (AppItem appItem : caseTypeItems) {
			productionstatusMap.put(appItem.getId().toString(), appItem.getLongName());
		}
		appUIScreenFilter.setListItemMap(productionstatusMap);
	}


/**
 * [Methods]
 * 
 * @DateAndTime : Feb 1, 2018 - 2:35:48 PM
 * 
 * @Author : karthi
 * 
 * @Description : populated For Account Details in Portal
 * 
 * @Tags :
 * @param columns
 *            input as list of String columns
 * @param obj
 *            input as object
 * @param value
 *            input as object
 * @param appUIScreenField
 *            input as appUIScreenField
 * @throws IllegalAccessException
 * @throws InvocationTargetException
 * @throws NoSuchMethodException
 * @Git_Config : name email
 * 
 */
private void populateForAccount(List<String> columns, Object obj, Object value, AppUIScreenField appUIScreenField)
		throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
	if (value != null) {
		String accountName = (String) PropertyUtils.getNestedProperty(obj,
				appUIScreenField.getDbFieldName() + ".name");
		columns.add(accountName);
	} else {
		columns.add(AppConstants.EMPTY_STRING);
	}
}

/**
 * [Methods]
 * 
 * @DateAndTime : Feb 1, 2018 - 2:35:48 PM
 * 
 * @Author : karthi
 * 
 * @Description : populated For Case Details
 * 
 * @Tags :
 * @param columns
 *            input as list of column names
 * @param obj
 *            input as object
 * @param caseEncryptedId
 *            input as encrypted Case Id
 * @param value
 *            input as object value
 * @param appUIScreenField
 *            input as custom class
 * @throws IllegalAccessException
 * @throws InvocationTargetException
 * @throws NoSuchMethodException
 * @Git_Config : name email
 * 
 */
private void populateForCase(List<String> columns, Object obj, StringBuilder caseEncryptedId, Object value,
		AppUIScreenField appUIScreenField)
		throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
	if (value != null) {
		try {
			String caseName = (String) PropertyUtils.getNestedProperty(obj,
					appUIScreenField.getDbFieldName() + ".name");
			columns.add(caseName);
			Long caseId = (Long) PropertyUtils.getNestedProperty(obj, appUIScreenField.getDbFieldName() + ".id");
			caseEncryptedId.append(EncryptionUtils.encryptId(caseId));
		} catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException ex) {
			LOGGER.error(CLASS_NAME, "populateForCase", ex);
		}
	} else {
		columns.add(AppConstants.EMPTY_STRING);
	}
}
/**
 * [Methods]
 * 
 * @DateAndTime : Feb 1, 2018 - 2:35:48 PM
 * 
 * @Author : karthi
 * 
 * @Description : Populated For AppItem in portal
 * 
 * @Tags :
 * @param columns
 * @param obj
 * @param value
 * @param appUIScreenField
 * @throws IllegalAccessException
 * @throws InvocationTargetException
 * @throws NoSuchMethodException
 * @Git_Config : name email
 * 
 */
private void populateForAppItem(List<String> columns, Object obj, Object value, AppUIScreenField appUIScreenField)
		throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
	if (value != null) {
		String longName = (String) PropertyUtils.getNestedProperty(obj,
				appUIScreenField.getDbFieldName() + ".longName");
		columns.add(longName);
	} else {
		columns.add(AppConstants.EMPTY_STRING);
	}
}
/**
 * [Methods]
 * 
 * @DateAndTime : Feb 1, 2018 - 2:35:48 PM
 * 
 * @Author : karthi
 * 
 * @Description : Populated For Case File Details
 * 
 * @Tags :
 * @param columns
 *            input as list of column names
 * @param obj
 *            input as object
 * @param caseEncryptedId
 *            input as encrypted Case Id
 * @param value
 *            input as object value
 * @param appUIScreenField
 *            input as custom class
 * @throws IllegalAccessException
 * @throws InvocationTargetException
 * @throws NoSuchMethodException
 * @Git_Config : name email
 * 
 */
private void populateForCaseFile(List<String> columns, Object obj, StringBuilder caseEncryptedId, Object value,
		AppUIScreenField appUIScreenField)
		throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
	if (value != null) {
		try {
			String caseFileName = (String) PropertyUtils.getNestedProperty(obj,
					appUIScreenField.getDbFieldName() + ".name");
			columns.add(caseFileName);
		} catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException ex) {
			columns.add(AppConstants.EMPTY_STRING);
			LOGGER.error(CLASS_NAME, "populateForCaseFile", ex);
		}
	} else {
		columns.add(AppConstants.EMPTY_STRING);
	}
}
/**
 * [Methods]
 * 
 * @DateAndTime : Feb 1, 2018 - 2:35:48 PM
 * 
 * @Author : karthi
 * 
 * @Description : Populated For Case Result File Details
 * 
 * @Tags :
 * @param columns
 *            input as list of column names
 * @param obj
 *            input as object
 * @param caseEncryptedId
 *            input as encrypted Case Id
 * @param value
 *            input as object value
 * @param appUIScreenField
 *            input as custom class
 * @throws IllegalAccessException
 * @throws InvocationTargetException
 * @throws NoSuchMethodException
 * @Git_Config : name email
 * 
 */
private void populateForCaseResultFile(List<String> columns, Object obj, StringBuilder caseEncryptedId,
		Object value, AppUIScreenField appUIScreenField)
		throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
	if (value != null) {
		try {
			String caseFileName = (String) PropertyUtils.getNestedProperty(obj,
					appUIScreenField.getDbFieldName() + ".name");
			columns.add(caseFileName);
		} catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException ex) {
			LOGGER.error(CLASS_NAME, "populateForCaseResultFile", ex);
		}
	} else {
		columns.add(AppConstants.EMPTY_STRING);
	}
}
/**
 * [Methods]
 * 
 * @DateAndTime : Feb 1, 2018 - 2:35:48 PM
 * 
 * @Author : karthi
 * 
 * @Description : Populated For Division Details
 * 
 * @Tags :
 * @param columns
 *            input as list of column names
 * @param obj
 *            input as object
 * @param caseEncryptedId
 *            input as encrypted Case Id
 * @param value
 *            input as object value
 * @param appUIScreenField
 *            input as custom class
 * @throws IllegalAccessException
 * @throws InvocationTargetException
 * @throws NoSuchMethodException
 *
 *
 * @Git_Config : name email
 * 
 */
private void populateForDivision(List<String> columns, Object obj, Object value, AppUIScreenField appUIScreenField)
		throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
	if (value != null) {
		String longName = (String) PropertyUtils.getNestedProperty(obj,
				appUIScreenField.getDbFieldName() + ".name");
		columns.add(longName);
	} else {
		columns.add(AppConstants.EMPTY_STRING);
	}
}

/**
 * [Methods]
 * 
 * @DateAndTime : Feb 1, 2018 - 2:35:48 PM
 * 
 * @Author : karthi
 * 
 * @Description : Populated For Case FileName Details
 * 
 * @Tags :
 * @param columns
 *            input as list of column names
 * @param obj
 *            input as object
 * @param caseEncryptedId
 *            input as encrypted Case Id
 * @param value
 *            input as object value
 * @param appUIScreenField
 *            input as custom class
 * @throws IllegalAccessException
 * @throws InvocationTargetException
 * @throws NoSuchMethodException
 * @Git_Config : name email
 * 
 */
private void populateForCaseFileName(List<String> columns, Object obj, StringBuilder caseEncryptedId, Object value,
		AppUIScreenField appUIScreenField)
		throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
	if (value != null) {
		Long id = Long.parseLong(value.toString());
		if (id != null) {
			try {
				CaseFile caseFile = this.caseFileRepository.findOne(id);
				CaseResultFile caseResultFile = this.caseResultFileRepository.findOne(id);
				if (caseFile != null) {
					String caseFileName = caseFile.getName();
					columns.add(caseFileName);
				} else if (caseResultFile != null) {
					String caseFileName = caseResultFile.getName();
					columns.add(caseFileName);
				} else {
					columns.add(AppConstants.EMPTY_STRING);
				}

			} catch (Exception ex) {
				LOGGER.error(CLASS_NAME, "populateForCaseFileName", ex);
				columns.add(AppConstants.EMPTY_STRING);
			}
		}
	} else {
		columns.add(AppConstants.EMPTY_STRING);
	}
}

/**
 * [Methods]
 * 
 * @DateAndTime : Feb 1, 2018 - 2:35:48 PM
 * 
 * @Author : karthi
 * 
 * @Description : Populated For Archival Query Name
 * 
 * @Tags :
 * @param columns
 *            input as list of column names
 * @param obj
 *            input as object
 * @param caseEncryptedId
 *            input as encrypted Case Id
 * @param value
 *            input as object value
 * @param appUIScreenField
 *            input as custom class
 * @throws IllegalAccessException
 * @throws InvocationTargetException
 * @throws NoSuchMethodException
 * @Git_Config : name email
 * 
 */
private void populateForArchivalQueryName(List<String> columns, Object obj, StringBuilder caseEncryptedId,
		Object value, AppUIScreenField appUIScreenField)
		throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
	if (value != null) {
		Long id = Long.parseLong(value.toString());
		if (id != null) {
			try {
				CaseQuery caseQuery = this.caseQueryRepository.findOne(id);
				if (caseQuery != null) {
					String queryName = caseQuery.getQuerySubject();
					columns.add(queryName);
				} else {
					columns.add(AppConstants.EMPTY_STRING);
				}
			} catch (Exception ex) {
				LOGGER.error(CLASS_NAME, "populateForArchivalQueryName", ex);
			}
		}
	} else {
		columns.add(AppConstants.EMPTY_STRING);
	}
}

/**
 * [Methods]
 * 
 * @DateAndTime : Feb 1, 2018 - 2:35:48 PM
 * 
 * @Author : karthi
 * 
 * @Description : Populated For Archival Task Name
 * 
 * @Tags :
 * @param columns
 *            input as list of column names
 * @param obj
 *            input as object
 * @param caseEncryptedId
 *            input as encrypted Case Id
 * @param value
 *            input as object value
 * @param appUIScreenField
 *            input as custom class
 * @throws IllegalAccessException
 * @throws InvocationTargetException
 * @throws NoSuchMethodException
 * @Git_Config : name email
 * 
 */
private void populateForArchivalTaskName(List<String> columns, Object obj, StringBuilder caseEncryptedId,
		Object value, AppUIScreenField appUIScreenField)
		throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
	if (value != null) {
		Long id = Long.parseLong(value.toString());
		if (id != null) {
			try {
				CaseTask caseTask = this.caseTaskRepository.findOne(id);
				if (caseTask != null) {
					String caseTaskName = caseTask.getName();
					columns.add(caseTaskName);
				} else {
					columns.add(AppConstants.EMPTY_STRING);
				}
			} catch (Exception ex) {
				LOGGER.error(CLASS_NAME, "populateForArchivalTaskName", ex);
				columns.add(AppConstants.EMPTY_STRING);
			}
		}
	} else {
		columns.add(AppConstants.EMPTY_STRING);
	}
}

/**
 * [Methods]
 * 
 * @DateAndTime : Feb 1, 2018 - 2:35:48 PM
 * 
 * @Author : karthi
 * 
 * @Description : Populated For CaseContactName Details. Begin Ramya 12/28/2017
 *              display contact name in case list
 * 
 * @Tags :
 * @param columns
 *            input as list of column names
 * @param obj
 *            input as object
 * @param value
 *            input as object value
 * @param caseEncryptedId
 *            input as Encrpted Case Id
 * @param appUIScreenField
 *            input as custom class
 * @throws IllegalAccessException
 * @throws InvocationTargetException
 * @throws NoSuchMethodException
 * @Git_Config : name email
 * 
 */
/* Begin Ramya 12/28/2017 display contact name in case list */
private void populateForCaseContactName(List<String> columns, Object obj, StringBuilder caseEncryptedId,
		Object value, AppUIScreenField appUIScreenField)
		throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
	if (obj instanceof Case) {
		Case cases = (Case) obj;
		Long caseid = cases.getId();
		if (caseid != null) {
			try {
				List<String> names = new ArrayList<>();
				List<CaseContacts> caseContactsList = this.caseContactsRepository
						.listCaseContactsByCaseID(AppConstants.NO, caseid);
				if (caseContactsList.size() > 0) {
					for (CaseContacts caseContacts : caseContactsList) {
						names.add(caseContacts.getName());
					}
					columns.add(StringUtils.join(names, ","));
				} else {
					columns.add(AppConstants.EMPTY_STRING);
				}
			} catch (Exception ex) {
				LOGGER.error(CLASS_NAME, "populateForCaseContactName", ex);
			}
		}
	} else {
		columns.add(AppConstants.EMPTY_STRING);
	}
}

private void populateForAdditionalRecService(List<String> columns, Object obj, StringBuilder caseEncryptedId,
		Object value, AppUIScreenField appUIScreenField) {
	if (value != null) {
		Long id = Long.parseLong(value.toString());
		if (id != null) {
			try {
				CaseFilesChangeHistory caseFilesChangeHistory = this.caseFilesChangeHistoryRepository.findOne(id);
				if (caseFilesChangeHistory != null) {
					String serviceshortCode = caseFilesChangeHistory.getServiceRequested();
					columns.add(id + "-" + serviceshortCode);
				} else {
					columns.add(AppConstants.EMPTY_STRING);
				}
			} catch (Exception ex) {
				LOGGER.error(CLASS_NAME, "populateForArchivalTaskName", ex);
			}
		}
	} else {
		columns.add(AppConstants.EMPTY_STRING);
	}

}



/**
 * [Methods]
 * 
 * @DateAndTime : Feb 1, 2018 - 2:35:48 PM
 * 
 * @Author : karthi
 * 
 * @Description : Populated CaseFilter Specifications
 * 
 * @Tags :
 * @param screenListFilterVO
 *            input as screenListFilterVO contains properties of Screen Details.
 * @param specifications
 *            input as defined Specifications
 * @return
 * @Git_Config : name email
 * 
 */
@SuppressWarnings("unused")
public Specifications<T> populateCaseFilterSpecifications(ScreenListFilterVO screenListFilterVO,
		Specifications<T> specifications) {
	Specification<T> specification = null;
	Specifications<T> filterSpecifications = null;
	Specifications<T> updatedSpecifications = specifications;
	List<AppUIScreenFilterVO> appUIScreenFilterVOs = screenListFilterVO.getAppUIScreenFilterVOs();
	List<Account> accountListToSearch = new ArrayList<>();
	List<AppItem> appItemListToSearch = new ArrayList<>();
	Specification<T> specificationsNew = null;
	for (AppUIScreenFilterVO appUIScreenFilterVO : appUIScreenFilterVOs) {
		if (StringUtils.isNotBlank(appUIScreenFilterVO.getValue())) {
			if (appUIScreenFilterVO.getFilterDataType().equals(CommonUtils.trimClassName(String.class.getName()))) {
				specification = this.genericSpecifications.dataTypeString(appUIScreenFilterVO.getDbFieldName(),
						appUIScreenFilterVO.getValue());

			} else if (appUIScreenFilterVO.getFilterDataType()
					.equals(CommonUtils.trimClassName(Character.class.getName()))) {
				specification = this.genericSpecifications.dataTypeCharacter(appUIScreenFilterVO.getDbFieldName(),
						appUIScreenFilterVO.getValue().charAt(0));
			} else if (appUIScreenFilterVO.getFilterDataType()
					.equals(CommonUtils.trimClassName(Calendar.class.getName()))
					|| appUIScreenFilterVO.getFilterDataType()
							.equals(CommonUtils.trimClassName(Date.class.getName()))) {
				if (appUIScreenFilterVO.getDbFieldName().indexOf("todatefield") < 0) {

					if (StringUtils.isNotBlank(appUIScreenFilterVO.getDbTableName())
							&& StringUtils.isNotEmpty(appUIScreenFilterVO.getDbTableName())
							&& StringUtils.isNotBlank(appUIScreenFilterVO.getFilterDataType())
							&& StringUtils.isNotEmpty(appUIScreenFilterVO.getFilterDataType())
							&& StringUtils.isNotBlank(appUIScreenFilterVO.getDbFieldName())
							&& StringUtils.isNotEmpty(appUIScreenFilterVO.getDbFieldName())) {

						for (AppUIScreenFilterVO appUIScreenFilterVOUpdate : appUIScreenFilterVOs) {
							if (appUIScreenFilterVO.getDbTableName()
									.equalsIgnoreCase(appUIScreenFilterVOUpdate.getDbTableName())
									&& appUIScreenFilterVO.getFilterDataType()
											.equalsIgnoreCase(appUIScreenFilterVOUpdate.getFilterDataType())
									&& appUIScreenFilterVOUpdate.getDbFieldName().equalsIgnoreCase(
											"todatefield".concat(appUIScreenFilterVO.getDbFieldName()))) {

								Calendar fromDate = CommonUtils.stringToCalendar(appUIScreenFilterVO.getValue());
								fromDate.set(Calendar.HOUR, 0);
								fromDate.set(Calendar.MINUTE, 0);
								fromDate.set(Calendar.SECOND, 0);
								fromDate.set(Calendar.MILLISECOND, 0);
								fromDate.set(Calendar.AM_PM, Calendar.AM);

								Calendar toDate = CommonUtils.stringToCalendar(
										StringUtils.isNotBlank(appUIScreenFilterVOUpdate.getValue())
												&& StringUtils.isNotEmpty(appUIScreenFilterVOUpdate.getValue())
														? appUIScreenFilterVOUpdate.getValue()
														: appUIScreenFilterVO.getValue());
								toDate = CommonUtils.getCalendarEndOfDayTime(toDate);

								if (fromDate.compareTo(toDate) > 0) {
									specification = this.genericSpecifications.dataTypeCalendar(
											appUIScreenFilterVO.getDbFieldName(), toDate, fromDate);
								} else {
									specification = this.genericSpecifications.dataTypeCalendar(
											appUIScreenFilterVO.getDbFieldName(), fromDate, toDate);
								}

								break;

							}
						}
					} else {
						Calendar fromDate = CommonUtils.stringToCalendar(appUIScreenFilterVO.getValue());
						fromDate.set(Calendar.HOUR, 0);
						fromDate.set(Calendar.MINUTE, 0);
						fromDate.set(Calendar.SECOND, 0);
						fromDate.set(Calendar.MILLISECOND, 0);
						fromDate.set(Calendar.AM_PM, Calendar.AM);

						Calendar toDate = CommonUtils.getCalendarEndOfDayTime(fromDate);

						if (fromDate.compareTo(toDate) > 0) {
							specification = this.genericSpecifications
									.dataTypeCalendar(appUIScreenFilterVO.getDbFieldName(), toDate, fromDate);
						} else {
							specification = this.genericSpecifications
									.dataTypeCalendar(appUIScreenFilterVO.getDbFieldName(), fromDate, toDate);
						}
					}
				}

			} else if (appUIScreenFilterVO.getFilterDataType()
					.equals(CommonUtils.trimClassName(User.class.getName()))) {
				User assignedToUser = this.cacheService.findByUserId(Long.valueOf(appUIScreenFilterVO.getValue()));
				specification = this.genericSpecifications.dataTypeUser(appUIScreenFilterVO.getDbFieldName(),
						assignedToUser);
			} else if (appUIScreenFilterVO.getFilterDataType()
					.equals(CommonUtils.trimClassName(Case.class.getName()))) {

				if (StringUtils.isNumeric(appUIScreenFilterVO.getValue())) {

					List<Case> appCase = this.caseService.getAssignedToCaseList(appUIScreenFilterVO.getValue());
					if (appCase.size() > 0) {
						specification = this.genericSpecifications
								.dataTypeCaseList(appUIScreenFilterVO.getDbFieldName(), appCase);
					}
				} else {
					specification = this.genericSpecifications.dataTypeClassName(
							appUIScreenFilterVO.getDbFieldName(), appUIScreenFilterVO.getValue());
				}

			} else if (appUIScreenFilterVO.getFilterDataType()
					.equals(CommonUtils.trimClassName(Division.class.getName()))) {
				Division division = this.cacheService
						.findDivisionName(Long.valueOf(appUIScreenFilterVO.getValue()));
				specification = this.genericSpecifications.dataTypeDivision(appUIScreenFilterVO.getDbFieldName(),
						division);
			} else if (appUIScreenFilterVO.getFilterDataType()
					.equals(CommonUtils.trimClassName(Role.class.getName()))) {
				Role role = this.cacheService.findByRoleId(Long.parseLong(appUIScreenFilterVO.getValue()));
				specification = this.genericSpecifications.dataTypeRole("role", role);
			} else if (appUIScreenFilterVO.getFilterDataType()
					.equals(CommonUtils.trimClassName(Team.class.getName()))) {
				Team team = this.cacheService.findByTeamId(Long.parseLong(appUIScreenFilterVO.getValue()));
				specification = this.genericSpecifications.dataTypeTeam("team", team);
			} else if (appUIScreenFilterVO.getFilterDataType()
					.equals(CommonUtils.trimClassName(Partner.class.getName()))) {
				Partner partner = this.cacheService.findByPartnerId(Long.parseLong(appUIScreenFilterVO.getValue()));
				specification = this.genericSpecifications.dataTypePartner(appUIScreenFilterVO.getDbFieldName(),
						partner);
			} else if (appUIScreenFilterVO.getFilterDataType().equals("requestCategory")) {
				if (appUIScreenFilterVO.getValue().equalsIgnoreCase("New")) {
					List<Case> cases = caseRepository.getcaseListNotinCaseFileHistory(AppConstants.NO);
					List<Long> caseIds = new ArrayList<>();
					for (Case appCase : cases) {
						caseIds.add(appCase.getId());
					}
					// Lambda Expression
					/*
					 * cases.stream().filter(casesNew -> casesNew.getId()!=null) .forEach(casesNew
					 * -> caseIds.add(casesNew.getId()) );
					 */
					specification = this.genericSpecifications.dataTypeLongList("id", caseIds);
				} else {
					List<Case> cases = caseRepository.getcaseListInCaseFileHistory(AppConstants.NO);
					List<Long> caseIds = new ArrayList<>();

					for (Case appCase : cases) {
						caseIds.add(appCase.getId());
					}
					// Lambda Expression
					/*
					 * cases.stream().filter(casesNew -> casesNew.getId()!=null) .forEach(casesNew
					 * -> caseIds.add(casesNew.getId()) );
					 */

					specification = this.genericSpecifications.dataTypeLongList("id", caseIds);
				}

			} else if (appUIScreenFilterVO.getFilterDataType()
					.equals(CommonUtils.trimClassName(Account.class.getName()))) {
				if (appUIScreenFilterVO.getFilterName().equalsIgnoreCase(AppConstants.ACCOUNT_MANAGER)) {
					if (appUIScreenFilterVO.getValue() != null
							&& StringUtils.isNotBlank(appUIScreenFilterVO.getValue())
							&& StringUtils.isNotEmpty(appUIScreenFilterVO.getValue())) {
						List<Account> listAccounts = this.accountRepository
								.findAccountsByManager(new Long(appUIScreenFilterVO.getValue()), AppConstants.NO);

						if (listAccounts.size() > 0 && !listAccounts.isEmpty()) {
							specification = this.genericSpecifications.dataTypeAccount("account", listAccounts);
						} else {
							Account accountName = this.cacheService.findByAccountId(AppConstants.MINUS_ONE);
							accountListToSearch.add(accountName);
							specification = this.genericSpecifications.dataTypeAccount("account",
									accountListToSearch);
						}
					}
				}
				if (appUIScreenFilterVO.getFilterName().trim().equalsIgnoreCase("Account Name")
						|| appUIScreenFilterVO.getFilterName().trim().equalsIgnoreCase("Account")) {
					if (StringUtils.isNumeric(appUIScreenFilterVO.getValue())) {
						Account accountName = this.cacheService
								.findByAccountId(new Long(appUIScreenFilterVO.getValue()));
						accountListToSearch.add(accountName);
						specification = this.genericSpecifications
								.dataTypeAccount(appUIScreenFilterVO.getDbFieldName(), accountListToSearch);
					} else {
						List<Account> accountDetails = this.accountRepository.findAll();
						for (Account acn : accountDetails) {
							if (acn.getName().toLowerCase()
									.startsWith(appUIScreenFilterVO.getValue().toLowerCase()) == true) {
								Account accountName = this.cacheService.findByAccountId(acn.getId());
								accountListToSearch.add(accountName);
							}
						}
						if (accountListToSearch.size() > 0) {
							specification = this.genericSpecifications
									.dataTypeAccount(appUIScreenFilterVO.getDbFieldName(), accountListToSearch);
						} else {
							Account accountName = this.cacheService.findByAccountId(AppConstants.MINUS_ONE);
							accountListToSearch.add(accountName);
							specification = this.genericSpecifications
									.dataTypeAccount(appUIScreenFilterVO.getDbFieldName(), accountListToSearch);
						}
					}
				}		
			}
			else if(appUIScreenFilterVO.getFilterDataType().equalsIgnoreCase("accountMultiple")) {
				String[] toAccount = appUIScreenFilterVO.getValue().toLowerCase().split(",");
				for (String toEmail : toAccount) {
					if (toEmail != null) {
						Account accountName = this.cacheService
								.findByAccountId(new Long(toEmail));
						accountListToSearch.add(accountName);
					}
				}
				specification = this.genericSpecifications
						.dataTypeAccount(appUIScreenFilterVO.getDbFieldName(), accountListToSearch);
			}
			else if (appUIScreenFilterVO.getFilterDataType()
					.equals(CommonUtils.trimClassName(AppItem.class.getName()))) {
				try {
					AppItem appItem = this.appItemRepository.getOne(Long.parseLong(appUIScreenFilterVO.getValue()));
					appItemListToSearch.add(appItem);
					specification = this.genericSpecifications.dataTypeAppItem(appUIScreenFilterVO.getDbFieldName(),
							appItemListToSearch);
				} catch (Exception e) {
					specification = null;
					LOGGER.error(CLASS_NAME, "populateCaseFilterSpecifications- AppItem Find", e);
				}

			} else {
				specification = null;
			}
			if (specification != null) {
				if (filterSpecifications == null) {
					filterSpecifications = Specifications.where(specification);
				} else {
					if (screenListFilterVO.getFilterCriteria().equals(AppConstants.FILTER_CRITERIA_AND)) {
						filterSpecifications = filterSpecifications.and(specification);
					} else {
						filterSpecifications = filterSpecifications.or(specification);
					}
				}
			}
		}

	}
	if (filterSpecifications != null) {
		updatedSpecifications = specifications.and(filterSpecifications);
	}
	if (specificationsNew != null) {
		updatedSpecifications = specifications.and(specificationsNew);
	}
	return updatedSpecifications;
}

/**
 * [Methods]
 * 
 * @DateAndTime : Feb 1, 2018 - 2:35:48 PM
 * 
 * @Author : karthi
 * 
 * @Description : Case View/Filter Overloading method. Populated
 *              CaseViewSpecifications Added on 2 September 2017
 *              Description:Client can view their branch cases if client role is
 *              Attorney Commented for Avoid the Client to load deleted data on
 *              27 June 2017
 * 
 * @Tags :
 * @param screenListFilterVO
 *            input as screenListFilterVO contains Screen fields & list
 * @param loginUser
 *            input as login user entity
 * @param specifications
 *            input as defined specifications
 * @param isCaseView
 *            input as boolean isCaseView
 * @return
 * @Git_Config : name email
 * 
 */
public Specifications<T> populateCaseViewSpecifications(ScreenListFilterVO screenListFilterVO, User loginUser,
		Specifications<T> specifications, boolean isCaseView) {
	Specification<T> specification = null;
	Specifications<T> updatedSpecifications = specifications;

	if (screenListFilterVO.getSelectedViewType().equals(AppUIScreenView.VIEW_ASSIGNED))
		specification = this.genericSpecifications.dataTypeUser("assignedTo", loginUser);
	else if (screenListFilterVO.getSelectedViewType().equals(AppUIScreenView.VIEW_TEAM)) {
		List<User> teamUsers = this.userRepository.listTeamMembers(AppConstants.TYPE_TRIVENT,
				loginUser.getTeam().getId(), AppConstants.NO);
		specification = this.genericSpecifications.anyUsers("assignedTo", teamUsers);
	} else if (screenListFilterVO.getSelectedViewType().equals(AppUIScreenView.VIEW_CREATED))
		specification = this.genericSpecifications.dataTypeUser("createdBy", loginUser);
	else if (screenListFilterVO.getSelectedViewType().equals(AppUIScreenView.VIEW_CLIENT)) {
		if (loginUser.getClientRole() != null) {
			if (loginUser.getClientRole().equals("Attorney")) {
				UserBranches userBranches = this.userBranchesRepository.findUserBranchesByUserId(AppConstants.NO,
						loginUser.getId());
				if ((userBranches != null) && (userBranches.getBranchId() != null)
						&& StringUtils.isNotBlank(userBranches.getBranchId())
						&& StringUtils.isNotEmpty(userBranches.getBranchId())) {
					List<UserBranches> userIds = this.userBranchesRepository.findUserBranchesBybranchId(
							AppConstants.NO, Long.parseLong(userBranches.getBranchId()));
					List<User> usersList = new ArrayList<>();
					List<Long> userListNew = new ArrayList<>();
					if (userIds != null) {
						for (UserBranches userId : userIds) {
							User user = this.userService.getUserById(userId.getUserId());
							usersList.add(user);
						}

						/*
						 * userIds.stream().filter(p -> p.getUserId()!=null) .forEach(p ->
						 * userListNew.add(p.getUserId()) );
						 */

						if (!userListNew.isEmpty())
							usersList = this.userService.getUserByIdNew(userListNew);

						specification = this.genericSpecifications.anyUsers("client", usersList);
					}

				}

				else if ((userBranches == null || (StringUtils.isBlank(userBranches.getBranchId())
						|| StringUtils.isEmpty(userBranches.getBranchId()))) && (loginUser.getAccount() != null)) {
					List<Account> accounts = new ArrayList<>();
					accounts.add(loginUser.getAccount());
					specification = this.genericSpecifications.dataTypeAccount("account", accounts);
				}

				else {
					specification = this.genericSpecifications.dataTypeUser("client", loginUser);
				}
			} else {
				specification = this.genericSpecifications.dataTypeUser("client", loginUser);
			}
		} else {
			specification = this.genericSpecifications.dataTypeUser("client", loginUser);
		}
	} else if (screenListFilterVO.getSelectedViewType().equals(AppUIScreenView.VIEW_ACCOUNT_MANAGER)) {
		List<Account> accounts = this.accountRepository.findAccountsByManager(loginUser.getId(), AppConstants.NO);
		if (accounts.isEmpty()) {
			Account account = loginUser.getAccount();
			accounts.add(account);
		}
		specification = this.genericSpecifications.anyAccount("account", accounts);
	}

	if (specification != null) {

		Specifications<T> specificationsnew = Specifications.where(specification);
		if (isCaseView) {
			if (screenListFilterVO.getSelectedViewType().equals(AppUIScreenView.VIEW_CLIENT)) {
				List<Long> caseIds = new ArrayList<>();
				List<CaseContacts> caseContacts = this.caseContactsRepository
						.listCaseContactsByLoginUser(AppConstants.NO, loginUser);
				for (CaseContacts caseContact : caseContacts) {
					Long ccCaseID = caseContact.getCaseid().getId();
					caseIds.add(ccCaseID);
				}


				if (caseIds.size() > 0) {
					specification = this.genericSpecifications.dataTypeLongList("id", caseIds);

					specificationsnew = specificationsnew.or(specification);
				}
			}
		}
		updatedSpecifications = specifications.and(specificationsnew);
	}
	return updatedSpecifications;
}


/**
 * [Methods]
 * 
 * @DateAndTime : Sept 18, 2018 - 2:35:48 PM
 * 
 * @Author : kavi
 * 
 * @Description : Populated ScreenList depends upon Screen Name , Screen Types
 * 
 * @Tags :
 * @param screenName
 *            input as Long Screen Name
 * @param screenType
 *            input as String Screen Type
 * @return
 * @throws TriventException
 * @throws ClassNotFoundException 
 * @Git_Config : name email
 * 
 */
public ScreenListFilterVO populateScreenListFilterVO(Long screenName, String screenType) throws TriventException {
	User loginUser = this.userService.getCurrentUser(null);
	AppUIScreen appUIScreen = this.cacheService.findByScreenNameTypeRole(screenName, screenType,
			loginUser.getRole().getId());
	if (appUIScreen != null) {
		List<AppUIScreenFilter> appUIScreenFilters = this.cacheService
				.findFiltersByAppUIScreenId(appUIScreen.getId());
		List<AppUIScreenView> appUIScreenViews = this.cacheService.findViewsByAppUIScreenId(appUIScreen.getId());
		if (appUIScreenViews.isEmpty()) {
			throw new TriventException(AppConstants.MSG_VIEW_NOT_CONFIGURED);
		}
		if (screenType.equalsIgnoreCase(AppConstants.SCREEN_TYPE_LIST)) {
			if (appUIScreenFilters.isEmpty()) {
				throw new TriventException(AppConstants.MSG_FILTER_NOT_CONFIGURED);
			}
		}
		return new ScreenListFilterVO(appUIScreenFilters, appUIScreenViews);
	}
	throw new TriventException(AppConstants.MSG_SCREEN_NOT_CONFIGURED);
}


}