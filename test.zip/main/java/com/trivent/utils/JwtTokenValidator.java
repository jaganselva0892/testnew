package com.trivent.utils;

import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.trivent.constants.AppConstants;
import com.trivent.dto.JwtUserDto;
import com.trivent.logging.LogManager;
import com.trivent.logging.Logger;
import com.trivent.models.User;
import com.trivent.repository.UserRepository;

/**
* FileName: JwtTokenValidator.java
* To parse specified string as JWT token
* @author Jagan 0010
* @version 1.0
*/
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Component
public class JwtTokenValidator {

	@Value("${jwt.secret}")
	private String secret;

	private static final Logger LOGGER = LogManager.getLogger();
	private static final String CLASS_NAME = JwtTokenValidator.class.getName();

	@Autowired
	UserRepository userRepository;
	
	/**
	 * Tries to parse specified String as a JWT token. If successful, returns User
	 * object with username, id and role prefilled (extracted from token). If
	 * unsuccessful (token is invalid or not containing all required user
	 * properties), simply returns null.
	 *
	 * @param token
	 *            the JWT token to parse
	 * @return the User object extracted from specified token or null if a token is
	 *         invalid.
	 */
	public JwtUserDto parseToken(String token) {
		JwtUserDto u = null;

		try {
			Claims body = Jwts.parser().setSigningKey(secret).parseClaimsJws(token).getBody();
			u = new JwtUserDto();
			u.setLoginId(body.getSubject());
			u.setId(Long.parseLong((String) body.get("userId")));
			u.setUsername((String) body.get("userName"));

		} catch (JwtException e) {

			LOGGER.error(CLASS_NAME, "Method: parseToken", e);

		}
		return u;
	}

	/*
	 * Method to generate the token against the loginId
	 */
	public String generateToken(JwtUserDto u) {

		User user = userRepository.findByLoginId(u.getLoginId());

		Claims claims = Jwts.claims().setSubject(u.getLoginId());
		claims.put("userId", user.getId() + "");
		claims.put("userName", user.getId() + "");

		return Jwts.builder().setClaims(claims).signWith(SignatureAlgorithm.HS512, secret).compact();
	}

	public String generateToken(User u) {

		User user = userRepository.findByLoginId(u.getLoginId());

		DateTime validThuru = DateTime.now().plusDays(new Integer(AppConstants.APP_JWT_DAYS_VALID_THURU));

		Claims claims = Jwts.claims().setSubject(u.getLoginId());
		claims.put("userName", user.getAliasName());
		claims.put("Password", user.getPassword());
		claims.put("date", DateTime.now());
		claims.put("validthurudate", validThuru);

		String strToken = Jwts.builder().setClaims(claims)
				.signWith(SignatureAlgorithm.HS512, AppConstants.APP_JWT_SECRET).compact();

		return strToken;
	}

}
