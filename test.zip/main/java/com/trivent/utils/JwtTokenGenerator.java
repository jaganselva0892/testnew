package com.trivent.utils;

public class JwtTokenGenerator {

}
