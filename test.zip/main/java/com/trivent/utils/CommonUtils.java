package com.trivent.utils;

import java.text.ParseException;
import java.util.Calendar;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.WordUtils;
import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.joda.time.DateTime;

import com.trivent.constants.AppConstants;
import com.trivent.logging.LogManager;
import com.trivent.logging.Logger;
import com.trivent.models.UserProfile;

/**
 * @FileName : CommonUtils.java
 * @ClassName : CommonUtils
 * @DateAndTime : Nov 21, 2018 - 2:27:40 PM
 * 
 * @Author : karthi
 * 
 * @Description : CommonUtils using to common methods for String to Date , Date
 *              to string. This class using to Implementing CodeReusuability.
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
public class CommonUtils {

	private static final String CLASS_NAME = CommonUtils.class.getName();
	private static final Logger LOGGER = LogManager.getLogger();

	/**
	 * [Constructor Method]
	 * 
	 * @DateAndTime : Nov 21, 2018 - 2:27:40 PM
	 * 
	 * @Author : karthi
	 * 
	 * @Description : Avoid Instantiation.
	 * 
	 * @Tags :
	 * @Git_Config : name email
	 * 
	 */
	private CommonUtils() {
		// Avoid Instantiation.
	}


	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Nov 21, 2018 - 2:27:40 PM
	 * 
	 * @Author : karthi
	 * 
	 * @Description : Conversion of DateTime To String
	 * 
	 * @Tags :
	 * @param dateTime
	 *            input as DateAndTime.
	 * @return String, Date and Time as String DataType.
	 * @Git_Config : name email
	 * 
	 */
	public static String dateTimeToString(DateTime dateTime) {
		String val = null;
		if (dateTime != null) {
			val = DateFormatUtils.format(dateTime.getMillis(), AppConstants.DATE_TIME_FORMAT);
		}
		return val;
	}
	
	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Nov 21, 2018 - 2:27:40 PM
	 * 
	 * @Author : karthi
	 * 
	 * @Description : GetFileExtenstion using to find given file extension
	 * 
	 * @Tags :
	 * @param fileName
	 *            input as File with extension
	 * @return String, Filename Extension is return
	 * @Git_Config : name email
	 * 
	 */
	public static String getFileExtenstion(String fileName) {
		return StringUtils
				.lowerCase(fileName.substring(fileName.lastIndexOf(AppConstants.DOT_SEPARATOR) + 1, fileName.length()));
	}
	
	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Nov 21, 2018 - 2:27:40 PM
	 * 
	 * @Author : karthi
	 * 
	 * @Description : Trim Whitespace given Class Name
	 * 
	 * @Tags :
	 * @param originalClassName
	 *            input as ClassName
	 * @return String, Trim Whitespace given Class Name
	 * @Git_Config : name email
	 * 
	 */
	public static String trimClassName(String originalClassName) {
		return StringUtils.substringAfterLast(originalClassName, AppConstants.DOT_SEPARATOR);
	}
	
	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Nov 21, 2018 - 2:27:40 PM
	 * 
	 * @Author : karthi
	 * 
	 * @Description : GetTotalHoursFromHoursAndMinutes
	 * 
	 * @Tags :
	 * @param hours
	 *            input as Hours
	 * @param minutes
	 *            input as minutes
	 * @return int, calculating (hours * 60) + minutes;
	 * @Git_Config : name email
	 * 
	 */
	public static int getTotalHoursFromHoursAndMinutes(int hours, int minutes) {
		return (hours * 60) + minutes;
	}
	

	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Nov 21, 2018 - 2:27:40 PM
	 * 
	 * @Author : karthi
	 * 
	 * @Description : Conversion of String to Integer
	 * 
	 * @Tags :
	 * @param value
	 *            input as value.
	 * @return Integer.
	 * @Git_Config : name email
	 * 
	 */
	public static Integer stringToInteger(String value) {
		Integer val = null;
		if (StringUtils.isNotBlank(value)) {
			val = Integer.valueOf(value);
		}
		return val;
	}
	
	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Nov 21, 2018 - 2:27:40 PM
	 * 
	 * @Author : karthi
	 * 
	 * @Description : Conversion of String To Float
	 * 
	 * @Tags :
	 * @param value
	 *            input as String
	 * @return Float, String to Float value.
	 * @Git_Config : name email
	 * 
	 */
	public static Float stringToFloat(String value) {
		Float val = null;
		if (StringUtils.isNotBlank(value)) {
			float ft = Float.valueOf(value);
			val = Double.valueOf(Math.round(ft * 100.0) / 100.0).floatValue();
		}
		return val;
	}
	
	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Nov 21, 2018 - 2:27:40 PM
	 * 
	 * @Author : karthi
	 * 
	 * @Description : Conversion of String To Calendar
	 * 
	 * @Tags :
	 * @param value,
	 *            Date is String Format.
	 * @return Calendar, String format to Calendar.
	 * @Git_Config : name email
	 * 
	 */
	public static Calendar stringToCalendarINDateFormat(String value) {
		try {
			Calendar cal = Calendar.getInstance();
			cal.setTime(DateUtils.parseDateStrictly(value, AppConstants.DATE_FORMAT_API));
			return cal;
		} catch (ParseException e) {
			return null;
		}
	}
	
	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Nov 21, 2018 - 2:27:40 PM
	 * 
	 * @Author : karthi
	 * 
	 * @Description : Conversion of String To Calendar
	 * 
	 * @Tags :
	 * @param value,
	 *            Date is String Format.
	 * @return Calendar, String format to Calendar.
	 * @Git_Config : name email
	 * 
	 */
	public static Calendar stringToCalendar(String value) {
		try {
			Calendar cal = Calendar.getInstance();
			cal.setTime(DateUtils.parseDateStrictly(value, AppConstants.DATE_FORMAT));
			return cal;
		} catch (ParseException e) {
			return null;
		}
	}
	
	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Nov 21, 2018 - 2:27:40 PM
	 * 
	 * @Author : karthi
	 * 
	 * @Description : Conversion of Calendar EndOfDayTime
	 * 
	 * @Tags :
	 * @param startDate
	 *            input as Calendar
	 * @return Calender, EndofDayTime calendar value.
	 * @Git_Config : name email
	 * 
	 */
	public static Calendar getCalendarEndOfDayTime(Calendar startDate) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(startDate.getTime());
		cal.set(Calendar.HOUR, 11);
		cal.set(Calendar.MINUTE, 59);
		cal.set(Calendar.SECOND, 59);
		cal.set(Calendar.MILLISECOND, 999);
		cal.set(Calendar.AM_PM, Calendar.PM);
		return cal;
	}
	
	
	public static String uniCodeToString(String psUniCodeValue) {
		String lsFromUniCodeValue = "";
		try {
			if (StringUtils.isNotBlank(psUniCodeValue) && StringUtils.isNotEmpty(psUniCodeValue)) {
				lsFromUniCodeValue = StringEscapeUtils.unescapeJava(psUniCodeValue);
			}
		} catch (Exception e) {
			lsFromUniCodeValue = psUniCodeValue;
			LOGGER.error(CLASS_NAME, "uniCodeToString", e);
		}
		return lsFromUniCodeValue;
	}
	

	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Nov 21, 2018 - 2:27:40 PM
	 * 
	 * @Author : karthi
	 * 
	 * @Description : GetHourPart of TotalHours
	 * 
	 * @Tags :
	 * @param totalHours
	 *            input as total Hours
	 * @return Integer, Calculating totalHours/60
	 * @Git_Config : name email
	 * 
	 */
	public static Integer getHourPartofTotalHours(Integer totalHours) {
		return totalHours == null ? null : totalHours / 60;
	}
	
	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Nov 21, 2018 - 2:27:40 PM
	 * 
	 * @Author : karthi
	 * 
	 * @Description : GetMinutesPartofTotalHours
	 * 
	 * @Tags :
	 * @param totalHours
	 *            input as total Hours
	 * @return Integer, Calculating totalHours%60
	 * @Git_Config : name email
	 * 
	 */
	public static Integer getMinutesPartofTotalHours(Integer totalHours) {
		return totalHours == null ? null : totalHours % 60;
	}
	
	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Nov 21, 2018 - 2:27:40 PM
	 * 
	 * @Author : karthi
	 * 
	 * @Description : conversion of calendarToString
	 * 
	 * @Tags :
	 * @param calendar
	 * @return String, Date with String format.
	 * @Git_Config : name email
	 * 
	 */
	public static String calendarToStringForQM(Calendar calendar) {

		String val = null;
		if (calendar != null) {
			val = DateFormatUtils.format(calendar, AppConstants.DATE_FORMAT_API);
		}
		return val;
	}
	
	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Nov 21, 2018 - 2:27:40 PM
	 * 
	 * @Author : karthi
	 * 
	 * @Description : FullDisplayName to FirstName, LastName concat.
	 * 
	 * @Tags :
	 * @param userProfile
	 *            input userProfile entity
	 * @return String, concatenation of FirstName, LastName
	 * @Git_Config : name email
	 * 
	 */
	public static String getFullDisplayName(UserProfile userProfile) {
		return userProfile.getFirstName() + AppConstants.SPACE_SEPARATOR + userProfile.getLastName();
	}
	

	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Nov 21, 2018 - 2:27:40 PM
	 * 
	 * @Author : karthi
	 * 
	 * @Description : conversion of calendarToString
	 * 
	 * @Tags :
	 * @param calendar
	 * @return String, Date with String format.
	 * @Git_Config : name email
	 * 
	 */
	public static String calendarToString(Calendar calendar) {
		String val = null;
		if (calendar != null) {
			val = DateFormatUtils.format(calendar, AppConstants.DATE_FORMAT);
		}
		return val;
	}
	
	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Feb 1, 2018 - 2:27:40 PM
	 * 
	 * @Author : karthi
	 * 
	 * @Description : Conversion of Date To String
	 * 
	 * @Tags :
	 * @param dateTime
	 *            input is DateAndTime format
	 * @return String, Date only return remove Time as String DataType
	 * @Git_Config : name email
	 * 
	 */
	public static String dateToString(DateTime dateTime) {
		String val = null;
		if (dateTime != null) {
			val = DateFormatUtils.format(dateTime.getMillis(), AppConstants.DATE_FORMAT);
		}
		return val;
	}
	
	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Feb 1, 2018 - 2:27:40 PM
	 * 
	 * @Author : karthi
	 * 
	 * @Description : CamelCase To Human Readable Format
	 * 
	 * @Tags :
	 * @param camelCase
	 *            input as String with CamelCase
	 * @return String, Capitalize all letters in CamelCase
	 * @Git_Config : name email
	 * 
	 */
	public static String camelCaseToReadable(String camelCase) {
		String humanReadable = camelCase.replaceAll("(.)([A-Z])", "$1 $2");
		return WordUtils.capitalize(humanReadable);
	}
	
	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Feb 1, 2018 - 2:27:40 PM
	 * 
	 * @Author : karthi
	 * 
	 * @Description : Conversion of Calendar StartOfDayTime
	 * 
	 * @Tags :
	 * @param startDate
	 *            input as Calendar
	 * @return Calendar, StartOfDayTime calendar value.
	 * @Git_Config : name email
	 * 
	 */
	public static Calendar getCalendarStartOfDayTime(Calendar startDate) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(startDate.getTime());
		cal.set(Calendar.HOUR, 0);
		cal.set(Calendar.MINUTE, 00);
		cal.set(Calendar.SECOND, 00);
		cal.set(Calendar.MILLISECOND, 000);
		cal.set(Calendar.AM_PM, Calendar.AM);
		return cal;
	}

}