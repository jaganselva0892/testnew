package com.trivent.utils;

import java.lang.reflect.Field;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Properties;
import java.util.TimeZone;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.trivent.constants.AppConstants;
import com.trivent.dto.AppDBTableVO;
import com.trivent.dto.AppUIScreenFieldVO;
import com.trivent.dto.AppUIScreenFilterVO;
import com.trivent.dto.RowVO;
import com.trivent.dto.ScreenListFilterVO;
import com.trivent.exceptions.TriventException;
import com.trivent.logging.LogManager;
import com.trivent.logging.Logger;
import com.trivent.models.AppUIScreen;
import com.trivent.models.AppUIScreenField;
import com.trivent.models.AppUIScreenFilter;
import com.trivent.models.AppUIScreenView;
import com.trivent.models.Capability;
import com.trivent.models.Case;
import com.trivent.models.CaseFile;
import com.trivent.models.CaseResultFile;
import com.trivent.models.ProdFile;
import com.trivent.models.User;
import com.trivent.service.AppDBTableService;
import com.trivent.service.CacheService;
import com.trivent.service.UserService;
import com.trivent.utils.CommonUtils;
import com.trivent.utils.EncryptionUtils;

/**
 * @FileName : ScreenCommonUtils.java
 * @ClassName : ScreenCommonUtils
 * @DateAndTime : Sep 3, 2018 - 3:12:12 PM
 * 
 * @Author : Boopathi
 * 
 * @Description : Function are used to get ScreenFilter list data and row list
 *              data as convert to Json data.
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
@Component
public class ScreenCommonUtils {

	private static final Logger LOGGER = LogManager.getLogger();

	private static final String CLASS_NAME = ScreenCommonUtils.class.getName();

	@Autowired
	private UserService userService;

	@Autowired
	private AppDBTableService appDBTableService;

	@Autowired
	private CacheService cacheService;

	@Autowired
	private Properties applicationProperties;

	/**
	 * @DateAndTime : sep 3, 2018 - 3:12:12 PM
	 * 
	 * @Author : Karthi
	 * 
	 * @Description : Method to getScreenListFilterUpdateDate for particular column
	 *              values
	 * 
	 * @return SimpleDateFormat
	 */
	public SimpleDateFormat getUserTimeZoneId() {

		String METHOD_NAME = "getUserTimeZoneId";

		TimeZone tz = TimeZone.getDefault();
		String psTimeZoneId = tz.getID();
		String psTimeZoneFormat = AppConstants.DATE_TIME_FORMAT;

		try {
			User loginUser = this.userService.getCurrentUser(null);
			psTimeZoneId = loginUser.getUserProfile().getTimeZoneLocationId();
			if (StringUtils.isBlank(psTimeZoneId) || StringUtils.isEmpty(psTimeZoneId)) {
				psTimeZoneId = tz.getID();
			}
			psTimeZoneFormat = loginUser.getUserProfile().getTimeZoneFormat();
			if (StringUtils.isBlank(psTimeZoneFormat) || StringUtils.isEmpty(psTimeZoneFormat)) {
				psTimeZoneFormat = AppConstants.DATE_TIME_FORMAT;
			}
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, METHOD_NAME, e);
		}
		SimpleDateFormat tzFormat = new SimpleDateFormat(psTimeZoneFormat);
		tz = TimeZone.getTimeZone(psTimeZoneId);
		tzFormat.setTimeZone(tz);
		return tzFormat;
	}

	/**
	 * @DateAndTime : sep 3, 2018 - 3:12:12 PM
	 * 
	 * @Author : Karthi
	 * 
	 * @Description : Method to getScreenListFilterVO for particular column values
	 * 
	 * @param pstrScreenName
	 *            as String
	 * @return ScreenListFilterVO POJO class.
	 * @throws TriventException
	 */
	public ScreenListFilterVO getScreenListFilterVO(String pstrScreenName) throws TriventException {

		String METHOD_NAME = "getScreenListFilterVO";
		String TABLE_AVOID_ONE = "EmailQueue";
		String TABLE_AVOID_ONE_COLUMN_ONE = "body";

		String LSTR_CREATED_DATE = "createdDate";

		String ENTITY_CLASS_NAME = "com.trivent.entity." + pstrScreenName;

		ScreenListFilterVO screenListFilterVO = new ScreenListFilterVO();

		try {

			User loginUser = this.userService.getCurrentUser(null);

			AppDBTableVO appDBTableVO = this.appDBTableService.getAppDBTableByName(pstrScreenName);
			String screenType = AppConstants.SCREEN_TYPE_LIST;

			List<Field> fieldList = new ArrayList<>();
			Class<?> tableClass = Class.forName(ENTITY_CLASS_NAME);
			Class<?> fieldClass = tableClass;
			while (null != fieldClass) {
				fieldList.addAll(Arrays.asList(fieldClass.getDeclaredFields()));
				fieldClass = fieldClass.getSuperclass();
			}

			AppUIScreen appUIScreen = this.cacheService.findByScreenNameTypeRole(appDBTableVO.getId(), screenType,
					loginUser.getRole().getId());

			if (appUIScreen == null) {
				throw new TriventException(AppConstants.MSG_SCREEN_NOT_CONFIGURED);
			}

			List<AppUIScreenField> appUIScreenFields = this.cacheService.findFieldsByAppUIScreenId(appUIScreen.getId());
			List<AppUIScreenFieldVO> appUIScreenFieldVOs = new ArrayList<AppUIScreenFieldVO>();

			for (AppUIScreenField appUIScreenField : appUIScreenFields) {

				List<Field> tableFieldList = fieldList.stream().filter(
						p -> null != p.getName() && p.getName().equalsIgnoreCase(appUIScreenField.getDbFieldName()))
						.collect(Collectors.toList());
				if (!tableFieldList.isEmpty()) {
					Field tableField = tableFieldList.get(0);
					if (null != tableField) {
						if (!TABLE_AVOID_ONE.equalsIgnoreCase(appDBTableVO.getName())) {
							AppUIScreenFieldVO appUIScreenFieldVO = new AppUIScreenFieldVO(appUIScreenField,
									appUIScreen);
							appUIScreenFieldVO.setEntityPropertyType(tableField.getType().getName());
							appUIScreenFieldVOs.add(appUIScreenFieldVO);
						} else if (!TABLE_AVOID_ONE_COLUMN_ONE.equalsIgnoreCase(appUIScreenField.getDbFieldName())) {
							AppUIScreenFieldVO appUIScreenFieldVO = new AppUIScreenFieldVO(appUIScreenField,
									appUIScreen);
							appUIScreenFieldVO.setEntityPropertyType(tableField.getType().getName());
							appUIScreenFieldVOs.add(appUIScreenFieldVO);
						}
					}
				}

			}

			if (null != appUIScreen) {
				List<AppUIScreenFilter> appUIScreenFilters = this.cacheService
						.findFiltersByAppUIScreenId(appUIScreen.getId());
				List<AppUIScreenView> appUIScreenViews = this.cacheService
						.findViewsByAppUIScreenId(appUIScreen.getId());
				if (appUIScreenViews.isEmpty()) {
					throw new TriventException(AppConstants.MSG_VIEW_NOT_CONFIGURED);
				}
				if (screenType.equalsIgnoreCase(AppConstants.SCREEN_TYPE_LIST)) {
					if (appUIScreenFilters.isEmpty()) {
						throw new TriventException(AppConstants.MSG_FILTER_NOT_CONFIGURED);
					}
				}

				screenListFilterVO = new ScreenListFilterVO(appUIScreenFilters, appUIScreenViews);

				List<AppUIScreenFilterVO> appUIScreenFilterVOList = screenListFilterVO.getAppUIScreenFilterVOs();

				List<AppUIScreenFilterVO> appUIScreenFilterVOList1 = appUIScreenFilterVOList.stream().filter(
						p -> null != p.getDbFieldName() && LSTR_CREATED_DATE.equalsIgnoreCase(p.getDbFieldName()))
						.collect(Collectors.toList());

				if (CaseFile.class.getName().equalsIgnoreCase(tableClass.getName())
						&& CaseResultFile.class.getName().equalsIgnoreCase(tableClass.getName())) {

					String LSTR_CLIENT_CASE = "clientCase";

					List<AppUIScreenFilterVO> appUIScreenFilterVOList2 = appUIScreenFilterVOList.stream().filter(
							p -> null != p.getDbFieldName() && LSTR_CLIENT_CASE.equalsIgnoreCase(p.getDbFieldName()))
							.collect(Collectors.toList());

					if (appUIScreenFilterVOList2.isEmpty()) {

						AppUIScreenFilter appUIScreenFilter = new AppUIScreenFilter();
						appUIScreenFilter.setDbFieldName("clientCase");
						appUIScreenFilter.setDbTableName(pstrScreenName);
						appUIScreenFilter.setFilterDataType("Case");
						appUIScreenFilter.setFilterName("Client Case");
						appUIScreenFilter.setFilterSeq(appUIScreenFilterVOList.size() + 1);
						appUIScreenFilter.setAppUiScreen(appUIScreen);

						AppUIScreenFilterVO appUIScreenFilterVO = new AppUIScreenFilterVO(appUIScreenFilter,
								appUIScreenFilter.getAppUiScreen());

						appUIScreenFilterVOList.add(appUIScreenFilterVO);

					}
				} /*else if (ProdFile.class.getName().equalsIgnoreCase(tableClass.getName())) {

					String LSTR_PRODUCTION = "productionId";

					List<AppUIScreenFilterVO> appUIScreenFilterVOList2 = appUIScreenFilterVOList.stream().filter(
							p -> null != p.getDbFieldName() && LSTR_PRODUCTION.equalsIgnoreCase(p.getDbFieldName()))
							.collect(Collectors.toList());

					if (appUIScreenFilterVOList2.isEmpty()) {

						AppUIScreenFilter appUIScreenFilter = new AppUIScreenFilter();
						appUIScreenFilter.setDbFieldName("productionId");
						appUIScreenFilter.setDbTableName(pstrScreenName);
						appUIScreenFilter.setFilterDataType("Production");
						appUIScreenFilter.setFilterName("Production");
						appUIScreenFilter.setFilterSeq(appUIScreenFilterVOList.size() + 1);
						appUIScreenFilter.setAppUiScreen(appUIScreen);

						AppUIScreenFilterVO appUIScreenFilterVO = new AppUIScreenFilterVO(appUIScreenFilter,
								appUIScreenFilter.getAppUiScreen());

						appUIScreenFilterVOList.add(appUIScreenFilterVO);

					}
				} */else if (!CaseFile.class.getName().equalsIgnoreCase(tableClass.getName())
						&& !CaseResultFile.class.getName().equalsIgnoreCase(tableClass.getName())
						&& !ProdFile.class.getName().equalsIgnoreCase(tableClass.getName())) {
					if (appUIScreenFilterVOList1.isEmpty()) {

						AppUIScreenFilter appUIScreenFilter = new AppUIScreenFilter();
						appUIScreenFilter.setDbFieldName("createdDate");
						appUIScreenFilter.setDbTableName(pstrScreenName);
						appUIScreenFilter.setFilterDataType("Date");
						appUIScreenFilter.setFilterName("Created Date");
						appUIScreenFilter.setFilterSeq(appUIScreenFilterVOList.size() + 1);
						appUIScreenFilter.setAppUiScreen(appUIScreen);

						AppUIScreenFilterVO appUIScreenFilterVO = new AppUIScreenFilterVO(appUIScreenFilter,
								appUIScreenFilter.getAppUiScreen());
						AppUIScreenFilterVO appUIScreenFilterVO1 = new AppUIScreenFilterVO(appUIScreenFilter,
								appUIScreenFilter.getAppUiScreen());
						appUIScreenFilterVO1.setDbFieldName("todatefield" + appUIScreenFilterVO1.getDbFieldName());
						appUIScreenFilterVO.setFilterName("From " + appUIScreenFilterVO1.getFilterName());
						appUIScreenFilterVO1.setFilterName("To " + appUIScreenFilterVO1.getFilterName());

						Calendar cal = Calendar.getInstance();
						cal.setTime(DateTime.now().toDate());
						cal.set(Calendar.DATE, DateTime.now().getDayOfMonth() - 3);
						cal.set(Calendar.HOUR, 00);
						cal.set(Calendar.MINUTE, 00);
						cal.set(Calendar.SECOND, 00);
						cal.set(Calendar.MILLISECOND, 001);
						cal.set(Calendar.AM_PM, Calendar.AM);

						appUIScreenFilterVO.setValue(CommonUtils.dateToString(new DateTime(cal)));

						appUIScreenFilterVOList.add(appUIScreenFilterVO);

						cal = Calendar.getInstance();
						cal.setTime(DateTime.now().toDate());
						cal.set(Calendar.HOUR, 11);
						cal.set(Calendar.MINUTE, 59);
						cal.set(Calendar.SECOND, 59);
						cal.set(Calendar.MILLISECOND, 999);
						cal.set(Calendar.AM_PM, Calendar.PM);

						appUIScreenFilterVO1.setValue(CommonUtils.dateToString(new DateTime(cal)));
						appUIScreenFilterVOList.add(appUIScreenFilterVO1);

					} else {
						for (AppUIScreenFilterVO appUIScreenFilterVO : appUIScreenFilterVOList) {
							if (LSTR_CREATED_DATE.equalsIgnoreCase(appUIScreenFilterVO.getDbFieldName())) {
								Calendar cal = Calendar.getInstance();
								cal.setTime(DateTime.now().toDate());
								cal.set(Calendar.DATE, DateTime.now().getDayOfMonth() - 3);
								cal.set(Calendar.HOUR, 00);
								cal.set(Calendar.MINUTE, 00);
								cal.set(Calendar.SECOND, 00);
								cal.set(Calendar.MILLISECOND, 001);
								cal.set(Calendar.AM_PM, Calendar.AM);

								appUIScreenFilterVO.setValue(CommonUtils.dateToString(new DateTime(cal)));
							} else if (("todatefield" + LSTR_CREATED_DATE)
									.equalsIgnoreCase(appUIScreenFilterVO.getDbFieldName())) {
								Calendar cal = Calendar.getInstance();
								cal.setTime(DateTime.now().toDate());
								cal.set(Calendar.HOUR, 11);
								cal.set(Calendar.MINUTE, 59);
								cal.set(Calendar.SECOND, 59);
								cal.set(Calendar.MILLISECOND, 999);
								cal.set(Calendar.AM_PM, Calendar.PM);

								appUIScreenFilterVO.setValue(CommonUtils.dateToString(new DateTime(cal)));
							}
						}
					}
				}

				if (ENTITY_CLASS_NAME.equalsIgnoreCase(Case.class.getName())) {
					if (null != loginUser && StringUtils.isNotBlank(loginUser.getLoginId())
							&& loginUser.getLoginId().equalsIgnoreCase(this.applicationProperties
									.getProperty("application.configuration.case.addcolumnBasedOnUser"))) {

						String LSTR_CASESUB_TYPE = "subType";
						String LSTR_CREATED_BY = "createdBy";

						List<AppUIScreenField> lsAppUIScreenFieldsubType = appUIScreenFields.stream()
								.filter(p -> null != p.getDbFieldName()
										&& LSTR_CASESUB_TYPE.equalsIgnoreCase(p.getDbFieldName()))
								.collect(Collectors.toList());

						if (lsAppUIScreenFieldsubType.isEmpty()) {
							AppUIScreenFieldVO appUIScreenFieldVO = new AppUIScreenFieldVO();
							appUIScreenFieldVO.setAppUIScreenId(appUIScreenFieldVOs.get(0).getAppUIScreenId());
							appUIScreenFieldVO.setAppUIScreenName(appUIScreenFieldVOs.get(0).getAppUIScreenName());
							appUIScreenFieldVO.setAppUIScreenType(appUIScreenFieldVOs.get(0).getAppUIScreenType());
							appUIScreenFieldVO.setAttributeDataType("String");
							appUIScreenFieldVO.setAttributeName("Case Sub Type");
							appUIScreenFieldVO.setAttributeSeq(10);
							appUIScreenFieldVO.setDbTableName(appUIScreenFieldVOs.get(0).getDbTableName());
							appUIScreenFieldVO.setDbFieldName("subType");
							appUIScreenFieldVO.setDisplayable(true);
							appUIScreenFieldVO.setReadOnly(true);
							appUIScreenFieldVOs.add(appUIScreenFieldVO);
						}

						List<AppUIScreenField> lsAppUIScreenFieldcreatedBy = appUIScreenFields.stream().filter(
								p -> null != p.getDbFieldName() && LSTR_CREATED_BY.equalsIgnoreCase(p.getDbFieldName()))
								.collect(Collectors.toList());

						if (lsAppUIScreenFieldcreatedBy.isEmpty()) {
							AppUIScreenFieldVO appUIScreenFieldVO = new AppUIScreenFieldVO();
							appUIScreenFieldVO.setAppUIScreenId(appUIScreenFieldVOs.get(0).getAppUIScreenId());
							appUIScreenFieldVO.setAppUIScreenName(appUIScreenFieldVOs.get(0).getAppUIScreenName());
							appUIScreenFieldVO.setAppUIScreenType(appUIScreenFieldVOs.get(0).getAppUIScreenType());
							appUIScreenFieldVO.setAttributeDataType("User");
							appUIScreenFieldVO.setAttributeName("Created By");
							appUIScreenFieldVO.setAttributeSeq(11);
							appUIScreenFieldVO.setDbTableName(appUIScreenFieldVOs.get(0).getDbTableName());
							appUIScreenFieldVO.setDbFieldName("createdBy");
							appUIScreenFieldVO.setDisplayable(true);
							appUIScreenFieldVO.setReadOnly(true);
							appUIScreenFieldVOs.add(appUIScreenFieldVO);
						}

					}

					List<Object[]> lsUserPermissionObject = this.userService.getUserPermission(loginUser.getId(),
							Capability.ACCOUNT_MANAGEMENR_CASELIST);
					if (!lsUserPermissionObject.isEmpty()) {

						String LSTR_ACCOUNT_MANAGER = "accountManager";
						List<AppUIScreenFieldVO> lsAppUIScreenFieldVOaccountManager = appUIScreenFieldVOs.stream()
								.filter(p -> null != p.getDbFieldName()
										&& LSTR_ACCOUNT_MANAGER.equalsIgnoreCase(p.getDbFieldName()))
								.collect(Collectors.toList());
						if (lsAppUIScreenFieldVOaccountManager.isEmpty()) {
							AppUIScreenFieldVO appUIScreenFieldVO = new AppUIScreenFieldVO();
							appUIScreenFieldVO.setAppUIScreenId(appUIScreenFieldVOs.get(0).getAppUIScreenId());
							appUIScreenFieldVO.setAppUIScreenName(appUIScreenFieldVOs.get(0).getAppUIScreenName());
							appUIScreenFieldVO.setAppUIScreenType(appUIScreenFieldVOs.get(0).getAppUIScreenType());
							appUIScreenFieldVO.setAttributeDataType("Account");
							appUIScreenFieldVO.setAttributeName("Account Manager");
							appUIScreenFieldVO.setAttributeSeq(1);
							appUIScreenFieldVO.setDbTableName(appUIScreenFieldVOs.get(0).getDbTableName());
							appUIScreenFieldVO.setDbFieldName("accountManager");
							appUIScreenFieldVO.setDisplayable(true);
							appUIScreenFieldVO.setReadOnly(true);
							appUIScreenFieldVOs.add(appUIScreenFieldVO);
						}

						List<AppUIScreenFilterVO> lsappUIScreenFilterVOaccountManager = appUIScreenFilterVOList.stream()
								.filter(p -> null != p.getDbFieldName()
										&& LSTR_ACCOUNT_MANAGER.equalsIgnoreCase(p.getDbFieldName()))
								.collect(Collectors.toList());
						if (lsappUIScreenFilterVOaccountManager.isEmpty()) {
							AppUIScreenFilter appUIScreenFilter = new AppUIScreenFilter();
							appUIScreenFilter.setDbFieldName("accountManager");
							appUIScreenFilter.setDbTableName("Account");
							appUIScreenFilter.setFilterDataType("Account");
							appUIScreenFilter.setFilterName("Account Manager");
							appUIScreenFilter.setFilterSeq(appUIScreenFilterVOList.size() + 1);
							appUIScreenFilter.setAppUiScreen(appUIScreen);

							AppUIScreenFilterVO appUIScreenFilterVO = new AppUIScreenFilterVO(appUIScreenFilter,
									appUIScreenFilter.getAppUiScreen());
							appUIScreenFilterVOList.add(appUIScreenFilterVO);
						}

					}
				}

				screenListFilterVO.setAppUIScreenFieldVOs(appUIScreenFieldVOs);
				screenListFilterVO.setAppDBTableVO(appDBTableVO);
				screenListFilterVO.setRoleType(loginUser.getRole().getType());

				SimpleDateFormat tzFormat = this.getUserTimeZoneId();
				screenListFilterVO.setLtmesimpleDateFormat(tzFormat.toPattern());
				screenListFilterVO.setLtmesimpleDateZoneid(tzFormat.getTimeZone().getID());

			}

		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, METHOD_NAME, e);
		}

		return screenListFilterVO;
	}

	/**
	 * @DateAndTime : sep 3, 2018 - 3:12:12 PM
	 * 
	 * @Author : Karthi
	 * 
	 * @Description : Method to getScreenListObjDetails for particular column values
	 * 
	 * @param screenListFilterVO
	 *            as ScreenListFilterVO POJO class
	 * @param pobjDataList
	 *            as List of object
	 * @return as List<RowVO>
	 * @throws TriventException
	 */
	public List<RowVO> getScreenListObjDetails(ScreenListFilterVO screenListFilterVO, List<Object[]> pobjDataList)
			throws TriventException {

		String METHOD_NAME = "getScreenListObjDetails";
		String SCREEN_NAME = "CaseQuery";
		boolean SCREEN_CONDITION = false;

		String SCREEN_NAME_PROD_FILE = "ProdFile";
		boolean SCREEN_CONDITION_PROD_FILE = false;

		String SCREEN_NAME_CASE_FILE = "CaseFile";
		boolean SCREEN_CONDITION_CASE_FILE = false;

		List<RowVO> rowVOs = new ArrayList<>(pobjDataList.size());
		if (SCREEN_NAME.equalsIgnoreCase(screenListFilterVO.getAppDBTableVO().getName())) {
			SCREEN_CONDITION = true;
		} else if (SCREEN_NAME_PROD_FILE.equalsIgnoreCase(screenListFilterVO.getAppDBTableVO().getName())) {
			SCREEN_CONDITION_PROD_FILE = true;
		} else if (SCREEN_NAME_CASE_FILE.equalsIgnoreCase(screenListFilterVO.getAppDBTableVO().getName())) {
			SCREEN_CONDITION_CASE_FILE = true;
		}
		RowVO rowVO = new RowVO();
		List<String> columns = new ArrayList<>();

		try {
			int size = screenListFilterVO.getAppUIScreenFieldVOs().size();
			StringBuilder caseEncryptedId = new StringBuilder();
			int loopStart = 1;
			if (SCREEN_CONDITION) {
				loopStart = 2;
				// Size Incremented
				size++;
			} else if (SCREEN_CONDITION_PROD_FILE) {
				loopStart = 9;
				// Size Incremented
				size += 8;
			} else if (SCREEN_CONDITION_CASE_FILE) {
			}

			for (Object[] objData : pobjDataList) {
				columns = new ArrayList<>(size);
				caseEncryptedId.setLength(0);

				for (int i = loopStart; i <= size; i++) {
					if (null != objData && objData.length > i) {
						Object value = objData[i];
						if (null != value && null != objData) {
							if (Calendar.class.equals(value.getClass())
									|| GregorianCalendar.class.equals(value.getClass())) {
								Calendar cal = (Calendar) value;

								try {

									SimpleDateFormat tzFormat = new SimpleDateFormat(
											screenListFilterVO.getLtmesimpleDateFormat());
									TimeZone tz = TimeZone.getTimeZone(screenListFilterVO.getLtmesimpleDateZoneid());
									tzFormat.setTimeZone(tz);

									// SimpleDateFormat tzFormat = new
									// SimpleDateFormat(screenListFilterVO.getLtmesimpleDateFormat());
									columns.add(tzFormat.format(new DateTime(cal.getTime()).toDate()));
								} catch (Exception e) {
									columns.add(CommonUtils.dateTimeToString(new DateTime(cal.getTime())));
								}
							} else if (Timestamp.class.equals(value.getClass())
									|| DateTime.class.equals(value.getClass()) || Date.class.equals(value.getClass())) {
								try {
									SimpleDateFormat tzFormat = new SimpleDateFormat(
											screenListFilterVO.getLtmesimpleDateFormat());
									TimeZone tz = TimeZone.getTimeZone(screenListFilterVO.getLtmesimpleDateZoneid());
									tzFormat.setTimeZone(tz);

									// SimpleDateFormat tzFormat = new
									// SimpleDateFormat(screenListFilterVO.getLtmesimpleDateFormat());
									columns.add(tzFormat.format(new DateTime(value).toDate()));
								} catch (Exception e) {
									columns.add(CommonUtils.dateTimeToString(new DateTime(value)));
								}
							} else {
								columns.add(String.valueOf(value));
							}
						} else {
							columns.add(AppConstants.EMPTY_STRING);
						}
					} else {
						columns.add(AppConstants.EMPTY_STRING);
					}

				}
				Long lId = new Long(String.valueOf(objData[0]));
				// ToDo: Set CaseEncryptedId For CaseQuery
				if (SCREEN_CONDITION && null != objData[1]) {
					// if (null != objData[1]) {
					caseEncryptedId.append(EncryptionUtils.encryptId(new Long(objData[1].toString())));
					// }
				}

				rowVO = new RowVO(lId, EncryptionUtils.encryptId(lId), caseEncryptedId, columns);

				rowVOs.add(rowVO);
			}
		} catch (Exception ex) {
			LOGGER.error(CLASS_NAME, METHOD_NAME, ex);
		}

		return rowVOs;
	}

	/**
	 * @DateAndTime : sep 3, 2018 - 3:12:12 PM
	 * 
	 * @Author : Karthi
	 * 
	 * @Description : Method to getScreenListFilterUpdateDate for particular column
	 *              values
	 * 
	 * @param screenListFilterVO
	 *            as ScreenListFilterVO POJO class
	 * @param pstrScreenName
	 *            as String
	 * @param pstrFromDate
	 *            as String
	 * @param pstrToDate
	 *            as String
	 * @return ScreenListFilterVO POJO class
	 * @throws TriventException
	 */
	public ScreenListFilterVO getScreenListFilterUpdateDate(ScreenListFilterVO screenListFilterVO,
			String pstrScreenName, String pstrFromDate, String pstrToDate) throws TriventException {

		String METHOD_NAME = "getScreenListFilterUpdateDate";

		String LSTR_CREATED_DATE = "createdDate";

		try {

			if (StringUtils.isNotBlank(pstrFromDate) || StringUtils.isNotBlank(pstrToDate)) {

				Calendar lcalFromDate = Calendar.getInstance();
				lcalFromDate.setTime(DateTime.now().toDate());
				Calendar lcalToDate = Calendar.getInstance();
				lcalToDate.setTime(DateTime.now().toDate());

				if (StringUtils.isNotBlank(pstrFromDate)) {
					lcalFromDate = CommonUtils.stringToCalendar(pstrFromDate);
					lcalFromDate.set(Calendar.HOUR, 00);
					lcalFromDate.set(Calendar.MINUTE, 00);
					lcalFromDate.set(Calendar.SECOND, 00);
					lcalFromDate.set(Calendar.MILLISECOND, 001);
					lcalFromDate.set(Calendar.AM_PM, Calendar.AM);
					if (StringUtils.isNotBlank(pstrToDate)) {
						lcalToDate = CommonUtils.stringToCalendar(pstrToDate);
					} else {
						lcalToDate = CommonUtils.stringToCalendar(pstrFromDate);
					}
					lcalToDate.set(Calendar.HOUR, 11);
					lcalToDate.set(Calendar.MINUTE, 59);
					lcalToDate.set(Calendar.SECOND, 59);
					lcalToDate.set(Calendar.MILLISECOND, 999);
					lcalToDate.set(Calendar.AM_PM, Calendar.PM);
				} else if (StringUtils.isNotBlank(pstrToDate)) {
					lcalToDate = CommonUtils.stringToCalendar(pstrToDate);
					lcalToDate.set(Calendar.HOUR, 11);
					lcalToDate.set(Calendar.MINUTE, 59);
					lcalToDate.set(Calendar.SECOND, 59);
					lcalToDate.set(Calendar.MILLISECOND, 999);
					lcalToDate.set(Calendar.AM_PM, Calendar.PM);

					lcalFromDate = CommonUtils.stringToCalendar(pstrToDate);
					lcalFromDate.set(Calendar.HOUR, 00);
					lcalFromDate.set(Calendar.MINUTE, 00);
					lcalFromDate.set(Calendar.SECOND, 00);
					lcalFromDate.set(Calendar.MILLISECOND, 001);
					lcalFromDate.set(Calendar.AM_PM, Calendar.AM);
				}

				String ENTITY_CLASS_NAME = "com.trivent.entity." + pstrScreenName;

				List<Field> fieldList = new ArrayList<>();
				Class<?> tableClass = Class.forName(ENTITY_CLASS_NAME);
				Class<?> fieldClass = tableClass;
				while (null != fieldClass) {
					fieldList.addAll(Arrays.asList(fieldClass.getDeclaredFields()));
					fieldClass = fieldClass.getSuperclass();
				}

				List<AppUIScreenFilterVO> appUIScreenFilterVOList = screenListFilterVO.getAppUIScreenFilterVOs();

				List<AppUIScreenFilterVO> appUIScreenFilterVOList1 = appUIScreenFilterVOList.stream().filter(
						p -> null != p.getDbFieldName() && LSTR_CREATED_DATE.equalsIgnoreCase(p.getDbFieldName()))
						.collect(Collectors.toList());

				if (!CaseFile.class.getName().equalsIgnoreCase(tableClass.getName())
						&& !CaseResultFile.class.getName().equalsIgnoreCase(tableClass.getName())
						&& !ProdFile.class.getName().equalsIgnoreCase(tableClass.getName())) {
					if (appUIScreenFilterVOList1.isEmpty()) {

						AppUIScreenFilterVO appUIScreenFilterVO = new AppUIScreenFilterVO();
						appUIScreenFilterVO.setAppUIScreenId(appUIScreenFilterVOList.get(0).getAppUIScreenId());
						appUIScreenFilterVO.setAppUIScreenType(appUIScreenFilterVOList.get(0).getAppUIScreenType());
						appUIScreenFilterVO.setDbFieldName("createdDate");
						appUIScreenFilterVO.setDbTableName(appUIScreenFilterVOList.get(0).getDbTableName());
						appUIScreenFilterVO.setFilterDataType("Date");
						appUIScreenFilterVO.setFilterName("From Created Date");
						appUIScreenFilterVO.setFilterSeq(appUIScreenFilterVOList.size() + 1);

						AppUIScreenFilterVO appUIScreenFilterVO1 = new AppUIScreenFilterVO();
						appUIScreenFilterVO1.setAppUIScreenId(appUIScreenFilterVOList.get(0).getAppUIScreenId());
						appUIScreenFilterVO1.setAppUIScreenType(appUIScreenFilterVOList.get(0).getAppUIScreenType());
						appUIScreenFilterVO1.setDbFieldName("todatefieldcreatedDate");
						appUIScreenFilterVO1.setDbTableName(appUIScreenFilterVOList.get(0).getDbTableName());
						appUIScreenFilterVO1.setFilterDataType("Date");
						appUIScreenFilterVO1.setFilterName("To Created Date");
						appUIScreenFilterVO1.setFilterSeq(appUIScreenFilterVOList.size() + 2);

						appUIScreenFilterVO.setValue(CommonUtils.dateToString(new DateTime(lcalFromDate)));

						appUIScreenFilterVOList.add(appUIScreenFilterVO);

						appUIScreenFilterVO1.setValue(CommonUtils.dateToString(new DateTime(lcalToDate)));
						appUIScreenFilterVOList.add(appUIScreenFilterVO1);

					} else {

						for (AppUIScreenFilterVO appUIScreenFilterVO : appUIScreenFilterVOList) {
							if (LSTR_CREATED_DATE.equalsIgnoreCase(appUIScreenFilterVO.getDbFieldName())) {
								appUIScreenFilterVO.setValue(CommonUtils.dateToString(new DateTime(lcalFromDate)));
							} else if (("todatefield" + LSTR_CREATED_DATE)
									.equalsIgnoreCase(appUIScreenFilterVO.getDbFieldName())) {
								appUIScreenFilterVO.setValue(CommonUtils.dateToString(new DateTime(lcalToDate)));
							}
						}
					}
				}
			}

		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, METHOD_NAME, e);
		}

		return screenListFilterVO;
	}

	/**
	 * @DateAndTime : sep 3, 2018 - 3:12:12 PM
	 * 
	 * @Author : Karthi
	 * 
	 * @Description : Method to getScreenListFilterUpdateField for particular column
	 *              values
	 * 
	 * @param screenListFilterVO
	 *            as ScreenListFilterVO POJO class
	 * @param pstrScreenName
	 *            as String
	 * @param pstrColumnName
	 *            as String
	 * @param pstrValue
	 *            as String
	 * @return ScreenListFilterVO
	 * @throws TriventException
	 */
	public ScreenListFilterVO getScreenListFilterUpdateField(ScreenListFilterVO screenListFilterVO,
			String pstrScreenName, String pstrColumnName, String pstrValue) throws TriventException {

		String METHOD_NAME = "getScreenListFilterUpdateField";

		try {

			if (StringUtils.isNotBlank(pstrValue)) {

				List<AppUIScreenFilterVO> appUIScreenFilterVOList = screenListFilterVO.getAppUIScreenFilterVOs();

				List<AppUIScreenFilterVO> appUIScreenFilterVOList1 = appUIScreenFilterVOList.stream()
						.filter(p -> null != p.getDbFieldName() && p.getDbFieldName().equalsIgnoreCase(pstrColumnName))
						.collect(Collectors.toList());

				if (appUIScreenFilterVOList1.isEmpty()) {

					AppUIScreenFilterVO appUIScreenFilterVO = new AppUIScreenFilterVO();
					appUIScreenFilterVO.setAppUIScreenId(appUIScreenFilterVOList.get(0).getAppUIScreenId());
					appUIScreenFilterVO.setAppUIScreenType(appUIScreenFilterVOList.get(0).getAppUIScreenType());
					appUIScreenFilterVO.setDbFieldName(pstrColumnName);
					appUIScreenFilterVO.setDbTableName(appUIScreenFilterVOList.get(0).getDbTableName());
					appUIScreenFilterVO.setFilterDataType(pstrColumnName);
					appUIScreenFilterVO.setFilterName(pstrColumnName);
					appUIScreenFilterVO.setFilterSeq(appUIScreenFilterVOList.size() + 1);

					appUIScreenFilterVO.setValue(pstrValue);

					appUIScreenFilterVOList.add(appUIScreenFilterVO);

				} else {

					for (AppUIScreenFilterVO appUIScreenFilterVO : appUIScreenFilterVOList) {
						if (appUIScreenFilterVO.getDbFieldName().equalsIgnoreCase(pstrColumnName)) {
							appUIScreenFilterVO.setValue(pstrValue);
							break;
						}
					}
				}
			}

		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, METHOD_NAME, e);
		}

		return screenListFilterVO;
	}

}
