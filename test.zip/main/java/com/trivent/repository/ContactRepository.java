package com.trivent.repository;

import java.util.List;

import org.joda.time.DateTime;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;

import com.trivent.models.Contact;

/**
 * @FileName 	:
 *				ContactRepository.java
 * @ClassName 	:
 * 				ContactRepository
 * @DateAndTime :
 *				Feb 2, 2018 - 6:55:01 PM
 * 
 * @Author 		:
 * 				karthi
 * 
 * @Description : Fetch Contact Details Related Native Query Implemented
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public interface ContactRepository extends JpaRepository<Contact, Long> {

	List<Contact> findAll(Specification<Contact> specification);

	@Query("select c from Contact c where c.entity = ?1 and c.entityId = ?2 and c.deleted = ?3 order by c.firstName, c.lastName, c.company")
	List<Contact> listContacts(String entity, Long entityId, char isDeleted);

	@Query("SELECT max(c.seqNo) FROM Contact c where c.entity = ?1 and c.entityId = ?2")
	Integer getLastSeqNo(String entity, Long entityId);

	@Query("select email from Contact c where c.entityId = ?1 and c.entity = ?2")
	List<String> getClientContact(Long caseContactEmailId, String entity);

	@Query("select email from Contact c where c.entityId = ?1 and c.entity = ?2 and c.email = ?3 and c.deleted = ?4")
	List<String> getExistEmails(Long entityId, String entity, String emailid, char isDeleted);

	@Query("select email from Contact c where c.entityId = ?1 and c.entity = ?2 and c.email = ?3 and c.id <> ?4 and c.deleted = ?5")
	List<String> getExistEmailsEditMode(Long entityId, String entity, String emailid, Long contactId, char isDeleted);

	@Query("select c from Contact c where c.entity = ?1 and c.entityId = ?2 and c.email = ?3 and c.deleted = ?4 order by c.firstName, c.lastName, c.company")
	List<Contact> listContactsbyEntityId(String entity, Long entityId, String contactEmailId, char isDeleted);

	@Query("SELECT c FROM Contact c where c.entity = ?1 and c.entityId = ?2 and c.userId = ?3")
	List<Contact> getContactbyEntity(String entity, Long entityId, Long userId);

	@Query("SELECT c FROM Contact c where c.entity = ?1 and c.email = ?2")
	List<Contact> getContactbyEmail(String entity, String emailId);

	@Query("SELECT c FROM Contact c where c.entity = ?1 and c.email = ?2 and c.contactType = ?3")
	List<Contact> getContactbyEmailNonUser(String entity, String emailId, String contactType);

	@Modifying
	@Query(value = "UPDATE Contact c SET c.userId = ?1, c.contactType = ?2 WHERE c.email = ?3")
	int updateContactsbyUserID(Long userId, String contactType, String emailId);

	@Modifying
	@Query(value = "UPDATE Contact c SET c.userId = ?1, c.contactType = ?2 WHERE c.email = ?3 and c.id = ?4")
	int updateContactsbyContactID(Long userId, String contactType, String emailId, Long contactId);

	@Query("SELECT c FROM Contact c where c.email = ?1")
	List<Contact> getContactbyEmail(String emailId);

	@Query("select c from Contact c where user_id is null and is_deleted=?1")
	List<Contact> listContactsByUserIdNull(char deleted);
	
	@Query("SELECT c FROM Contact c where c.email = ?1")
    Contact getContactbyEmailfornonportaluser(String emailId);
	
	@Query(value = "select DISTINCT(c.email) from contacts c where IFNULL(c.user_id, '') = '' and is_deleted=?1", nativeQuery = true)
	List<String> listStringByUserIdNull(char deleted);

	@Procedure("save_contacts")
	Long save_contacts(
			@Param("contact_id") Long contact_id,
			@Param("action") String action,
			@Param("created_date") DateTime created_date,
			@Param("modified_date") DateTime modified_date,
			@Param("optlock_version") Integer integer,
			@Param("is_deleted") Character is_deleted,
			@Param("address1") String address1,
			@Param("address2") String address2,
			@Param("city") String city,
			@Param("company") String company,
			@Param("email") String email,
			@Param("fax") String fax,
			@Param("first_name") String first_name,
			@Param("job_title") String job_title,
			@Param("last_name") String last_name,
			@Param("phone") String phone,
			@Param("state") String state,
			@Param("zipcode") String zipcode,
			@Param("entity") String entity,
			@Param("entity_id") Long entity_id,
			@Param("seq_no") Integer seq_no,
			@Param("type") String type,
			@Param("created_by") Long created_by,
			@Param("modified_by") Long modified_by,
			@Param("phone_extn") String phone_extn,
			@Param("user_id") Long user_id,
			@Param("contact_type") String contact_type);
			
			
	
	
}
