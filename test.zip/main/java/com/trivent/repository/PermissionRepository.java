package com.trivent.repository;

import java.util.List;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.trivent.models.Permission;

/**
 * @FileName 	:
 *				PermissionRepository.java
 * @ClassName 	:
 * 				PermissionRepository
 * @DateAndTime :
 *				Feb 2, 2018 - 7:02:56 PM
 * 
 * @Author 		:
 * 				karthi
 * 
 * @Description : Fetch Permission Related Native Query Implemented
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public interface PermissionRepository extends JpaRepository<Permission, Long> {

	List<Permission> findAll(Specification<Permission> specification);

	@Query("select p from Permission p where p.role.id = ?1 order by p.id")
	List<Permission> findAllByRoleId(Long roleId);

	@Modifying
	@Query("delete from Permission p where p.capability.id = ?1")
	int deleteByCapabilityId(Long capabilityId);

	@Query("select p from Permission p where p.role.id = ?1 and p.capability.id = ?2")
	Permission getByCapabilityId(Long roleId, Long capabilityId);

}
