package com.trivent.repository;

import java.util.List;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.trivent.models.AppItem;

/**
 * @FileName : AppItemRepository.java
 * @ClassName : AppItemRepository
 * @DateAndTime : Feb 2, 2018 - 6:19:05 PM
 * 
 * @Author : karthi
 * 
 * @Description : Fetch Application Item Related Native Query implemented
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
public interface AppItemRepository extends JpaRepository<AppItem, Long> {

	List<AppItem> findAll(Specification<AppItem> specification);

	@Query("select i from AppItem i where i.appList.id = ?1 order by i.seqNo")
	List<AppItem> findByListId(Long listId);

	@Query("select si from AppItem si JOIN FETCH si.appList where si.appList.id = ?1")
	List<AppItem> findByListIdSame(Long appListId);

	@Query("select i from AppItem i where i.appList.id = ?1 order by i.longName asc")
	List<AppItem> findByListName(Long listId);

	@Query("select i from AppItem i where i.appList.id = ?1 order by i.longName desc")
	List<AppItem> findByListNameDesc(Long listId);

	@Query("select i from AppItem i where i.longName = ?1 and i.appList.id = ?2")
	AppItem findByLongName(String longName, Long listId);

	@Query("select i from AppItem i where i.shortName = ?1 and i.appList.id = ?2")
	AppItem findByShortName(String shortName, Long listId);

	@Query("select i from AppItem i where i.id = ?1 and i.appList.id = ?2")
	AppItem findByitemIdandListId(Long itemId, Long listId);

	@Query("select longName from AppItem i where i.appList.id=?1 ORDER BY  longName ASC")
	String[] findByLongNAmeChart(Long listId);

	@Query("select i from AppItem i where i.appList.id=?1")
	String[] findByItemIdChart(Long listId);

	@Query("select i.id from AppItem i where i.longName=?1")
	Long findAppItemIDByLongName(String longName);

	@Query("select i from AppItem i where i.id = ?1")
	AppItem findByitemId(Long itemId);

	@Query("select i from AppItem i where i.appList.id = ?1")
	List<AppItem> listItems(Long listId);

	@Query("select i from AppItem i where i.longName LIKE ?1")
	AppItem findAppItemByLongName(String longName);


	

}
