package com.trivent.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.trivent.models.AppItem;
import com.trivent.models.AppServiceDesc;
import com.trivent.models.AppSubItem;
import com.trivent.models.Partner;

/**
 * @FileName 	:
 *				AppServiceDescRepository.java
 * @ClassName 	:
 * 				AppServiceDescRepository
 * @DateAndTime :
 *				Feb 2, 2018 - 6:26:30 PM
 * 
 * @Author 		:
 * 				karthi
 * 
 * @Description : Fetch Application Service for Desc related Native Query implemented
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public interface AppServiceDescRepository extends JpaRepository<AppServiceDesc, Long> {

	@Query("select s from AppServiceDesc s where s.deleted = ?1")
	List<AppServiceDesc> listAll(char isDeleted);

	@Query("select i from AppItem i where i.appList.id = ?1")
	List<AppItem> listItems(Long listId);
	
	@Modifying
	@Transactional
	@Query("Update AppServiceDesc i set i.deleted = 'Y' where i.id = ?1")
	int deleteById(Long AppServiceDescId);

	@Query("select i from AppServiceDesc i where i.subService = ?1 and i.partnerCode =?2 and i.deleted = ?3")
	AppServiceDesc findBySubItemId(AppSubItem appSubItems, Partner partner,char isDeleted );

	@Query("select i from AppServiceDesc i where i.subService = ?1 and i.mainService =?2 and i.deleted = ?3")
	List<AppServiceDesc> listByAppSubItem(AppSubItem subService, AppItem mainService ,char isDeleted );
	
	@Query("select i from AppServiceDesc i where i.subService = ?1 and i.deleted = ?2")
	List<AppServiceDesc> findByAppSubItemId(AppSubItem appSubServiceDescId,char isDeleted);
	
	@Query("select i from AppServiceDesc i where i.partnerCode = ?1 and  i.subService = ?2 and i.deleted = ?3 ")
	AppServiceDesc listBySubService(Partner partner,AppSubItem appSubServiceId,char isDeleted);
}
