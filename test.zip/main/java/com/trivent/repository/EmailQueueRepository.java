package com.trivent.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.trivent.models.EmailQueue;


/**
 * @FileName 	:
 *				EmailQueueRepository.java
 * @ClassName 	:
 * 				EmailQueueRepository
 * @DateAndTime :
 *				Feb 2, 2018 - 6:56:13 PM
 * 
 * @Author 		:
 * 				karthi
 * 
 * @Description : Fetch Email Queue Related Native Query Implemented
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public interface EmailQueueRepository extends JpaRepository<EmailQueue, Long> {

  Page<EmailQueue> findAll(Specification<EmailQueue> specification, Pageable constructPageSpecification);
  
  @Query("from EmailQueue q LEFT JOIN FETCH q.account ac LEFT JOIN FETCH q.user u LEFT JOIN FETCH q.appCase c LEFT JOIN FETCH q.createdBy cu LEFT JOIN FETCH q.lastModifiedBy mu JOIN FETCH ac.partner p WHERE q.id = ?1")
  EmailQueue getByEmailQueueId(Long plEmailQueueId);
  
  @Query("select q from EmailQueue q where q.deleted = ?1 and q.status = ?2 AND q.createdDate > ?3")
  List<EmailQueue> findNewStatusMail(char isDeleted ,String status, Date pdCreatedDate);
  
}
