package com.trivent.repository;

import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.metamodel.EntityType;
import javax.persistence.metamodel.Metamodel;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 * @FileName 	:
 *				MetadataRepository.java
 * @ClassName 	:
 * 				MetadataRepository
 * @DateAndTime :
 *				Feb 2, 2018 - 6:59:37 PM
 * 
 * @Author 		:
 * 				karthi
 * 
 * @Description : Fetch Meta Data Repository
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Repository
public class MetadataRepository {

  @Autowired
  private EntityManager entityManager;

  public Set<EntityType<?>> getEntityTypes() {
    Metamodel model = entityManager.getEntityManagerFactory().getMetamodel();
    return model.getEntities();
  }
}