package com.trivent.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.trivent.models.Report;

/**
 * @FileName : ReportRepository.java
 * @ClassName : ReportRepository
 * @DateAndTime : Feb 2, 2018 - 7:06:46 PM
 * 
 * @Author : karthi
 * 
 * @Description : Fetch Report Related Native Query Implemented
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
public interface ReportRepository extends JpaRepository<Report, Long> {

	@Query(value = "SELECT c.case_id, COUNT(DISTINCT c.case_id), IFNULL(crs.client_reqn_specification_id, ''), COUNT(ct.case_task_id), COUNT(ctp.case_task_id), CONCAT_WS(' ', upc.first_name, upc.last_name), CONCAT_WS(' ', up.first_name, up.last_name) FROM cases c LEFT JOIN client_reqn_specification crs ON crs.client_id = c.client_id AND crs.is_deleted LIKE 'N' LEFT JOIN case_tasks ct ON ct.case_id = c.case_id AND ct.is_deleted LIKE 'N' LEFT JOIN case_production cp ON cp.case_id = c.case_id LEFT JOIN case_tasks ctp ON ctp.production_id = cp.production_id AND ctp.is_deleted LIKE 'N' LEFT JOIN accounts a ON a.account_id = c.account_id LEFT JOIN user_profiles up ON up.user_id = a.account_manager_id LEFT JOIN user_profiles upc ON upc.user_id = c.created_by WHERE c.case_id IN (?1) GROUP BY c.case_id", nativeQuery = true)
	List<Object[]> ListCaseDetails(List<Long> pllCaseId);

	@Query(value = "SELECT c.case_id, IFNULL(GROUP_CONCAT('`~`', CONCAT_WS('``~',al.app_label_id, CONCAT_WS('~^~', al.title, al.color))), '') FROM cases c LEFT JOIN case_labels cl ON cl.caseId = c.case_id AND cl.is_deleted LIKE 'N' LEFT JOIN app_labels al ON al.app_label_id = cl.app_label_id AND al.is_deleted LIKE 'N' WHERE c.case_id IN (?1) GROUP BY c.case_id", nativeQuery = true)
	List<Object[]> ListCaseDetailLabels(List<Long> pllCaseId);

	@Query(value = "SELECT cq.case_query_id, COUNT(DISTINCT cq.case_query_id), COUNT(DISTINCT cqrf.query_response_file_id), COUNT(DISTINCT cqf.case_query_flag_id), COUNT(DISTINCT cqf1.case_query_flag_id),cq.query_type FROM case_query cq LEFT JOIN case_query_response cqr ON cq.case_query_id = cqr.case_query_id LEFT JOIN case_query_response_files cqrf ON cqr.case_query_response_id = cqrf.case_query_response_id LEFT JOIN case_query_flag cqf ON cq.case_query_id = cqf.case_query_id AND cqf.case_query_flag_type IN (?2) AND cqf.is_deleted LIKE 'N' LEFT JOIN case_query_flag cqf1 ON cq.case_query_id = cqf1.case_query_id AND cqf1.user_id = ?1 AND cqf1.is_deleted LIKE 'N' WHERE cq.case_query_id IN (?3) GROUP BY cq.case_query_id", nativeQuery = true)
	List<Object[]> ListCaseQueryDetails(Long plUserId, List<String> plsFlag, List<Long> pllCaseQueryId);

}