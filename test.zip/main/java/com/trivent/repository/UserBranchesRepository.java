package com.trivent.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.trivent.models.UserBranches;

/**
 * @FileName 	:
 *				UserBranchesRepository.java
 * @ClassName 	:
 * 				UserBranchesRepository
 * @DateAndTime :
 *				Feb 2, 2018 - 7:09:22 PM
 * 
 * @Author 		:
 * 				karthi
 * 
 * @Description : Fetch User Branches Related Native Query Implemented
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public interface UserBranchesRepository extends JpaRepository<UserBranches, Long> {

	@Query("select ub from UserBranches ub where ub.deleted=?1 and ub.userId=?2")
	UserBranches findUserBranchesByUserId(char deleted,Long userId);
	
	@Query("select ub from UserBranches ub where ub.deleted=?1 and ub.branchId like CONCAT('%',?2,'%')")
	List<UserBranches> findUserBranchesBybranchId(char deleted,Long branchId);
}
