package com.trivent.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.trivent.models.AppDBTable;
import com.trivent.models.AppDBTableColumn;

/**
 * @FileName 	:
 *				AppDBTableColumnRepository.java
 * @ClassName 	:
 * 				AppDBTableColumnRepository
 * @DateAndTime :
 *				Feb 2, 2018 - 5:51:23 PM
 * 
 * @Author 		:
 * 				karthi
 * 
 * @Description : 
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public interface AppDBTableColumnRepository extends JpaRepository<AppDBTableColumn, Long> {

	@Query("from AppDBTableColumn a WHERE a.dbTable.id = ?1 and a.availableForAppUIScreen = 'Y' Order by a.seqNo")
	public List<AppDBTableColumn> findAppDBTablesForUIScreen(Long appDBTableId);

	@Query("from AppDBTableColumn a WHERE a.dbTable.id = ?1 and a.availableForReport = 'Y' Order by a.seqNo")
	public List<AppDBTableColumn> findAppDBTablesForReport(Long appDBTableId);

	@Query("from AppDBTableColumn a WHERE a.dbTable.name = ?1 and a.name = ?2")
	public AppDBTableColumn findByTableColumnName(String tableName, String columnName);

	@Query("from AppDBTableColumn a WHERE  a.dbTable.id = ?1 and a.name = ?2 Order by a.seqNo")
	public List<AppDBTableColumn> findByNameTable(Long appDBTableId, String columnName);

	@Query("from AppDBTableColumn a WHERE  a.dbTable.id = ?1")
	public List<AppDBTableColumn> findByNameTable(Long appDBTableId);

	@Query("from AppDBTableColumn a WHERE  a.dbTable = ?1 and a.name = ?2 Order by a.seqNo")
	public List<AppDBTableColumn> findByNameTable(AppDBTable appDBTableId, String columnName);

}
