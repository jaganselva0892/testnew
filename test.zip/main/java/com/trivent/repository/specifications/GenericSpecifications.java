package com.trivent.repository.specifications;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.Subquery;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.trivent.constants.AppConstants;
import com.trivent.models.Account;
import com.trivent.models.AppConfig;
import com.trivent.models.AppItem;
import com.trivent.models.Capability;
import com.trivent.models.Case;
import com.trivent.models.Division;
import com.trivent.models.Partner;
import com.trivent.models.ProdFile;
import com.trivent.models.Production;
import com.trivent.models.Role;
import com.trivent.models.Team;
import com.trivent.models.User;
import com.trivent.utils.CommonUtils;

/**
 * @FileName : GenericSpecifications.java
 * @ClassName : GenericSpecifications
 * @DateAndTime : Feb 3, 2018 - 9:48:09 AM
 * 
 * @Author : karthi
 * 
 * @Description : GenericSpecifications For All Type of Entity Classes
 * 
 * @Tags :
 * @param <T>
 * @Git_Config : name email
 * 
 */
@Component
public class GenericSpecifications<T> {

	private GenericSpecifications() {

	}

	private static String getLikePattern(final String searchTerm) {
		StringBuilder pattern = new StringBuilder();
		pattern.append(searchTerm.toLowerCase());
		pattern.insert(0, "%");
		pattern.append("%");
		return pattern.toString();
	}

	// For String Type Columns
	public Specification<T> dataTypeString(final String columnName, final String searchTerm) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				String likePattern = getLikePattern(searchTerm);
				return cb.like(cb.lower(root.<String>get(columnName)), likePattern);
			}
		};
	}

	public Specification<T> dataTypeNotLikePattern(final String columnName, final String searchTerm) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				String likePattern = getLikePattern(searchTerm);
				return cb.notLike(cb.lower(root.<String>get(columnName)), likePattern);
			}
		};
	}

	// For Character Type Columns
	public Specification<T> dataTypeCharacter(final String columnName, final char searchTerm) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.equal(root.<Character>get(columnName), searchTerm);
			}
		};
	}

	// For Calendar Type Columns
	public Specification<T> dataTypeCalendar(final String columnName, final Calendar searchTerm) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.between(root.<Date>get(columnName), searchTerm.getTime(),
						CommonUtils.getCalendarEndOfDayTime(searchTerm).getTime());
			}
		};
	}

	// For Date type columns
	public Specification<T> dataTypeDate(final String columnName, final Date searchTerm, final Date searchTerm1) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {

				return cb.between(root.<Date>get(columnName), searchTerm, searchTerm1);
			}
		};
	}

	public Specification<T> dataTypeCalendar(final String columnName, final Calendar searchTerm,
			final Calendar searchTerm1) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {

				return cb.between(root.<Date>get(columnName), searchTerm.getTime(), searchTerm1.getTime());
			}
		};
	}

	public Specification<T> dataTypeDate(final String columnName, final Date searchTerm) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {

				return cb.equal(root.<Date>get(columnName), searchTerm);

			}
		};
	}

	// For Calendar Type Columns
	public Specification<T> limitRecordsByDays(final String columnName) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				Calendar calendar = Calendar.getInstance();
				// current date -30 days records
				calendar.add(Calendar.DAY_OF_MONTH, -60);
				return cb.greaterThan(root.<Date>get(columnName),
						CommonUtils.getCalendarEndOfDayTime(calendar).getTime());
			}
		};
	}

	// For User Type Columns
	public Specification<T> dataTypeUser(final String columnName, final User searchTerm) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.equal(root.<User>get(columnName), searchTerm);
			}
		};
	}

	// For Case Type Columns
	public Specification<T> dataTypeCase(final String columnName, final Case searchTerm) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.equal(root.<Case>get(columnName), searchTerm);
			}
		};
	}

	// For Partner Type Columns
	public Specification<T> dataTypePartner(final String columnName, final Partner searchTerm) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.equal(root.<Partner>get(columnName), searchTerm);
			}
		};
	}

	public Specification<T> dataTypeCaseQueryLikePattern(final String columnName, final String searchTerm) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				String likePattern = getLikePattern(searchTerm);
				return cb.like(cb.lower(root.<String>get(columnName)), likePattern);
			}
		};
	}

	public Specification<T> dataTypeAccount(final String columnName, final List<Account> searchTerm) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.and(root.<Account>get(columnName).in(searchTerm));
			}
		};
	}

	public Specification<T> dataTypeAppItem(final String columnName, final List<AppItem> searchTerm) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.and(root.<AppItem>get(columnName).in(searchTerm));
			}
		};
	}

	public Specification<T> dataTypeParentTask(final String columnName, final Long searchTerm) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.and(root.<Long>get(columnName).in(searchTerm));
			}
		};
	}

	public Specification<T> dataTypeParentTaskNull(final String columnName, final Long searchTerm) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.and(cb.isNull(root.get(columnName)));
			}
		};
	}

	// For User Type Columns
	public Specification<T> dataTypeClassName(final String columnName, final String searchTerm) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				String likePattern = getLikePattern(searchTerm);
				return cb.like(cb.lower(root.get(columnName).<String>get(Case.PROPERTY_NAME)), likePattern);
			}
		};
	}

	// For User Type Columns
	public Specification<T> anyAccount(final String columnName, final List<Account> accounts) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.and(root.<Account>get(columnName).in(accounts));
			}
		};
	}

	// For User Type Columns with in option
	public Specification<T> anyUsers(final String columnName, final List<User> users) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.and(root.<User>get(columnName).in(users));
			}
		};
	}

	// For User Type Columns with in option
	public Specification<T> notAnyUsers(final String columnName, final List<User> users) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.not(root.<User>get(columnName).in(users));
			}
		};
	}

	public Specification<T> anyStringColumns(final String columnName, final List<String> searchTerm) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.and(root.<String>get(columnName).in(searchTerm));
			}
		};
	}

	// For Long Type Columns
	public Specification<T> dataTypeLong(final String columnName, final Long searchTerm) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.equal(root.<Long>get(columnName), searchTerm);
			}
		};
	}

	// For Long Type Columns
	public Specification<T> dataTypeLongList(final String columnName, final List<Long> searchTerm) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.or(root.<Long>get(columnName).in(searchTerm));
			}
		};
	}

	// For String List Type Columns
	public Specification<T> dataTypeStringList(final String columnName, final List<String> searchTerm) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.or(root.<String>get(columnName).in(searchTerm));
			}
		};
	}

	// For User Type Columns with in option
	public Specification<T> anyUsersLogin(final String columnName, final List<String> users) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.and(root.<String>get(columnName).in(users));
			}
		};
	}

	// For Appconfig Type Columns with in option
	public Specification<T> anyAppConfig(final String columnName, final List<AppConfig> appConfigs) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.and(root.<AppConfig>get(columnName).in(appConfigs));
			}
		};
	}

	// For String Type Columns equal
	public Specification<T> dataTypeStringEqual(final String columnName, final String searchTerm) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.equal(cb.lower(root.<String>get(columnName)),
						(searchTerm != null ? searchTerm.toLowerCase() : searchTerm));
			}
		};
	}

	// For date comparison (less than)
	public Specification<T> dataTypeLessThanDate(final String columnName, final Date searchTerm) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {

				return cb.lessThan(root.<Date>get(columnName), searchTerm);
			}
		};
	}

	// For date comparison (less than)
	public Specification<T> dataTypeGreaterThanDate(final String columnName, final Date searchTerm) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {

				return cb.greaterThan(root.<Date>get(columnName), searchTerm);
			}
		};
	}

	// for two column comparison
	public Specification<T> dataTypeGreaterThanDate(final String columnName, final String columnName1) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {

				return cb.greaterThan(root.<Date>get(columnName), root.<Date>get(columnName1));
			}
		};
	}

	// For case list filter
	public Specification<T> dataTypeCaseList(final String columnName, final List<Case> searchTerm) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.and(root.<Case>get(columnName).in(searchTerm));
			}
		};
	}

	// For Production list filter
	public Specification<T> dataTypeProductionList(final String columnName, final List<Production> searchTerm) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.and(root.<ProdFile>get(columnName).in(searchTerm));
			}
		};
	}

	// For String Type Columns Not equal
	public Specification<T> dataTypeStringNotEqual(final String columnName, final String searchTerm) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.notEqual(cb.lower(root.<String>get(columnName)),
						(searchTerm != null ? searchTerm.toLowerCase() : searchTerm));
			}
		};
	}

	

	// For Role Type Columns with in option
	public Specification<T> anyRole(final String columnName, final List<Role> searchTerm) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.and(root.<Role>get(columnName).in(searchTerm));
			}
		};
	}

	// For Role Type Columns with in option
	public Specification<T> anyCapability(final String columnName, final List<Capability> searchTerm) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.and(root.<Capability>get(columnName).in(searchTerm));
			}
		};
	}

	public Specification<T> dataTypeAppConfigNull(final String columnName) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.and(cb.isNull(root.get(columnName)));
			}
		};
	}

	// For String List Type Columns
	public Specification<T> dataTypeStringNotList(final String columnName, final List<String> searchTerm) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.not(root.<String>get(columnName).in(searchTerm));
			}
		};
	}

	

	public Specification<T> dataTypeAccount(final String columnName, final Character searchTerm) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.equal(root.<Account>get(columnName), searchTerm);
			}
		};
	}

	public Specification<T> dataTypeCaseDeleted(final String columnName, final char searchTerm) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.equal(root.<Case>get(columnName), searchTerm);
			}
		};
	}

	
	

	public Specification<T> dataTypeNotNull(final String columnName) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.and(cb.isNotNull(root.get(columnName)));
			}
		};
	}

	

	public Specification<T> anyOrderByColumnDesc(final String columnName) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				query.orderBy(cb.desc(root.get(columnName)));
				return cb.equal(root.get(columnName), root.get(columnName));
			}
		};
	}

	public Specification<T> dataTypeParentNull(final String columnName) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.and(cb.isNull(root.get(columnName)));
			}
		};
	}

	public Specification<T> dataTypePartnerList(final String columnName, final List<Partner> searchTerm) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.and(root.<Partner>get(columnName).in(searchTerm));
			}
		};
	}

	// For Role Type Columns
	public Specification<T> dataTypeRole(final String columnName, final Role searchTerm) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.equal(root.<Role>get(columnName), searchTerm);
			}
		};
	}

	

	

	public Specification<T> joinUsers(final String columnName) {

		return new Specification<T>() {

			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {

				final Subquery<Long> subQuery = query.subquery(Long.class);
				final Root<User> user = subQuery.from(User.class);
				Predicate checkIsDeleted = cb.equal(user.get("deleted"), AppConstants.NO);
				subQuery.select(root.<Long>get(columnName));
				subQuery.where((cb.equal(user.<Long>get("id"), root.<Long>get(columnName))), checkIsDeleted);
				return cb.exists(subQuery);
			}
		};

	}

	public Specification<T> joinPartners(final String columnName) {

		return new Specification<T>() {

			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {

				final Subquery<Long> subQuery = query.subquery(Long.class);
				final Root<Partner> partner = subQuery.from(Partner.class);
				Predicate checkIsDeleted = cb.equal(partner.get("deleted"), AppConstants.NO);
				subQuery.select(root.<Long>get(columnName));
				subQuery.where((cb.equal(partner.<Long>get("id"), root.<Long>get(columnName))), checkIsDeleted);
				return cb.exists(subQuery);
			}
		};

	}

	public Specification<T> dataTypeStringNotInList(final String columnName, final List<Long> searchTerm) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.not(root.<String>get(columnName).in(searchTerm));
			}
		};
	}


	public Specification<T> dataTypeStringNotLike(final String columnName, final String searchTerm) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				String likePattern = getLikePattern(searchTerm);
				return cb.notLike(cb.lower(root.<String>get(columnName)), likePattern);
			}
		};
	}

	public Specification<T> joinAccounts(final String columnName) {

		return new Specification<T>() {

			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {

				final Subquery<String> subQuery = query.subquery(String.class);
				final Root<Account> account = subQuery.from(Account.class);
				Predicate checkIsDeleted = cb.equal(account.get("deleted"), AppConstants.NO);
				subQuery.select(root.<String>get(columnName));
				subQuery.where(checkIsDeleted);
				return cb.exists(subQuery);
			}
		};

	}

	
	public Specification<T> dataTypeUserForQI(final String columnName, final String searchTerm) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.equal(root.<String>get(columnName), searchTerm);
			}
		};
	}
	
	
	public Specification<T> dataTypeTeamForQI(final String columnName, final String searchTerm) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.equal(root.<String>get(columnName), searchTerm);
			}
		};
	}
	
	// For User Type Columns with in option
		public Specification<T> anyUsersForQM(final String columnName, final List<String> users) {
			return new Specification<T>() {
				@Override
				public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
					return cb.and(root.<String>get(columnName).in(users));
				}
			};
		}
		
		public Specification<T> anyUsersForQMLikePattern(final String columnName, final String searchTerm) {
			return new Specification<T>() {
				@Override
				public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
					String likePattern = getLikePattern(searchTerm);
					return cb.like(cb.lower(root.<String>get(columnName)), likePattern);
				}
			};
		}
		
		public Specification<T> dataTypeDivision(final String columnName, final Division searchTerm) {
			return new Specification<T>() {
				@Override
				public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
					return cb.equal(root.<Division>get(columnName), searchTerm);
				}
			};
		}
		
		// For Team Type Columns
		public Specification<T> dataTypeTeam(final String columnName, final Team searchTerm) {
			return new Specification<T>() {
				@Override
				public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
					return cb.equal(root.<Team>get(columnName), searchTerm);
				}
			};
		}
}
