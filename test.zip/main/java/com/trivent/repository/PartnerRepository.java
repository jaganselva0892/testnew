package com.trivent.repository;

import java.util.List;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.trivent.models.Partner;

/**
 * @FileName : PartnerRepository.java
 * @ClassName : PartnerRepository
 * @DateAndTime : Feb 2, 2018 - 7:02:13 PM
 * 
 * @Author : karthi
 * 
 * @Description : Fetch Partner Related Native Query Implemented
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
public interface PartnerRepository extends JpaRepository<Partner, Long> {

	List<Partner> findAll(Specification<Partner> specification);

	@Query("select p from Partner p where p.deleted = ?1 order by p.name")
	List<Partner> listPartners(char isDeleted);

	@Query("select p from Partner p where p.name = ?1")
	Partner findByName(String name);

	@Query("select p from Partner p where p.partnerCode = ?1 and p.deleted = 'N'")
	Partner findByPartnerCode(String code);

	@Query(value = "select p.partner_code as 'partnerCode' from partners p inner join accounts a on a.partner_id = p.partner_id inner join users u on u.account_id = a.account_id and u.login_id = ?1", nativeQuery = true)
	public Object[] findPartnerbyEmail(String emailId);

	@Query("select p from Partner p where p.id = ?1 and p.deleted = 'N'")
	Partner findByPartnerId(Long id);

	@Query("select p.partnerDomain from Partner p where p.id = ?1 and p.deleted = 'N'")
	String getDomainByPartnerId(Long partnerId);

}
