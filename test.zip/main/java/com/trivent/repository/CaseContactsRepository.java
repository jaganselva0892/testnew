package com.trivent.repository;

import java.util.List;

import org.joda.time.DateTime;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;

import com.trivent.models.Case;
import com.trivent.models.CaseContacts;
import com.trivent.models.User;

/**
 * @FileName 	:
 *				CaseContactsRepository.java
 * @ClassName 	:
 * 				CaseContactsRepository
 * @DateAndTime :
 *				Feb 2, 2018 - 6:39:18 PM
 * 
 * @Author 		:
 * 				karthi
 * 
 * @Description : Fetch Case Contact  Related Native Query Implemented
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public interface CaseContactsRepository extends JpaRepository<CaseContacts, Long> {

	List<CaseContacts> findAll(Specification<CaseContacts> specification);

	@Query("select c from CaseContacts c where c.deleted = ?1 and c.userId = ?2 and c.caseId.id = ?3")
	List<CaseContacts> existCaseContactbyUserId(char isDeleted, User user, Long caseId);

	@Query("select c from CaseContacts c where c.deleted = ?1 and c.contactId = ?2 and c.caseId.id = ?3")
	List<CaseContacts> existCaseContactbyEntity(char isDeleted, Long contactId, Long caseId);

	@Query("select c from CaseContacts c where c.deleted = ?1 and c.caseId.id = ?2")
	List<CaseContacts> listCaseContactsByCaseID(char isDeleted, Long caseId);

	@Query("select c from CaseContacts c where c.deleted = ?1 and c.userId = ?2")
	List<CaseContacts> listCaseContactsByLoginUser(char isDeleted, User user);

	@Query("select c from CaseContacts c where c.deleted = ?1 and c.userId.id = ?2")
	List<CaseContacts> listCaseContactsByUserId(char isDeleted, Long user);

	@Modifying
	@Query(value = "UPDATE CaseContacts c SET c.deleted = ?1 WHERE c.caseId.id = ?2")
	int updateCaseContactsbyCaseID(char isDeleted, Long caseId);

	@Query("select c from CaseContacts c where c.deleted = ?1 and c.userId = ?2 and c.caseId = ?3")
	List<CaseContacts> existCaseContactbyUserId(char isDeleted, User user, Case caseId);

	@Modifying
	@Query(value = "UPDATE CaseContacts c SET c.deleted = ?1 WHERE c.caseId = ?2")
	int updateCaseContactsbyCaseID(char isDeleted, Case caseId);

	@Modifying
	@Query(value = "UPDATE CaseContacts c SET c.deleted = ?1 WHERE c.caseId = ?2 and c.id = ?3")
	int updateCaseContactsbyId(char isDeleted, Case caseId, Long caseContactId);

	// @Query("select c from CaseContacts c where c.deleted = ?1 and c.userId.id
	// = ?2")
	// CaseContacts> listCaseContactsByUserId(char isDeleted, Long user);

	@Query("SELECT c FROM CaseContacts c where c.emailId = ?1")
	List<CaseContacts> getCaseContactbyEmail(String emailId);

	@Modifying
	@Query(value = "UPDATE CaseContacts c SET c.userId = ?1, c.contactType = ?2, c.contactId = ?3 WHERE c.emailId = ?4")
	int updateCaseContactsbyUserID(User userId, String contactType, Long contactId, String emailId);
	
	@Query("select c from CaseContacts c where userId.id is null and is_deleted=?1")
	List<CaseContacts> listCaseContactsByCaseIdNull(char deleted);
	
	@Query("select c from CaseContacts c where c.caseId=?1 and c.emailId=?2 and c.deleted=?3")
	CaseContacts getCaseContactByCaseAndEmailId(Case appCase,String mailId,char deleted);

	@Query(value = "select c from CaseContacts c where c.deleted= ?1 and  c.contactId = ?2")
	List<CaseContacts> updateCaseContactsbyEmail(char isDeleted, Long contactId);
	
	//Call Procedure for insert save_case_contacts
	@Procedure("save_case_contacts")
	Long save_case_contacts(
						@Param("case_contact_id") Long case_contact_id,
						@Param("action") String action,
						@Param("column_to_update") String column_to_update,
						@Param("case_id") Long case_id,
						@Param("user_id") Long user_id,
						@Param("name") String name,
						@Param("email_id") String email_id,						
						@Param("created_date") DateTime created_date,
						@Param("created_by") Long created_by,
						@Param("modified_date") DateTime modified_date,
						@Param("modified_by") Long modified_by,
						@Param("optlock_version") Integer optlock_version,
						@Param("is_deleted") Character is_deleted,						
						@Param("contact_id") Long contact_id,											
						@Param("contact_type") String contact_type					
	);
	
	@Procedure("save_case_contacts_by_case_id")
	Long save_case_contacts_by_case_id(
						@Param("case_contact_id") Long case_contact_id,
						@Param("action") String action,
						@Param("column_to_update") String column_to_update,
						@Param("case_id") Long case_id,
						@Param("user_id") Long user_id,
						@Param("name") String name,
						@Param("email_id") String email_id,						
						@Param("created_date") DateTime created_date,
						@Param("created_by") Long created_by,
						@Param("modified_date") DateTime modified_date,
						@Param("modified_by") Long modified_by,
						@Param("optlock_version") Integer optlock_version,
						@Param("is_deleted") Character is_deleted,						
						@Param("contact_id") Long contact_id,											
						@Param("contact_type") String contact_type					
	);
	
	@Procedure("update_casecontacts_by_caseid_contactid")
	Long update_casecontacts_by_caseid_contactid(
						@Param("case_contact_id") Long case_contact_id,
						@Param("action") String action,
						@Param("column_to_update") String column_to_update,
						@Param("case_id") Long case_id,
						@Param("user_id") Long user_id,
						@Param("name") String name,
						@Param("email_id") String email_id,						
						@Param("created_date") DateTime created_date,
						@Param("created_by") Long created_by,
						@Param("modified_date") DateTime modified_date,
						@Param("modified_by") Long modified_by,
						@Param("optlock_version") Integer optlock_version,
						@Param("is_deleted") Character is_deleted,						
						@Param("contact_id") Long contact_id,											
						@Param("contact_type") String contact_type					
	);
}
