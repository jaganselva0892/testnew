package com.trivent.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.trivent.models.AppLabels;

public interface AppLabelsRepository extends JpaRepository<AppLabels, Long> {
	
	@Query("select a from AppLabels a where a.deleted=?1")
	List<AppLabels> findLabelNames(char deleted);

}
