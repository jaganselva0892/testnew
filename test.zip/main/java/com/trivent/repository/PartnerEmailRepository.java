package com.trivent.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.trivent.models.EmailTemplate;
import com.trivent.models.Partner;
import com.trivent.models.PartnerEmails;

/**
 * @FileName 	:
 *				PartnerEmailRepository.java
 * @ClassName 	:
 * 				PartnerEmailRepository
 * @DateAndTime :
 *				Feb 2, 2018 - 7:01:55 PM
 * 
 * @Author 		:
 * 				karthi
 * 
 * @Description : Fetch Partner Email Related Native Query Implemented
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public interface PartnerEmailRepository extends JpaRepository<PartnerEmails, Long> {

	@Query("select p from PartnerEmails p where p.deleted = ?1 and p.partner = ?2 and p.emailTemplate = ?3")
	PartnerEmails getByParterTemplate(char isDeleted, Partner partner, EmailTemplate emailTemplate);
	
}
