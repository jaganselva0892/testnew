package com.trivent.repository;

import java.util.List;

import org.joda.time.DateTime;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;

import com.trivent.models.CaseLabels;

/**
 * @FileName 	:
 *				CaseLabelsRepository.java
 * @ClassName 	:
 * 				CaseLabelsRepository
 * @DateAndTime :
 *				Feb 2, 2018 - 6:47:33 PM
 * 
 * @Author 		:
 * 				karthi
 * 
 * @Description : Fetch Case Labels Related Native Query Implemented
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public interface CaseLabelsRepository extends JpaRepository<CaseLabels, Long> {
  
	@Query("select cl from CaseLabels cl where cl.caseId=?1 and deleted=?2")
	List<CaseLabels> findLabelsByCaseID(Long caseId,char deleted);
	
	@Query("select cl from CaseLabels cl where cl.appLabelId=?1")
	CaseLabels findCaseLabelsByAppLabelId(Long appLabelId);
	
	@Query("select cl from CaseLabels cl where cl.appLabelId=?1")
	List<CaseLabels> findCaseLabelsListByAppLabelId(Long appLabelId);
	
	
	//Call Procedure for insert save_case_labels
	@Procedure("save_case_labels")
	Long save_case_labels(
				@Param("case_label_id") Long case_label_id,
				@Param("action") String action,
				@Param("app_label_id") Long app_label_id,
				@Param("caseId") Long caseId,
				@Param("created_date") DateTime created_date,
				@Param("created_by") Long created_by,
				@Param("modified_date") DateTime modified_date,
				@Param("modified_by") Long modified_by,				
				@Param("optlock_version") Integer optlock_version,
				@Param("is_deleted") Character is_deleted
	);	
}
