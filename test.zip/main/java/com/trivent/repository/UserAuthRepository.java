package com.trivent.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;

import com.trivent.models.UserAuth;

public interface UserAuthRepository extends JpaRepository<UserAuth, Long> {
	
	UserAuth findByLoginId(String loginId);
	
	@Procedure("save_user_auth")
	Long createUserAuth(@Param("psEmailID") String psEmailID,@Param("psToken") String psToken,@Param("pnUserid") Long pnUserid);
	
	@Procedure("update_user_auth")
	void updateUserAuth(String psEmailID, String psToken,Long pnUserid);
	
	@Query("select ua from UserAuth ua where ua.token=?1 and deleted=?2")
	UserAuth findByTokenIP(String token, char deleted);


}
