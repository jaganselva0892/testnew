package com.trivent.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.trivent.models.Team;

/**
 * @FileName 	:
 *				TeamRepository.java
 * @ClassName 	:
 * 				TeamRepository
 * @DateAndTime :
 *				Feb 2, 2018 - 7:08:50 PM
 * 
 * @Author 		:
 * 				karthi
 * 
 * @Description : Fetch Team Related Native Query Implemented
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public interface TeamRepository extends JpaRepository<Team, Long> {

	@Query("select t from Team t JOIN FETCH t.division where t.deleted = ?1 order by t.name")
	List<Team> listTeams(char isDeleted);

	@Query("select t from Team t where t.name = ?1")
	Team findByName(String name);

	@Query("select t.id from Team t where t.deleted=?1")
	Integer findById(char isDeleted);

	Page<Team> findAll(Specification<Team> specification, Pageable constructPageSpecification);

}
