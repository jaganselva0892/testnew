package com.trivent.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.trivent.models.AppDBTable;

/**
 * @FileName 	:
 *				AppDBTableRepository.java
 * @ClassName 	:
 * 				AppDBTableRepository
 * @DateAndTime :
 *				Feb 2, 2018 - 5:55:52 PM
 * 
 * @Author 		:
 * 				karthi
 * 
 * @Description : Application DB Table Related Native Query Implemented
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public interface AppDBTableRepository extends JpaRepository<AppDBTable, Long> {

  public AppDBTable findByName(String tableName);

  @Query("from AppDBTable a WHERE a.availableForAppUIScreen = 'Y' Order by a.seqNo")
  public List<AppDBTable> findAppDBTablesForUIScreen();

  @Query("from AppDBTable a WHERE a.availableForReport = 'Y' Order by a.seqNo")
  public List<AppDBTable> findAppDBTablesForReport();
  
  @Query("from AppDBTable a WHERE a.name = ?1")
  public AppDBTable findByNameTable(String tableName);

}
