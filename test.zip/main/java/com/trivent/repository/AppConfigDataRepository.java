package com.trivent.repository;

import java.util.List;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;

import com.trivent.models.AppConfigData;

/**
 * @FileName : AppConfigDataRepository.java
 * @ClassName : AppConfigDataRepository
 * @DateAndTime : Feb 2, 2018 - 5:20:14 PM
 * 
 * @Author : karthi
 * 
 * @Description : Application Configuration Related Details Implemented
 * 
 * @Tags :
 * 
 */
public interface AppConfigDataRepository extends JpaRepository<AppConfigData, Long> {

	List<AppConfigData> findAll(Specification<AppConfigData> specification);

}
