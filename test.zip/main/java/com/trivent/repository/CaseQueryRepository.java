package com.trivent.repository;

import java.util.Date;
import java.util.List;

import org.joda.time.DateTime;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;

import com.trivent.models.CaseQuery;
import com.trivent.models.User;

/**
 * @FileName : CaseQueryRepository.java
 * @ClassName : CaseQueryRepository
 * @DateAndTime : Feb 2, 2018 - 6:48:24 PM
 * 
 * @Author : karthi
 * 
 * @Description : Fetch Case Query Related Native Query Implemented
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
public interface CaseQueryRepository extends JpaRepository<CaseQuery, Long> {

	List<CaseQuery> findAll(Specification<CaseQuery> specification);

	@Query("select cq from CaseQuery cq where cq.clientCase.id = ?1 and cq.deleted = ?2 order by cq.seqNo")
	List<CaseQuery> findAllByCaseId(Long caseId, Character isDeleted);

	@Query("select cq from CaseQuery cq where cq.clientCase.id = ?1 and cq.isVisible2Client = ?2 and cq.deleted = ?3 order by cq.seqNo")
	List<CaseQuery> findAllByCaseIdForCustomer(Long caseId, Character isVisible2Client, Character isDeleted);

	@Query("select cq from CaseQuery cq where cq.clientCase.id = ?1 and cq.isVisible2Client = ?2 and cq.deleted = ?3 and (cq.queryTo LIKE CONCAT('%', ?4, '%') OR cq.client.id = ?5) order by cq.seqNo")
	List<CaseQuery> findAllByCaseIdForCustomer(Long caseId, Character isVisible2Client, Character isDeleted,
			String clientloginId, Long clientId);

	@Query("select cq from CaseQuery cq where cq.clientCase.id = ?1 and cq.isInternal = ?2 and cq.deleted = ?3 order by cq.seqNo")
	List<CaseQuery> findAllByCaseIdForInternal(Long caseId, Character isInternal, Character isDeleted);

	Page<CaseQuery> findAll(Specification<CaseQuery> specification, Pageable constructPageSpecification);

	@Query("select coalesce(max(cq.seqNo), '0') from CaseQuery cq where cq.clientCase.id = ?1")
	Integer getNextQuerySeqNoByCaseId(Long caseId);

	@Modifying
	@Query("Update CaseQuery cq set cq.deleted = 'Y' where cq.clientCase.id = ?1")
	int deleteCaseQueryByCaseId(Long caseId);

	@Modifying
	@Query("Update CaseQuery cq set cq.deleted = 'Y' where cq.id = ?1")
	int deleteCaseQueryId(Long queryId);

	@Query("select cq.id,cq.querySubject from CaseQuery cq where cq.deleted=?1 order by cq.id desc")
	List<CaseQuery> findAllQuerySubjects(Character isDeleted);

	@Query("select cq.id,cq.querySubject from CaseQuery cq where cq.deleted= ?1 and cq.client.id =?2  order by cq.id desc")
	List<Object[]> findAllQuerySubjects(Character isDeleted, Long clientId);

	@Query("select cq.id,cq.querySubject from CaseQuery cq where cq.deleted= ?1 and cq.querySubject like CONCAT('%',?2,'%') order by cq.id desc")
	List<Object[]> findAllQuerySubjectsSearch(Character isDeleted, String searchTerm);

	@Query("select cq.id,cq.querySubject from CaseQuery cq where cq.deleted= ?1 and cq.querySubject like CONCAT('%',?2,'%') and cq.querySubject like CONCAT('%',?3,'%') order by cq.id desc")
	List<Object[]> findAllQuerySubjectsSearchBean(Character isDeleted, String searchTerm, String outBean);

	@Query("select cq.id,cq.querySubject from CaseQuery cq where cq.deleted= ?1 and cq.querySubject like CONCAT('%',?2,'%') and (cq.queryPartnerBean like CONCAT('%',?3,'%') or cq.queryPartnerBean like CONCAT('%',?4,'%')) order by cq.id desc")
	List<Object[]> findAllQuerySubjectsSearchBean(Character isDeleted, String searchTerm, String outBean,
			String internalBean);

	@Modifying
	@Query("Update CaseQuery cq set cq.deleted = 'Y' where cq.id = ?1")
	int deleteCaseQueryById(Long queryId);

	@Query("select cq from CaseQuery cq where cq.deleted= 'N'  order by cq.id desc")
	List<CaseQuery> QueryListAPI();

	@Query("select cq from CaseQuery cq where cq.clientCase.id = ?1 and cq.deleted = 'N' and cq.isVisible2Client = 'Y' order by cq.seqNo")
	List<CaseQuery> CaseQueriesByCaseIdAPI(Long caseId);

	@Query("select cq from CaseQuery cq where cq.clientCase.id = ?1 and cq.deleted = 'N' order by cq.seqNo")
	List<CaseQuery> CaseCsQueriesByCaseIdAPI(Long caseId);

	@Query("select count(*) from CaseQuery cq where cq.isQueryOpen=?1 and cq.deleted=?2")
	Object[] listUnreadQueries(Character isQueryOpen, char isDeleted);

	// @Query("select count(*) from Case c where date(createdDate)=CURRENT_DATE
	// and c.deleted=?1")
	// Object[] listTodayCommunicationswithoutCase(char isDeleted);
	//
	// @Query("select count(*) from Case c where date(createdDate)=CURRENT_DATE
	// and c.deleted=?1 and c.case_id=?2")
	// Object[] listTodayCommunicationswithCase(char isDeleted, Long caseId);

	@Query("select count(*) from CaseQuery cq where cq.createdBy=?1 and cq.deleted=?2 and cq.isQueryOpen=?3")
	Object[] getUnreadQueriesCount(User createdBy, char isDeleted, char isQueryOpen);

	@Query("select count(*) from CaseQuery cq where date(cq.createdDate)=curdate()and cq.ownerRoleType='Customer' and cq.clientCase is not null and not cq.clientCase='' and cq.deleted= ?1 ")
	Object[] listTodaysCaseBasedQueries(char isDeleted);

	@Query("select count(*) from CaseQuery cq where date(cq.createdDate)=curdate() and cq.ownerRoleType ='Customer' and cq.clientCase is null and cq.deleted= ?1 ")
	Object[] listTodaysQueries(char isDeleted);

	@Query("select count(*) from CaseQuery cq where (date(cq.createdDate) between ?1 and ?2) and cq.ownerRoleType ='Customer' and cq.clientCase is null and cq.deleted= ?3 ")
	Object[] listQueriesbyDate(Date fromCreatedDate, Date toCreatedDate, char isDeleted);

	@Query("select count(*) from CaseQuery cq where (date(cq.createdDate) between ?1 and ?2) and cq.ownerRoleType='Customer' and cq.clientCase is not null and not cq.clientCase='' and cq.deleted= ?3 ")
	Object[] listCaseBasedQueriesByDate(Date fromCreatedDate, Date toCreatedDate, char isDeleted);

	@Query("select cq.query_type from CaseQuery cq where cq.deleted=?1")
	Object[] findAllLongNames(char deleted);

	@Query("select cq from CaseQuery cq where cq.query_type like CONCAT('%',?1,'%')")
	List<CaseQuery> findAllNegativeLongNames(String queryType);

	@Query("select count(*) from CaseQuery cq where date(cq.createdDate)=curdate() and cq.deleted= ?1 and cq.query_type like CONCAT('%',?2,'%')")
	Object[] listTodayQueriesByType(char isDeleted, String qType);

	@Query("select count(*) from CaseQuery cq where (date(cq.createdDate) between ?1 and ?2) and cq.deleted= ?3 and cq.query_type like CONCAT('%',?4,'%') ")
	Object[] listQueriesByDate(Date fromCreatedDate, Date toCreatedDate, char isDeleted, String qType);

	@Query("select count(*) from CaseQuery cq where (date(cq.createdDate) between ?1 and ?2) and cq.deleted= ?3 and cq.query_type like CONCAT('%',?4,'%') and cq.querySubject like CONCAT('%',?5,'%') ")
	Object[] listQueriesByDatePartner(Date fromCreatedDate, Date toCreatedDate, char isDeleted, String qType,
			String filterPartnerCode);

	@Query("select count(*) from CaseQuery cq where date(cq.createdDate)=curdate() and cq.deleted= ?1 and cq.query_type like CONCAT('%',?2,'%') and cq.querySubject like CONCAT('%',?3,'%')")
	Object[] listTodayQueriesByTypePartner(char isDeleted, String qType, String filterPartnerCode);

	@Query("select count(*) from CaseQuery cq where (date(cq.createdDate) between ?1 and ?2) and cq.deleted= ?3 and cq.query_type like CONCAT('%',?4,'%')")
	Object[] listQueriesByDatePartner(Date fromCreatedDate, Date toCreatedDate, char isDeleted, String qType);

	@Query("select count(*) from CaseQuery cq where date(cq.createdDate)=curdate() and cq.deleted= ?1 and cq.query_type is null")
	Object[] listTodayQueriesByTypeNull(char isDeleted);

	@Query("select count(*) from CaseQuery cq where date(cq.createdDate)=curdate() and cq.deleted= ?1 and cq.query_type is null and cq.querySubject like CONCAT('%',?2,'%')")
	Object[] listTodayQueriesByTypeNullPartner(char isDeleted, String filterPartnerCode);

	@Query("select count(*) from CaseQuery cq where (date(cq.createdDate) between ?1 and ?2) and cq.deleted= ?3 and cq.query_type is null")
	Object[] listQueriesByDateTypeNullPartner(Date fromCreatedDate, Date toCreatedDate, char isDeleted);

	@Query("select count(*) from CaseQuery cq where (date(cq.createdDate) between ?1 and ?2) and cq.deleted= ?3 and cq.query_type is null and cq.querySubject like CONCAT('%',?4,'%') ")
	Object[] listQueriesByDateTypeNullPartner(Date fromCreatedDate, Date toCreatedDate, char isDeleted,
			String filterPartnerCode);

	@Query("select cq from CaseQuery cq where cq.deleted = ?1")
	List<CaseQuery> listQueries(char isDeleted);

	@Query(value = "select cq.case_id from case_query cq where cq.case_query_id = ?1", nativeQuery = true)
	Long findById(Long queryId);

	@Query("select c.account.id, c.id from CaseQuery c WHERE date(c.createdDate) BETWEEN ?1 and ?2 AND FIND_IN_SET(?3, c.query_type) > 0 AND c.deleted = 'N' group by c.id HAVING COUNT(1) > 0 ORDER BY COUNT(1) DESC ")
	List<Object[]> getGroupByAccount(Date fromDate, Date toDate, String psQueryType);

	@Query(value = "SELECT a.account_id, COUNT( DISTINCT cq.case_query_id) AS cntquery, GROUP_CONCAT(cq.case_query_id SEPARATOR ',') AS case_query_ids FROM accounts a LEFT JOIN case_query cq ON cq.account_id = a.account_id AND cq.is_deleted = 'N' AND date(cq.created_date) BETWEEN ?1 AND ?2 JOIN app_items ai ON ((IFNULL(?4, '') <> '' AND FIND_IN_SET(ai.item_id, cq.query_type) > 0 AND ai.item_id IN (?3) ) OR ((IFNULL(?4, '') = '' AND 1 = 1))) WHERE a.is_deleted = 'N' GROUP BY a.account_id HAVING COUNT(cq.case_query_id) > 0 ORDER BY COUNT(cq.case_query_id) DESC ", nativeQuery = true)
	List<Object[]> getGroupByAccountQuery(Date fromDate, Date toDate, List<Long> plQueryType, String psQueryType);

	@Query("select cq from CaseQuery cq where cq.query_type like CONCAT('%',?1,'%') AND cq.id = ?2")
	List<CaseQuery> findAllNegativeLongNames(String queryType, Long psQueryId);

	@Query(value = "SELECT a.account_id, COUNT( DISTINCT cq.case_query_id) AS cntquery, GROUP_CONCAT(DISTINCT cq.case_query_id SEPARATOR ',') AS case_query_ids FROM accounts a LEFT JOIN case_query cq ON cq.account_id = a.account_id AND cq.is_deleted = 'N' AND date(cq.created_date) BETWEEN ?1 AND ?2 JOIN app_items ai ON ((IFNULL(?9, '') <> '' AND FIND_IN_SET(ai.item_id, cq.query_type) > 0 AND ai.item_id IN (?3) ) OR ((IFNULL(?9, '') = '' AND ai.item_id IN (1, 2, 3)))) WHERE a.is_deleted = 'N' AND ((IFNULL(?4, '') <> '' AND a.name LIKE CONCAT('%', ?4, '%')) OR (IFNULL(?4, '') = '' AND 1 = 1)) AND ((IFNULL(?5, '') <> '' AND a.partner_id IN (?5)) OR (IFNULL(?5, '') = '' AND 1 = 1)) AND ((IFNULL(?6, '') <> '' AND a.account_manager_id IN (?6)) OR (IFNULL(?6, '') = '' AND 1 = 1)) GROUP BY a.account_id HAVING COUNT(cq.case_query_id) > 0 ORDER BY COUNT(DISTINCT cq.case_query_id) DESC  LIMIT ?7, ?8", nativeQuery = true)
	List<Object[]> getGroupByAccountQuerycolumSortDsec(Date fromDate, Date toDate, List<Long> psQueryType,
			String psAccName, String psAccPartner, String psAccManager, int lvstartPage, int recordsPerPage,
			String lscategoryType);

	@Query(value = "SELECT a.account_id, COUNT( DISTINCT cq.case_query_id) AS cntquery, GROUP_CONCAT(DISTINCT cq.case_query_id SEPARATOR ',') AS case_query_ids FROM accounts a LEFT JOIN case_query cq ON cq.account_id = a.account_id AND cq.is_deleted = 'N' AND date(cq.created_date) BETWEEN ?1 AND ?2 JOIN app_items ai ON ((IFNULL(?9, '') <> '' AND FIND_IN_SET(ai.item_id, cq.query_type) > 0 AND ai.item_id IN (?3) ) OR ((IFNULL(?9, '') = '' AND ai.item_id IN (1, 2, 3)))) WHERE a.is_deleted = 'N' AND ((IFNULL(?4, '') <> '' AND a.name LIKE CONCAT('%', ?4, '%')) OR (IFNULL(?4, '') = '' AND 1 = 1)) AND ((IFNULL(?5, '') <> '' AND a.partner_id IN (?5)) OR (IFNULL(?5, '') = '' AND 1 = 1)) AND ((IFNULL(?6, '') <> '' AND a.account_manager_id IN (?6)) OR (IFNULL(?6, '') = '' AND 1 = 1)) GROUP BY a.account_id HAVING COUNT(cq.case_query_id) > 0 ORDER BY COUNT(DISTINCT cq.case_query_id) ASC  LIMIT ?7, ?8", nativeQuery = true)
	List<Object[]> getGroupByAccountQuerycolumSortAsc(Date fromDate, Date toDate, List<Long> psQueryType,
			String psAccName, String psAccPartner, String psAccManager, int lvstartPage, int recordsPerPage,
			String lscategoryType);

	@Query(value = "SELECT a.account_id, COUNT( DISTINCT cq.case_query_id) AS cntquery, GROUP_CONCAT(DISTINCT cq.case_query_id SEPARATOR ',') AS case_query_ids FROM accounts a LEFT JOIN case_query cq ON cq.account_id = a.account_id AND cq.is_deleted = 'N' AND date(cq.created_date) BETWEEN ?1 AND ?2 JOIN app_items ai ON ((IFNULL(?9, '') <> '' AND FIND_IN_SET(ai.item_id, cq.query_type) > 0 AND ai.item_id IN (?3) ) OR ((IFNULL(?9, '') = '' AND ai.item_id IN (1, 2, 3)))) WHERE a.is_deleted = 'N' AND ((IFNULL(?4, '') <> '' AND a.name LIKE CONCAT('%', ?4, '%')) OR (IFNULL(?4, '') = '' AND 1 = 1)) AND ((IFNULL(?5, '') <> '' AND a.partner_id IN (?5)) OR (IFNULL(?5, '') = '' AND 1 = 1)) AND ((IFNULL(?6, '') <> '' AND a.account_manager_id IN (?6)) OR (IFNULL(?6, '') = '' AND 1 = 1)) GROUP BY a.account_id HAVING COUNT(cq.case_query_id) > 0 ORDER BY a.name DESC  LIMIT ?7, ?8", nativeQuery = true)
	List<Object[]> getGroupByAccountNameSortDsec(Date fromDate, Date toDate, List<Long> psQueryType, String psAccName,
			String psAccPartner, String psAccManager, int lvstartPage, int recordsPerPage, String lscategoryType);

	@Query(value = "SELECT a.account_id, COUNT( DISTINCT cq.case_query_id) AS cntquery, GROUP_CONCAT(DISTINCT cq.case_query_id SEPARATOR ',') AS case_query_ids FROM accounts a LEFT JOIN case_query cq ON cq.account_id = a.account_id AND cq.is_deleted = 'N' AND date(cq.created_date) BETWEEN ?1 AND ?2 JOIN app_items ai ON ((IFNULL(?9, '') <> '' AND FIND_IN_SET(ai.item_id, cq.query_type) > 0 AND ai.item_id IN (?3) ) OR ((IFNULL(?9, '') = '' AND ai.item_id IN (1, 2, 3)))) WHERE a.is_deleted = 'N' AND ((IFNULL(?4, '') <> '' AND a.name LIKE CONCAT('%', ?4, '%')) OR (IFNULL(?4, '') = '' AND 1 = 1)) AND ((IFNULL(?5, '') <> '' AND a.partner_id IN (?5)) OR (IFNULL(?5, '') = '' AND 1 = 1)) AND ((IFNULL(?6, '') <> '' AND a.account_manager_id IN (?6)) OR (IFNULL(?6, '') = '' AND 1 = 1)) GROUP BY a.account_id HAVING COUNT(cq.case_query_id) > 0 ORDER BY a.name ASC LIMIT ?7, ?8", nativeQuery = true)
	List<Object[]> getGroupByAccountNameSortAsc(Date fromDate, Date toDate, List<Long> psQueryType, String psAccName,
			String psAccPartner, String psAccManager, int lvstartPage, int recordsPerPage, String lscategoryType);

	@Query(value = "SELECT IFNULL(COUNT(1), 0) FROM (SELECT IFNULL(COUNT(DISTINCT a.account_id), 0) FROM accounts a LEFT JOIN case_query cq ON cq.account_id = a.account_id AND cq.is_deleted = 'N' AND date(cq.created_date) BETWEEN ?1 AND ?2 JOIN app_items ai ON ((IFNULL(?7, '') <> '' AND FIND_IN_SET(ai.item_id, cq.query_type) > 0 AND ai.item_id IN (?3) ) OR ((IFNULL(?7, '') = '' AND ai.item_id IN (1, 2, 3)))) WHERE a.is_deleted = 'N' AND ((IFNULL(?4, '') <> '' AND a.name LIKE CONCAT('%', ?4, '%')) OR (IFNULL(?4, '') = '' AND 1 = 1)) AND ((IFNULL(?5, '') <> '' AND a.partner_id IN (?5)) OR (IFNULL(?5, '') = '' AND 1 = 1)) AND ((IFNULL(?6, '') <> '' AND a.account_manager_id IN (?6)) OR (IFNULL(?6, '') = '' AND 1 = 1)) GROUP BY a.account_id HAVING COUNT(cq.case_query_id) > 0 ORDER BY a.name ASC) AS t1 ", nativeQuery = true)
	int getGroupByAccountRecordsCount(Date fromDate, Date toDate, List<Long> psQueryType, String psAccName,
			String psAccPartner, String psAccManager, String lscategoryType);

	// @Query(value = "select cq from case_query cq where cq.query_type in (?1) and
	// cq.is_deleted = ?2",nativeQuery = true)
	// List<CaseQuery> findAllqueriesBasedOnQueryType(List<String> queryType, char
	// isDeleted);
	//
	// @Query(value = "select cq from case_query cq where cq.query_type like
	// ('%',?1,'%') and cq.is_deleted = ?2 and (date(cq.created_date) between ?3 and
	// ?4)",nativeQuery = true)

	@Query(value = "SELECT cq.case_query_id, cq.query_subject, DATE_FORMAT((cq.created_date),'%Y-%m-%d'), cq.case_id FROM case_query cq JOIN (SELECT DISTINCT cq.case_query_id,  SUBSTRING_INDEX(SUBSTRING_INDEX(cq.query_type, ',', numbers.n), ',', -1) AS query_type FROM case_query cq JOIN (SELECT @rownumquery\\:= @rownumquery + 1 AS n FROM accounts t, (SELECT @rownumquery\\:= 0) r LIMIT 0, 500) AS numbers  ON CHAR_LENGTH(cq.query_type) - CHAR_LENGTH(REPLACE(cq.query_type, ',', '')) >= numbers.n-1) AS cq1 ON cq1.case_query_id = cq.case_query_id AND cq1.query_type in (?1) where cq1.query_type in (?1) and cq.is_deleted = ?2 order by cq.created_date DESC", nativeQuery = true)
	List<Object[]> findAllqueriesBasedOnQueryType(List<String> queryType, char isDeleted);

	@Query(value = "SELECT cq.case_query_id, cq.query_subject, DATE_FORMAT((cq.created_date),'%Y-%m-%d'), cq.case_id FROM case_query cq JOIN (SELECT DISTINCT cq.case_query_id,  SUBSTRING_INDEX(SUBSTRING_INDEX(cq.query_type, ',', numbers.n), ',', -1) AS query_type FROM case_query cq JOIN (SELECT @rownumquery\\:= @rownumquery + 1 AS n FROM accounts t, (SELECT @rownumquery\\:= 0) r LIMIT 0, 500) AS numbers  ON CHAR_LENGTH(cq.query_type) - CHAR_LENGTH(REPLACE(cq.query_type, ',', '')) >= numbers.n-1) AS cq1 ON cq1.case_query_id = cq.case_query_id AND cq1.query_type in (?1) where cq1.query_type in (?1) and cq.is_deleted = ?2 and (date(cq.created_date) between ?3 and ?4) order by cq.created_date DESC", nativeQuery = true)
	List<Object[]> findAllqueriesBasedOnQueryTypeAndDate(List<String> queryType, char isDeleted, Date fromCreatedDate,
			Date toCreatedDate);

	@Query("select cq from CaseQuery cq where cq.clientCase.id = ?1 and cq.deleted = ?2 order by cq.createdDate asc")
	List<CaseQuery> findAllByCaseIdForQM(Long caseId, Character isDeleted);

	@Query("select cq from CaseQuery cq LEFT JOIN FETCH cq.clientCase cc LEFT JOIN FETCH cq.client cl LEFT JOIN FETCH cq.account ac LEFT JOIN FETCH cq.assignedTo asign LEFT JOIN FETCH cq.createdBy cb LEFT JOIN FETCH cq.lastModifiedBy mb WHERE cq.id IN ?1 order by cq.id DESC")
	List<CaseQuery> findAllByQueryIds(List<Long> caseId);

	@Query("select cq from CaseQuery cq where cq.client.id = ?1 and cq.deleted = 'N'")
	List<CaseQuery> getByUserId(Long clienId);

	@Query("select cq from CaseQuery cq where cq.account.id = ?1 and cq.deleted = 'N'")
	List<CaseQuery> getByAccountId(Long accountId);

	@Query("select cq from CaseQuery cq where cq.account.id IN (?1) and cq.deleted = 'N'")
	List<CaseQuery> getByAccountIdList(List<Long> accountId);

	@Query(value = "select max(cq.case_query_id) from case_query cq", nativeQuery = true)
	Long findMaxID();

	@Procedure("save_case_query")
	Long save_case_query(@Param("case_query_id") Long case_query_id, @Param("action") String action,
			@Param("created_date") DateTime created_date, @Param("modified_date") DateTime modified_date,
			@Param("optlock_version") Integer optlock_version, @Param("is_deleted") Character is_deleted,
			@Param("is_email_notify") Character is_email_notify, @Param("is_internal") Character is_internal,
			@Param("is_new_query") Character is_new_query, @Param("is_client_viewable") Character is_client_viewable,
			@Param("owner_role_type") String owner_role_type, @Param("query_cc") String query_cc,
			@Param("query_from") String query_from, @Param("query_source") Character query_source,
			@Param("query_to") String query_to, @Param("seq_no") Integer seq_no,
			@Param("query_subject") String query_subject, @Param("status") String status,
			@Param("created_by") Long created_by, @Param("modified_by") Long modified_by,
			@Param("account_id") Long account_id, @Param("assigned_to") Long assigned_to,
			@Param("client_id") Long client_id, @Param("case_id") Long case_id, @Param("query_bcc") String query_bcc,
			
			@Param("query_partner_bean") String query_partner_bean, @Param("is_query_open") Character is_query_open,
			@Param("query_type") String query_type, @Param("query_sub_type") String query_sub_type);

}
