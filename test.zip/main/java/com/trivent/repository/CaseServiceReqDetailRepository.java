package com.trivent.repository;

import java.util.Date;
import java.util.List;

import org.joda.time.DateTime;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;

import com.trivent.models.CaseServiceReqDetail;

/**
 * @FileName : CaseServiceReqDetailRepository.java
 * @ClassName : CaseServiceReqDetailRepository
 * @DateAndTime : Feb 2, 2018 - 6:21:42 PM
 * 
 * @Author : seetha
 * 
 * @Description : Fetch CaseServiceReqDetail Related Native Query Implemented
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
public interface CaseServiceReqDetailRepository extends JpaRepository<CaseServiceReqDetail, Long> {

	@Query("select csr from CaseServiceReqDetail csr where csr.appCase.id in ?1 and csr.deleted= ?2 order by csr.seqNo")
	List<CaseServiceReqDetail> findAllByCaseId(Long caseId, Character isDeleted);

	@Query("select csr from CaseServiceReqDetail csr where ((IFNULL(?1, '') <> '' AND csr.additionalRecId = ?1 ) OR ((IFNULL(?1, '') = '' AND csr.additionalRecId IS NULL))) and csr.caseServiceReqId= ?2 and csr.deleted= 'N'")
	CaseServiceReqDetail findByAdditionalIdAndServiceId(Long addtionalRecId, Long caseServiceId);

	@Query("select csr from CaseServiceReqDetail csr where  csr.caseServiceReqId= ?1 and csr.deleted= 'N'")
	List<CaseServiceReqDetail> findByCaseSerid(Long appCaseSerReqId);

	@Query("select csr from CaseServiceReqDetail csr where csr.additionalRecId = ?1 and csr.deleted=?2")
	List<CaseServiceReqDetail> getDetailByAdditionalRecId(Long addRecId, char isDelete);

	@Query("select csr from CaseServiceReqDetail csr where csr.appCase.id in ?1 and csr.deleted= ?2 order by csr.seqNo")
	List<CaseServiceReqDetail> findAllByCaseId(List<Long> caseId, Character isDeleted);

	@Query("select csr from CaseServiceReqDetail csr where csr.appCase.id = ?1 and csr.deleted= ?2 and csr.additionalRecId is null")
	List<CaseServiceReqDetail> findByCaseId(Long caseId, Character isDeleted);

	@Query("select csr from CaseServiceReqDetail csr where  csr.caseServiceReqId= ?1 and csr.serviceName = ?2")
	List<CaseServiceReqDetail> findByCaseSeridAndSerName(Long appCaseSerReqId, String serviceName);

	@Query("select csr from CaseServiceReqDetail csr where csr.appCase.id = ?1 and csr.deleted= 'Y' and csr.additionalRecId is null")
	List<CaseServiceReqDetail> findByCaseId(Long caseId);
	
	//Call Procedure for insert save_case_report_users
		@Procedure("save_case_service_req_detail")
		Long case_service_req_detail(
							@Param("case_service_req_detail_id") Long case_report_user_id,
							@Param("action") String action,
							@Param("created_date") DateTime created_date,
							@Param("modified_date") DateTime modified_date,
							@Param("created_by") Long created_by,
							@Param("modified_by") Long modified_by,
							@Param("optlock_version") Integer optlock_version,
							@Param("is_deleted") Character is_deleted,
							@Param("notes") String notes,
							@Param("seq_no") Integer seq_no,
							@Param("service_name") String service_name,						
							@Param("estimate_hours") Long estimate_hours,
							@Param("production_hours") Long production_hours,
							@Param("approved_hours") Long approved_hours,
							@Param("discount_hours") Long discount_hours,
							@Param("indirect_hours") Long indirect_hours,
							@Param("invoice_hours") Long invoice_hours,
							@Param("deviation_hours") Long deviation_hours,							
							@Param("quality_score") Float quality_score,
							@Param("service_name_short_code") String service_name_short_code,						
							@Param("approved_date") Date approved_date,
							@Param("deliver_date") Date deliver_date,
							@Param("estimate_date") Date estimate_date,
							@Param("estimateon_hours") Long estimateon_hours,
							@Param("reestimate_hours") Long reestimate_hours,
							@Param("approve_status") Long approve_status,
							@Param("audit_score") Float audit_score,						
							@Param("itemId") Long itemId,
							@Param("additional_rec_id") Long additional_rec_id,
							@Param("case_id") Long case_id,
							@Param("case_service_req_id") Long case_service_req_id
			);


}