package com.trivent.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.trivent.models.CaseQueryResponseFiles;

/**
 * @FileName 	:
 *				CaseQueryResponseFilesRepository.java
 * @ClassName 	:
 * 				CaseQueryResponseFilesRepository
 * @DateAndTime :
 *				Feb 2, 2018 - 6:48:40 PM
 * 
 * @Author 		:
 * 				karthi
 * 
 * @Description : Fetch Case Query Response Files Related Native Query Implemented
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public interface CaseQueryResponseFilesRepository extends JpaRepository<CaseQueryResponseFiles, Long> {

	@Query("select p from CaseQueryResponseFiles p where p.caseQueryResponseId = ?1 ")
	List<CaseQueryResponseFiles> findAllAttachmentByResponseId(Long responseId);

	@Query("select p from CaseQueryResponseFiles p where p.caseQueryResponseId = ?1 ")
	List<CaseQueryResponseFiles> CaseQueryFilesAPI(Long responseId);
}
