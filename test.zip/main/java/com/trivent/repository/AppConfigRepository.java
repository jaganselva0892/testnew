package com.trivent.repository;

import java.util.List;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.trivent.models.AppConfig;

/**
 * @FileName 	:
 *				AppConfigRepository.java
 * @ClassName 	:
 * 				AppConfigRepository
 * @DateAndTime :
 *				Feb 2, 2018 - 5:27:47 PM
 * 
 * @Author 		:
 * 				karthi
 * 
 * @Description : Application Configuration Related Native Query Implemented
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public interface AppConfigRepository extends JpaRepository<AppConfig, Long> {
	
	List<AppConfig> findAll(Specification<AppConfig> specification);

	@Query("FROM AppConfig a WHERE a.deleted = ?1")
	List<AppConfig> getAllAppConfig(char isDeleted);

	@Query("FROM AppConfig a WHERE a.deleted = ?1 AND a.id = ?2")
	AppConfig getAppConfigById(char isDeleted, Long appConfigId);

	@Query("FROM AppConfig a WHERE a.deleted = ?1 AND a.appRefConfig = ?2")
	List<AppConfig> getAllAppConfigByMenu(char isDeleted, AppConfig appConfig);

	@Query("FROM AppConfig a WHERE a.deleted = ?1 AND a.screen = ?2")
	List<AppConfig> getAllAppConfigByScreen(char isDeleted, String screen);

	@Query("FROM AppConfig a WHERE a.deleted = ?1 AND a.name = ?2 and a.appRefConfig = ?3")
	List<AppConfig> getAllAppConfigByScreenandRef(char isDeleted, String name, AppConfig appConfig);

	@Query("FROM AppConfig a WHERE a.deleted = ?1 AND a.screen = ?2 and a.appRefConfig = ?3")
	List<AppConfig> getAllAppConfigByScreennameandRef(char isDeleted, String screen, AppConfig appConfig);

}
