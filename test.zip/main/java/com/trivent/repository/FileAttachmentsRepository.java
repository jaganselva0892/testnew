package com.trivent.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.trivent.models.FileAttachments;

/**
 * @FileName 	:
 *				FileAttachmentsRepository.java
 * @ClassName 	:
 * 				FileAttachmentsRepository
 * @DateAndTime :
 *				Feb 2, 2018 - 6:57:08 PM
 * 
 * @Author 		:
 * 				karthi
 * 
 * @Description : Fetch Attachements Related Native Query Implemented
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public interface FileAttachmentsRepository extends JpaRepository<FileAttachments, Long> {

	@Query("select f from FileAttachments f where f.refId = ?1 ")
	List<FileAttachments> findAllAttachmentByTaskId(Long refId);
}
