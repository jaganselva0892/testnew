package com.trivent.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;


import com.trivent.constants.AppConstants;
import com.trivent.models.Case;
import com.trivent.models.CaseFile;

/**
 * @FileName : CaseFileRepository.java
 * @ClassName : CaseFileRepository
 * @DateAndTime : Feb 2, 2018 - 6:46:44 PM
 * 
 * @Author : karthi
 * 
 * @Description : Fetch Case File Related Native Query Implemented
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
public interface CaseFileRepository extends JpaRepository<CaseFile, Long> {

	List<CaseFile> findAll(Specification<CaseFile> specification);

	Page<CaseFile> findAll(Specification<CaseFile> specification, Pageable constructPageSpecification);

	@Query("select cf from CaseFile cf where cf.deleted = ?1 order by cf.fileType, cf.seqNo")
	List<CaseFile> getCaseFileByDeleteStaus(char isDeleted);

	@Query("select cf from CaseFile cf where cf.deleted = ?1 AND cf.pageCountStatus LIKE ?2 order by cf.fileType, cf.seqNo")
	List<CaseFile> getCaseFileByDeleteStaus(char isDeleted, String pageCountStatus);

	@Query("select cf from CaseFile cf where cf.clientCase.id = ?1 and cf.deleted = ?2 order by cf.fileType, cf.seqNo")
	List<CaseFile> findAllCaseFileByCaseId(Long caseId, char isDeleted);

	@Query("select cf from CaseFile cf where cf.clientCase.id = ?1 and cf.name = ?2 and cf.deleted = ?3 order by cf.seqNo")
	CaseFile getCaseFileNameByName(Long caseId, String fileName, char isDeleted);

	@Query("select cf from CaseFile cf where cf.clientCase.id = ?1 and cf.name = ?2 order by cf.seqNo")
	CaseFile getCaseFileNameByName(Long caseId, String fileName);

	@Query("select cf from CaseFile cf where cf.clientCase.id = ?1 and cf.deleted = ?2 order by cf.id desc")
	List<CaseFile> getLastCaseFileByCaseId(Long caseId, char isDeleted);

	@Query("select coalesce(max(cf.seqNo), '0') from CaseFile cf where cf.clientCase.id = ?1")
	Integer lastSeqNoByCaseId(Long caseId);

	@Query(value = "from CaseFile cf where cf.fileType=3 and cf.name=?1 and cf.sourceCaseFileId=?2 and cf.deleted = ?3")
	List<CaseFile> deleteStampFileCasefileId(String caseFileName, Long fileId, char isDeleted);

	@Modifying
	@Query(value = "UPDATE CaseFile cf SET cf.deleted = ?2 WHERE cf.id=?1")
	int updatedeleteStampFileCasefileId(Long fileId, char isDeleted);

	@Query(value = "from CaseFile cf where cf.fileType IN (4, 5) and cf.name=?1 and cf.clientCase=?2 and cf.deleted = ?3")
	List<CaseFile> deleteMergeFileCasefileId(String caseFileName, Case caseId, char isDeleted);

	@Modifying
	@Query(value = "UPDATE CaseFile cf SET cf.deleted = ?2 WHERE cf.id=?1")
	int updatedeleteMergeFileCasefileId(Long fileId, char isDeleted);

	@Query(value = "from CaseFile cf where cf.fileType=2 and cf.name=?1 and cf.clientCase=?2 and cf.deleted = ?3")
	List<CaseFile> deleteRotateFileId(String caseFileName, Case caseId, char isDeleted);

	@Modifying
	@Query(value = "UPDATE case_files SET replicated_file_location = ?2, replicated_type = ?3, file_page_count  = ?4, page_count_status = ?5, replicated_date = NOW() WHERE case_file_id = ?1", nativeQuery = true)
	int updateReplicationInfoAndPageCount(Long caseFileId, String replicatedFileLocation, String replicationType,
			Integer pageCount, String pageCountStatus);

	@Modifying
	@Query(value = "UPDATE case_files SET replicated_file_location = ?2, replicated_type = ?3, replicated_date = NOW() WHERE case_file_id = ?1", nativeQuery = true)
	int updateReplicationInfoAndPageCount(Long caseFileId, String replicatedFileLocation, String replicationType);

	@Modifying
	@Query(value = "UPDATE case_files SET name = ?2, is_latest = ?3, modified_date = NOW(), modified_by=?4 WHERE case_file_id = ?1", nativeQuery = true)
	int updateNameIsLatest(Long caseFileId, String name, char isLatest, Long modifiedBy);

	@Modifying
	@Query(value = "INSERT INTO case_files (is_deleted, file_content_type, file_location, is_zipped, name, seq_no, created_by, account_id, client_id, case_id, is_latest, replicated_file_location, version, file_size,modified_by,file_extension,root_path,optlock_version,page_count_status, created_date,modified_date, upload_remotely, cur_status, file_from) VALUES (?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11,?12,?13,?14,?15,?16,?17,?18,?19,NOW(),NOW(),?20,'"
			+ AppConstants.TRACE_NEW + "','" + AppConstants.TRACE_FTP + "')", nativeQuery = true)
	int insertNewCaseFileFromRemote(char isDeleted, String fileContentType, String fileLocation, char isZipped,
			String name, int seqNo, Long createdBy, Long accountId, Long clientId, Long caseId, char isLatest,
			String replicatedFileLocation, int version, Long fileSize, Long modifiedBy, String fileExtension,
			String caseFileRootPath, int optLockVersion, String fileStatus, char uploadRemotely);

	@Query("select cf from CaseFile cf where cf.clientCase.id = ?1 and cf.deleted = ?2 order by cf.createdDate desc")
	List<CaseFile> getLastCaseFileByCaseIdDecByDate(Long caseId, char isDeleted);

	@Modifying
	@Query(value = "UPDATE case_files SET page_count_status = ?2, modified_date = NOW(), modified_by=?3 WHERE case_file_id = ?1", nativeQuery = true)
	int updateFilePageCountStatus(Long caseFileId, String pageCountStatus, Long modifiedBy);

	// Hard Delete a case Start

	@Modifying
	@Query(value = "delete from case_files where case_id=?1", nativeQuery = true)
	void deleteFile(Long caseId);

	// Hard Delete a case End

	// Stamping
	@Modifying
	@Query(value = "INSERT INTO case_files (is_deleted, file_content_type, file_location, is_zipped, name, seq_no, created_by, account_id, client_id, case_id, is_latest, replicated_file_location, version, file_size,file_page_count,modified_by,file_extension,root_path,optlock_version,page_count_status, created_date,modified_date, upload_remotely,file_type,source_case_file_id, cur_status, file_from) VALUES (?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11,?12,?13,?14,?15,?16,?17,?18,?19,?20,NOW(),NOW(),?21,?22,?23,'"
			+ AppConstants.TRACE_NEW + "','" + AppConstants.TRACE_FTP + "')", nativeQuery = true)
	void insertNewCaseFileStamp(char isDeleted, String fileContentType, String fileLocation, char isZipped, String name,
			int seqNo, Long createdBy, Long accountId, Long clientId, Long caseId, char isLatest,
			String replicatedFileLocation, int version, Long fileSize, Long pageCount, Long modifiedBy,
			String fileExtension, String caseFileRootPath, int optLockVersion, String fileStatus, char uploadRemotely,
			int fileType, Long source_case_id);

	@Modifying
	@Query(value = "delete from case_files where file_type=3 and name=?1", nativeQuery = true)
	void deleteStampFile(String caseFileName);

	// Rotate
	@Modifying
	@Query(value = "INSERT INTO case_files (is_deleted, file_content_type, file_location, is_zipped, name, seq_no, created_by, account_id, client_id, case_id, is_latest, replicated_file_location, version, file_size,file_page_count,modified_by,file_extension,root_path,optlock_version,page_count_status, created_date,modified_date, upload_remotely,file_type,source_case_file_id, cur_status, file_from) VALUES (?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11,?12,?13,?14,?15,?16,?17,?18,?19,?20,NOW(),NOW(),?21,?22,?23,'"
			+ AppConstants.TRACE_NEW + "','" + AppConstants.TRACE_FTP + "')", nativeQuery = true)
	void insertNewCaseFileRotate(char isDeleted, String fileContentType, String fileLocation, char isZipped,
			String name, int seqNo, Long createdBy, Long accountId, Long clientId, Long caseId, char isLatest,
			String replicatedFileLocation, int version, Long fileSize, Long pageCount, Long modifiedBy,
			String fileExtension, String caseFileRootPath, int optLockVersion, String fileStatus, char uploadRemotely,
			int fileType, Long source_case_id);

	@Modifying
	@Query(value = "delete from case_files where file_type=2 and name=?1", nativeQuery = true)
	void deleteRotateFile(String caseFileName);

	// Merging

	@Modifying
	@Query(value = "INSERT INTO case_files (is_deleted, file_content_type, file_location, is_zipped, name, seq_no, created_by, account_id, client_id, case_id, is_latest, replicated_file_location, version, file_size,file_page_count,modified_by,file_extension,root_path,optlock_version,page_count_status, created_date,modified_date, upload_remotely,file_type,source_case_file_id, cur_status, file_from) VALUES (?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11,?12,?13,?14,?15,?16,?17,?18,?19,?20,NOW(),NOW(),?21,?22,?23,'"
			+ AppConstants.TRACE_NEW + "','" + AppConstants.TRACE_FTP + "')", nativeQuery = true)
	void insertNewCaseFileMerge(char isDeleted, String fileContentType, String fileLocation, char isZipped, String name,
			int seqNo, Long createdBy, Long accountId, Long clientId, Long caseId, char isLatest,
			String replicatedFileLocation, int version, Long fileSize, Long pageCount, Long modifiedBy,
			String fileExtension, String caseFileRootPath, int optLockVersion, String fileStatus, char uploadRemotely,
			int fileType, Long source_case_id);

	@Modifying
	@Query(value = "delete from case_files where file_type in (4,5) and case_id=?1", nativeQuery = true)
	void deleteMergeFile(Long caseId);

	@Modifying
	@Query(value = "INSERT INTO case_files (is_deleted, file_content_type, file_location, is_zipped, name, seq_no, created_by, account_id, client_id, case_id, is_latest, replicated_file_location, version, file_size,file_page_count,modified_by,file_extension,root_path,optlock_version,page_count_status, created_date,modified_date, upload_remotely,file_type,source_case_file_id, cur_status, file_from) VALUES (?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11,?12,?13,?14,?15,?16,?17,?18,?19,?20,NOW(),NOW(),?21,?22,?23,'"
			+ AppConstants.TRACE_NEW + "','" + AppConstants.TRACE_FTP + "')", nativeQuery = true)
	void insertMergedStamp(char isDeleted, String fileContentType, String fileLocation, char isZipped, String name,
			int seqNo, Long createdBy, Long accountId, Long clientId, Long caseId, char isLatest,
			String replicatedFileLocation, int version, Long fileSize, Long pageCount, Long modifiedBy,
			String fileExtension, String caseFileRootPath, int optLockVersion, String fileStatus, char uploadRemotely,
			int fileType, Long source_case_id);

	@Modifying
	@Query(value = "delete from case_files where file_type = 4 and case_id=?1", nativeQuery = true)
	void deleteMergedStampFile(Long caseId);

	@Query("select cf from CaseFile cf where cf.clientCase.id = ?1 and cf.id = ?2 and cf.deleted = ?3")
	CaseFile getCaseFileDetail(Long caseId, Long caseFileId, char isDeleted);

	@Query("select cf from CaseFile cf where cf.clientCase.id = ?1 and cf.deleted = 'N' and cf.fileType = 1 order by cf.seqNo")
	List<CaseFile> CaseFilesAPI(Long caseId);

	@Query("select cf from CaseFile cf where cf.clientCase.id = ?1 and cf.deleted = 'N' order by cf.seqNo")
	List<CaseFile> CsCaseFilesAPI(Long caseId);

	@Modifying
	@Query(value = "UPDATE case_files SET is_deleted = ?2 WHERE case_file_id = ?1", nativeQuery = true)
	int updateDelStatus(Long caseFileId, Character delStatus);

	@Query("select cf from CaseFile cf where cf.clientCase.id = ?2 and cf.deleted = ?1 and cf.id < ?3 order by cf.createdDate desc")
	List<CaseFile> getLastCaseFileByCaseIdFileIdDecByDate(char isDeleted, Long caseId, Long fileId);

	@Query("select cf from CaseFile cf where cf.deleted = ?1 order by cf.id desc")
	List<CaseFile> getCaseFileByDeleteStausOrderByID(char isDeleted);

	@Query("select cf from CaseFile cf where cf.deleted = ?1 and (date(cf.createdDate) between date(?2) and date(?3)) order by cf.id desc")
	List<CaseFile> getCaseFileByDeleteStausOrderByID(char isDeleted, Date fromDate, Date toDate);

	@Modifying
	@Query(value = "UPDATE CaseFile cf SET cf.archived = ?2 WHERE cf.id=?1")
	int updateArchivedStatusCaseFileId(Long fileId, char isArchived);

	@Query("select cf from CaseFile cf where cf.clientCase.id = ?1 order by cf.fileType, cf.seqNo")
	List<CaseFile> findAllCaseFileByCaseId(Long caseId);

	// @Modifying
	// @Query(value = "INSERT INTO case_files (is_deleted, created_by, modified_by,
	// created_date, modified_date, optlock_version, file_content_type,
	// file_location, is_zipped, name, seq_no, account_id, client_id, case_id,
	// is_latest, replicated_file_location, version, file_size,
	// file_extension,root_path, page_count_status, upload_remotely,
	// replicated_type, replicated_date, cur_status, file_from) VALUES
	// (?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11,?12,?13,?14,?15,?16,?17,?18,?19,?20,?21,?22,
	// '"
	// + AppConstants.TRACE_NEW + "', '" + AppConstants.TRACE_FTP + "')",
	// nativeQuery = true)
	// int insertNewCaseFileFromRemote(char isDeleted, Long createdBy, Long
	// lastModifiedBy, Date createdDate,
	// Date lastModifiedDate, int optLockVersion, String fileContentType, String
	// fileLocation, char isZipped,
	// String name, int seqNo, Long accountId, Long clientId, Long caseId, char
	// isLatest,
	// String replicatedFileLocation, int version, Long fileSize, String
	// fileExtension, String caseFileRootPath,
	// String fileStatus, char uploadRemotely, String replicatedType, Date
	// replicatedDate);

	@Modifying
	@Query(value = "INSERT INTO case_files (is_deleted, created_by, modified_by, created_date, modified_date, optlock_version, file_content_type, file_location, is_zipped, name, seq_no, account_id, client_id, case_id, is_latest, replicated_file_location, version, file_size, file_extension,root_path, page_count_status, upload_remotely, replicated_type, replicated_date) VALUES (?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11,?12,?13,?14,?15,?16,?17,?18,?19,?20,?21,?22,?23,?24)", nativeQuery = true)
	int insertNewCaseFileFromRemote(char isDeleted, Long createdBy, Long lastModifiedBy, Date createdDate,
			Date lastModifiedDate, int optLockVersion, String fileContentType, String fileLocation, char isZipped,
			String name, int seqNo, Long accountId, Long clientId, Long caseId, char isLatest,
			String replicatedFileLocation, int version, Long fileSize, String fileExtension, String caseFileRootPath,
			String fileStatus, char uploadRemotely, String replicatedType, Date replicatedDate);

	@Modifying
	@Query(value = "UPDATE case_files SET cur_status = ?2 WHERE case_file_id = ?1 AND cur_status NOT LIKE '"
			+ AppConstants.TRACE_FAILED + "'", nativeQuery = true)
	int updatecurStatus(Long caseFileId, String curStatus);

	@Modifying
	@Query(value = "UPDATE case_files SET cus_msg = CONCAT(ifnull(cus_msg, ''), ifnull(?2, '')) WHERE case_file_id = ?1", nativeQuery = true)
	int updatecurStatusMsg(Long caseFileId, String curMsg);

	@Modifying
	@Query(value = "UPDATE case_files SET cur_status = '" + AppConstants.TRACE_NEW
			+ "' WHERE case_file_id = ?1", nativeQuery = true)
	int updatecurStatusNew(Long caseFileId);

	@Modifying
	@Query(value = "UPDATE CaseFile cf SET cf.backup = ?2 WHERE cf.id=?1")
	int updateBackupStatusFileId(Long fileId, char isBackup);

	@Modifying
	@Query(value = "UPDATE CaseFile cf SET cf.removeFile = ?2 WHERE cf.id=?1")
	int updateRemoveStatusFileId(Long fileId, char isBackup);

	@Query("FROM CaseFile cf WHERE cf.deleted = ?1 AND cf.curStatus NOT LIKE ?2 AND date(cf.createdDate) > date(?3) AND IFNULL(cf.curMsg, '') <> '' AND (cf.curMsg NOT LIKE  '%File Size is not Match%' AND cf.curMsg NOT LIKE '%cannot find%' AND cf.curMsg NOT LIKE  '%No such file%' AND cf.curMsg NOT LIKE  '%No such directory%')")
	List<CaseFile> getFilesByCurStatus(char isDeleted, String psCusrStatus, Date createdDate);

	@Query("select cf from CaseFile cf where cf.clientCase.id = ?1 and cf.id = ?2 and cf.deleted = 'N'")
	CaseFile getCaseFileDetail(Long caseId, Long caseFileId);

	@Modifying
	@Query(value = "UPDATE case_files SET additional_rec_id = ?1 WHERE case_file_id in ?2", nativeQuery = true)
	int updateAdditionalRecID(Long additionalRecId, List<Long> casefileId);

	@Query("select cf from CaseFile cf where cf.additionalRecId = ?1 and cf.deleted = 'N'")
	List<CaseFile> findByAdditionalRecId(Long additionalRecId);

	@Query("select c from CaseFile c where  c.deleted = 'N' and c.id in ?1 ")
	List<CaseFile> getCaseFileByItsId(List<Long> caseId);

	@Modifying
	@Query(value = "UPDATE case_files SET case_id = ?2 where case_file_id = ?1", nativeQuery = true)
	int updateSubCaseIdAsCaseId(Long id, Case appCase);

}
