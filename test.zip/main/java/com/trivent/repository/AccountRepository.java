package com.trivent.repository;

import java.util.List;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.trivent.models.Account;
import com.trivent.models.Partner;

/**
 * @FileName 	:
 *				AccountRepository.java
 * @ClassName 	:
 * 				AccountRepository
 * @DateAndTime :
 *				Feb 2, 2018 - 4:39:57 PM
 * 
 * @Author 		:
 * 				karthi
 * 
 * @Description : Account Related Native Query is Implemented this Interface
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 
 
 * 
 */

public interface AccountRepository extends  JpaRepository<Account, Long>{

	@Query("from Account a WHERE a.partner = ?1 and a.deleted = ?2 order by a.name")
	List<Account> findAccountByPartner(Partner partner, char isDeleted);
	
	@Query("select a from Account a JOIN FETCH a.partner where a.deleted = ?1 order by a.name")
	List<Account> listAccounts(char isDeleted);
	
	@Query("select a from Account a where a.accountManager.id = ?1 and a.deleted = ?2")
	List<Account> findAccountsByManager(Long accountManagerId, char isDeleted);
	
	@Query("select a from Account a where a.id = ?1 ")
	Account findById(Long accId);
	

	@Query("from Account a WHERE a.partner.id = ?1 and a.deleted = ?2")
	List<Account> findAccountByPartnerId(Long partner, char isDeleted);

	List<Account> findAll(Specification<Account> specification);

	@Query("select a from Account a where a.partner= ?1 and  a.deleted = ?2")
	List<Account> getAllAccount(Partner strPartnerCode, char isDeleted); 
}
