package com.trivent.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.trivent.models.CaseFilesChangeHistory;

/**
 * @FileName : CaseFilesChangeHistoryRepository.java
 * @ClassName : CaseFilesChangeHistoryRepository
 * @DateAndTime : Feb 2, 2018 - 6:47:07 PM
 * 
 * @Author : karthi
 * 
 * @Description : Fetch Case Files Change History Related Native Query
 *              Implemented
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
public interface CaseFilesChangeHistoryRepository extends JpaRepository<CaseFilesChangeHistory, Long> {

	@Query("select c from CaseFilesChangeHistory c where c.caseId = ?1 and c.deleted = ?2 and c.caseFileId <>'' order by c.createdDate desc")
	List<CaseFilesChangeHistory> listCaseAdditionalRecords(Long caseId, char isDeleted);

	@Query("select c from CaseFilesChangeHistory c where c.caseId = ?1 and c.deleted = ?2")
	List<CaseFilesChangeHistory> findByCaseId(Long caseId, char isDeleted);

	@Query("select count(*) from CaseFilesChangeHistory c where c.caseId = ?1 and c.deleted = ?2")
	int findCountByCaseId(Long caseId, char isDeleted);

	@Query("select c from CaseFilesChangeHistory c where c.caseId = ?2 and c.subCaseId = ?1  and c.deleted = 'N'")
	List<CaseFilesChangeHistory> findByCaseIdAdnSubCaseId(Long subCase, Long caseId);
	
	@Query("select c from CaseFilesChangeHistory c where c.subCaseId = ?1 and c.deleted = ?2")
	List<CaseFilesChangeHistory> findBySubCaseId(Long subCased, char isDeleted);
	
	@Query("select c from CaseFilesChangeHistory c where c.subCaseId = ?1 and c.deleted = ?2 and c.caseFileId <>'' order by c.createdDate desc")
	List<CaseFilesChangeHistory> listSubCaseAdditionalRecords(Long caseId, char isDeleted);

}
