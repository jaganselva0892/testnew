package com.trivent.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.trivent.models.AppList;

/**
 * @FileName 	:
 *				AppListRepository.java
 * @ClassName 	:
 * 				AppListRepository
 * @DateAndTime :
 *				Feb 2, 2018 - 6:20:27 PM
 * 
 * @Author 		:
 * 				karthi
 * 
 * @Description : Fetch Application List Native Query implemented
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public interface AppListRepository extends JpaRepository<AppList, Long> {

  AppList findByName(String name);

  @Query("select a from AppList a where a.deleted = ?1 order by a.name")
  List<AppList> listAppLists(char isDeleted);

  @Query("select a from AppList a where a.name = ?1")
  AppList getListByName(String name);
}
