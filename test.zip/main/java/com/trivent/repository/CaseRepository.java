package com.trivent.repository;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.joda.time.DateTime;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;

import com.trivent.models.Account;
import com.trivent.models.Case;
import com.trivent.models.User;

/**
 * @FileName : CaseRepository.java
 * @ClassName : CaseRepository
 * @DateAndTime : Feb 2, 2018 - 6:49:56 PM
 * 
 * @Author : karthi
 * 
 * @Description : Fetch Case Related Native Query Implemented
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */

public interface CaseRepository extends JpaRepository<Case, Long> {

	@Query("select c from Case c where c.deleted = ?1 order by c.createdDate desc")
	List<Case> listCases(char isDeleted);

	@Query("select c from Case c where c.deleted = ?1 and c.createdBy.id = ?2 and c.parentCase IS NULL order by c.createdDate desc")
	List<Case> findCasesByCreatedById(char isDeleted, Long userId);

	@Query("select c from Case c where c.deleted = ?1 and c.account = ?2 and c.parentCase IS NULL order by c.createdDate desc")
	List<Case> findCasesByCreatedByAccount(char isDeleted, Account account);

	Page<Case> findAll(Specification<Case> specification, Pageable constructPageSpecification);

	List<Case> findAll(Specification<Case> specification);

	@Query("select c from Case c where c.name = ?1 and c.account.id = ?2 and c.client.id = ?3 and c.deleted = 'N'")
	Case findByCaseName(String name, Long accountId, Long clientId);

	@Modifying
	@Query(value = "UPDATE cases SET case_total_page_count = ?2 WHERE case_id = ?1", nativeQuery = true)
	int updateFilePageCount(Long caseId, Integer pageCount);

	@Query(value = "SELECT  IFNULL(c.total_approved_hours/60,0), IFNULL(u.login_id ,' ') a, IFNULL(c.bates_reference,' '), IFNULL(c.case_code,' '), IFNULL(c.client_priority,' '), IFNULL(c.cs_priority,' '), IFNULL(c.cs_status,' '), IFNULL(c.depsum_pages,0), IFNULL(c.total_estimate_hours/60 ,0) x, IFNULL(c.estimate_request,' '), c.expedited_delivery_date, IFNULL(c.expedited_request,' '), c.file_delivery_date, c.file_migration_date, c.file_received_date, IFNULL(c.case_id,0), IFNULL(c.name ,' ') g, IFNULL(c.case_total_page_count,0), c.parent_case_id, IFNULL(c.pdf_reference,' '), c.production_delivery_date, c.production_end_date, c.production_start_date, IFNULL(c.total_production_hours/60,' '), IFNULL(c.service_requested_shortcode,' '), IFNULL(c.case_sub_type,' '), IFNULL(c.type,' '), IFNULL(c.is_demand,' '), IFNULL(LEFT(c.case_overview,32000),' '), IFNULL(LEFT(c.client_notes,32000),' '), IFNULL(LEFT(c.cs_notes,32000),' '), IFNULL(LEFT(c.cs_description,32000),' '), IFNULL(LEFT(c.expedited_request_reason,32000),' '), IFNULL(csr.approved_hours/60,0), IFNULL(csr.estimate_hours/60 ,0) z, IFNULL(csr.case_service_req_id,0), IFNULL(csr.production_hours/60,0), IFNULL(csr.quality_score/1,0), IFNULL(csr.service_name,0), IFNULL(u1.login_id ,0) b, IFNULL(ct.estimate_hours/60 ,0) y, IFNULL(ct.name ,' ') h, IFNULL(ct.start_date,' '), IFNULL(ct.status,' '), IFNULL(ct.total_hours/60,0) FROM  cases c LEFT OUTER JOIN case_query cq ON c.case_id = cq.case_id LEFT OUTER JOIN case_service_req csr ON c.case_id = csr.case_id LEFT OUTER JOIN case_tasks ct ON ct.case_id=c.case_id LEFT OUTER JOIN users u on u.user_id = c.assigned_to LEFT OUTER JOIN users u1 on u1.user_id = cq.assigned_to where c.is_deleted = 'N'", nativeQuery = true)
	List<Object[]> findJoinResultOfCaseCaseTaskCaseQueryAndCaseSerReqForProd();

	@Query(value = "SELECT IFNULL(at1.name, ' ') ac1, IFNULL(c.total_approved_hours/60, 0), IFNULL(u.login_id, ' ') at1, IFNULL(c.balance_due, 0), IFNULL(c.bates_reference, ' '), IFNULL(c.case_code, 0), IFNULL(u4.login_id, ' ') ci1, IFNULL(c.client_priority, ' '), IFNULL(c.client_status, ' '), IFNULL(c.is_customer_downloaded, ' '), IFNULL(c.case_contact_name, ' '), IFNULL(u3.login_id, ' ') cb1, c.created_date cd1, IFNULL(c.cs_priority, ' '), IFNULL(c.cs_status, ' '), IFNULL(c.is_deleted, ' ') is1, IFNULL(c.depsum_pages, 0), IFNULL(c.total_deviation_hours/60, 0), IFNULL(c.total_discount_hours/60, 0), IFNULL(c.download_count, 0), c.downloaded_date_time, IFNULL(c.case_contact_email_id, ' '), IFNULL(c.total_estimate_hours/60, 0) eh1, IFNULL(c.estimate_request, ' '), c.expedited_delivery_date, IFNULL(c.expedited_request, ' '), c.file_delivery_date, c.file_migration_date, c.file_received_date, IFNULL(c.case_id, 0) cse1, IFNULL(c.total_indirect_hours/60, 0), IFNULL(c.total_invoice_hours/60, 0), IFNULL(c.is_file_downloaded, ' '), IFNULL(c.is_invoiced, ' '), IFNULL(c.job_id, 0), IFNULL(u5.login_id, ' ') mb1, c.modified_date md1, IFNULL(c.name, ' ') nm1, IFNULL(c.optlock_version, 0) op1, IFNULL(c.case_total_page_count, 0), IFNULL(c.parent_case_id, 0), IFNULL(c.pdf_reference, ' '), c.production_delivery_date, c.production_end_date, c.production_start_date, IFNULL(c.total_production_hours/60, 0), IFNULL(c.service_requested_shortcode, ' '), IFNULL(c.case_sub_type, ' '), IFNULL(c.type, ' '), IFNULL(c.is_demand, ' '), IFNULL(LEFT(c.case_overview,32000), ' '), IFNULL(LEFT(c.client_notes,32000), ' ') nt1, IFNULL(LEFT(c.cs_notes,32000), ' ') nt2, IFNULL(LEFT(c.delay_reasons,32000), ' '), IFNULL(LEFT(c.cs_description,32000), ' ') dsp1, IFNULL(LEFT(c.expedited_request_reason,32000), ' '), IFNULL(u6.login_id, ' ') cb2, csr.created_date cd2, IFNULL(csr.is_deleted, ' ') is2, IFNULL(csr.case_service_req_id, 0), IFNULL(u7.login_id, ' ') mb2, csr.modified_date md2, csr.optlock_version op2, IFNULL(csr.approved_hours/60, 0), IFNULL(csr.deviation_hours/60, 0), IFNULL(csr.discount_hours/60, 0), IFNULL(csr.estimate_hours/60, 0) eh2, IFNULL(csr.indirect_hours/60, 0), IFNULL(csr.invoice_hours/60, 0), IFNULL(csr.production_hours/60, 0), IFNULL(csr.quality_score/1, 0), IFNULL(csr.seq_no, ' ') sn1, IFNULL(csr.service_name, ' '), IFNULL(csr.service_name_short_code, ' '), IFNULL(LEFT(csr.notes,32000), ' ') nt3, IFNULL(u.login_id, ' ') at2, IFNULL(u8.login_id, ' ') cb3, cq.created_date cd3, IFNULL(cq.is_deleted, ' ') is3, IFNULL(cq.case_query_id, ' '), IFNULL(cq.is_email_notify, ' '), IFNULL(cq.is_internal, ' '), IFNULL(cq.is_new_query, ' '), IFNULL(cq.is_client_viewable, ' '), IFNULL(u9.login_id, ' ') mb3, cq.modified_date md3, IFNULL(cq.optlock_version, ' ') op3, IFNULL(cq.owner_role_type, ' '), IFNULL(cq.query_cc, ' '), IFNULL(cq.query_from, ' '), IFNULL(cq.query_source, ' '), IFNULL(cq.query_subject, ' '), IFNULL(cq.query_to, ' '), IFNULL(cq.seq_no, ' ') sn2, IFNULL(cq.status, ' ') st1, IFNULL(u2.login_id, ' ') at3, IFNULL(cts.casetask2service_id, ' '), ct.completed_date, IFNULL(u10.login_id, ' ') cb4, ct.created_date cd4, IFNULL(ct.is_deleted, ' ') is4, IFNULL(ct.estimate_hours/60, 0) eh3, IFNULL(ct.case_task_id, ' '), IFNULL(u11.login_id, ' ') mb4, ct.modified_date md4, IFNULL(ct.name, ' ') nm2, IFNULL(ct.optlock_version, ' ') op4, IFNULL(ct.seq_no, ' ') sn3, ct.start_date, IFNULL(ct.status, ' ') st2, IFNULL(ct.total_hours/60, 0), IFNULL(LEFT(ct.description,32000), ' ') dsp2, IFNULL(LEFT(ct.notes,32000), ' ') nt4  FROM cases c LEFT OUTER JOIN case_query cq ON c.case_id = cq.case_id LEFT OUTER JOIN case_service_req csr ON c.case_id = csr.case_id LEFT OUTER JOIN case_tasks ct ON ct.case_id=c.case_id LEFT OUTER JOIN case_task_2_services cts ON cts.case_id=c.case_id LEFT OUTER JOIN users u on u.user_id = c.assigned_to LEFT OUTER JOIN users u1 on u1.user_id = cq.assigned_to LEFT OUTER JOIN users u2 ON u2.user_id = ct.assigned_to LEFT OUTER JOIN users u3 on u3.user_id = c.created_by LEFT OUTER JOIN accounts at1 ON at1.account_id=c.account_id LEFT OUTER JOIN users u4 ON u4.user_id=c.client_id LEFT OUTER JOIN users u5 ON u5.user_id=c.modified_by LEFT OUTER JOIN users u6 ON u6.user_id=csr.created_by LEFT OUTER JOIN users u7 ON u7.user_id=csr.modified_by LEFT OUTER JOIN users u8 ON u8.user_id=cq.created_by LEFT OUTER JOIN users u9 ON u9.user_id=cq.modified_by LEFT OUTER JOIN users u10 ON u10.user_id=ct.created_by LEFT OUTER JOIN users u11 ON u11.user_id=ct.modified_by where c.is_deleted = 'N' ", nativeQuery = true)
	List<Object[]> findJoinResultOfCaseCaseTaskCaseQueryAndCaseSerReqForUSCustomerSupportTeam();

	@Query(value = "SELECT at1.name a,c.total_approved_hours/60,c.balance_due,c.case_code,u1.login_id d,c.depsum_pages,c.total_discount_hours/60,c.total_estimate_hours/60,c.expedited_request,c.file_delivery_date,c.file_received_date,c.total_indirect_hours/60,c.total_invoice_hours/60,c.name,c.case_total_page_count,c.production_delivery_date,c.total_production_hours/60,c.type,csr.approved_hours/60,csr.deviation_hours/60,csr.discount_hours/60,csr.estimate_hours/60,csr.indirect_hours/60,csr.invoice_hours/60,csr.production_hours/60,csr.service_name FROM cases c LEFT OUTER JOIN case_query cq ON c.case_id = cq.case_id LEFT OUTER JOIN case_service_req csr ON c.case_id = csr.case_id LEFT OUTER JOIN accounts at1 ON at1.account_id=c.account_id LEFT OUTER JOIN users u1 ON u1.user_id=c.client_id where c.is_deleted = 'N'", nativeQuery = true)
	List<Object[]> findJoinResultOfCaseCaseTaskCaseQueryAndCaseSerReqForFinance();

	@Query(value = "SELECT a1.name nm1,u1.login_id lg1,cts.casetask2service_id,u2.login_id lg2,c.name nm3,ct.completed_date,u3.login_id lg3,ct.created_date,ct.is_deleted,ct.estimate_hours/60,ct.case_task_id,u4.login_id lg4,ct.modified_date,ct.name nm2,ct.optlock_version,ct.seq_no,ct.start_date,ct.status,ct.total_hours/60,LEFT(ct.description,32000),LEFT(ct.notes,32000) FROM case_tasks ct LEFT OUTER JOIN users u1 ON u1.user_id=ct.assigned_to LEFT OUTER JOIN users u2 ON ct.client_id=u2.user_id LEFT OUTER JOIN users u3 ON ct.created_by=u3.user_id LEFT OUTER JOIN users u4 ON ct.modified_by=u4.user_id LEFT OUTER JOIN accounts a1 ON a1.account_id=ct.account_id LEFT OUTER JOIN cases c ON c.case_id=ct.case_id LEFT OUTER JOIN case_task_2_services cts ON cts.case_task_id=ct.case_task_id where ct.is_deleted = 'N'", nativeQuery = true)
	List<Object[]> findJoinResultOfCaseTask();

	@Query(value = "SELECT  a1.name nm1,u1.login_id lg1,u2.login_id lg2,c.name nm2,u3.login_id lg3,cq.created_date,cq.is_deleted,cq.case_query_id,cq.is_email_notify,cq.is_internal,cq.is_new_query,cq.is_client_viewable,u4.login_id lg4,cq.modified_date,cq.optlock_version,cq.owner_role_type,cq.query_cc,cq.query_from,cq.query_source,cq.query_subject,cq.query_to,cq.seq_no,cq.status FROM case_query cq LEFT OUTER JOIN users u1 ON u1.user_id=cq.assigned_to LEFT OUTER JOIN users u2 ON cq.client_id=u2.user_id LEFT OUTER JOIN users u3 ON cq.created_by=u3.user_id LEFT OUTER JOIN users u4 ON cq.modified_by=u4.user_id LEFT OUTER JOIN accounts a1 ON a1.account_id=cq.account_id LEFT OUTER JOIN cases c ON c.case_id=cq.case_id where cq.is_deleted = 'N'", nativeQuery = true)
	List<Object[]> findJoinResultOfCaseQuery();

	@Query("select c.name as csname,c.id as csid,c.caseCode as casecode from Case c where c.deleted = ?1 and c.account.id = ?2  and c.parentCase is null and c.name like CONCAT('%',?3,'%') order by c.createdDate desc")
	List<Object[]> listAllCasesNameID(char isDeleted, Long accountId, String searchTerm);

	@Query("select c.name as csname,c.id as csid,c.caseCode as casecode from Case c where c.deleted = ?1 and c.account.id = ?2  order by c.createdDate desc")
	List<Object[]> listAllCasesNameIDCode(char isDeleted, Long accountId);

	@Query("select c.name as csname,c.id as csid,c.caseCode as casecode from Case c where c.deleted = ?1 order by c.createdDate desc")
	List<Case> listAllCasesNameID(char isDeleted);

	@Query("select c from Case c where c.clientStatus in('Partial Delivery','File Delivered') and c.deleted= ?1 and c.client.id= ?2 and c.parentCase IS NULL order by c.createdDate desc")
	List<Case> findCasesbyClientStatusDelivery(char isDeleted, Long userId);

	@Query("select c from Case c where c.clientStatus in('Partial Delivery','File Delivered') and c.deleted= ?1 and c.account= ?2 and c.parentCase IS NULL order by c.createdDate desc")
	List<Case> findCasesbyClientStatusDeliveryAccount(char isDeleted, Account account);

	@Query("select c from Case c where c.clientStatus in('Closed') and c.deleted= ?1 and c.client.id= ?2 and c.parentCase IS NULL order by c.createdDate desc")
	List<Case> findCasesbyClientStatusClosed(char isDeleted, Long userId);

	@Query("select c from Case c where c.clientStatus in('Closed') and c.deleted= ?1 and c.account = ?2 and c.parentCase IS NULL order by c.createdDate desc")
	List<Case> findCasesbyClientStatusClosedAccount(char isDeleted, Account account);

	@Query("select c from Case c where c.clientStatus in('Partial Delivery','File Delivered') and c.deleted= ?1 order by c.createdDate desc")
	List<Case> findClientStatusDelivery(char isDeleted);

	@Query("select c from Case c where c.deleted= ?1 and c.client.id= ?2  order by c.createdDate desc")
	List<Case> listAllCasesbyClientId(char isDeleted, Long userId);

	@Query("select count(*), sum(c.pageCount) from Case c where date(c.createdDate)=date(CURRENT_DATE()) and c.deleted=?1 and c.type=?2 group by c.type having count(*) > 0")
	Object[] listTodayReceivedCases(char isDeleted, String type);

	@Query("select count(*),sum(c.pageCount) from Case c where (date(c.createdDate) BETWEEN ?1 and ?2) and c.type=?3 and c.deleted= ?4")
	Object[] listReceivedCasesPagesbyDate(Date fromcreatedDate, Date tocreatedDate, String type, char isDeleted);

	@Query(" select count(*),sum(c.pageCount) from Case c where date(c.fileDeliveryDate) = date(CURRENT_DATE()) and (c.fileDeliveryDate) >= date(CURRENT_DATE()) and c.deleted=?1 and c.type=?2 group by c.type having count(*) > 0")
	Object[] listTodayDeliverededCases(char isDeleted, String type);

	@Query("select count(*),sum(c.pageCount) from Case c where (date(c.fileDeliveryDate) BETWEEN ?1 and ?2) and c.type=?3 and c.deleted= ?4 and c.csStatus='File Delivery' group by c.csStatus, c.type  having count(*) > 0")
	Object[] listDeliveredCasePagessbyDate(Date fromcreatedDate, Date tocreatedDate, String type, char isDeleted);

	@Query("select count(*) from Case c where str_to_date(c.delayReasons,'%m/%d/%Y')<date(CURRENT_DATE()) and c.delayReasons is not null and not c.delayReasons='' and c.deleted=?1 and c.type=?2 group by c.type")
	Object[] listPendingCases(char isDeleted, String type);

	@Query("select count(*) from Case c where (date(c.cf_1_Date)<date(CURRENT_DATE()) or date(c.expeditedDeliveryDate)<date(CURRENT_DATE())) and c.deleted=?1 and c.type=?2")
	Object[] listOverDueCases(char isDeleted, String type);

	@Query("select count(*) from Case c where c.deleted=?1 and type=?2 and (((date(c.cf_1_Date) between ?3 and ?4) AND (date(cf_1_Date)<date(CURRENT_DATE())) AND ((date(c.fileDeliveryDate) > date(c.cf_1_Date)) OR c.fileDeliveryDate IS NULL )) or ((date(c.expeditedDeliveryDate) between ?3 and ?4) AND (date(c.expeditedDeliveryDate)<date(CURRENT_DATE())) AND ((date(c.fileDeliveryDate) > date(c.expeditedDeliveryDate)) OR c.fileDeliveryDate IS NULL)))")
	Object[] listOverDueCasesbyDate(char isDeleted, String type, Date fromcreatedDate, Date tocreatedDate);

	@Query("select count(*) from Case c where date(c.lastModifiedDate)=date(CURRENT_DATE()) and c.type='Personal Injury' and c.csStatus=?1 and c.deleted=?2")
	Object[] listDailyAbstractCasespi(String csStatus, char isDeleted);

	@Query("select count(*) from Case c where (date(c.lastModifiedDate) between ?1 and ?2) and c.type='Personal Injury' and c.csStatus=?3 and c.deleted=?4")
	Object[] listDailyAbstractCasespibyDate(Date fromcreatedDate, Date tocreatedDate, String csStatus, char isDeleted);

	@Query("select count(*) from Case c where date(c.lastModifiedDate)=date(CURRENT_DATE()) and c.type='Medmal' and c.csStatus=?1 and c.deleted=?2")
	Object[] listDailyAbstractCasesmm(String csStatus, char isDeleted);

	@Query("select count(*) from Case c where (date(c.lastModifiedDate) between ?1 and ?2) and c.type='Medmal' and c.csStatus=?3 and c.deleted=?4")
	Object[] listDailyAbstractCasesmmbyDate(Date fromcreatedDate, Date tocreatedDate, String csStatus, char isDeleted);

	@Query("select count(*) from Case c where date(c.lastModifiedDate)=date(CURRENT_DATE()) and c.type='Masstort' and c.csStatus=?1 and c.deleted=?2")
	Object[] listDailyAbstractCasesmt(String csStatus, char isDeleted);

	@Query("select count(*) from Case c where (date(c.lastModifiedDate) between ?1 and ?2) and c.type='Masstort' and c.csStatus=?3 and c.deleted=?4")
	Object[] listDailyAbstractCasesmtbyDate(Date fromcreatedDate, Date tocreatedDate, String csStatus, char isDeleted);

	@Query("select sum(c.pageCount) from Case c where date(c.lastModifiedDate)=date(CURRENT_DATE()) and c.type='Personal Injury' and c.csStatus=?1 and c.deleted=?2")
	Object[] listDailyAbstractPagespi(String csStatus, char isDeleted);

	@Query("select sum(c.pageCount) from Case c where (date(c.lastModifiedDate) between ?1 and ?2) and c.type='Personal Injury' and c.csStatus=?3 and c.deleted=?4")
	Object[] listDailyAbstractPagespibyDate(Date fromcreatedDate, Date tocreatedDate, String csStatus, char isDeleted);

	@Query("select sum(c.pageCount)  from Case c where date(c.lastModifiedDate)=date(CURRENT_DATE()) and c.type='Medmal' and c.csStatus=?1 and c.deleted=?2")
	Object[] listDailyAbstractPagesmm(String csStatus, char isDeleted);

	@Query("select sum(c.pageCount)  from Case c where (date(c.lastModifiedDate) between ?1 and ?2) and c.type='Medmal' and c.csStatus=?3 and c.deleted=?4")
	Object[] listDailyAbstractPagesmmbyDate(Date fromcreatedDate, Date tocreatedDate, String csStatus, char isDeleted);

	@Query("select sum(c.pageCount)  from Case c where date(c.lastModifiedDate)=date(CURRENT_DATE()) and c.type='Masstort' and c.csStatus=?1 and c.deleted=?2")
	Object[] listDailyAbstractPagesmt(String csStatus, char isDeleted);

	@Query("select sum(c.pageCount)  from Case c where (date(c.lastModifiedDate) between ?1 and ?2) and c.type='Masstort' and c.csStatus=?3 and c.deleted=?4")
	Object[] listDailyAbstractPagesmtbyDate(Date fromcreatedDate, Date tocreatedDate, String csStatus, char isDeleted);

	@Query("select count(*) from Case c where c.deleted=?1")
	Integer getReceivedCasesCount(char isDeleted);

	@Query("select sum(c.pageCount) from Case c where c.deleted=?1")
	Integer getReceivedPagesCount(char isDeleted);

	@Query("select count(*) from Case c where c.deleted=?1 and c.csStatus='File Delivery'")
	Integer getDeliveredCasesCount(char isDeleted);

	@Query("select sum(c.pageCount) from Case c where c.deleted=?1 and c.csStatus='File Delivery'")
	Integer getDeliveredPagesCount(char isDeleted);

	@Query("select c from Case c where c.deleted = ?1 and c.name like CONCAT('%',?2,'%') and c.client=?3 order by c.createdDate desc")
	List<Case> listCasesByParametersforCustomer(char isDeleted, String searchString, User clientId);

	@Query("select c from Case c where c.deleted = ?1 and c.name like CONCAT('%',?2,'%') order by c.createdDate desc")
	List<Case> listCasesByParametersforCs(char isDeleted, String searchString);

	@Query("select client.id from Case c where c.deleted=?1 and c.id=?2")
	Long getClientId(char deleted, Long caseId);

	@Query("select c from Case c where c.deleted= ?1 and c.account= ?2 and c.parentCase IS NULL order by c.createdDate desc")
	List<Case> listAllCasesbyClientIdAccount(char isDeleted, Account account);

	@Query("select c from Case c where c.deleted= 'N' and c.client.id= ?1 order by c.createdDate desc")
	List<Case> CaseListAPI(Long userId);

	@Query("select c from Case c where c.deleted = 'N' order by c.createdDate desc")
	List<Case> CsCaseListAPI();

	@Query("select c from Case c where c.id=?1")
	List<Case> CaseDetailsAPI(Long caseId);

	@Query("select c from Case c where c.id=?1")
	Case getAssignedToAPI(Long caseId);

	@Modifying
	@Query("Update Case c set c.addRecordDate = ?1 where  c.id=?2")
	public void updateAppRecDate(DateTime date, Long id);

	@Query("select count(1), sum(c.pageCount), c.type from Case c where date(c.createdDate)=date(CURRENT_DATE()) and c.deleted=?1 and c.csStatus NOT LIKE 'File Delivery' group by c.type")
	List<Object[]> getTodayReceivedCases(char isDeleted);

	@Query("select count(1), sum(c.pageCount), c.type from Case c where (date(c.createdDate) BETWEEN date(?1) and date(?2)) and c.deleted= ?3 and c.csStatus NOT LIKE 'File Delivery'  group by c.type")
	List<Object[]> getTodayReceivedCasesbyDate(Date fromcreatedDate, Date tocreatedDate, char isDeleted);

	@Query("select count(1), sum(c.pageCount), c.type from Case c where date(c.fileDeliveryDate) = date(CURRENT_DATE()) and c.deleted=?1 and c.csStatus='File Delivery' group by c.type")
	List<Object[]> getTodayDeliverededCases(char isDeleted);

	@Query("select count(1), sum(c.pageCount), c.type from Case c where (date(c.fileDeliveryDate) BETWEEN date(?1) and date(?2)) and c.deleted= ?3 and c.csStatus='File Delivery' group by c.type")
	List<Object[]> getTodayDeliverededCasesbyDate(Date fromcreatedDate, Date tocreatedDate, char isDeleted);

	@Query("select count(1), sum(c.pageCount), c.type from Case c where (date(c.cf_1_Date)<date(CURRENT_DATE()) or date(c.expeditedDeliveryDate)<date(CURRENT_DATE())) and c.deleted=?1 group by c.type")
	List<Object[]> getOverDueCases(char isDeleted);

	@Query("select count(1), sum(c.pageCount), c.type from Case c where (((date(c.cf_1_Date) between date(?1) and date(?2)) AND (date(c.cf_1_Date)<date(CURRENT_DATE())) AND ((date(c.fileDeliveryDate) > date(c.cf_1_Date)) OR c.fileDeliveryDate IS NULL )) or ((date(c.expeditedDeliveryDate) between date(?1) and date(?2)) AND (date(c.expeditedDeliveryDate)<date(CURRENT_DATE())) AND ((date(c.fileDeliveryDate) > date(c.expeditedDeliveryDate)) OR c.fileDeliveryDate IS NULL))) and c.deleted=?3 group by c.type")
	List<Object[]> getOverDueCasesbyDate(Date fromcreatedDate, Date tocreatedDate, char isDeleted);

	@Query("select count(1), sum(c.pageCount), c.type from Case c where date(c.lastModifiedDate)=date(CURRENT_DATE()) and c.csStatus=?1 and c.deleted=?2 group by c.type")
	List<Object[]> getDailyAbstractCases(String csStatus, char isDeleted);

	@Query("select count(1), sum(c.pageCount), c.type from Case c where (date(c.lastModifiedDate) between date(?1) and date(?2)) and c.csStatus=?3 and c.deleted=?4 group by c.type")
	List<Object[]> getDailyAbstractCasesbyDate(Date fromcreatedDate, Date tocreatedDate, String csStatus,
			char isDeleted);

	@Query("select count(1), sum(c.pageCount), c.type from Case c where date(c.lastModifiedDate)=date(CURRENT_DATE()) and c.csStatus=?1 and c.deleted=?2 group by c.type")
	List<Object[]> getDailyAbstractPages(String csStatus, char isDeleted);

	@Query("select count(1), sum(c.pageCount), c.type from Case c where (date(c.lastModifiedDate) between date(?1) and date(?2)) and c.csStatus=?3 and c.deleted=?4 group by c.type")
	List<Object[]> getDailyAbstractPagesbyDate(Date fromcreatedDate, Date tocreatedDate, String csStatus,
			char isDeleted);

	@Query("select count(1), sum(c.pageCount) from Case c where date(c.lastModifiedDate)=date(CURRENT_DATE()) and c.csStatus=?1 and c.deleted=?2 and c.type=?3 group by c.type having count(1) > 0")
	List<Object[]> getDailyAbstractPagesCases(String csStatus, char isDeleted, String type);

	@Query("select count(1), sum(c.pageCount) from Case c where (date(c.lastModifiedDate) between date(?1) and date(?2)) and c.csStatus=?3 and c.deleted=?4 and c.type=?5 group by c.type having count(1) > 0")
	List<Object[]> getDailyAbstractPagesCasesbyDate(Date fromcreatedDate, Date tocreatedDate, String csStatus,
			char isDeleted, String type);

	@Query("select count(1), sum(c.pageCount), c.type from Case c where date(c.fileDeliveryDate) = date(CURRENT_DATE()) and c.deleted=?1 and c.type=?2 group by c.type having count(1) > 0")
	List<Object[]> getTodayDeliverededCasesbyType(char isDeleted, String type);

	@Query("select count(1), sum(c.pageCount), c.type from Case c where (date(c.fileDeliveryDate) BETWEEN date(?1) and date(?2)) and c.deleted= ?3 and c.csStatus='File Delivery' group by c.type having count(1) > 0")
	List<Object[]> getTodayDeliverededCasesbyDateType(Date fromcreatedDate, Date tocreatedDate, char isDeleted);

	@Query("select count(1), sum(c.pageCount), c.type from Case c where date(c.createdDate)=date(CURRENT_DATE()) and c.deleted=?1 and c.csStatus = ?2 group by c.type")
	List<Object[]> getDailyAbstractPagesCases(char isDeleted, String strStatus);

	@Query("select count(1), sum(c.pageCount), c.type from Case c where (date(c.createdDate) BETWEEN date(?1) and date(?2)) and c.deleted= ?3 and c.csStatus = ?4  group by c.type")
	List<Object[]> getDailyAbstractPagesCases(Date fromcreatedDate, Date tocreatedDate, char isDeleted,
			String strStatus);

	@Query("select c.name as csname,c.id as csid,c.caseCode as casecode from Case c where c.deleted = ?1 and c.account.id = ?2 order by c.createdDate desc")
	List<Case> listAllCasesNameIDByAccountID(char isDeleted, Long accountId);

	@Query("select count(1), sum(c.pageCount), c.type from Case c where c.deleted= ?1 and date(c.createdDate)=date(CURRENT_DATE()) and c.account.id=?2 and c.csStatus NOT LIKE 'File Delivery'  group by c.type")
	List<Object[]> getReceivedCasesByPartner(char isDeleted, Long partnerId);

	@Query("select count(1), sum(c.pageCount), c.type from Case c where c.deleted= ?1 and date(c.fileDeliveryDate)=date(CURRENT_DATE()) and c.account.id=?2 and c.csStatus='File Delivery' group by c.type having count(1) > 0")
	List<Object[]> getDeliverededCasesbyPartner(char isDeleted, Long partnerId);

	@Modifying
	@Query(value = "UPDATE Case c SET c.type = ?1 WHERE c.type = ?2")
	int updateCaseType(String type, String type1);

	@Modifying
	@Query(value = "UPDATE Case c SET c.csStatus = ?1 WHERE c.csStatus = ?2")
	int updateCsStatus(String csStatus, String csStatus1);

	@Modifying
	@Query(value = "UPDATE Case c SET c.clientStatus = ?1 WHERE c.clientStatus = ?2")
	int updateCustomerStatus(String clientStatus, String clientStatus1);

	@Query("select count(1), sum(c.pageCount), c.type from Case c where date(c.createdDate)=date(CURRENT_DATE()) and c.deleted=?1 group by c.type")
	List<Object[]> getTodayReceivedCasesAllPages(char isDeleted);

	@Query("select count(1), sum(c.pageCount), c.type from Case c where (date(c.createdDate) BETWEEN date(?1) and date(?2)) and c.deleted= ?3 group by c.type")
	List<Object[]> getTodayReceivedCasesbyDateAllPages(Date fromcreatedDate, Date tocreatedDate, char isDeleted);

	@Query("select count(1), sum(c.pageCount), c.type from Case c where (date(c.fileDeliveryDate) BETWEEN date(?1) and date(?2)) and c.deleted= ?3 and c.account.id=?4 and c.csStatus='File Delivery' group by c.type")
	List<Object[]> getDeliverededCasesPagesbyDateAndPartner(Date fromcreatedDate, Date tocreatedDate, char isDeleted,
			Long accountId);

	@Query("select count(1), sum(c.pageCount), c.type from Case c where (date(c.createdDate) BETWEEN date(?1) and date(?2)) and c.deleted= ?3 and c.account.id=?4 group by c.type")
	List<Object[]> getReceivedCasesPagesbyDateAndPartner(Date fromcreatedDate, Date tocreatedDate, char isDeleted,
			Long accountId);

	@Query("select count(1), sum(c.pageCount), c.type from Case c where date(c.createdDate)=date(CURRENT_DATE()) and c.deleted=?1 and c.csStatus = ?2 and c.account.id=?3 group by c.type")
	List<Object[]> getDailyAbstractPagesCasesByPartner(char isDeleted, String strStatus, Long accountId);

	@Query("select count(1), sum(c.pageCount), c.type from Case c where (date(c.createdDate) BETWEEN date(?1) and date(?2)) and c.deleted= ?3 and c.csStatus = ?4 and c.account.id=?5  group by c.type")
	List<Object[]> getDailyAbstractPagesCasesByDatePartner(Date fromcreatedDate, Date tocreatedDate, char isDeleted,
			String strStatus, Long accountId);

	@Query("select count(1), sum(c.pageCount), c.type from Case c where c.deleted= ?1 and (date(c.fileDeliveryDate)BETWEEN date(?2) and date(?3)) and c.account.id=?4 and c.csStatus='File Delivery' group by c.type having count(1) > 0")
	List<Object[]> getDeliverededCasesPagesbyPartnerDate(char isDeleted, Date fromcreatedDate, Date tocreatedDate,
			Long partnerId);

	@Query("select count(1), sum(c.pageCount), c.type from Case c where c.deleted= ?1 and (date(c.fileDeliveryDate)BETWEEN date(?2) and date(?3)) and c.csStatus='File Delivery' group by c.type having count(1) > 0")
	List<Object[]> getDeliverededCasesPagesbyDate(char isDeleted, Date fromcreatedDate, Date tocreatedDate);

	@Query("select count(1), sum(c.pageCount), c.type from Case c where (date(c.cf_1_Date)<date(CURRENT_DATE()) or date(c.expeditedDeliveryDate)<date(CURRENT_DATE())) and c.deleted=?1 and c.account.id=?2 and c.csStatus not like '%File Delivery%' and c.csStatus not like '%Closed%' group by c.type")
	List<Object[]> getOverDueCasesbyPartner(char isDeleted, Long accountId);

	@Query("select count(1), sum(c.pageCount), c.type from Case c where (((date(c.cf_1_Date) between date(?1) and date(?2)) AND (date(cf_1_Date)<date(CURRENT_DATE())) AND ((date(c.fileDeliveryDate) > date(c.cf_1_Date)) OR c.fileDeliveryDate IS NULL )) or ((date(c.expeditedDeliveryDate) between date(?1) and date(?2)) AND (date(c.expeditedDeliveryDate)<date(CURRENT_DATE())) AND ((date(c.fileDeliveryDate) > date(c.expeditedDeliveryDate)) OR c.fileDeliveryDate IS NULL))) and c.deleted=?3 and c.account.id=?4 group by c.type")
	List<Object[]> getOverDueCasesbyPartnerDate(Date fromcreatedDate, Date tocreatedDate, char isDeleted,
			Long accountId);

	@Modifying
	@Query(value = "UPDATE Case c SET c.serviceRequestedShortCode = ?1 WHERE c.serviceRequestedShortCode = ?2")
	int updateserviceRequestedShortCode(String serviceRequestedShortCode, String serviceRequestedShortCode1);

	@Query("select c from Case c where c.deleted= 'N' and c.assignedTo  is not null and c.assignedTo = ?1 ")
	List<Case> listCaseByAssignedUser(char isDeleted, User userId);

	@Query("select c from Case c where c.id=?1 and c.deleted=?2")
	List<Case> ListCasesByCaseId(Long caseId, char deleted);

	@Query("select c from Case c JOIN FETCH c.client cc LEFT JOIN FETCH cc.lastViewedCase cclvc LEFT JOIN FETCH cc.account ccac LEFT JOIN FETCH cc.role ccr LEFT JOIN FETCH cc.team cct LEFT JOIN FETCH cc.userProfile ccup LEFT JOIN FETCH cc.createdBy cccb LEFT JOIN FETCH cc.lastModifiedBy ccmb JOIN FETCH c.account ac LEFT JOIN FETCH ac.partner LEFT JOIN FETCH c.job cj LEFT JOIN FETCH c.parentCase LEFT JOIN FETCH c.assignedTo ca LEFT JOIN FETCH c.createdBy cb LEFT JOIN FETCH c.lastModifiedBy mb where c.id = ?1")
	Case getCaseById(Long caseId);

	@Query("select c.account.id, COUNT(1) from Case c WHERE date(c.fileReceivedDate) BETWEEN ?1 and ?2 group by c.account.id HAVING COUNT(1) > 0 ORDER BY COUNT(1) DESC ")
	List<Object[]> getGroupByAccount(Date fromDate, Date toDate);

	@Query(value = "SELECT a.account_id AS account, COUNT(DISTINCT u.user_id)AS cntuser, COUNT( DISTINCT c.case_id) AS cntcase, COUNT( DISTINCT c1.case_id) AS cntdeliveredcase, COUNT( DISTINCT c2.case_id) AS cntpendingcase, IFNULL(SUM(c.case_total_page_count), 0) AS sumreceivedpage, GROUP_CONCAT(c.case_id SEPARATOR ',') AS case_ids, IFNULL(SUM(crf.file_page_count), 0) AS sumdeliverypage, a.name AS accName FROM accounts a JOIN users u ON a.account_id = u.account_id AND u.is_deleted = 'N' LEFT JOIN cases c ON a.account_id = c.account_id AND u.user_id = c.client_id AND c.is_deleted = 'N' AND date(c.file_received_date) BETWEEN ?1 AND ?2 LEFT JOIN cases c1 ON a.account_id = c1.account_id AND u.user_id = c1.client_id AND c1.is_deleted = 'N' AND c.case_id = c1.case_id AND c1.cs_status LIKE 'File Delivery' LEFT JOIN cases c2 ON a.account_id = c2.account_id AND u.user_id = c2.client_id AND c2.is_deleted = 'N' AND c2.cs_status NOT LIKE 'File Delivery' AND c.case_id = c2.case_id WHERE a.is_deleted = 'N' GROUP BY a.account_id HAVING COUNT(c.case_id) > 0 ORDER BY COUNT(c.case_id) DESC LIMIT ?3, ?4", nativeQuery = true)
	List<Object[]> getGroupByAccountCase(Date fromDate, Date toDate, int startPage, int endPage);

	@Query("select c from Case c where c.id = ?1 and c.deleted = 'N'")
	Case findByCaseId(Long name);

	@Query("select c from Case c where c.id not in (select cf.caseId from CaseFilesChangeHistory cf) and c.deleted = ?1")
	List<Case> getcaseListNotinCaseFileHistory(char isDeleted);

	@Query("select c from Case c where c.id in (select cf.caseId from CaseFilesChangeHistory cf) and c.deleted = ?1")
	List<Case> getcaseListInCaseFileHistory(char isDeleted);

	@Modifying
	@Query(value = "UPDATE Case cf SET cf.deleted = ?2 WHERE cf.id=?1")
	int updatedeleteCaseId(Long caseId, char isDeleted);

	@Query(value = "SELECT "
			+ " SUM(IFNULL((c.total_estimate_hours - IFNULL((SELECT SUM(IFNULL(cc.total_estimate_hours, 0)) FROM cases cc WHERE cc.is_deleted LIKE 'N' AND cc.parent_case_id = (c.case_id)), 0)),0))/60 AS total_estimate_hours,  "
			+ " SUM(IFNULL(DATEDIFF(IF(date(c.file_delivery_date) <= date(?3), date(c.file_delivery_date), IF(date(c.file_migration_date) <= date(?3), date(c.file_migration_date), null)), c.created_date), 0)) / count(IFNULL(c.case_id, 0)) AS tat,  "
			+ " SUM(IFNULL(IF(date(c.file_delivery_date) <= date(?3), (c.total_invoice_hours - IFNULL((SELECT SUM(IFNULL(cc.total_invoice_hours, 0)) FROM cases cc WHERE cc.is_deleted LIKE 'N' AND cc.parent_case_id = (c.case_id)),0)), 0),0))/60 AS total_invoice_hours, "
			+ " SUM(IF(IFNULL(c.parent_case_id, '') = '', IFNULL((SELECT SUM(csrd.quality_score) FROM case_service_req_detail csrd WHERE IFNULL(csrd.additional_rec_id, '') = '' AND csrd.case_id = c.case_id), 0), IFNULL((SELECT SUM(csrd.quality_score) FROM case_service_req_detail csrd JOIN case_files_change_history cfch ON cfch.case_files_chng_hist_id = csrd.additional_rec_id WHERE IFNULL(csrd.additional_rec_id, '') <> '' AND cfch.sub_case_id = c.case_id), 0)))  / count(IFNULL(c.case_id, 0)) As quality_score"
			+ " FROM cases c "
			/*
			 * +
			 * " WHERE c.case_id IN (SELECT DISTINCT c.case_id FROM cases c JOIN case_production cp ON cp.case_id = c.case_id JOIN prod_assignee_flow pa ON pa.production_id = cp.production_id JOIN users u ON u.user_id = pa.assignee JOIN teams t ON t.team_id = u.team_id WHERE c.is_deleted LIKE 'N' AND u.is_deleted LIKE 'N' AND t.is_deleted  LIKE 'N') "
			 */
			+ " WHERE c.is_deleted  LIKE 'N' "
			+ " AND (c.file_delivery_date IS NOT NULL OR c.file_migration_date IS NOT NULL)"
			+ " AND (date(c.file_delivery_date) BETWEEN date(?2) and date(?3) OR date(c.file_migration_date) BETWEEN date(?2) and date(?3)) "
			+ " AND ((IFNULL(?1, '') <> '' AND c.type LIKE ?1 ) OR ((IFNULL(?1, '') = '' AND 1 = 1))) "
			+ " ", nativeQuery = true)
	Object[] totalAchievedCaseFileCount(String csStatus, Date fromDate, Date toDate);

	@Query(value = "select count(IFNULL(c.caseid, 0)) from QIDatabase c where (date(c.date) BETWEEN date(?2) and date(?3)) AND c.casetype IN ('Personal Injury', 'MassTort', 'Medical Malpractice', 'Demand')"
			+ " AND ((IFNULL(?1, '') <> '' AND c.casetype LIKE ?1 ) OR ((IFNULL(?1, '') = '' AND 1 = 1))) ", nativeQuery = true)
	Object totalQualityIssueCount(String psDepartment, Date fromDate, Date toDate);

	@Query(value = "SELECT t1.user_id, t1.uname, t1.long_name, t1.name, SUM(t1.etimate_hrs), SUM(t1.case_total_page_count), COUNT(DISTINCT qd.caseid) FROM  (SELECT u.user_id, concat_ws('', up.first_name, ' ', up.last_name) uname, ai.long_name, t.name, (SELECT  ROUND((c.total_estimate_hours / 60) / COUNT(pa.assignee),2) AS etimate_hrs FROM cases c JOIN case_production cp ON cp.case_id = c.case_id  JOIN prod_assignee_flow pa ON pa.production_id = cp.production_id  JOIN users u ON u.user_id = pa.assignee  WHERE c.is_deleted LIKE 'N' AND u.is_deleted LIKE 'N' AND c.file_delivery_date IS NOT NULL AND c.cs_status = 'File Delivery' AND c.case_id = cc.case_id GROUP BY c.case_id ) AS etimate_hrs, cc.case_total_page_count FROM cases cc  JOIN case_production cp ON cp.case_id = cc.case_id  JOIN prod_assignee_flow pa ON pa.production_id = cp.production_id  JOIN users u ON u.user_id = pa.assignee  JOIN teams t  ON u.team_id = t.team_id  JOIN user_profiles up  ON up.user_id = u.user_id  JOIN app_items ai  ON ai.item_id = u.designation_id WHERE cc.is_deleted LIKE 'N' AND u.is_deleted LIKE 'N' AND cc.file_delivery_date IS NOT NULL AND cc.cs_status = 'File Delivery' AND (date(cc.file_delivery_date) BETWEEN date(?2) and date(?3)) AND ((IFNULL(?1, '') <> '' AND cc.type LIKE ?1 ) OR ((IFNULL(?1, '') = '' AND 1 = 1))) GROUP BY cc.case_id, u.user_id) AS t1 LEFT JOIN QIDatabase qd ON qd.productionstaff = t1.uname GROUP BY t1.user_id", nativeQuery = true)
	List<Object[]> getListofStaffDeliverededCasesPagesbyTeam(String teamName, Date fromDate, Date toDate);

	@Query(value = "  SELECT t1.user_id, t1.uname, t1.long_name, t1.type,t1.name, sum(t1.etimate_hrs), sum(t1.case_total_page_count), COUNT(DISTINCT IFNULL(qd.caseid, 0))\r\n"
			+ "		FROM (SELECT Distinct u.user_id, concat_ws('', up.first_name, ' ', up.last_name) uname, ai.long_name, c.type,c.case_id,t.name, SUM(c.etimate_hrs) etimate_hrs, SUM(c.case_total_page_count) case_total_page_count\r\n"
			+ "		FROM (SELECT @rownum\\:= @rownum + 1 AS n FROM users t, (SELECT @rownum\\:= 0) r LIMIT 0, 500) AS n1 INNER JOIN (\r\n"
			+ "		SELECT  ROUND((c.total_estimate_hours / 60) / COUNT(cp.user_id),2) AS etimate_hrs, c.case_total_page_count, c.case_id, c.is_deleted, c.type,(user_id) user_id\r\n"
			+ "		FROM cases c JOIN (SELECT DISTINCT case_report_users.case_id,  SUBSTRING_INDEX(SUBSTRING_INDEX(case_report_users.prod_user, ',', numbers.n), ',', -1) user_id\r\n"
			+ "		FROM (SELECT @rownum1\\:= @rownum1 + 1 AS n FROM users t, (SELECT @rownum1\\:= 0) r LIMIT 0, 500) AS numbers \r\n"
			+ "		INNER JOIN case_report_users ON CHAR_LENGTH(case_report_users.prod_user) - CHAR_LENGTH(REPLACE(case_report_users.prod_user, ',', '')) >= numbers.n-1\r\n"
			+ "		ORDER BY case_id, n) cp ON cp.case_id = c.case_id  \r\n"
			+ "		WHERE c.is_deleted LIKE 'N' AND c.file_delivery_date IS NOT NULL AND c.cs_status = 'File Delivery' \r\n"
			+ "		AND (date(c.file_delivery_date) BETWEEN date(?2) and date(?3)) AND ((IFNULL(?1, '') <> '' AND c.type LIKE ?1 ) OR ((IFNULL(?1, '') = '' AND 1 = 1)))\r\n"
			+ "		GROUP BY c.case_id)  c ON CHAR_LENGTH(c.user_id) - CHAR_LENGTH(REPLACE(c.user_id, ',', '')) >= n1.n-1\r\n"
			+ "		JOIN cases c1 ON c.case_id = c1.case_id\r\n"
			+ "		JOIN users u ON u.user_id = SUBSTRING_INDEX(SUBSTRING_INDEX(c.user_id, ',', n1.n), ',', -1)  \r\n"
			+ "		JOIN teams t  ON u.team_id = t.team_id  \r\n"
			+ "		JOIN user_profiles up  ON up.user_id = u.user_id \r\n"
			+ "		JOIN app_items ai  ON ai.item_id = u.designation_id\r\n"
			+ "		WHERE c.is_deleted LIKE 'N' AND u.is_deleted LIKE 'N'\r\n"
			+ "		AND c1.file_delivery_date IS NOT NULL AND c1.cs_status = 'File Delivery' \r\n"
			+ "		GROUP BY u.user_id,c.case_id) AS t1 LEFT JOIN QIDatabase qd ON qd.productionstaff = t1.uname \r\n"
			+ "        AND (date(qd.date) BETWEEN date(?2) and date(?3)) AND qd.casetype IN ('Personal Injury', 'MassTort', 'Medical Malpractice', 'Demand')\r\n"
			+ "		AND ((IFNULL(?1, '') <> '' AND qd.casetype LIKE ?1 ) OR ((IFNULL(?1, '') = '' AND 1 = 1)))\r\n"
			+ "        GROUP BY t1.user_id;  ", nativeQuery = true)
	List<Object[]> getListofStaffDeliverededCasesPagesbyTeamForQM(String teamName, Date fromDate, Date toDate);

	@Query("select c from Case c where c.deleted = ?1 and c.account.id = ?2 and c.name like CONCAT('%',?3,'%') order by c.createdDate desc")
	List<Case> listAllCasesName(char isDeleted, Long accountId, String searchTerm);

	@Query("select c from Case c where c.deleted= ?1 and c.client.id= ?2 and c.parentCase IS NULL  order by c.createdDate desc")
	List<Case> listAllCasesbyClientIdParentCaseNull(char isDeleted, Long userId);

	@Query("select c from Case c where c.deleted= 'N' and c.parentCase.id= ?1")
	List<Case> findByParentId(Long caseId);

	@Query("select c from Case c where c.id=?1 and c.deleted=?2")
	Case pageCountByCaseId(Long caseId, char deleted);

	@Query("select c from Case c where c.deleted= 'N' and c.parentCase.id= ?1 order by c.id desc ")
	List<Case> findByParentIdOrderBy(Long caseId);

	@Query("select c from Case c where c.deleted= ?1 and c.client.id= ?2  order by c.createdDate desc")
	List<Case> listAllCasesbyClientIdforCSLogin(char isDeleted, Long userId);

	@Query(value = "SELECT a.account_id AS account, COUNT(DISTINCT u.user_id)AS cntuser, COUNT( DISTINCT c.case_id) AS cntcase, COUNT( DISTINCT c1.case_id) AS cntdeliveredcase, COUNT( DISTINCT c2.case_id) AS cntpendingcase, IFNULL(SUM(c.case_total_page_count), 0) AS sumreceivedpage, GROUP_CONCAT(DISTINCT c.case_id SEPARATOR ',') AS case_ids, IFNULL(SUM(crf.file_page_count), 0) AS sumdeliverypage, a.name AS accName FROM accounts a JOIN users u ON a.account_id = u.account_id AND u.is_deleted = 'N' LEFT JOIN cases c ON a.account_id = c.account_id AND u.user_id = c.client_id AND c.is_deleted = 'N' AND date(c.file_received_date) BETWEEN ?1 AND ?2 LEFT JOIN cases c1 ON a.account_id = c1.account_id AND u.user_id = c1.client_id AND c1.is_deleted = 'N' AND c.case_id = c1.case_id AND c1.cs_status IN ?8 LEFT JOIN cases c2 ON a.account_id = c2.account_id AND u.user_id = c2.client_id AND c2.is_deleted = 'N' AND c2.cs_status NOT IN ?8 AND c.case_id = c2.case_id LEFT JOIN case_result_file crf ON c.case_id = crf.case_id AND crf.is_deleted LIKE 'N' AND c.cs_status IN ?8 WHERE a.is_deleted = 'N' AND c.is_deleted LIKE 'N' AND ((IFNULL(?5, '') <> '' AND a.name LIKE CONCAT('%', ?5, '%')) OR (IFNULL(?5, '') = '' AND 1 = 1)) AND ((IFNULL(?6, '') <> '' AND a.partner_id IN (?6)) OR (IFNULL(?6, '') = '' AND 1 = 1)) AND ((IFNULL(?7, '') <> '' AND a.account_manager_id IN (?7)) OR (IFNULL(?7, '') = '' AND 1 = 1)) GROUP BY a.account_id HAVING COUNT(c.case_id) > 0 ORDER BY a.name DESC LIMIT ?3,?4", nativeQuery = true)
	List<Object[]> getGroupByAccountNameDsec(Date fromDate, Date toDate, int startPage, int endPage, String psAccName,
			String psAccPartner, String psAccManager, List<String> csStatus);

	@Query(value = "SELECT a.account_id AS account, COUNT(DISTINCT u.user_id)AS cntuser, COUNT( DISTINCT c.case_id) AS cntcase, COUNT( DISTINCT c1.case_id) AS cntdeliveredcase, COUNT( DISTINCT c2.case_id) AS cntpendingcase, IFNULL(SUM(c.case_total_page_count), 0) AS sumreceivedpage, GROUP_CONCAT(DISTINCT c.case_id SEPARATOR ',') AS case_ids, IFNULL(SUM(crf.file_page_count), 0) AS sumdeliverypage, a.name AS accName FROM accounts a JOIN users u ON a.account_id = u.account_id AND u.is_deleted = 'N' LEFT JOIN cases c ON a.account_id = c.account_id AND u.user_id = c.client_id AND c.is_deleted = 'N' AND date(c.file_received_date) BETWEEN ?1 AND ?2 LEFT JOIN cases c1 ON a.account_id = c1.account_id AND u.user_id = c1.client_id AND c1.is_deleted = 'N' AND c.case_id = c1.case_id AND c1.cs_status IN ?8 LEFT JOIN cases c2 ON a.account_id = c2.account_id AND u.user_id = c2.client_id AND c2.is_deleted = 'N' AND c2.cs_status NOT IN ?8 AND c.case_id = c2.case_id LEFT JOIN case_result_file crf ON c.case_id = crf.case_id AND crf.is_deleted LIKE 'N' AND c.cs_status IN ?8 WHERE a.is_deleted = 'N' AND c.is_deleted LIKE 'N' AND ((IFNULL(?5, '') <> '' AND a.name LIKE CONCAT('%', ?5, '%')) OR (IFNULL(?5, '') = '' AND 1 = 1)) AND ((IFNULL(?6, '') <> '' AND a.partner_id IN (?6)) OR (IFNULL(?6, '') = '' AND 1 = 1)) AND ((IFNULL(?7, '') <> '' AND a.account_manager_id IN (?7)) OR (IFNULL(?7, '') = '' AND 1 = 1)) GROUP BY a.account_id HAVING COUNT(c.case_id) > 0 ORDER BY a.name ASC LIMIT ?3,?4", nativeQuery = true)
	List<Object[]> getGroupByAccountNameAsec(Date fromDate, Date toDate, int startPage, int endPage, String psAccName,
			String psAccPartner, String psAccManager, List<String> csStatus);

	@Query(value = "SELECT a.account_id AS account, COUNT(DISTINCT u.user_id)AS cntuser, COUNT( DISTINCT c.case_id) AS cntcase, COUNT( DISTINCT c1.case_id) AS cntdeliveredcase, COUNT( DISTINCT c2.case_id) AS cntpendingcase, IFNULL(SUM(c.case_total_page_count), 0) AS sumreceivedpage, GROUP_CONCAT(DISTINCT c.case_id SEPARATOR ',') AS case_ids, IFNULL(SUM(crf.file_page_count), 0) AS sumdeliverypage, a.name AS accName FROM accounts a JOIN users u ON a.account_id = u.account_id AND u.is_deleted = 'N' LEFT JOIN cases c ON a.account_id = c.account_id AND u.user_id = c.client_id AND c.is_deleted = 'N' AND date(c.file_received_date) BETWEEN ?1 AND ?2 LEFT JOIN cases c1 ON a.account_id = c1.account_id AND u.user_id = c1.client_id AND c1.is_deleted = 'N' AND c.case_id = c1.case_id AND c1.cs_status IN ?8 LEFT JOIN cases c2 ON a.account_id = c2.account_id AND u.user_id = c2.client_id AND c2.is_deleted = 'N' AND c2.cs_status NOT IN ?8 AND c.case_id = c2.case_id LEFT JOIN case_result_file crf ON c.case_id = crf.case_id AND crf.is_deleted LIKE 'N' AND c.cs_status IN ?8 WHERE a.is_deleted = 'N' AND c.is_deleted LIKE 'N' AND ((IFNULL(?5, '') <> '' AND a.name LIKE CONCAT('%', ?5, '%')) OR (IFNULL(?5, '') = '' AND 1 = 1)) AND ((IFNULL(?6, '') <> '' AND a.partner_id IN (?6)) OR (IFNULL(?6, '') = '' AND 1 = 1)) AND ((IFNULL(?7, '') <> '' AND a.account_manager_id IN (?7)) OR (IFNULL(?7, '') = '' AND 1 = 1)) GROUP BY a.account_id HAVING COUNT(c.case_id) > 0 ORDER BY COUNT(DISTINCT c.case_id) DESC LIMIT ?3,?4", nativeQuery = true)
	List<Object[]> getGroupByAccountCaseCountDsec(Date fromDate, Date toDate, int startPage, int endPage,
			String psAccName, String psAccPartner, String psAccManager, List<String> csStatus);

	@Query(value = "SELECT a.account_id AS account, COUNT(DISTINCT u.user_id)AS cntuser, COUNT( DISTINCT c.case_id) AS cntcase, COUNT( DISTINCT c1.case_id) AS cntdeliveredcase, COUNT( DISTINCT c2.case_id) AS cntpendingcase, IFNULL(SUM(c.case_total_page_count), 0) AS sumreceivedpage, GROUP_CONCAT(DISTINCT c.case_id SEPARATOR ',') AS case_ids, IFNULL(SUM(crf.file_page_count), 0) AS sumdeliverypage, a.name AS accName FROM accounts a JOIN users u ON a.account_id = u.account_id AND u.is_deleted = 'N' LEFT JOIN cases c ON a.account_id = c.account_id AND u.user_id = c.client_id AND c.is_deleted = 'N' AND date(c.file_received_date) BETWEEN ?1 AND ?2 LEFT JOIN cases c1 ON a.account_id = c1.account_id AND u.user_id = c1.client_id AND c1.is_deleted = 'N' AND c.case_id = c1.case_id AND c1.cs_status IN ?8 LEFT JOIN cases c2 ON a.account_id = c2.account_id AND u.user_id = c2.client_id AND c2.is_deleted = 'N' AND c2.cs_status NOT IN ?8 AND c.case_id = c2.case_id LEFT JOIN case_result_file crf ON c.case_id = crf.case_id AND crf.is_deleted LIKE 'N' AND c.cs_status IN ?8 WHERE a.is_deleted = 'N' AND c.is_deleted LIKE 'N' AND ((IFNULL(?5, '') <> '' AND a.name LIKE CONCAT('%', ?5, '%')) OR (IFNULL(?5, '') = '' AND 1 = 1)) AND ((IFNULL(?6, '') <> '' AND a.partner_id IN (?6)) OR (IFNULL(?6, '') = '' AND 1 = 1)) AND ((IFNULL(?7, '') <> '' AND a.account_manager_id IN (?7)) OR (IFNULL(?7, '') = '' AND 1 = 1)) GROUP BY a.account_id HAVING COUNT(c.case_id) > 0 ORDER BY COUNT(DISTINCT c.case_id) ASC LIMIT ?3,?4", nativeQuery = true)
	List<Object[]> getGroupByAccountCaseCountAec(Date fromDate, Date toDate, int startPage, int endPage,
			String psAccName, String psAccPartner, String psAccManager, List<String> csStatus);

	@Query(value = "SELECT a.account_id AS account, COUNT(DISTINCT u.user_id)AS cntuser, COUNT( DISTINCT c.case_id) AS cntcase, COUNT( DISTINCT c1.case_id) AS cntdeliveredcase, COUNT( DISTINCT c2.case_id) AS cntpendingcase, IFNULL(SUM(c.case_total_page_count), 0) AS sumreceivedpage, GROUP_CONCAT(DISTINCT c.case_id SEPARATOR ',') AS case_ids, IFNULL(SUM(crf.file_page_count), 0) AS sumdeliverypage, a.name AS accName FROM accounts a JOIN users u ON a.account_id = u.account_id AND u.is_deleted = 'N' LEFT JOIN cases c ON a.account_id = c.account_id AND u.user_id = c.client_id AND c.is_deleted = 'N' AND date(c.file_received_date) BETWEEN ?1 AND ?2 LEFT JOIN cases c1 ON a.account_id = c1.account_id AND u.user_id = c1.client_id AND c1.is_deleted = 'N' AND c.case_id = c1.case_id AND c1.cs_status IN ?8 LEFT JOIN cases c2 ON a.account_id = c2.account_id AND u.user_id = c2.client_id AND c2.is_deleted = 'N' AND c2.cs_status NOT IN ?8 AND c.case_id = c2.case_id LEFT JOIN case_result_file crf ON c.case_id = crf.case_id AND crf.is_deleted LIKE 'N' AND c.cs_status IN ?8 WHERE a.is_deleted = 'N' AND c.is_deleted LIKE 'N' AND ((IFNULL(?5, '') <> '' AND a.name LIKE CONCAT('%', ?5, '%')) OR (IFNULL(?5, '') = '' AND 1 = 1)) AND ((IFNULL(?6, '') <> '' AND a.partner_id IN (?6)) OR (IFNULL(?6, '') = '' AND 1 = 1)) AND ((IFNULL(?7, '') <> '' AND a.account_manager_id IN (?7)) OR (IFNULL(?7, '') = '' AND 1 = 1)) GROUP BY a.account_id HAVING COUNT(c.case_id) > 0 ORDER BY COUNT(DISTINCT u.user_id) DESC LIMIT ?3,?4", nativeQuery = true)
	List<Object[]> getGroupByAccountNoOfUserDsec(Date fromDate, Date toDate, int startPage, int endPage,
			String psAccName, String psAccPartner, String psAccManager, List<String> csStatus);

	@Query(value = "SELECT a.account_id AS account, COUNT(DISTINCT u.user_id)AS cntuser, COUNT( DISTINCT c.case_id) AS cntcase, COUNT( DISTINCT c1.case_id) AS cntdeliveredcase, COUNT( DISTINCT c2.case_id) AS cntpendingcase, IFNULL(SUM(c.case_total_page_count), 0) AS sumreceivedpage, GROUP_CONCAT(DISTINCT c.case_id SEPARATOR ',') AS case_ids, IFNULL(SUM(crf.file_page_count), 0) AS sumdeliverypage, a.name AS accName FROM accounts a JOIN users u ON a.account_id = u.account_id AND u.is_deleted = 'N' LEFT JOIN cases c ON a.account_id = c.account_id AND u.user_id = c.client_id AND c.is_deleted = 'N' AND date(c.file_received_date) BETWEEN ?1 AND ?2 LEFT JOIN cases c1 ON a.account_id = c1.account_id AND u.user_id = c1.client_id AND c1.is_deleted = 'N' AND c.case_id = c1.case_id AND c1.cs_status IN ?8 LEFT JOIN cases c2 ON a.account_id = c2.account_id AND u.user_id = c2.client_id AND c2.is_deleted = 'N' AND c2.cs_status NOT IN ?8 AND c.case_id = c2.case_id LEFT JOIN case_result_file crf ON c.case_id = crf.case_id AND crf.is_deleted LIKE 'N' AND c.cs_status IN ?8 WHERE a.is_deleted = 'N' AND c.is_deleted LIKE 'N' AND ((IFNULL(?5, '') <> '' AND a.name LIKE CONCAT('%', ?5, '%')) OR (IFNULL(?5, '') = '' AND 1 = 1)) AND ((IFNULL(?6, '') <> '' AND a.partner_id IN (?6)) OR (IFNULL(?6, '') = '' AND 1 = 1)) AND ((IFNULL(?7, '') <> '' AND a.account_manager_id IN (?7)) OR (IFNULL(?7, '') = '' AND 1 = 1)) GROUP BY a.account_id HAVING COUNT(c.case_id) > 0 ORDER BY COUNT(DISTINCT u.user_id) ASC LIMIT ?3,?4", nativeQuery = true)
	List<Object[]> getGroupByAccountNoOfUserAsc(Date fromDate, Date toDate, int startPage, int endPage,
			String psAccName, String psAccPartner, String psAccManager, List<String> csStatus);

	@Query(value = "SELECT a.account_id AS account, COUNT(DISTINCT u.user_id)AS cntuser, COUNT( DISTINCT c.case_id) AS cntcase, COUNT( DISTINCT c1.case_id) AS cntdeliveredcase, COUNT( DISTINCT c2.case_id) AS cntpendingcase, IFNULL(SUM(c.case_total_page_count), 0) AS sumreceivedpage, GROUP_CONCAT(DISTINCT c.case_id SEPARATOR ',') AS case_ids, IFNULL(SUM(crf.file_page_count), 0) AS sumdeliverypage, a.name AS accName FROM accounts a JOIN users u ON a.account_id = u.account_id AND u.is_deleted = 'N' LEFT JOIN cases c ON a.account_id = c.account_id AND u.user_id = c.client_id AND c.is_deleted = 'N' AND date(c.file_received_date) BETWEEN ?1 AND ?2 LEFT JOIN cases c1 ON a.account_id = c1.account_id AND u.user_id = c1.client_id AND c1.is_deleted = 'N' AND c.case_id = c1.case_id AND c1.cs_status IN ?8 LEFT JOIN cases c2 ON a.account_id = c2.account_id AND u.user_id = c2.client_id AND c2.is_deleted = 'N' AND c2.cs_status NOT IN ?8 AND c.case_id = c2.case_id LEFT JOIN case_result_file crf ON c.case_id = crf.case_id AND crf.is_deleted LIKE 'N' AND c.cs_status IN ?8 WHERE a.is_deleted = 'N' AND c.is_deleted LIKE 'N' AND ((IFNULL(?5, '') <> '' AND a.name LIKE CONCAT('%', ?5, '%')) OR (IFNULL(?5, '') = '' AND 1 = 1)) AND ((IFNULL(?6, '') <> '' AND a.partner_id IN (?6)) OR (IFNULL(?6, '') = '' AND 1 = 1)) AND ((IFNULL(?7, '') <> '' AND a.account_manager_id IN (?7)) OR (IFNULL(?7, '') = '' AND 1 = 1)) GROUP BY a.account_id HAVING COUNT(c.case_id) > 0 ORDER BY COUNT(DISTINCT c1.case_id) DESC LIMIT ?3,?4", nativeQuery = true)
	List<Object[]> getGroupByAccountNoOfDeliveryCaseDsec(Date fromDate, Date toDate, int startPage, int endPage,
			String psAccName, String psAccPartner, String psAccManager, List<String> csStatus);

	@Query(value = "SELECT a.account_id AS account, COUNT(DISTINCT u.user_id)AS cntuser, COUNT( DISTINCT c.case_id) AS cntcase, COUNT( DISTINCT c1.case_id) AS cntdeliveredcase, COUNT( DISTINCT c2.case_id) AS cntpendingcase, IFNULL(SUM(c.case_total_page_count), 0) AS sumreceivedpage, GROUP_CONCAT(DISTINCT c.case_id SEPARATOR ',') AS case_ids, IFNULL(SUM(crf.file_page_count), 0) AS sumdeliverypage, a.name AS accName FROM accounts a JOIN users u ON a.account_id = u.account_id AND u.is_deleted = 'N' LEFT JOIN cases c ON a.account_id = c.account_id AND u.user_id = c.client_id AND c.is_deleted = 'N' AND date(c.file_received_date) BETWEEN ?1 AND ?2 LEFT JOIN cases c1 ON a.account_id = c1.account_id AND u.user_id = c1.client_id AND c1.is_deleted = 'N' AND c.case_id = c1.case_id AND c1.cs_status IN ?8 LEFT JOIN cases c2 ON a.account_id = c2.account_id AND u.user_id = c2.client_id AND c2.is_deleted = 'N' AND c2.cs_status NOT IN ?8 AND c.case_id = c2.case_id LEFT JOIN case_result_file crf ON c.case_id = crf.case_id AND crf.is_deleted LIKE 'N' AND c.cs_status IN ?8 WHERE a.is_deleted = 'N' AND c.is_deleted LIKE 'N' AND ((IFNULL(?5, '') <> '' AND a.name LIKE CONCAT('%', ?5, '%')) OR (IFNULL(?5, '') = '' AND 1 = 1)) AND ((IFNULL(?6, '') <> '' AND a.partner_id IN (?6)) OR (IFNULL(?6, '') = '' AND 1 = 1)) AND ((IFNULL(?7, '') <> '' AND a.account_manager_id IN (?7)) OR (IFNULL(?7, '') = '' AND 1 = 1)) GROUP BY a.account_id HAVING COUNT(c.case_id) > 0 ORDER BY COUNT(DISTINCT c1.case_id) ASC LIMIT ?3,?4", nativeQuery = true)
	List<Object[]> getGroupByAccountNoOfDeliveryCaseAsc(Date fromDate, Date toDate, int startPage, int endPage,
			String psAccName, String psAccPartner, String psAccManager, List<String> csStatus);

	@Query(value = "SELECT a.account_id AS account, COUNT(DISTINCT u.user_id)AS cntuser, COUNT( DISTINCT c.case_id) AS cntcase, COUNT( DISTINCT c1.case_id) AS cntdeliveredcase, COUNT( DISTINCT c2.case_id) AS cntpendingcase, IFNULL(SUM(c.case_total_page_count), 0) AS sumreceivedpage, GROUP_CONCAT(DISTINCT c.case_id SEPARATOR ',') AS case_ids, IFNULL(SUM(crf.file_page_count), 0) AS sumdeliverypage, a.name AS accName FROM accounts a JOIN users u ON a.account_id = u.account_id AND u.is_deleted = 'N' LEFT JOIN cases c ON a.account_id = c.account_id AND u.user_id = c.client_id AND c.is_deleted = 'N' AND date(c.file_received_date) BETWEEN ?1 AND ?2 LEFT JOIN cases c1 ON a.account_id = c1.account_id AND u.user_id = c1.client_id AND c1.is_deleted = 'N' AND c.case_id = c1.case_id AND c1.cs_status IN ?8 LEFT JOIN cases c2 ON a.account_id = c2.account_id AND u.user_id = c2.client_id AND c2.is_deleted = 'N' AND c2.cs_status NOT IN ?8 AND c.case_id = c2.case_id LEFT JOIN case_result_file crf ON c.case_id = crf.case_id AND crf.is_deleted LIKE 'N' AND c.cs_status IN ?8 WHERE a.is_deleted = 'N' AND c.is_deleted LIKE 'N' AND ((IFNULL(?5, '') <> '' AND a.name LIKE CONCAT('%', ?5, '%')) OR (IFNULL(?5, '') = '' AND 1 = 1)) AND ((IFNULL(?6, '') <> '' AND a.partner_id IN (?6)) OR (IFNULL(?6, '') = '' AND 1 = 1)) AND ((IFNULL(?7, '') <> '' AND a.account_manager_id IN (?7)) OR (IFNULL(?7, '') = '' AND 1 = 1)) GROUP BY a.account_id HAVING COUNT(c.case_id) > 0 ORDER BY COUNT(DISTINCT c2.case_id) DESC LIMIT ?3,?4", nativeQuery = true)
	List<Object[]> getGroupByAccountNoOfPendingCAseDsec(Date fromDate, Date toDate, int startPage, int endPage,
			String psAccName, String psAccPartner, String psAccManager, List<String> csStatus);

	@Query(value = "SELECT a.account_id AS account, COUNT(DISTINCT u.user_id)AS cntuser, COUNT( DISTINCT c.case_id) AS cntcase, COUNT( DISTINCT c1.case_id) AS cntdeliveredcase, COUNT( DISTINCT c2.case_id) AS cntpendingcase, IFNULL(SUM(c.case_total_page_count), 0) AS sumreceivedpage, GROUP_CONCAT(DISTINCT c.case_id SEPARATOR ',') AS case_ids, IFNULL(SUM(crf.file_page_count), 0) AS sumdeliverypage, a.name AS accName FROM accounts a JOIN users u ON a.account_id = u.account_id AND u.is_deleted = 'N' LEFT JOIN cases c ON a.account_id = c.account_id AND u.user_id = c.client_id AND c.is_deleted = 'N' AND date(c.file_received_date) BETWEEN ?1 AND ?2 LEFT JOIN cases c1 ON a.account_id = c1.account_id AND u.user_id = c1.client_id AND c1.is_deleted = 'N' AND c.case_id = c1.case_id AND c1.cs_status IN ?8 LEFT JOIN cases c2 ON a.account_id = c2.account_id AND u.user_id = c2.client_id AND c2.is_deleted = 'N' AND c2.cs_status NOT IN ?8 AND c.case_id = c2.case_id LEFT JOIN case_result_file crf ON c.case_id = crf.case_id AND crf.is_deleted LIKE 'N' AND c.cs_status IN ?8 WHERE a.is_deleted = 'N' AND c.is_deleted LIKE 'N' AND ((IFNULL(?5, '') <> '' AND a.name LIKE CONCAT('%', ?5, '%')) OR (IFNULL(?5, '') = '' AND 1 = 1)) AND ((IFNULL(?6, '') <> '' AND a.partner_id IN (?6)) OR (IFNULL(?6, '') = '' AND 1 = 1)) AND ((IFNULL(?7, '') <> '' AND a.account_manager_id IN (?7)) OR (IFNULL(?7, '') = '' AND 1 = 1)) GROUP BY a.account_id HAVING COUNT(c.case_id) > 0 ORDER BY COUNT(DISTINCT c2.case_id) ASC LIMIT ?3,?4", nativeQuery = true)
	List<Object[]> getGroupByAccountNoOfPendingCAseAsc(Date fromDate, Date toDate, int startPage, int endPage,
			String psAccName, String psAccPartner, String psAccManager, List<String> csStatus);

	@Query(value = "SELECT a.account_id AS account, COUNT(DISTINCT u.user_id)AS cntuser, COUNT( DISTINCT c.case_id) AS cntcase, COUNT( DISTINCT c1.case_id) AS cntdeliveredcase, COUNT( DISTINCT c2.case_id) AS cntpendingcase, IFNULL(SUM(c.case_total_page_count), 0) AS sumreceivedpage, GROUP_CONCAT(DISTINCT c.case_id SEPARATOR ',') AS case_ids, IFNULL(SUM(crf.file_page_count), 0) AS sumdeliverypage, a.name AS accName FROM accounts a JOIN users u ON a.account_id = u.account_id AND u.is_deleted = 'N' LEFT JOIN cases c ON a.account_id = c.account_id AND u.user_id = c.client_id AND c.is_deleted = 'N' AND date(c.file_received_date) BETWEEN ?1 AND ?2 LEFT JOIN cases c1 ON a.account_id = c1.account_id AND u.user_id = c1.client_id AND c1.is_deleted = 'N' AND c.case_id = c1.case_id AND c1.cs_status IN ?8 LEFT JOIN cases c2 ON a.account_id = c2.account_id AND u.user_id = c2.client_id AND c2.is_deleted = 'N' AND c2.cs_status NOT IN ?8 AND c.case_id = c2.case_id LEFT JOIN case_result_file crf ON c.case_id = crf.case_id AND crf.is_deleted LIKE 'N' AND c.cs_status IN ?8 WHERE a.is_deleted = 'N' AND c.is_deleted LIKE 'N' AND ((IFNULL(?5, '') <> '' AND a.name LIKE CONCAT('%', ?5, '%')) OR (IFNULL(?5, '') = '' AND 1 = 1)) AND ((IFNULL(?6, '') <> '' AND a.partner_id IN (?6)) OR (IFNULL(?6, '') = '' AND 1 = 1)) AND ((IFNULL(?7, '') <> '' AND a.account_manager_id IN (?7)) OR (IFNULL(?7, '') = '' AND 1 = 1)) GROUP BY a.account_id HAVING COUNT(c.case_id) > 0  ORDER BY sumreceivedpage DESC LIMIT ?3,?4", nativeQuery = true)
	List<Object[]> getGroupByAccountReceivedPageCountDesc(Date fromDate, Date toDate, int startPage, int endPage,
			String psAccName, String psAccPartner, String psAccManager, List<String> csStatus);

	@Query(value = "SELECT a.account_id AS account, COUNT(DISTINCT u.user_id)AS cntuser, COUNT( DISTINCT c.case_id) AS cntcase, COUNT( DISTINCT c1.case_id) AS cntdeliveredcase, COUNT( DISTINCT c2.case_id) AS cntpendingcase, IFNULL(SUM(c.case_total_page_count), 0) AS sumreceivedpage, GROUP_CONCAT(DISTINCT c.case_id SEPARATOR ',') AS case_ids, IFNULL(SUM(crf.file_page_count), 0) AS sumdeliverypage, a.name AS accName FROM accounts a JOIN users u ON a.account_id = u.account_id AND u.is_deleted = 'N' LEFT JOIN cases c ON a.account_id = c.account_id AND u.user_id = c.client_id AND c.is_deleted = 'N' AND date(c.file_received_date) BETWEEN ?1 AND ?2 LEFT JOIN cases c1 ON a.account_id = c1.account_id AND u.user_id = c1.client_id AND c1.is_deleted = 'N' AND c.case_id = c1.case_id AND c1.cs_status IN ?8 LEFT JOIN cases c2 ON a.account_id = c2.account_id AND u.user_id = c2.client_id AND c2.is_deleted = 'N' AND c2.cs_status NOT IN ?8 AND c.case_id = c2.case_id LEFT JOIN case_result_file crf ON c.case_id = crf.case_id AND crf.is_deleted LIKE 'N' AND c.cs_status IN ?8 WHERE a.is_deleted = 'N' AND c.is_deleted LIKE 'N' AND ((IFNULL(?5, '') <> '' AND a.name LIKE CONCAT('%', ?5, '%')) OR (IFNULL(?5, '') = '' AND 1 = 1)) AND ((IFNULL(?6, '') <> '' AND a.partner_id IN (?6)) OR (IFNULL(?6, '') = '' AND 1 = 1)) AND ((IFNULL(?7, '') <> '' AND a.account_manager_id IN (?7)) OR (IFNULL(?7, '') = '' AND 1 = 1)) GROUP BY a.account_id HAVING COUNT(c.case_id) > 0  ORDER BY sumreceivedpage ASC LIMIT ?3,?4", nativeQuery = true)
	List<Object[]> getGroupByAccountReceivedPageCountAsc(Date fromDate, Date toDate, int startPage, int endPage,
			String psAccName, String psAccPartner, String psAccManager, List<String> csStatus);

	@Query(value = "SELECT a.account_id AS account, COUNT(DISTINCT u.user_id)AS cntuser, COUNT( DISTINCT c.case_id) AS cntcase, COUNT( DISTINCT c1.case_id) AS cntdeliveredcase, COUNT( DISTINCT c2.case_id) AS cntpendingcase, IFNULL(SUM(c.case_total_page_count), 0) AS sumreceivedpage, GROUP_CONCAT(DISTINCT c.case_id SEPARATOR ',') AS case_ids, IFNULL(SUM(crf.file_page_count), 0) AS sumdeliverypage, a.name AS accName FROM accounts a JOIN users u ON a.account_id = u.account_id AND u.is_deleted = 'N' LEFT JOIN cases c ON a.account_id = c.account_id AND u.user_id = c.client_id AND c.is_deleted = 'N' AND date(c.file_received_date) BETWEEN ?1 AND ?2 LEFT JOIN cases c1 ON a.account_id = c1.account_id AND u.user_id = c1.client_id AND c1.is_deleted = 'N' AND c.case_id = c1.case_id AND c1.cs_status IN ?8 LEFT JOIN cases c2 ON a.account_id = c2.account_id AND u.user_id = c2.client_id AND c2.is_deleted = 'N' AND c2.cs_status NOT IN ?8 AND c.case_id = c2.case_id LEFT JOIN case_result_file crf ON c.case_id = crf.case_id AND crf.is_deleted LIKE 'N' AND c.cs_status IN ?8 WHERE a.is_deleted = 'N' AND c.is_deleted LIKE 'N' AND ((IFNULL(?5, '') <> '' AND a.name LIKE CONCAT('%', ?5, '%')) OR (IFNULL(?5, '') = '' AND 1 = 1)) AND ((IFNULL(?6, '') <> '' AND a.partner_id IN (?6)) OR (IFNULL(?6, '') = '' AND 1 = 1)) AND ((IFNULL(?7, '') <> '' AND a.account_manager_id IN (?7)) OR (IFNULL(?7, '') = '' AND 1 = 1)) GROUP BY a.account_id HAVING COUNT(c.case_id) > 0  ORDER BY sumdeliverypage DESC LIMIT ?3,?4", nativeQuery = true)
	List<Object[]> getGroupByAccountReceivedDeliveryCountDesc(Date fromDate, Date toDate, int startPage, int endPage,
			String psAccName, String psAccPartner, String psAccManager, List<String> csStatus);

	@Query(value = "SELECT a.account_id AS account, COUNT(DISTINCT u.user_id)AS cntuser, COUNT( DISTINCT c.case_id) AS cntcase, COUNT( DISTINCT c1.case_id) AS cntdeliveredcase, COUNT( DISTINCT c2.case_id) AS cntpendingcase, IFNULL(SUM(c.case_total_page_count), 0) AS sumreceivedpage, GROUP_CONCAT(DISTINCT c.case_id SEPARATOR ',') AS case_ids, IFNULL(SUM(crf.file_page_count), 0) AS sumdeliverypage, a.name AS accName FROM accounts a JOIN users u ON a.account_id = u.account_id AND u.is_deleted = 'N' LEFT JOIN cases c ON a.account_id = c.account_id AND u.user_id = c.client_id AND c.is_deleted = 'N' AND date(c.file_received_date) BETWEEN ?1 AND ?2 LEFT JOIN cases c1 ON a.account_id = c1.account_id AND u.user_id = c1.client_id AND c1.is_deleted = 'N' AND c.case_id = c1.case_id AND c1.cs_status IN ?8 LEFT JOIN cases c2 ON a.account_id = c2.account_id AND u.user_id = c2.client_id AND c2.is_deleted = 'N' AND c2.cs_status NOT IN ?8 AND c.case_id = c2.case_id LEFT JOIN case_result_file crf ON c.case_id = crf.case_id AND crf.is_deleted LIKE 'N' AND c.cs_status IN ?8 WHERE a.is_deleted = 'N' AND c.is_deleted LIKE 'N' AND ((IFNULL(?5, '') <> '' AND a.name LIKE CONCAT('%', ?5, '%')) OR (IFNULL(?5, '') = '' AND 1 = 1)) AND ((IFNULL(?6, '') <> '' AND a.partner_id IN (?6)) OR (IFNULL(?6, '') = '' AND 1 = 1)) AND ((IFNULL(?7, '') <> '' AND a.account_manager_id IN (?7)) OR (IFNULL(?7, '') = '' AND 1 = 1)) GROUP BY a.account_id HAVING COUNT(c.case_id) > 0  ORDER BY sumdeliverypage ASC LIMIT ?3,?4", nativeQuery = true)
	List<Object[]> getGroupByAccountReceivedDeliveryCountAsc(Date fromDate, Date toDate, int startPage, int endPage,
			String psAccName, String psAccPartner, String psAccManager, List<String> csStatus);

	@Query(value = "SELECT IFNULL(COUNT(1), 0) FROM (SELECT IFNULL(COUNT(DISTINCT a.account_id), 0) FROM accounts a JOIN users u ON a.account_id = u.account_id AND u.is_deleted = 'N' LEFT JOIN cases c ON a.account_id = c.account_id AND u.user_id = c.client_id AND c.is_deleted = 'N' AND date(c.file_received_date) BETWEEN ?1 AND ?2 LEFT JOIN cases c1 ON a.account_id = c1.account_id AND u.user_id = c1.client_id AND c1.is_deleted = 'N' AND c.case_id = c1.case_id AND c1.cs_status IN ?6 LEFT JOIN cases c2 ON a.account_id = c2.account_id AND u.user_id = c2.client_id AND c2.is_deleted = 'N' AND c2.cs_status NOT IN ?6 AND c.case_id = c2.case_id WHERE a.is_deleted = 'N' AND c.is_deleted LIKE 'N' AND ((IFNULL(?3, '') <> '' AND a.name LIKE CONCAT('%', ?3, '%')) OR (IFNULL(?3, '') = '' AND 1 = 1)) AND ((IFNULL(?4, '') <> '' AND a.partner_id IN (?4)) OR (IFNULL(?4, '') = '' AND 1 = 1)) AND ((IFNULL(?5, '') <> '' AND a.account_manager_id IN (?5)) OR (IFNULL(?5, '') = '' AND 1 = 1)) GROUP BY a.account_id ORDER BY COUNT(c.case_id) DESC) AS t1", nativeQuery = true)
	int getGroupByAccountRecordsCount(Date fromDate, Date toDate, String psAccName, String psAccPartner,
			String psAccManager, List<String> csStatus);

	@Query("select c from Case c where c.caseCode LIKE ?1")
	List<Case> findByCaseCode(String objCode);

	@Modifying
	@Query(value = "UPDATE cases c SET c.case_total_page_count = (SELECT SUM(cf.file_page_count) FROM case_files cf WHERE cf.case_id = c.case_id AND cf.is_deleted LIKE 'N') WHERE c.case_id = ?1", nativeQuery = true)
	int totalPageCountCaseId(Long caseId);

	@Modifying
	@Query(value = "UPDATE cases c SET c.case_total_page_count = ?1 WHERE c.case_id = ?2", nativeQuery = true)
	int totalPageCountCaseId(int psPageCount, Long caseId);

	@Query(value = "SELECT IFNULL(SUM(cf.file_page_count), 0) FROM case_files cf WHERE cf.case_id = ?1 AND cf.is_deleted LIKE 'N'", nativeQuery = true)
	int totalPageCountFROMCaseFile(Long caseId);

	@Query("select c from Case c where c.deleted= 'N' and (c.parentCase.id= ?1 OR c.id = ?1)")
	List<Case> findChildAndParent(Long caseId);

	@Query(value = "select c.case_id, CONCAT_WS(' - ', c.name, c.case_code) from cases c where c.account_id IN (?1) AND c.is_deleted LIKE 'N'", nativeQuery = true)
	List<Object[]> listCaseIdNameCode(List<Long> accountList);

	@Query(value = "select DISTINCT c.case_id,concat_ws('-',c.name,c.case_code) from cases c\r\n"
			+ "LEFT JOIN case_production cp ON c.case_id = cp.case_id\r\n"
			+ "LEFT join prod_assignee_flow paf  on cp.production_id = paf.production_id\r\n" + "LEFT join (\r\n"
			+ " SELECT\r\n"
			+ " DISTINCT cp.production_id,  SUBSTRING_INDEX(SUBSTRING_INDEX(cp.production_status, ',', numbers.n), ',', -1) AS production_status\r\n"
			+ " FROM case_production cp\r\n"
			+ " JOIN (SELECT @rownum\\:= @rownum + 1 AS n FROM accounts t, (SELECT @rownum\\:= 0) r LIMIT 0, 500) AS numbers ON CHAR_LENGTH(cp.production_status) - CHAR_LENGTH(REPLACE(cp.production_status, ',', '')) >= numbers.n-1\r\n"
			+ " ) AS cp1 ON cp1.production_id = cp.production_id\r\n"
			+ "where (IFNULL(cp1.production_id, '') <> ''  and cp1.production_status in(?1) and paf.assignee in(?2) and cp.is_deleted= ?3) and c.is_deleted=?3", nativeQuery = true)
	List<Object[]> findCaseNameForQMbyStatusBasedForproduction(List<String> ProductionStatus, Long user,
			char isDeleted);

	@Query(value = "select DISTINCT c.case_id,concat_ws('-',c.name,c.case_code) from cases c\r\n"
			+ "LEFT JOIN case_tasks ct ON ct.case_id = c.case_id\r\n" + "LEFT join (\r\n" + "SELECT\r\n"
			+ "DISTINCT ct.case_task_id, SUBSTRING_INDEX(SUBSTRING_INDEX(ct.status, ',', numbers.n), ',', -1) AS status\r\n"
			+ "FROM case_tasks ct\r\n"
			+ "JOIN (SELECT @rownum\\:= @rownum + 1 AS n FROM accounts t, (SELECT @rownum\\:= 0) r LIMIT 0, 500) AS numbers  ON CHAR_LENGTH(ct.status) - CHAR_LENGTH(REPLACE(ct.status, ',', '')) >= numbers.n-1\r\n"
			+ ") AS ct1 ON ct1.case_task_id=ct.case_task_id and ct1.status in (?1)\r\n"
			+ "where (IFNULL(ct.case_id, '') <> '' and ct1.status in(?1) and ct.assigned_to in(?2) and ct.is_deleted= ?3) and c.is_deleted=?3", nativeQuery = true)
	List<Object[]> findCaseNameForQMbyStatusBasedForcaseTask(List<String> CaseTaskStatus, Long user, char isDeleted);

	@Query(value = "select c.case_id, CONCAT_WS(' - ', c.name, c.case_code) from cases c where c.is_deleted = ?1 order by c.created_date desc", nativeQuery = true)
	List<Object[]> listCasesfornonCom(char isDeleted);

	@Query("select c from Case c where c.client.id=?1 and c.deleted='N'")
	List<Case> findByClientId(Long client);

	@Query("select c from Case c where c.deleted = ?1 and c.account = ?2")
	List<Case> findCasesByAccount(char isDeleted, Account account);
	
	//Call Procedure for insert Case
	@Procedure("save_cases")
	Long save_cases(
			@Param("case_id") Long case_id,
			@Param("action") String action,
			@Param("delay_reasons") String delay_reasons,
			@Param("modified_by") Long modified_by,
			@Param("created_by") Long created_by,
			@Param("account_id") Long account_id,
			@Param("client_id") Long client_id,
			@Param("name") String name,
			@Param("is_file_downloaded") Character is_file_downloaded,
			@Param("type") String type,
			@Param("optlock_version") Integer optlock_version,
			@Param("assigned_to") Long assigned_to,
			@Param("job_id") Long job_id,
			@Param("parent_case_id") Long parent_case_id,
			@Param("case_total_page_count") Integer integer,
			@Param("total_approved_hours") Long total_approved_hours,
			@Param("total_deviation_hours") Long total_deviation_hours,
			@Param("total_discount_hours") Long total_discount_hours,
			@Param("total_estimate_hours") Long  total_estimate_hours,
			@Param("total_indirect_hours") Long total_indirect_hours,
			@Param("total_invoice_hours") Long total_invoice_hours,
			@Param("total_production_hours") Long total_production_hours,
			@Param("production_status") Long production_status,
			@Param("balance_due") Float balance_due,
			@Param("depsum_pages") Integer depsum_pages,
			@Param("download_count") Integer download_count,
			@Param("custom_hours_1") Integer custom_hours_1,
			@Param("custom_hours_2") Integer custom_hours_2,
			@Param("custom_hours_3") Integer custom_hours_3,
			@Param("custom_number_1") Integer custom_number_1,
			@Param("custom_number_2") Integer custom_number_2,
			@Param("custom_number_3") Integer custom_number_3,
			@Param("custom_long_text_1") String custom_long_text_1,
			@Param("custom_long_text_2") String custom_long_text_2,
			@Param("custom_long_text_3") String custom_long_text_3,
			@Param("client_priority") String client_priority,
			@Param("client_status") String client_status,
			@Param("cs_priority") String cs_priority,
			@Param("cs_status") String cs_status,
			@Param("prefix_case_id") String prefix_case_id,
			@Param("case_sub_type") String case_sub_type,
			@Param("expedited_date") Calendar calendar,
			@Param("case_code") String case_code,
			@Param("service_requested_shortcode") String service_requested_shortcode,
			@Param("custom_text_1") String custom_text_1,
			@Param("custom_text_2") String custom_text_2,
			@Param("custom_text_3") String custom_text_3,
			@Param("is_demand") String is_demand,
			@Param("is_customer_downloaded") String is_customer_downloaded,
			@Param("is_deleted") Character is_deleted,
			@Param("expedited_request") Character expedited_request,
			@Param("estimate_request") Character estimate_request,
			@Param("bates_reference") Character bates_reference,
			@Param("is_invoiced") Character is_invoiced,
			@Param("pdf_reference") Character pdf_reference,
			@Param("custom_char_1") Character custom_char_1,
			@Param("custom_char_2") Character custom_char_2,
			@Param("custom_char_3") Character custom_char_3,
			@Param("created_date") DateTime created_date,
			@Param("modified_date") DateTime modified_date,
			@Param("expedited_delivery_date") Calendar expedited_delivery_date,
			@Param("file_delivery_date") Calendar file_delivery_date,
			@Param("file_migration_date") Calendar file_migration_date,
			@Param("file_received_date") Calendar file_received_date,
			@Param("production_delivery_date") Calendar production_delivery_date,
			@Param("production_end_date") Calendar production_end_date,
			@Param("production_start_date") Calendar production_start_date,
			@Param("date_of_clarrification") Calendar date_of_clarrification,
			@Param("estimate_approved_date") Calendar estimate_approved_date,
			@Param("estimate_provision_date") Calendar estimate_provision_date,
			@Param("add_rec_date") Date date,
			@Param("cs_estimate_send_date") Calendar cs_estimate_send_date,
			@Param("production_estimate_send_date") Calendar production_estimate_send_date,
			@Param("estimate_approval_received_date") Calendar estimate_approval_received_date,
			@Param("revised_estimate_send_date") Calendar revised_estimate_send_date,
			@Param("cs_delivery_date") Calendar cs_delivery_date,
			@Param("downloaded_date_time") Calendar downloaded_date_time,
			@Param("custom_date_1") Calendar custom_date_1,
			@Param("custom_date_2") Calendar custom_date_2,
			@Param("custom_date_3") Calendar custom_date_3,
			@Param("custom_date_4") Calendar custom_date_4,
			@Param("custom_date_5") Calendar custom_date_5,
			@Param("custom_date_6") Calendar custom_date_6,
			@Param("custom_date_7") Calendar custom_date_7,
			@Param("custom_date_8") Calendar custom_date_8,
			@Param("case_overview") String case_overview,
			@Param("client_notes") String client_notes,
			@Param("cs_notes") String cs_notes,
			@Param("expedited_request_reason") String expedited_request_reason,
			@Param("case_contact_email_id") String case_contact_email_id,
			@Param("case_contact_name") String case_contact_name,
			@Param("cs_description") String cs_description);
	
	@Modifying
	@Query(value = "UPDATE Case c SET c.contactName = ?2 WHERE c.id = ?1")
	int updateCaseContatcNameByCaseID(Long caseId, String contactName);
	
	@Query("select c from Case c where c.deleted= 'N' and c.parentCase= ?1")
	List<Case> findByParentCase(Case caseId);
	
	@Query(value = "select c.* from cases c WHERE IFNULL(c.parent_case_id, '') <> '' and c.parent_case_id = ?1", nativeQuery = true)
	List<Object[]> getCaseListByParentCaseId(Long parent_case_id);
	
	@Query("select c from Case c where c.deleted= 'N' and c.client.id= ?1")
	List<Case> findByParentCaseClient(Long client);

	
}
