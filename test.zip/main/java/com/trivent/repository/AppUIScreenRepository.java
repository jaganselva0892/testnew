package com.trivent.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.trivent.models.AppUIScreen;

/**
 * @FileName 	:
 *				AppUIScreenRepository.java
 * @ClassName 	:
 * 				AppUIScreenRepository
 * @DateAndTime :
 *				Feb 2, 2018 - 6:29:18 PM
 * 
 * @Author 		:
 * 				karthi
 * 
 * @Description : Fetch Application UI Screen Related Native Query Implemented
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public interface AppUIScreenRepository extends JpaRepository<AppUIScreen, Long> {

  @Query("select a from AppUIScreen a where a.screenName = ?1 and a.screenType  = ?2 and a.role.id = ?3")
  AppUIScreen findByScreenNameTypeAndRole(String screenName, String screenType, Long roleId);

  @Query("select a from AppUIScreen a JOIN FETCH a.role JOIN FETCH a.appDbScreenName where a.deleted = ?1 order by a.appDbScreenName, a.screenType, a.role.id")
  List<AppUIScreen> listAppUIScreens(char isDeleted);
  
  @Query("select a from AppUIScreen a where a.appDbScreenName.id = ?1 and a.screenType  = ?2 and a.role.id = ?3")
  AppUIScreen findByScreenNameTypeAndRole(Long screenName, String screenType, Long roleId);
  
  @Query("select a from AppUIScreen a where a.appDbScreenName.id = ?1 and a.screenType  = ?2 and a.role.id = ?3")
  AppUIScreen findByScreenId(Long screenName, String screenType, Long roleId);
  
  @Query("select a from AppUIScreen a where a.appDbScreenName.id = ?1 and a.screenType  = ?2 and a.role.id = ?3")
  List<AppUIScreen> findByScreenNameTypeAndRoleUpdate(Long screenName, String screenType, Long roleId);

}
