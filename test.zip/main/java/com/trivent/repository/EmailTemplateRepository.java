package com.trivent.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.trivent.models.EmailTemplate;

/**
 * @FileName 	:
 *				EmailTemplateRepository.java
 * @ClassName 	:
 * 				EmailTemplateRepository
 * @DateAndTime :
 *				Feb 2, 2018 - 6:56:26 PM
 * 
 * @Author 		:
 * 				karthi
 * 
 * @Description : Fetch Email Template Related Native Query Implemented
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public interface EmailTemplateRepository extends JpaRepository<EmailTemplate, Long> {

	List<EmailTemplate> findByCode(String code);

	@Query("FROM EmailTemplate e LEFT JOIN FETCH e.partner ep LEFT JOIN FETCH ep.createdBy ecb LEFT JOIN FETCH ep.lastModifiedBy emb where e.id = ?1")
	List<EmailTemplate> getEmailTemplateById(Long emailTemplateId);

}
