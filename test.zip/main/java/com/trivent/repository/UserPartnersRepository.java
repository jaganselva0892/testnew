package com.trivent.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.trivent.models.Partner;
import com.trivent.models.User;
import com.trivent.models.UserPartners;

/**
 * @FileName 	:
 *				UserPartnersRepository.java
 * @ClassName 	:
 * 				UserPartnersRepository
 * @DateAndTime :
 *				Feb 2, 2018 - 7:10:05 PM
 * 
 * @Author 		:
 * 				karthi
 * 
 * @Description : Fetch User Partner Related Native Query Implemented
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public interface UserPartnersRepository extends JpaRepository<UserPartners, Long> {

	Page<UserPartners> findAll(Specification<UserPartners> specification, Pageable constructPageSpecification);

	List<UserPartners> findAll(Specification<UserPartners> specification);

	@Query("from UserPartners up JOIN FETCH up.user u JOIN FETCH up.partner p LEFT JOIN FETCH u.role r LEFT JOIN FETCH u.account a LEFT JOIN FETCH u.team t JOIN FETCH u.userProfile uup WHERE (up.user IN (?1) OR up.partner IN (?3)) and up.deleted = ?2")
	List<UserPartners> findAll(List<User> userList, char isDeleted, List<Partner> partnerList);

}
