package com.trivent.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.trivent.models.AppUIScreenField;

/**
 * @FileName 	:
 *				AppUIScreenFieldRepository.java
 * @ClassName 	:
 * 				AppUIScreenFieldRepository
 * @DateAndTime :
 *				Feb 2, 2018 - 6:28:13 PM
 * 
 * @Author 		:
 * 				karthi
 * 
 * @Description : Fetch Application UI Screen Fields Related Native Query Implemented
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public interface AppUIScreenFieldRepository extends JpaRepository<AppUIScreenField, Long> {

  @Query("select a from AppUIScreenField a JOIN FETCH a.appUiScreen aus where a.appUiScreen.id = ?1 order by a.attributeUIColumn, a.attributeSeq")
  List<AppUIScreenField> findByAppUIScreenId(Long appUIScreenId);

}
