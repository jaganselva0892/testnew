package com.trivent.repository;

import java.util.List;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.trivent.models.CaseQueryFlag;
import com.trivent.models.User;

/**
 * @FileName : CaseQueryFlagRepository.java
 * @ClassName : CaseQueryFlagRepository
 * @DateAndTime : Feb 2, 2018 - 6:48:05 PM
 * 
 * @Author : karthi
 * 
 * @Description : Fetch Case Query Related Native Query Implemented
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
public interface CaseQueryFlagRepository extends JpaRepository<CaseQueryFlag, Long> {

	@Modifying
	@Query("delete from CaseQueryFlag cq where cq.caseQueryId= ?1 and cq.createdBy=?2 and cq.caseQueryFlagType=?3")
	int deleteBycaseQueryFlag(Long caseQueryId, User createdBy, String caseQueryFlagType);

	@Query("select cq from CaseQueryFlag cq where cq.caseQueryId= ?1 and cq.createdBy=?2 and cq.caseQueryFlagType=?3")
	List<CaseQueryFlag> getCaseQueryFlag(Long caseQueryId, User createdBy, String caseQueryFlagType);

	@Query("select cq from CaseQueryFlag cq where cq.caseQueryId= ?1 and cq.client=?2 and cq.deleted = ?3")
	List<CaseQueryFlag> getCaseQueryFlagReadStatus(Long caseQueryId, User client, Character isDeleted);

	@Query("select cq from CaseQueryFlag cq where cq.caseQueryId= ?1 and cq.client=?2")
	List<CaseQueryFlag> getCaseQueryFlagByCaseQueryId(Long caseQueryId, User client);

	@Query("select count(*) from CaseQueryFlag cq where cq.client=?1 and cq.caseQueryFlagType='UNREAD'")
	Integer getUnreadQueries(User userId);

	@Query("select count(*) from CaseQueryFlag cq where cq.client=?1 and cq.caseQueryFlagType='UNREAD' AND cq.caseQueryId IN (?2)")
	Integer getUnreadQueries(User userId, List<Long> psLQueryId);

	@Query("select cq from CaseQueryFlag cq where cq.caseQueryId=?1 and cq.deleted=?2")
	List<CaseQueryFlag> getCaseQueryID(Long caseQueryId, char deleted);

	List<CaseQueryFlag> findAll(Specification<CaseQueryFlag> specification);

	@Query(value = "select count(*) FROM case_query_flag cqf  where cqf.user_id = ?1 and  cqf.case_query_flag_type = 'UNREAD' and cqf.case_query_id in "
			+ "(select cq.case_query_id from case_query cq JOIN case_query_response cqr where cq.is_new_query = 'Y' and "
			+ "cq.is_deleted = 'N' and date(cq.created_date)=date(CURRENT_DATE()) and cq.query_subject LIKE CONCAT('%',?2,'%')"
			+ "and cqr.is_deleted = 'N' and cq.case_query_id = cqr.case_query_id)", nativeQuery = true)
	Integer getUnreadedQueries(User loginUser, String strPartner);

}
