package com.trivent.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.trivent.models.AppUIScreenView;

/**
 * @FileName 	:
 *				AppUIScreenViewRepository.java
 * @ClassName 	:
 * 				AppUIScreenViewRepository
 * @DateAndTime :
 *				Feb 2, 2018 - 6:30:30 PM
 * 
 * @Author 		:
 * 				karthi
 * 
 * @Description : Fetch Application UI Screen View Related Native Query Implemented
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public interface AppUIScreenViewRepository extends JpaRepository<AppUIScreenView, Long> {

  @Query("select a from AppUIScreenView a JOIN FETCH a.appUiScreen where a.appUiScreen.id = ?1 order by a.seqNo")
  List<AppUIScreenView> findByAppUIScreenId(Long appUIScreenId);

}
