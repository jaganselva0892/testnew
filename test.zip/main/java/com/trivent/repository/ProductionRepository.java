package com.trivent.repository;

import java.util.Date;
import java.util.List;

import org.joda.time.DateTime;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;

import com.trivent.models.Production;

/**
 * @FileName : ProductionRepository.java
 * @ClassName : ProductionRepository
 * @DateAndTime : Feb 2, 2018 - 7:05:49 PM
 * 
 * @Author : karthi
 * 
 * @Description : Fetch Production Related Native Query Implemented
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
public interface ProductionRepository extends JpaRepository<Production, Long> {

	List<Production> findAll(Specification<Production> specification);

	@Modifying
	@Query(value = "UPDATE case_production cdt SET cdt.complete_process = ?1 WHERE cdt.production_id = ?2", nativeQuery = true)
	int setProductionPercentageupdate(Integer completeProcess, Long productionId);

	@Query("select a from Production a where a.deleted = ?1 and a.caseId = ?2")
	Production getProductionByCaseId(Character isDeleted, Long caseId);

	@Query("select a from Production a where a.deleted = ?1 and a.caseId = ?2")
	List<Production> getProductionByCaseIdList(Character isDeleted, Long caseId);

	@Query("SELECT p FROM Production p WHERE p.caseId = ?1 AND p.deleted=?2")
	Production getProductionPercentageupdate(Long caseId, char isDeleted);

	@Query("SELECT p FROM Production p WHERE p.caseId = ?1")
	Production getProductionPercentageupdate(Long caseId);

	@Query("select caseId from Production p where p.id=?1 AND p.deleted=?2")
	Long getCaseIdByProductionId(Long prodId, char deleted);

	@Query("select p from Production p where p.deleted=?1")
	List<Production> getProductionCases(char deleted);

	@Modifying
	@Query(value = "UPDATE cases SET assigned_to = ?1 WHERE case_id = ?2", nativeQuery = true)
	int saveAssignedToAPI(Long userId, Long caseId);


	@Modifying
	@Query(value = "UPDATE case_production SET isDeliver = ?2 WHERE production_id = ?1", nativeQuery = true)
	int updateIsDeliver(Long prodId, String isDeliver);

	@Modifying
	@Query(value = "UPDATE case_production SET production_status = ?2 WHERE production_id = ?1", nativeQuery = true)
	int updateProdStatus(Long prodId, Long statusId);
	
	//Call Procedure for insert save_case_production
	@Procedure("save_case_production")
	Long save_case_production(
						@Param("production_id") Long production_id,
						@Param("action") String action,
						@Param("case_id") Long case_id,	
						@Param("production_status") Long production_status,	
						@Param("complete_process") Integer complete_process,
						@Param("optlock_version") Integer optlock_version,
						@Param("is_deleted") Character is_deleted,
						@Param("created_date") DateTime created_date,
						@Param("created_by") Long account_id,
						@Param("modified_date") DateTime modified_date,
						@Param("modified_by") Long modified_by,									
						@Param("isDeliver") String isDeliver,
						@Param("is_active") Character is_active,
						@Param("date_of_clarification") Date date_of_clarification,
						@Param("review_status") Character review_status,
						@Param("prod_delivery_date") Date date,
						@Param("case_servicereq_id") Long case_servicereq_id									
	);
}
