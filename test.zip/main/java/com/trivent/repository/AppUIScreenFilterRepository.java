package com.trivent.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.trivent.models.AppUIScreenFilter;

/**
 * @FileName 	:
 *				AppUIScreenFilterRepository.java
 * @ClassName 	:
 * 				AppUIScreenFilterRepository
 * @DateAndTime :
 *				Feb 2, 2018 - 6:28:42 PM
 * 
 * @Author 		:
 * 				karthi
 * 
 * @Description : Fetch Application Screen Filter Related Native Query Implemented
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public interface AppUIScreenFilterRepository extends JpaRepository<AppUIScreenFilter, Long> {

  @Query("select a from AppUIScreenFilter a JOIN FETCH a.appUiScreen aus where a.appUiScreen.id = ?1 order by a.filterSeq")
  List<AppUIScreenFilter> findByAppUIScreenId(Long appUIScreenId);

}
