package com.trivent.repository;

import java.util.List;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;

import com.trivent.models.Capability;

/**
 * @FileName 	:
 *				CapabilityRepository.java
 * @ClassName 	:
 * 				CapabilityRepository
 * @DateAndTime :
 *				Feb 2, 2018 - 6:33:27 PM
 * 
 * @Author 		:
 * 				karthi
 * 
 * @Description : Fetch Capability Related Native Query Implemented
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public interface CapabilityRepository extends JpaRepository<Capability, Long> {

	List<Capability> findAll(Specification<Capability> specification);

	public Capability findByName(String capabilityName);

}
