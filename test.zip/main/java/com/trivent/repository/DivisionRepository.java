package com.trivent.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.trivent.models.Division;

/**
 * @FileName 	:
 *				DivisionRepository.java
 * @ClassName 	:
 * 				DivisionRepository
 * @DateAndTime :
 *				Feb 2, 2018 - 6:55:52 PM
 * 
 * @Author 		:
 * 				karthi
 * 
 * @Description : Fetch Division Related Native Query Implemented
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public interface DivisionRepository extends JpaRepository<Division, Long> {

	@Query("select d from Division d where d.deleted = ?1 order by d.name")
	List<Division> listDivisions(char isDeleted);

	@Query("select d from Division d where d.name = ?1")
	Division findByName(String name);

	@Query("select d from Division d where d.deleted = ?1 and d.name like CONCAT('%',?2,'%') ")
	List<Division> listDivisionsbyName(char isDeleted,String name);

	Page<Division> findAll(Specification<Division> specification, Pageable constructPageSpecification);

}
