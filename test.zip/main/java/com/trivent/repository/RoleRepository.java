package com.trivent.repository;

import java.util.List;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.trivent.models.Role;

/**
 * @FileName 	:
 *				RoleRepository.java
 * @ClassName 	:
 * 				RoleRepository
 * @DateAndTime :
 *				Feb 2, 2018 - 7:07:51 PM
 * 
 * @Author 		:
 * 				karthi
 * 
 * @Description : Fetch Role Related Native Query Implemented
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public interface RoleRepository extends JpaRepository<Role, Long> {

	
	Role findByName(String roleName);
//	@Query("select r from Role r where r.name = ?1")
//	Role findByName(String roleName);

	@Query("select r from Role r where r.type = ?1")
	List<Role> findByType(String roleType);

	@Query("select r from Role r where r.name = ?1 and r.type = ?2")
	Role findByRoleNameAndType(String name, String type);

	List<Role> findAll(Specification<Role> specification);

}
