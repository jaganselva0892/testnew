package com.trivent.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;


import com.trivent.models.ProdFile;
import com.trivent.models.Production;

/**
 * @FileName : ProdFileRepository.java
 * @ClassName : ProdFileRepository
 * @DateAndTime : Feb 2, 2018 - 7:03:49 PM
 * 
 * @Author : karthi
 * 
 * @Description : Fetch Production File Related Native Query Implemented
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
public interface ProdFileRepository extends JpaRepository<ProdFile, Long> {

	Page<ProdFile> findAll(Specification<ProdFile> specification, Pageable constructPageSpecification);

	@Query("select a from ProdFile a where a.productionId = ?1 and a.deleted = ?2 order by a.createdDate desc")
	List<ProdFile> findFileByProduction(Production production, char isDeleted);

	@Query("select a from ProdFile a where a.productionId = ?1")
	List<ProdFile> findFileByProduction(Production production);

	@Modifying
	@Query("UPDATE ProdFile cdt SET cdt.isDeliverable = ?3 WHERE cdt.id = ?1 and cdt.productionId = ?2")
	int setProdcutionFileDeliveryStatus(Long fileId, Production production, Character isDelivery);

	@Modifying
	@Query("UPDATE ProdFile cdt SET cdt.deleted = ?1 WHERE cdt.id = ?2")
	int setProdcutionFiledelete(Character isDeleted, Long prodFileId);

	@Query("select a from ProdFile a where a.productionId = ?1 and a.deleted = ?2 and a.isDeliverable = ?3 order by a.createdDate desc")
	List<ProdFile> findFileByProduction(Production production, char isDeleted, Character isDelivery);

	@Modifying
	@Query(value = "UPDATE prod_files SET is_deliverable = ?2, is_delivered = ?3 WHERE prod_file_id = ?1", nativeQuery = true)
	int updateIsDeliverable(Long prodFileId, Character isDeliverable, Character isDelivered);

	List<ProdFile> findAll(Specification<ProdFile> specification);

	@Modifying
	@Query(value = "INSERT INTO prod_files (is_deleted, created_by, modified_by, created_date, modified_date, optlock_version, production_id, file_content_type, file_description, file_extension, file_location, file_name, file_page_count, file_seq_no, is_zipped, root_path, file_size, version, is_latest, is_deliverable, is_delivered) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10, ?11, ?12, ?13, ?14, ?15, ?16, ?17, ?18, ?19, ?20, ?21)", nativeQuery = true)
	void saveNewProdFile(char isDeleted, Long createdBy, Long lastModifiedBy, Date createdDate, Date lastModifiedDate,
			int optLockVersion, Long productionId, String fileContentType, String fileDescription, String fileExtension,
			String fileLocation, String fileName, int filePageCount, int fileSeqNo, char fileZipped, String rootPath,
			long fileSize, int version, char isLatest, char isDeliverable, char isDelivered);

	@Modifying
	@Query(value = "UPDATE prod_files SET is_latest = ?2, file_name = ?3 WHERE prod_file_id = ?1", nativeQuery = true)
	int setProdcutionFileupdate(Long prodFileId, Character isLatest, String fileName);

	@Modifying
	@Query(value = "UPDATE ProdFile pf SET pf.backup = ?2 WHERE pf.id=?1")
	int updateBackupStatusFileId(Long fileId, char isBackup);

	@Modifying
	@Query(value = "INSERT INTO prod_files (is_deleted, created_by, modified_by, created_date, modified_date, optlock_version, production_id, file_content_type, file_description, file_extension, file_location, file_name, file_page_count, file_seq_no, is_zipped, root_path, file_size, version, is_latest, is_deliverable, is_delivered) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10, ?11, ?12, ?13, ?14, ?15, ?16, ?17, ?18, ?19, ?20, ?21)", nativeQuery = true)
	int saveNewProdFileEntity(char isDeleted, Long createdBy, Long lastModifiedBy, Date createdDate,
			Date lastModifiedDate, int optLockVersion, Long productionId, String fileContentType,
			String fileDescription, String fileExtension, String fileLocation, String fileName, int filePageCount,
			int fileSeqNo, char fileZipped, String rootPath, long fileSize, int version, char isLatest,
			char isDeliverable, char isDelivered);

	@Modifying
	@Query(value = "UPDATE ProdFile pf SET pf.removed = ?2 WHERE pf.id=?1")
	int updateRemoveStatusFileId(Long fileId, char isRemoved);

	@Query("select a from ProdFile a where a.productionId = ?1 AND fileName = ?2")
	List<ProdFile> findFileByProdFileName(Production production, String psProdFile);

}
