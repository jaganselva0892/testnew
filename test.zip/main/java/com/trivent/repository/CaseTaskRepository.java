package com.trivent.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.trivent.models.CaseTask;

/**
 * @FileName 	:
 *				CaseTaskRepository.java
 * @ClassName 	:
 * 				CaseTaskRepository
 * @DateAndTime :
 *				Feb 2, 2018 - 6:52:22 PM
 * 
 * @Author 		:
 * 				karthi
 * 
 * @Description : Fetch Case Task Related Native Query Implemented
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public interface CaseTaskRepository extends JpaRepository<CaseTask, Long> {

	@Query("select ct from CaseTask ct JOIN FETCH ct.assignedTo where ct.clientCase.id = ?1 and ct.deleted = ?2 order by ct.createdDate desc")
	List<CaseTask> findAllByCaseId(Long caseId, Character deleted);

	@Query("select ct from CaseTask ct JOIN FETCH ct.assignedTo where (ct.assignedTo.id=?1 or ct.createdBy.id=?2) and ct.clientCase.id = ?3 and ct.deleted = ?4 and ct.parentTask is null order by ct.createdDate desc")
	List<CaseTask> findCaseTaskByParentIdNull(Long assignedTo, Long createdBy, Long caseId, Character deleted);

	Page<CaseTask> findAll(Specification<CaseTask> specification, Pageable constructPageSpecification);

	@Query("select coalesce(max(ct.seqNo), '0') from CaseTask ct where ct.clientCase.id = ?1")
	Integer findMaxByCaseId(Long caseId);

	@Modifying
	@Query("Update CaseTask ct set ct.deleted = 'Y' where ct.clientCase.id = ?1")
	int deleteCaseTaskByCaseId(Long caseId);

	@Query("select name from CaseTask ct where id=?1")
	String findTasknameById(Long taskId);

	@Query("from CaseTask ct where ct.id=?1 and ct.deleted=?2")
	CaseTask findProductionTasks(Long taskId, char deleted);

	@Query("select ct from CaseTask ct where ct.clientCase.id=?1 and ct.deleted=?2 and ct.productionId.id=?3")
	CaseTask findCaseProductionTasks(Long caseId, char deleted, Long productionId);

	@Query("select ct from CaseTask ct where ct.parentTask=?1 and ct.deleted=?2")
	List<CaseTask> findSumOfEstimateHrs(Long parentTask, char deleted);

	@Query("select ct from CaseTask ct where ct.deleted=?1 order by ct.id")
	List<CaseTask> findAllTAsks(char deleted);

	@Query("select ct from CaseTask ct where ct.parentTask is null and ct.deleted=?1")
	List<CaseTask> findnullParentTasks(char deleted);

	@Query("select ct from CaseTask ct where ct.parentTask is not null and ct.deleted=?1")
	List<CaseTask> findSubTasks(char deleted);

	@Query("select ct from CaseTask ct where ct.clientCase.id=?1 and ct.deleted=?2 and ct.parentTask is null")
	List<CaseTask> findParentTasksByCaseId(Long caseId, char deleted);

	@Query("select ct from CaseTask ct where ct.clientCase.id=?1 and ct.deleted=?2 and ct.parentTask is not null")
	List<CaseTask> findSubTasksByCaseId(Long caseId, char deleted);

	@Query("from CaseTask ct where ct.id=?1 and ct.deleted=?2")
	List<CaseTask> findTaskDetails(Long taskId, char deleted);

	@Query("from CaseTask ct where ct.deleted=?1 and ct.productionId.id=?2")
	List<CaseTask> findProductionTasks(char deleted, Long prodId);

	@Query("from CaseTask ct where ct.deleted=?1 and ct.productionId.id=?2 and ct.parentTask is null")
	List<CaseTask> findProductionParentTasks(char deleted, Long prodId);

	@Query("from CaseTask ct where ct.deleted=?1 and ct.productionId.id=?2 and ct.parentTask is not null")
	List<CaseTask> findProductionSubTasks(char deleted, Long prodId);

	@Query("select ct from CaseTask ct where ct.parentTask is not null and ct.deleted=?1 and ct.assignedTo.id=?2 and ct.createdBy.id=?3")
	List<CaseTask> findAssignedToSubTasks(char deleted, Long assignedTo, Long createdBy);

	@Query("select ct from CaseTask ct where ct.parentTask is not null and ct.deleted=?1 and ct.parentTask=?2")
	List<CaseTask> findSubTasksByTaskId(char deleted, Long parentTask);

	@Query("select ct from CaseTask ct where ct.parentTask=?1 and ct.deleted=?2")
	List<CaseTask> findSubTaskByParentId(Long taskId, char deleted);

	@Query("select ct from CaseTask ct where ct.assignedTo.id=?1 and ct.deleted=?2")
	List<CaseTask> findAssignedTasks(Long assignedTo, char deleted);

	@Modifying
	@Query("Update CaseTask ct set ct.deleted = 'Y' where ct.id = ?1")
	int deleteByCaseTaskId(Long caseTaskId);

	List<CaseTask> findAll(Specification<CaseTask> specification);
	
	@Query(value = "SELECT GROUP_CONCAT(lv SEPARATOR ',') FROM ( SELECT @pv\\:=(SELECT GROUP_CONCAT(case_task_id SEPARATOR ',') FROM case_tasks WHERE parent_task IN (@pv)) AS lv FROM case_tasks JOIN (SELECT @pv\\:=?1) tmp WHERE case_task_id IN (@pv)) a", nativeQuery = true)
	Object findChildTasksById(Long task_id);
	
	@Query("select ct.clientCase.id from CaseTask ct where ct.assignedTo.id=?1 and ct.deleted=?2 and ct.clientCase.id NOT IN ?3")
	List<Long> findAssignedTasksforQA(Long assignedTo, char deleted, List<Long> cases);
	
	@Query("select ct.clientCase.id from CaseTask ct where ct.assignedTo.id=?1 and ct.deleted=?2 and ct.clientCase IS NOT NULL")
	List<Long> findCaseIdsAssignedTasks(Long assignedTo, char deleted);
	
	@Query("select ct from CaseTask ct JOIN FETCH ct.assignedTo au JOIN FETCH ct.createdBy cu JOIN FETCH ct.lastModifiedBy mu WHERE ct.id = ?1")
	CaseTask findAllByTaskId(Long pnTaskId);

}