package com.trivent.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.trivent.models.UserProfile;

public interface UserProfileRepository  extends JpaRepository<UserProfile, Long> {

	//List<UserProfile> findAll(Specifications<UserProfile> specification);
	
	@Query(value = "SELECT up FROM UserProfile up WHERE up.user.id = ?1")
	UserProfile getProfileByUserID(Long userId);
}
