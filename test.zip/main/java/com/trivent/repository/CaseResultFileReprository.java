package com.trivent.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;


import com.trivent.constants.AppConstants;
import com.trivent.models.CaseResultFile;

/**
 * @FileName : CaseResultFileReprository.java
 * @ClassName : CaseResultFileReprository
 * @DateAndTime : Feb 2, 2018 - 6:50:10 PM
 * 
 * @Author : karthi
 * 
 * @Description : Fetch Case Result File Related Native Query Implemented
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
public interface CaseResultFileReprository extends JpaRepository<CaseResultFile, Long> {

	@Query("select cf from CaseResultFile cf where cf.deleted = ?1 order by cf.seqNo")
	List<CaseResultFile> getCaseResultFileByDeleteStatus(char isDeleted);

	@Query("select cf from CaseResultFile cf where cf.deleted = ?1 AND cf.pageCountStatus LIKE ?2 order by cf.seqNo")
	List<CaseResultFile> getCaseResultFileByDeleteStatus(char isDeleted, String pageCountStatus);

	@Query("select cf from CaseResultFile cf where cf.clientCase.id = ?1 and cf.deleted = ?2 order by cf.seqNo")
	List<CaseResultFile> findAllCaseResultFileByCaseId(Long caseId, char isDeleted);

	@Query("select cf from CaseResultFile cf where cf.clientCase.id = ?1 and cf.name = ?2 and cf.deleted = ?3 order by cf.seqNo")
	CaseResultFile getCaseResultFileNameByName(Long caseId, String fileName, char isDeleted);

	@Query("select cf from CaseResultFile cf where cf.clientCase.id = ?1 and cf.name = ?2 order by cf.seqNo")
	CaseResultFile getCaseResultFileNameByName(Long caseId, String fileName);

	@Query("select cf from CaseResultFile cf where cf.clientCase.id = ?1 and cf.deleted = ?2 order by cf.id desc")
	List<CaseResultFile> getLastCaseResultFileByCaseId(Long caseId, char isDeleted);

	@Query("select coalesce(max(cf.seqNo), '0') from CaseResultFile cf where cf.clientCase.id = ?1")
	Integer lastSeqNoByCaseId(Long caseId);

	@Modifying
	@Query(value = "UPDATE case_result_file SET replicated_file_location = ?2, replicated_type = ?3, replicated_date = NOW() WHERE case_result_file_id = ?1", nativeQuery = true)
	int updateReplicationInfoAndPageCount(Long caseFileId, String replicatedFileLocation, String replicationType);

	@Modifying
	@Query(value = "UPDATE case_result_file SET replicated_file_location = ?2, replicated_type = ?3, file_page_count  = ?4, page_count_status = ?5, replicated_date = NOW() WHERE case_result_file_id = ?1", nativeQuery = true)
	int updateReplicationInfoAndPageCount(Long caseFileId, String replicatedFileLocation, String replicationType,
			Integer pageCount, String pageCountStatus);

	@Modifying
	@Query(value = "UPDATE case_result_file SET file_name = ?2, is_latest = ?3, modified_date = NOW(), modified_by=?4 WHERE case_result_file_id = ?1", nativeQuery = true)
	int updateNameIsLatest(Long caseFileId, String name, char isLatest, Long modifiedBy);

	@Modifying
	@Query(value = "INSERT INTO case_result_file (is_deleted, file_content_type, file_location, is_zipped, file_name, file_seq_no, created_by, account_id, client_id, case_id, is_latest, replicated_file_location, version, file_size,modified_by,file_extension,root_path,optlock_version,page_count_status,production_file, created_date,modified_date, upload_remotely, cur_status, file_from) VALUES (?1,?2,?3,?4,?5,?6,?7,?8,?9,?10,?11,?12,?13,?14,?15,?16,?17,?18,?19,?20,NOW(),NOW(),?21, '"
			+ AppConstants.TRACE_NEW + "', '" + AppConstants.TRACE_FTP + "')", nativeQuery = true)
	int insertNewCaseResultFileFromRemote(char isDeleted, String fileContentType, String fileLocation, char isZipped,
			String name, int seqNo, Long createdBy, Long accountId, Long clientId, Long caseId, char isLatest,
			String replicatedFileLocation, int version, Long fileSize, Long modifiedBy, String fileExtension,
			String caseFileRootPath, int optLockVersion, String fileStatus, char productionFile, char uploadRemotely);

	@Query("select cf from CaseResultFile cf where cf.clientCase.id = ?1 and cf.deleted = ?2 order by cf.createdDate desc")
	List<CaseResultFile> getLastCaseResultFileByCaseIdDecByDate(Long caseId, char isDeleted);

	@Modifying
	@Query(value = "UPDATE case_result_file SET page_count_status = ?2, modified_date = NOW(), modified_by=?3 WHERE case_result_file_id = ?1", nativeQuery = true)
	int updateFilePageCountStatus(Long caseResultFileId, String pageCountStatus, Long modifiedBy);

	@Modifying
	@Query(value = "UPDATE case_result_file SET is_deleted = ?2 WHERE case_result_file_id = ?1", nativeQuery = true)
	int updateDelStatus(Long caseFileId, Character delStatus);

	@Query("select cf from CaseResultFile cf where cf.clientCase.id = ?1 and cf.id = ?2 and cf.deleted = ?3")
	CaseResultFile getCaseResultFileDetail(Long caseId, Long caseResultFileId, char isDeleted);

	@Query("select cf from CaseResultFile cf where cf.clientCase.id = ?1 and cf.deleted = 'N' order by cf.seqNo")
	List<CaseResultFile> CaseResultFilesAPI(Long caseId);

	@Query("select cf from CaseResultFile cf where cf.clientCase.id = ?2 and cf.deleted = ?1 and cf.id < ?3 order by cf.id desc")
	List<CaseResultFile> getLastCaseResultFileByCaseIdFileId(char isDeleted, Long caseId, Long fileId);

	@Query("select cf from CaseResultFile cf where cf.deleted = ?1 order by cf.id desc")
	List<CaseResultFile> getCaseResultFileByDeleteStatusOrderByID(char isDeleted);

	@Query("select cf from CaseResultFile cf where cf.deleted = ?1 and (date(cf.createdDate) between date(?2) and date(?3)) order by cf.id desc")
	List<CaseResultFile> getCaseResultFileByDeleteStatusOrderByID(char isDeleted, Date fromDate, Date toDate);

	@Query("select count(cf.clientCase), sum(cf.filePageCount), cf.clientCase.type FROM CaseResultFile cf JOIN cf.clientCase where date(cf.clientCase.fileDeliveryDate)=date(CURRENT_DATE()) AND cf.deleted = ?1 AND cf.clientCase.deleted= ?1 and cf.clientCase.csStatus='File Delivery' group by cf.clientCase.type having count(1) > 0")
	List<Object[]> getTodayDeliverededCasesbyDateType(char isDeleted);

	@Query("select count(cf.clientCase), sum(cf.filePageCount), cf.clientCase.type FROM CaseResultFile cf JOIN cf.clientCase where cf.deleted = ?3 AND (date(cf.clientCase.fileDeliveryDate) BETWEEN date(?1) and date(?2)) and cf.clientCase.deleted= ?3 and cf.clientCase.csStatus='File Delivery' group by cf.clientCase.type having count(1) > 0")
	List<Object[]> getTodayDeliverededCasesbyDateType(Date fromcreatedDate, Date tocreatedDate, char isDeleted);

	@Query("select count(cf.clientCase), sum(cf.filePageCount), cf.clientCase.type FROM CaseResultFile cf JOIN cf.clientCase where cf.deleted = ?1 AND date(cf.clientCase.fileDeliveryDate)=date(CURRENT_DATE()) AND cf.clientCase.deleted= ?1 and cf.clientCase.account.id=?2 and cf.clientCase.csStatus='File Delivery' group by cf.clientCase.type having count(1) > 0")
	List<Object[]> getDeliverededCasesbyPartner(char isDeleted, Long partnerId);

	@Query("select count(cf.clientCase), sum(cf.filePageCount), cf.clientCase.type FROM CaseResultFile cf JOIN cf.clientCase where cf.deleted = ?3 AND (date(cf.clientCase.fileDeliveryDate) BETWEEN date(?1) and date(?2)) and cf.clientCase.deleted= ?3 and cf.account.id=?4 and cf.clientCase.csStatus='File Delivery' group by cf.clientCase.type having count(1) > 0")
	List<Object[]> geDeliverededCasesPagesbyDateTypePartner(Date fromcreatedDate, Date tocreatedDate, char isDeleted,
			Long accountId);

	List<CaseResultFile> findAll(Specification<CaseResultFile> specification);

	Page<CaseResultFile> findAll(Specification<CaseResultFile> specification, Pageable constructPageSpecification);

	@Modifying
	@Query(value = "UPDATE CaseResultFile cf SET cf.archived = ?2 WHERE cf.id=?1")
	int updateArchivedStatusCaseResultFileId(Long fileId, char isArchived);

	@Query("select cf from CaseResultFile cf where cf.clientCase.id = ?1 order by cf.id desc")
	List<CaseResultFile> getLastCaseResultFileByCaseId(Long caseId);

	@Modifying
	@Query(value = "UPDATE case_result_file SET cur_status = ?2 WHERE case_result_file_id = ?1 AND cur_status NOT LIKE '"
			+ AppConstants.TRACE_FAILED + "'", nativeQuery = true)
	int updatecurStatus(Long caseFileId, String curStatus);

	@Modifying
	@Query(value = "UPDATE case_result_file SET cus_msg = CONCAT(ifnull(cus_msg, ''), ifnull(?2, '')) WHERE case_result_file_id = ?1", nativeQuery = true)
	int updatecurStatusMsg(Long caseFileId, String curMsg);

	@Modifying
	@Query(value = "UPDATE case_result_file SET cur_status = '" + AppConstants.TRACE_NEW
			+ "' WHERE case_result_file_id = ?1", nativeQuery = true)
	int updatecurStatusNew(Long caseFileId);

	@Modifying
	@Query(value = "UPDATE CaseResultFile cf SET cf.backup = ?2 WHERE cf.id=?1")
	int updateBackupStatusFileId(Long fileId, char isBackup);

	@Modifying
	@Query(value = "UPDATE CaseResultFile cf SET cf.removeFile = ?2 WHERE cf.id=?1")
	int updateRemoveStatusFileId(Long fileId, char isBackup);

	@Query("FROM CaseResultFile crf WHERE crf.deleted = ?1 AND crf.curStatus NOT LIKE ?2 AND date(crf.createdDate) > date(?3) AND IFNULL(crf.curMsg, '') <> '' AND (crf.curMsg NOT LIKE '%File Size is not Match%' AND crf.curMsg NOT LIKE '%cannot find%' AND crf.curMsg NOT LIKE  '%No such file%' AND crf.curMsg NOT LIKE  '%No such directory%')")
	List<CaseResultFile> getFilesByCurStatus(char isDeleted, String psCusrStatus, Date createdDate);

	@Query("select cf from CaseResultFile cf where cf.clientCase.id = ?1 and cf.id = ?2 and cf.deleted = 'N'")
	CaseResultFile getCaseResultFileDetail(Long caseId, Long caseResultFileId);
}
