package com.trivent.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.trivent.models.AppItem;
import com.trivent.models.AppSubItem;

/**
 * @FileName 	:
 *				AppSubItemRepository.java
 * @ClassName 	:
 * 				AppSubItemRepository
 * @DateAndTime :
 *				Feb 2, 2018 - 6:27:29 PM
 * 
 * @Author 		:
 * 				karthi
 * 
 * @Description : Fetch Application SunItem Related Native Query implemented
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public interface AppSubItemRepository extends JpaRepository<AppSubItem, Long> {

	@Query("select si from AppSubItem si JOIN FETCH si.appItem where si.appItem.id = ?1 order by si.seqNo")
	List<AppSubItem> findByItemId(Long appItemId);
	
	@Query("select si from AppSubItem si JOIN FETCH si.appItem where si.appItem.id = ?1")
	List<AppSubItem> findByItemIdSame(Long appItemId);

	@Query("select si from AppSubItem si where si.longName = ?1 and si.appItem.id = ?2")
	AppSubItem findByLongName(String longName, Long itemId);

	@Query("select si from AppSubItem si where si.shortName = ?1 and si.appItem.id = ?2")
	AppSubItem findByShortName(String shortName, Long itemId);

	@Query("select si from AppSubItem si JOIN FETCH si.appItem where si.appItem.id = ?1 order by si.longName asc")
	List<AppSubItem> findBySubItemNameAsc(Long appItemId);

	@Query("select si from AppSubItem si JOIN FETCH si.appItem where si.appItem.id = ?1 order by si.longName desc")
	List<AppSubItem> findBySubItemNameDesc(Long appItemId);

	@Query("select si from AppSubItem si where si.appItem.id=?1")
	List<AppSubItem> FindSubITems(Long appItemId);

	@Query("select si from AppSubItem si  where si.appList.id = ?1 and si.appItem = ?2")
	List<AppSubItem> findByListId(Long appListId, AppItem appItemId);

	@Query("select si from AppSubItem si where  si.id = ?1")
	AppSubItem findById(Long subItemId);

	@Query("select si from AppSubItem si where  si.appList.id = ?1 and si.shortName=?2")
	List<AppSubItem> findShortNameByListId(Long appListId,String shortName);
	
	@Query("select si from AppSubItem si where si.longName=?1 and si.shortName=?2")
	List<AppSubItem> FindSubITemsByLongShortName(String longName,String shortName);
	
	@Query("select si from AppSubItem si where  si.appList.id = ?1 and si.shortName=?2")
	List<AppSubItem> findShortNameByListIdGroubBy(Long appListId,String shortName);
	
	@Query("select si from AppSubItem si where  si.appList.id = ?1")
	List<AppSubItem> findByListId(Long appListId);
}
