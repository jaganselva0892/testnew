package com.trivent.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.trivent.models.CaseQueryResponse;

/**
 * @FileName : CaseQueryResponseRepository.java
 * @ClassName : CaseQueryResponseRepository
 * @DateAndTime : Feb 2, 2018 - 6:49:05 PM
 * 
 * @Author : karthi
 * 
 * @Description : Fetch Case Query Response Related Native Query Implemented
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
public interface CaseQueryResponseRepository extends JpaRepository<CaseQueryResponse, Long> {

	List<CaseQueryResponse> findAll(Specification<CaseQueryResponse> specification);

	@Query("select cq from CaseQueryResponse cq where cq.caseQuery.id = ?1 and cq.deleted = ?2 order by cq.createdDate desc")
	List<CaseQueryResponse> findAllByCaseQueryId(Long caseQueryId, Character isDeleted);

	@Query("select cq from CaseQueryResponse cq where cq.caseQuery.id = ?1 and cq.isVisible2Client = ?2 and cq.deleted = ?3 order by cq.createdDate desc")
	List<CaseQueryResponse> findAllByCaseQueryIdForCustomer(Long caseQueryId, Character isVisible2Client,
			Character isDeleted);

	@Query("select cq from CaseQueryResponse cq where cq.caseQuery.id = ?1 and cq.isInternal = ?2 and cq.deleted = ?3 order by cq.createdDate desc")
	List<CaseQueryResponse> findAllByCaseQueryIdForInternal(Long caseQueryId, Character isInternal,
			Character isDeleted);

	@Query("select coalesce(max(cq.seqNo), '0') from CaseQueryResponse cq where cq.caseQuery.id = ?1")
	Integer getNextResponseSeqNoByCaseQueryId(Long caseQueryId);

	@Query("select cq from CaseQueryResponse cq where cq.caseQuery.id = ?1 Order by cq.createdDate desc")
	List<CaseQueryResponse> getCaseQueryResponceVOByMaxSeqNo(Long caseQueryId);

	@Query("select count(*) from CaseQueryResponse cq where date(cq.createdDate)=curdate() and cq.ownerRoleType ='Customer' and cq.clientCase is null and cq.deleted= ?1 ")
	Object[] listTodaysQueryResponses(char isDeleted);

	@Query("select count(*) from CaseQueryResponse cq where (date(cq.createdDate) between ?1 and ?2) and cq.ownerRoleType ='Customer' and cq.clientCase is null and cq.deleted= ?3 ")
	Object[] lisQueryResponsesbyDate(Date fromCreatedDate, Date toCreatedDate, char isDeleted);

	@Query("select count(*) from CaseQueryResponse cq where date(cq.createdDate)=curdate()and cq.ownerRoleType='Customer' and cq.clientCase is not null and not cq.clientCase='' and cq.deleted= ?1 ")
	Object[] listTodaysCaseBasedQueryResponses(char isDeleted);

	@Query("select count(*) from CaseQueryResponse cq where (date(cq.createdDate) between ?1 and ?2) and cq.ownerRoleType='Customer' and cq.clientCase is not null and not cq.clientCase='' and cq.deleted= ?3 ")
	Object[] listCaseBasedQueryResponsesByDate(Date fromCreatedDate, Date toCreatedDate, char isDeleted);

	@Query("select cq from CaseQueryResponse cq where cq.caseQuery.id = ?1 and cq.deleted = 'N' and cq.isVisible2Client = 'Y' order by cq.id")
	List<CaseQueryResponse> CaseQueryDetailAPI(Long caseQueryId);

	@Query("select cq from CaseQueryResponse cq where cq.caseQuery.id = ?1 and cq.deleted = 'N' order by cq.id")
	List<CaseQueryResponse> CaseCsQueryDetailAPI(Long caseQueryId);

	@Query("select cq from CaseQueryResponse cq where cq.caseQuery.id = ?1 Order by cq.createdDate asc")
	List<CaseQueryResponse> getCaseQueryResponceVOByMaxSeqNoASC(Long caseQueryId);

	/*
	 * @Query("select cq.caseQuery.id from CaseQueryResponse cq where cq.id = ?1 and cq.deleted = 'N' order by cq.id"
	 * ) long CaseQueryIDForGlobalSearch(Long caseQueryResId);
	 */

	@Query("select cq.caseQuery.id from CaseQueryResponse cq where cq.id in (?1) and cq.deleted = 'N' order by cq.id")
	List<Long> CaseQueryIDForGlobalSearch(List<Long> caseQueryResId);

	@Query("select cq from CaseQueryResponse cq where cq.caseQuery.id = ?1 and (date(cq.createdDate) between ?2 and ?3) Order by cq.createdDate asc")
	List<CaseQueryResponse> getCaseQueryResponceVOByMaxSeqNoASCbtwnDate(Long caseQueryId, Date fromDate, Date toDate);

	@Query("select cq.queryDetails from CaseQueryResponse cq where cq.id = ?1 and cq.deleted = 'N'")
	String getExistingMeassage(Long queryResponseID);

	@Query("select cq.caseQuery.id from CaseQueryResponse cq where cq.id in ?1 and cq.deleted = 'N'")
	Long getCaseQueryId(Long queryResponseID);

	@Query("select cq from CaseQueryResponse cq where cq.caseQuery.id = ?1 and cq.deleted = ?2 order by cq.lastModifiedDate desc")
	List<CaseQueryResponse> getCaseQueryListOrderByModifiedDate(Long caseQueryId, Character isDeleted);

	@Query("select cq from CaseQueryResponse cq where cq.caseQuery.id = ?1 and cq.deleted = ?2 order by cq.createdDate asc")
	List<CaseQueryResponse> findAllByCaseQueryIdForQm(Long caseQueryId, Character isDeleted);

	@Query("select cq from CaseQueryResponse cq where cq.caseQuery.id = ?1 and cq.deleted = ?2 and cq.isQiNotify = ?3 order by cq.createdDate desc")
	List<CaseQueryResponse> findAllByCaseQueryIdAndisQiNotify(Long caseQueryId, Character isDeleted,
			Character isQiNotify);
	
	@Query("select cq from CaseQueryResponse cq where cq.caseQuery.id = ?1 and cq.deleted = ?2 and cq.isAppreciationNotify = ?3 order by cq.createdDate desc")
	List<CaseQueryResponse> findAllByCaseQueryIdAndisAppreciatonNotify(Long caseQueryId, Character isDeleted,
			Character isQiNotify);
}
