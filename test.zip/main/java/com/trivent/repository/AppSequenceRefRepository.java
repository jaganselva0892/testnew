package com.trivent.repository;

import org.joda.time.DateTime;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;

import com.trivent.models.AppSequenceRef;

/**
 * @FileName 	:
 *				AppSequenceRefRepository.java
 * @ClassName 	:
 * 				AppSequenceRefRepository
 * @DateAndTime :
 *				Feb 2, 2018 - 6:26:03 PM
 * 
 * @Author 		:
 * 				karthi
 * 
 * @Description : Fetch Application Sequencse Ref Related Native Query Implemented
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public interface AppSequenceRefRepository extends JpaRepository<AppSequenceRef, Long> {

  @Query("from AppSequenceRef ref where ref.objType = ?1 and ref.objCode = ?2")
  AppSequenceRef getSequenceRefByTypeAndCode(String objType, String objCode);
  
  @Modifying
  @Query(value = "UPDATE AppSequenceRef a SET a.optLockVersion = ?2,a.objCode = ?3,a.objCodeSeq = ?4,a.objType = ?5 WHERE a.id = ?1")
 int updateAppSequenceRefbyID(Long app_sequence_ref_id,Integer optlock_version,String object_code, Integer object_code_sequence,String object_type);
  
  
  //Call Procedure for insert save_app_sequence_ref
  @Procedure("save_app_sequence_ref")
  Long save_app_sequence_ref_procedure(
				@Param("app_sequence_ref_id") Long app_sequence_ref_id,
				@Param("action") String action,
				@Param("created_date") DateTime created_date,
				@Param("modified_date") DateTime modified_date,
				@Param("optlock_version") Integer optlock_version,
				@Param("object_code") String object_code,
				@Param("object_code_sequence") Integer object_code_sequence,
				@Param("object_type") String object_type,
				@Param("created_by") Long created_by,
				@Param("modified_by") Long modified_by
	);

}
