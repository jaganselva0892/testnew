package com.trivent.repository;

import java.util.Date;
import java.util.List;

import org.joda.time.DateTime;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;

import com.trivent.models.CaseServiceReq;

/**
 * @FileName : CaseServiceReqRepository.java
 * @ClassName : CaseServiceReqRepository
 * @DateAndTime : Feb 2, 2018 - 6:50:44 PM
 * 
 * @Author : karthi
 * 
 * @Description : Fetch Case Service Request Related Native Query Implemented
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
public interface CaseServiceReqRepository extends JpaRepository<CaseServiceReq, Long> {

	List<CaseServiceReq> findAll(Specification<CaseServiceReq> specification);

	Page<CaseServiceReq> findAll(Specification<CaseServiceReq> specification, Pageable constructPageSpecification);

	@Query("select csr from CaseServiceReq csr where csr.clientCase.id = ?1 and csr.deleted= ?2 order by csr.seqNo")
	List<CaseServiceReq> findAllByCaseId(Long caseId, Character isDeleted);

	@Query("select csr from CaseServiceReq csr where csr.serviceName = ?1 and csr.clientCase.id = ?2 and csr.deleted= ?3")
	CaseServiceReq getCaseServiceReqByNameAndCaseId(String serviceName, Long caseId, Character isDeleted);

	@Query("select coalesce(max(csr.seqNo), '0') from CaseServiceReq csr where csr.clientCase.id = ?1")
	Integer findMaxByCaseId(Long caseId);

	@Query("select csr.id, csr.serviceName, csr.serviceNameShortCode from CaseServiceReq csr where csr.clientCase.id = ?1 and csr.deleted= ?2 order by csr.seqNo")
	List<CaseServiceReq> getAllServiceByCaseId(Long caseId, Character isDeleted);

	@Query("select csr from CaseServiceReq csr where csr.clientCase.id = ?1 and csr.deleted= 'N' order by csr.seqNo")
	List<CaseServiceReq> CaseServiceAPI(Long caseId);

	@Query("select csr from CaseServiceReq csr where csr.clientCase.id=?1 and csr.deleted=?2")
	List<CaseServiceReq> findCaseServiceReqByCaseId(Long caseId, char deleted);

	@Modifying
	@Query("update CaseServiceReq set serviceName=?1, serviceNameShortCode=?2 where subItemId=?3 and deleted='N'")
	void updateCaseServiceReqBySubItemId(String serviceName, String serNameShorCode, Long subItemId);

	@Query("select csr from CaseServiceReq csr where csr.serviceNameShortCode = ?1 and csr.clientCase.id = ?2 and csr.deleted= ?3")
	CaseServiceReq getCaseServiceReqByCodeAndCaseId(String serviceCode, Long caseId, Character isDeleted);

	@Modifying
	@Query(value = "UPDATE case_service_req SET additional_rec_id = ?1 WHERE case_service_req_id = ?2", nativeQuery = true)
	int updateAdditionalRecID(Long additionalRecId, Long caseServiceReqId);

	@Query("select csr from CaseServiceReq csr where csr.additionalRecId = ?1 and csr.deleted=?2")
	List<CaseServiceReq> getByAdditionalRecId(Long addRecId, char isDelete);
	
	//Call Procedure for insert save_case_report_users
	@Procedure("save_case_service_req")
	Long save_case_service_req(
						@Param("case_service_req_id") Long case_report_user_id,
						@Param("action") String action,
						@Param("created_date") DateTime created_date,
						@Param("modified_date") DateTime modified_date,
						@Param("optlock_version") Integer optlock_version,
						@Param("is_deleted") Character is_deleted,
						@Param("notes") String notes,
						@Param("seq_no") Integer seq_no,
						@Param("service_name") String service_name,						
						@Param("estimate_hours") Long estimate_hours,
						@Param("production_hours") Long production_hours,
						@Param("approved_hours") Long approved_hours,
						@Param("discount_hours") Long discount_hours,
						@Param("indirect_hours") Long indirect_hours,
						@Param("invoice_hours") Long invoice_hours,
						@Param("deviation_hours") Long deviation_hours,
						@Param("created_by") Long created_by,
						@Param("modified_by") Long modified_by,
						@Param("account_id") Long account_id,
						@Param("client_id") Long client_id,
						@Param("case_id") Long case_id,
						@Param("quality_score") Float quality_score,
						@Param("service_name_short_code") String service_name_short_code,						
						@Param("approved_date") Date approved_date,
						@Param("deliver_date") Date deliver_date,
						@Param("estimate_date") Date estimate_date,
						@Param("estimateon_hours") Long estimateon_hours,
						@Param("reestimate_hours") Long reestimate_hours,
						@Param("approve_status") Long approve_status,
						@Param("audit_score") Float audit_score,						
						@Param("itemId") Long itemId,
						@Param("additional_rec_id") Long additional_rec_id					
		);

}
