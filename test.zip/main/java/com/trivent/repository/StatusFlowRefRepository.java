package com.trivent.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.trivent.models.StatusFlowRef;

/**
 * @FileName 	:
 *				StatusFlowRefRepository.java
 * @ClassName 	:
 * 				StatusFlowRefRepository
 * @DateAndTime :
 *				Feb 2, 2018 - 7:08:34 PM
 * 
 * @Author 		:
 * 				karthi
 * 
 * @Description : Fetch Status Flow Related Native Query Implemented
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public interface StatusFlowRefRepository extends JpaRepository<StatusFlowRef, Long> {

	@Query("select s from StatusFlowRef s where s.deleted = ?1 order by s.seqNo")
	List<StatusFlowRef> listStatusFlowRefs(char isDeleted);

	@Query("select s from StatusFlowRef s LEFT OUTER JOIN FETCH s.extEmailTemplate LEFT OUTER JOIN FETCH s.intEmailTemplate  where s.objectType = ?1 and s.deleted = ?2 order by s.seqNo")
	List<StatusFlowRef> findByObjType(String objType, char isDeleted);

	@Query("select s from StatusFlowRef s LEFT OUTER JOIN FETCH s.extEmailTemplate LEFT OUTER JOIN FETCH s.intEmailTemplate where s.objectType = ?1 and s.customerSupportStatus= ?2 and s.deleted = ?3 order by s.seqNo")
	StatusFlowRef findByCsStatus(String objType, String csStatus, char isDeleted);

	@Query("select s from StatusFlowRef s where s.objectType = ?1 and s.deleted = ?3 order by s.seqNo")
	StatusFlowRef getFirstStatusFlow(String objType, char isDeleted);

	@Modifying
	@Query(value = "UPDATE StatusFlowRef s SET s.customerSupportStatus = ?1 WHERE s.customerSupportStatus = ?2")
	int updateCustomerSupportStatus(String csStatus, String csStatus1);
	
	@Modifying
	@Query(value = "UPDATE StatusFlowRef s SET s.customerStatus = ?1 WHERE s.customerStatus = ?2")
	int updateCustomerStatus(String clientStatus, String clientStatus1);
}
