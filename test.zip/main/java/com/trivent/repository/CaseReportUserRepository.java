package com.trivent.repository;

import java.util.List;

import org.joda.time.DateTime;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;

import com.trivent.models.CaseReportUser;

/**
 * @FileName : CaseReportUserRepository.java
 * @ClassName : CaseReportUserRepository
 * @DateAndTime : April 19, 2018 - 6:49:56 PM
 * 
 * @Author : Boopathi P S
 * 
 * @Description : Fetch Case Report User Related Native Query Implemented
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
public interface CaseReportUserRepository extends JpaRepository<CaseReportUser, Long> {

	
	List<CaseReportUser> findAll(Specification<CaseReportUser> specification);

	Page<CaseReportUser> findAll(Specification<CaseReportUser> specification, Pageable constructPageSpecification);
	
	@Query("select c from CaseReportUser c where  c.caseId =?1 and c.deleted = ?2")
	CaseReportUser findbyCaseIdForProdcutionMandaotry(Long caseId,char isDeleted);
	
	//Call Procedure for insert save_case_report_users
	@Procedure("save_case_report_users")
	Long save_case_report_users(
					@Param("case_report_user_id") Long case_report_user_id,
					@Param("action") String action,
					@Param("created_date") DateTime created_date,
					@Param("modified_date") DateTime modified_date,
					@Param("optlock_version") Integer optlock_version,
					@Param("is_deleted") Character is_deleted,
					@Param("created_by") Long created_by,
					@Param("modified_by") Long modified_by,
					@Param("case_id") Long case_id,					
					@Param("prod_user") String prod_user,
					@Param("prod_lead") String prod_lead,
					@Param("prod_md") String prod_md,
					@Param("prod_qc") String prod_qc,
					@Param("client_type") Long client_type					
	);
	
}
