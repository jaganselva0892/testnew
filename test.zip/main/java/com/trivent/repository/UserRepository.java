package com.trivent.repository;
/**
* FileName: UserRepository.java
* Defining of procedure, select and update queries 
* @author Jagan 0010
* @version 1.0
*/


import java.util.List;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.trivent.models.User;

public interface UserRepository extends JpaRepository<User, Long>{
	
	User findByLoginId(String loginId);
	
	@Query("from User u WHERE u.role.id = ?1")
	User getAdminUser(Long adminRoleId);
	
	@Query("from User u JOIN FETCH u.userProfile up JOIN FETCH u.role r LEFT OUTER JOIN FETCH u.account ac JOIN FETCH ac.partner p WHERE u.id = ?1")
	User findCustomerById(Long pnUserId);
	
	@Query("select u from User u JOIN FETCH u.userProfile up WHERE u.type = ?1 and u.team.id = ?2 and u.deleted = ?3")
	List<User> listTeamMembers(String userType, Long teamId, char isDeleted);
	
	@Query("from User u JOIN FETCH u.userProfile up JOIN FETCH u.role r LEFT OUTER JOIN FETCH u.account ac JOIN FETCH ac.partner p WHERE u.id IN ?1")
	List<User> findCustomerByIdNew(List<Long> pnUserId);

	List<User> findAll(Specification<User> usersSpecification);
	
	@Query("select u from User u where u.account.id = ?1 and u.deleted = ?2 ")
	List<User> findUserByAccountId(Long accountId, char isDeleted);
	
	@Query("from User u JOIN FETCH u.account ac JOIN FETCH u.userProfile up JOIN FETCH u.role r LEFT JOIN FETCH u.team t WHERE u.type = ?1 and u.deleted = ?2 and u.status NOT IN (?3) Order By up.firstName, up.lastName")
	List<User> getAllUsers(String userType, char isDeleted, char inactive);
	
	@Query("from User u JOIN FETCH u.userProfile up WHERE u.account.id = ?1 and u.type = ?2 and u.deleted = ?3 ORDER BY up.firstName, up.lastName")
	List<User> listAccountUsers(Long accountId, String userType, char isDeleted);


}
