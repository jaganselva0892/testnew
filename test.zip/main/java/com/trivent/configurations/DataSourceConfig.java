package com.trivent.configurations;

public class DataSourceConfig {

}
