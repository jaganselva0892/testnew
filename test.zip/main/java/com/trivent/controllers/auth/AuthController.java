package com.trivent.controllers.auth;
/**
FileName: AuthController.class
@author Jagan 0010
@version 1.0
*/

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.trivent.dto.UserLoginVO;
import com.trivent.dto.UserVO;
import com.trivent.logging.LogManager;
import com.trivent.logging.Logger;
import com.trivent.models.User;
import com.trivent.repository.UserRepository;
import com.trivent.service.UserService;

@SuppressWarnings("unused")
@RestController
@RequestMapping("/auth")
@CrossOrigin
public class AuthController {

	private static final Logger LOGGER = LogManager.getLogger();

	private static final String CLASS_NAME = AuthController.class.getName();

	@Autowired
	private UserService userService;

	
	
	@Autowired
	private UserRepository userRepository;

	@Autowired
	public void setUserService(UserService userService) {

		try {
			this.userService = userService;
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "Method : setUserService - Set User Service Access Error", e.getMessage());
		}

	}

	/**
	 * Method to generate the authentication token
	 * 
	 * @param strBody
	 *            contains the logged in user details
	 * @param response
	 *            httpResponse
	 * @param request
	 *            httpRequest
	 * 
	 */
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ResponseEntity<UserLoginVO> loginAuth(@RequestBody String strBody, HttpServletResponse response,
			HttpServletRequest request) {

		UserLoginVO userloginVO = new UserLoginVO();
		try {

			Gson gson = new Gson();
			UserVO userVO = new UserVO();
			userVO = gson.fromJson(strBody, UserVO.class);
			User user = new User();
			user = userService.login(userVO.getLoginId(), userVO.getPassword(), response, request);
			if (user != null) {
				userloginVO.setToken(response.getHeader("Token"));
				userloginVO.setTokenExpiry(response.getHeader("TokenExpiry"));
			}
			return ResponseEntity.ok(userloginVO);
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "Method : loginAuth - User Login", e.getMessage());
			return new ResponseEntity<>(userloginVO, HttpStatus.CREATED);
		}
	}
	
	@RequestMapping(value = "/test", method = RequestMethod.GET)
	public ResponseEntity<UserLoginVO> apiTest(HttpServletResponse response, HttpServletRequest request) {

		UserLoginVO userloginVO = new UserLoginVO();
		try {
			return ResponseEntity.ok(userloginVO);
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "Method : apiTest", e.getMessage());
			return new ResponseEntity<>(userloginVO, HttpStatus.CREATED);
		}
	}


}
