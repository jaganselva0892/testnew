package com.trivent.controllers;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.trivent.constants.AppConstants;
import com.trivent.dto.CaseDetailsVO;
import com.trivent.dto.CaseVO;
import com.trivent.dto.PaginationVO;
import com.trivent.dto.ReturnVO;
import com.trivent.dto.RowVO;
import com.trivent.dto.ScreenListFilterVO;
import com.trivent.dto.UserVO;
import com.trivent.exceptions.JwtTokenMalformedException;
import com.trivent.exceptions.JwtTokenMissingException;
import com.trivent.exceptions.TriventException;
import com.trivent.logging.LogManager;
import com.trivent.logging.Logger;
import com.trivent.service.CaseService;
import com.trivent.service.UserService;

/**
 * @ProjectName : trivent
 * @PackageName : com.trivent.controller
 * 
 * @FileName : CaseController.java
 * @TypeName : CaseController
 * @DateAndTime : Feb 3, 2018 - 12:32:23 PM
 * 
 * @Author : karthi
 * 
 * @Description : for case create view save edit are implemented through this
 *              controller
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
@RestController
@CrossOrigin
@RequestMapping("/app/cases")
public class CaseController {

	private static final Logger LOGGER = LogManager.getLogger();
	private static final String CLASS_NAME = CaseController.class.getName();

	@Autowired
	private CaseService caseService;

	@Autowired
	private UserService userService;

	/**
	 * Method to get the list of project details created by logged in user
	 * 
	 * @param response
	 *            httpResponse
	 * 
	 */
	@RequestMapping(value = "/getScreenFilter", method = RequestMethod.GET)
	public ResponseEntity<ReturnVO> getScreenFilter(HttpServletResponse response) {
		ReturnVO returnVO = new ReturnVO();
		returnVO.setIsData(false);
		returnVO.setTokenExpiry(false);

		ScreenListFilterVO screenListFilterVO = new ScreenListFilterVO();
		try {
			returnVO.setIsData(true);
			screenListFilterVO = this.caseService.getDefaultScreenListFilterVO();
			Object data = (Object) screenListFilterVO;
			returnVO.setData(data);

		} catch (JwtTokenMalformedException | JwtTokenMissingException e) {
			LOGGER.error(CLASS_NAME, "Method : getScreenFilter - Token Error or Invalid token", e.getMessage());
			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setMessage("Not valid Token");
			returnVO.setTokenExpiry(true);
			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "Method : getScreenFilter", e.getMessage());
			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setMessage("No Data Found");
			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		}

		return new ResponseEntity<>(returnVO, HttpStatus.OK);
	}

	@RequestMapping(value = "/getCaseList", method = RequestMethod.POST)
	public ResponseEntity<ReturnVO> getCaseList(@RequestBody String pstrFilters, HttpServletRequest request) {
		ReturnVO returnVO = new ReturnVO();
		returnVO.setIsData(false);
		returnVO.setTokenExpiry(false);
		try {
			String type = null;
			String fromDate = null;
			String toDate = null;
			String partnerCode = null;
			String lsAccountId = null;
			String caseStatus = null;
			returnVO.setIsData(true);
			UserVO userVO = userService.getUserDetails(request);
			Gson gson = new Gson();
			ScreenListFilterVO screenListFilterVO = new ScreenListFilterVO();
			screenListFilterVO = gson.fromJson(pstrFilters, ScreenListFilterVO.class);
			PaginationVO paginationVO = new PaginationVO();
			paginationVO.setPage(screenListFilterVO.getPageNo());
			paginationVO.setLimit(screenListFilterVO.getRecordsPerPage());
			paginationVO.setSortByField(screenListFilterVO.getSortByField());
			paginationVO.setSortOrder(screenListFilterVO.getSortOrder());
			List<Object> dataList = new ArrayList<>();
			List<RowVO> rowVOs = this.caseService.listCases(screenListFilterVO, type, fromDate, toDate, partnerCode,
					lsAccountId, caseStatus, userVO);
			paginationVO.setTotalRecords(screenListFilterVO.getTotalRecords());
			dataList = Arrays.asList(rowVOs);
			returnVO.setDataList(dataList);
			returnVO.setPaginationVO(paginationVO);
		} catch (JwtTokenMalformedException | JwtTokenMissingException e) {
			LOGGER.error(CLASS_NAME, "Method : getCaseList - Token Error or Invalid token", e.getMessage());
			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setMessage("Not valid Token");
			returnVO.setTokenExpiry(true);
			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "Method : getCaseList", e.getMessage());
			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setMessage("No Data Found");
			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		}

		return new ResponseEntity<>(returnVO, HttpStatus.OK);
	}

	/**
	 * Method to create Permission
	 * 
	 * @param strBody
	 *            contains the Permission details
	 * @param request
	 *            httpRequest
	 * @param response
	 *            httpResponse
	 * 
	 */
	@RequestMapping(value = "/saveCase", method = RequestMethod.POST)
	public ResponseEntity<ReturnVO> saveCase(@RequestBody String strBody, HttpServletRequest request,
			HttpServletResponse response) {
		ReturnVO returnVO = new ReturnVO();
		returnVO.setIsData(false);
		returnVO.setTokenExpiry(false);
		try {
			UserVO userVO = userService.getUserDetails(request);
			Gson gson = new Gson();
			CaseVO caseVO = new CaseVO();
			caseVO = gson.fromJson(strBody, CaseVO.class);
			// UserVO userVO = userService.getUserDetails(request);
			caseVO = this.caseService.saveCase(caseVO, userVO);
			if (caseVO != null) {
				returnVO.setIsData(true);
				returnVO.setMessage("Case Saved");
				Object data = (Object) caseVO;
				returnVO.setData(data);
			} else {
				returnVO.setIsData(false);
				returnVO.setMessage("Save failed!");
			}
		} catch (JwtTokenMalformedException | JwtTokenMissingException e) {
			LOGGER.error(CLASS_NAME, "Method : saveCase - Token Error or Invalid token", e.getMessage());
			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setTokenExpiry(true);
			returnVO.setMessage("Not valid Token");

			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "Method : saveCase", e.getMessage());
			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setMessage("Invalid Token");
			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		}
		return new ResponseEntity<>(returnVO, HttpStatus.OK);
	}

	/**
	 * Method to get Details of Case
	 * 
	 * @param strBody
	 *            contains the caseId
	 * @param request
	 *            httpRequest
	 * @param response
	 *            httpResponse
	 * 
	 */
	@RequestMapping(value = "/caseDetails", method = RequestMethod.GET)
	public ResponseEntity<ReturnVO> editCase(@RequestParam(value = "caseId") Long caseId,
			@RequestParam(value = "selectedCaseTab", required = false) Integer selectedCaseTab,
			@RequestParam(value = "parentCase", required = false) Integer parentCase, HttpServletRequest request)
			throws TriventException, UnsupportedEncodingException {
		ReturnVO returnVO = new ReturnVO();
		returnVO.setIsData(false);
		returnVO.setTokenExpiry(false);
		try {
			returnVO.setIsData(true);
			UserVO userVO = userService.getUserDetails(request);
			CaseDetailsVO caseDetailsVO = this.caseService.getCaseDetailsVO(caseId, userVO);
			Object data = (Object) caseDetailsVO;
			returnVO.setData(data);
		} catch (JwtTokenMalformedException | JwtTokenMissingException e) {
			LOGGER.error(CLASS_NAME, "Method : getCaseDetails - Token Error or Invalid token", e.getMessage());
			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setMessage("Not valid Token");
			returnVO.setTokenExpiry(true);
			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "Method : getCaseDetails", e.getMessage());
			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setMessage("No Data Found");
			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		}

		return new ResponseEntity<>(returnVO, HttpStatus.OK);
	}

	@RequestMapping(value = "/addCase", method = RequestMethod.GET)
	public ResponseEntity<ReturnVO> addCase(HttpServletRequest request) {
		ReturnVO returnVO = new ReturnVO();
		returnVO.setIsData(false);
		returnVO.setTokenExpiry(false);
		try {
			returnVO.setIsData(true);
			UserVO userVO = userService.getUserDetails(request);
			CaseVO caseVO = this.caseService.getNewCase(userVO);
			Object data = (Object) caseVO;
			returnVO.setData(data);
		} catch (JwtTokenMalformedException | JwtTokenMissingException e) {
			LOGGER.error(CLASS_NAME, "Method : getNewCase - Token Error or Invalid token", e.getMessage());
			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setMessage("Not valid Token");
			returnVO.setTokenExpiry(true);
			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "Method : getNewCase", e.getMessage());
			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setMessage("No Data Found");
			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		}

		return new ResponseEntity<>(returnVO, HttpStatus.OK);
	}

	@RequestMapping(value = "/getPaggination/{pageObj}/{pssortOrder}/{pssortByField}", method = RequestMethod.GET)
	public ResponseEntity<ReturnVO> getPaggination(@PathVariable("pageObj") String psPageObject,
			@PathVariable("pssortOrder") String psSortOrder, @PathVariable("pssortByField") String psSortByField,
			HttpServletResponse response) {
		ReturnVO returnVO = new ReturnVO();
		returnVO.setIsData(false);
		returnVO.setTokenExpiry(false);
		ScreenListFilterVO screenListFilterVO = new ScreenListFilterVO();
		try {
			returnVO.setIsData(true);
			Gson gson = new Gson();
			PaginationVO paginationVO = new PaginationVO();
			paginationVO = gson.fromJson(psPageObject, PaginationVO.class);
			paginationVO.setSortByField(psSortByField);
			if (psSortOrder.equals(AppConstants.ASCENDING)) {
				paginationVO.setSortOrder(AppConstants.SORT_PREF_ASC);
			} else {
				paginationVO.setSortOrder(AppConstants.SORT_PREF_DESC);
			}
			screenListFilterVO = this.caseService.getDefaultScreenListFilterVO();
			screenListFilterVO.setPageNo(paginationVO.getPage());
			screenListFilterVO.setRecordsPerPage(paginationVO.getLimit());
			screenListFilterVO.setSortByField(paginationVO.getSortByField());
			screenListFilterVO.setSortOrder(paginationVO.getSortOrder());
			Object data = (Object) screenListFilterVO;
			returnVO.setData(data);
			returnVO.setPageable(true);
			returnVO.setPaginationVO(paginationVO);
		} catch (JwtTokenMalformedException | JwtTokenMissingException e) {
			LOGGER.error(CLASS_NAME, "Method : getPaggination - Token Error or Invalid token", e.getMessage());
			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setMessage("Not valid Token");
			returnVO.setTokenExpiry(true);
			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "Method : getPaggination", e.getMessage());
			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setMessage("No Data Found");
			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		}

		return new ResponseEntity<>(returnVO, HttpStatus.OK);
	}

}
