package com.trivent.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.trivent.dto.ContactVO;
import com.trivent.dto.ReturnVO;
import com.trivent.dto.UserVO;
import com.trivent.dto.base.EncryptedId;
import com.trivent.exceptions.JwtTokenMalformedException;
import com.trivent.exceptions.JwtTokenMissingException;
import com.trivent.logging.LogManager;
import com.trivent.logging.Logger;
import com.trivent.service.ContactService;
import com.trivent.service.UserService;



@RestController
@CrossOrigin
@RequestMapping("/app/contact")


public class ContactController {
	
	private static final Logger LOGGER = LogManager.getLogger();
	private static final String CLASS_NAME = ContactController.class.getName();
	
	@Autowired
	private UserService userService;
	
	@Autowired
	ContactService contactService;
	
	
	@RequestMapping(value = "/saveContacts", method = RequestMethod.POST)
	public ResponseEntity<ReturnVO> saveContacts(@RequestBody String strBody, HttpServletRequest request,
			HttpServletResponse response) {
		ReturnVO returnVO = new ReturnVO();
		returnVO.setIsData(false);
		returnVO.setTokenExpiry(false);
		try {
			UserVO userVO = userService.getUserDetails(request);
			Gson gson = new Gson();
			ContactVO contactVO = new ContactVO();
			contactVO = gson.fromJson(strBody, ContactVO.class);
			//UserVO userVO = userService.getUserDetails(request);
			contactVO = this.contactService.saveContacts(contactVO,userVO);
			if (contactVO != null) {
				returnVO.setIsData(true);
				returnVO.setMessage("Case Saved");
				Object data = (Object) contactVO;
				returnVO.setData(data);
			} else {
				returnVO.setIsData(false);
				returnVO.setMessage("Save failed!");
			}
		} catch (JwtTokenMalformedException | JwtTokenMissingException e) {
			LOGGER.error(CLASS_NAME, "Method : saveContacts - Token Error or Invalid token", e.getMessage());
			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setTokenExpiry(true);
			returnVO.setMessage("Not valid Token");

			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "Method : saveContacts", e.getMessage());
			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setMessage("Invalid Token");
			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		}
		return new ResponseEntity<>(returnVO, HttpStatus.OK);
	}
	@RequestMapping(value = "/addContact", method = RequestMethod.GET)	
	public ResponseEntity<ReturnVO> addContact(@RequestParam (value="entityId",required = false) EncryptedId entityId,
			@RequestParam(value="clientId",required = false) Long clientId, @RequestParam String entity,
			@RequestParam(value="screen",required = false) String screen, @RequestParam(value="caseId",required = false) EncryptedId caseId,HttpServletResponse response, HttpServletRequest request) {
		ReturnVO returnVO = new ReturnVO();
		returnVO.setIsData(false);
		returnVO.setTokenExpiry(false);
		try {
			returnVO.setIsData(true);
			UserVO userVO = userService.getUserDetails(request);
			Long id;
			if (entityId != null) {
				id = entityId.getId();
			} else {
				id = clientId;
			}
			ContactVO contactVO = this.contactService.getNewContact(id, entity, screen, caseId,userVO);
			Object data = (Object) contactVO;
			returnVO.setData(data);
			
		} catch (JwtTokenMalformedException | JwtTokenMissingException e) {
			LOGGER.error(CLASS_NAME, "Method : addContact - Token Error or Invalid token", e.getMessage());
			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setMessage("Not valid Token");
			returnVO.setTokenExpiry(true);
			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "Method : addContact", e.getMessage());
			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setMessage("No Data Found");
			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		}

		return new ResponseEntity<>(returnVO, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/getContactDetailsForAccountUser", method = RequestMethod.GET)	
	public ResponseEntity<ReturnVO> getContactDetailsForAccountUser(@RequestParam Long userId,
		HttpServletResponse response, HttpServletRequest request) {
		ReturnVO returnVO = new ReturnVO();
		returnVO.setIsData(false);
		returnVO.setTokenExpiry(false);
		try {
			returnVO.setIsData(true);
			UserVO userVO = contactService.getUserDetails(userId);
			Object data = (Object) userVO;
			returnVO.setData(data);
			
		} catch (JwtTokenMalformedException | JwtTokenMissingException e) {
			LOGGER.error(CLASS_NAME, "Method : getContactDetailsForAccountUser - Token Error or Invalid token", e.getMessage());
			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setMessage("Not valid Token");
			returnVO.setTokenExpiry(true);
			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "Method : getContactDetailsForAccountUser", e.getMessage());
			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setMessage("No Data Found");
			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		}

		return new ResponseEntity<>(returnVO, HttpStatus.OK);
	}
}
