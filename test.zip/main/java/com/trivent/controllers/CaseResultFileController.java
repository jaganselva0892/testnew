package com.trivent.controllers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.trivent.dto.ReturnVO;
import com.trivent.dto.RowVO;
import com.trivent.dto.ScreenListFilterVO;
import com.trivent.exceptions.JwtTokenMalformedException;
import com.trivent.exceptions.JwtTokenMissingException;
import com.trivent.logging.LogManager;
import com.trivent.logging.Logger;
import com.trivent.service.CaseResultFileService;

/**
 * @ProjectName : trivent
 * @PackageName : com.trivent.controller
 * 
 * @FileName : CaseController.java
 * @TypeName : CaseController
 * @DateAndTime : Feb 3, 2018 - 12:32:23 PM
 * 
 * @Author : karthi
 * 
 * @Description : for case File create view save edit are implemented through this
 *              controller
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
@RestController
@CrossOrigin
@RequestMapping("/caseResultFiles")
public class CaseResultFileController {

	private static final Logger LOGGER = LogManager.getLogger();
	private static final String CLASS_NAME = CaseResultFileController.class.getName();
	
	@Autowired
	private CaseResultFileService caseResultFileService;
	
	/**
	 * Method to get the list of project details created by logged in user
	 * 
	 * @param response
	 *            httpResponse
	 * 
	 */
	@RequestMapping(value = "/getScreenFilter", method = RequestMethod.GET)	
	public ResponseEntity<ReturnVO> getScreenFilter(HttpServletResponse response) {
		ReturnVO returnVO = new ReturnVO();
		returnVO.setIsData(false);
		returnVO.setTokenExpiry(false);
		
		ScreenListFilterVO screenListFilterVO = new ScreenListFilterVO();
		try {
			returnVO.setIsData(true);			
			screenListFilterVO = this.caseResultFileService.getDefaultScreenListFilterVO();
			Object data = (Object) screenListFilterVO;
			returnVO.setData(data);
			
		} catch (JwtTokenMalformedException | JwtTokenMissingException e) {
			LOGGER.error(CLASS_NAME, "Method : getScreenFilter - Token Error or Invalid token", e.getMessage());
			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setMessage("Not valid Token");
			returnVO.setTokenExpiry(true);
			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "Method : getScreenFilter", e.getMessage());
			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setMessage("No Data Found");
			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		}

		return new ResponseEntity<>(returnVO, HttpStatus.OK);
	}

	@RequestMapping(value = "/getCaseResultFileList", method = RequestMethod.POST)
	public ResponseEntity<ReturnVO> getCaseList(@RequestBody String pstrFilters) {
		ReturnVO returnVO = new ReturnVO();
		returnVO.setIsData(false);
		returnVO.setTokenExpiry(false);
		try {
			returnVO.setIsData(true);
			
			Gson gson = new Gson();
			ScreenListFilterVO screenListFilterVO = new ScreenListFilterVO();
			screenListFilterVO = gson.fromJson(pstrFilters, ScreenListFilterVO.class);
			screenListFilterVO = this.caseResultFileService.getDefaultScreenListFilterVO();
			List<Object> dataList = new ArrayList<>();
			Long caseId = new Long(22246);
			String psType = "";
			List<RowVO> rowVOs = this.caseResultFileService.listCaseResultFilesByCaseId(caseId, screenListFilterVO, psType);
			dataList = Arrays.asList(rowVOs);
			returnVO.setDataList(dataList);
		} catch (JwtTokenMalformedException | JwtTokenMissingException e) {
			LOGGER.error(CLASS_NAME, "Method : getCaseList - Token Error or Invalid token", e.getMessage());
			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setMessage("Not valid Token");
			returnVO.setTokenExpiry(true);
			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "Method : getCaseList", e.getMessage());
			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setMessage("No Data Found");
			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		}

		return new ResponseEntity<>(returnVO, HttpStatus.OK);
	}
	
	


}
