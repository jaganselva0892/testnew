package com.trivent.controllers.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.trivent.controllers.CaseController;
import com.trivent.dto.AccountVO;
import com.trivent.dto.AppItemVO;
import com.trivent.dto.AppSubItemVO;
import com.trivent.dto.AppUIScreenFilterVO;
import com.trivent.dto.DropDownVO;
import com.trivent.dto.ReturnVO;
import com.trivent.dto.UserVO;
import com.trivent.exceptions.JwtTokenMalformedException;
import com.trivent.exceptions.JwtTokenMissingException;
import com.trivent.logging.LogManager;
import com.trivent.logging.Logger;
import com.trivent.models.Case;
import com.trivent.service.AccountService;
import com.trivent.service.CaseQueryService;
import com.trivent.service.CaseService;
import com.trivent.service.UserService;

/**
 * @ProjectName : trivent
 * @PackageName : com.trivent.controller
 * 
 * @FileName : CaseController.java
 * @TypeName : CaseController
 * @DateAndTime : Feb 3, 2018 - 12:32:23 PM
 * 
 * @Author : Seetha
 * 
 * @Description : for case create view save edit are implemented through this
 *              controller
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
@RestController
@CrossOrigin
@RequestMapping("/app/utils")
public class UtilsController {

	private static final Logger LOGGER = LogManager.getLogger();
	private static final String CLASS_NAME = CaseController.class.getName();

	@Autowired
	private CaseService caseService;

	@Autowired
	private UserService userService;

	@Autowired
	private AccountService accountService;

	@Autowired
	private CaseQueryService caseQueryService;

	@RequestMapping(value = "/getUsers", method = RequestMethod.GET)
	public ResponseEntity<ReturnVO> getUsers(HttpServletRequest request, HttpServletResponse response) {
		ReturnVO returnVO = new ReturnVO();
		returnVO.setIsData(false);
		returnVO.setTokenExpiry(false);
		try {
			List<UserVO> userVO = userService.getUser(request);
			if (userVO != null) {
				returnVO.setIsData(true);
				returnVO.setMessage("Login");
				List<Object> dataList = new ArrayList<>();
				dataList = Arrays.asList(userVO);
				returnVO.setDataList(dataList);
			} else {
				returnVO.setIsData(false);
				returnVO.setMessage("no Details");
			}
		} catch (JwtTokenMalformedException | JwtTokenMissingException e) {
			LOGGER.error(CLASS_NAME, "Method : GetUser - Token Error or Invalid token", e.getMessage());
			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setTokenExpiry(true);
			returnVO.setMessage("Not valid Token");
			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "Method : GetUser", e.getMessage());
			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setMessage("Invalid Token");
			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		}
		return new ResponseEntity<>(returnVO, HttpStatus.OK);
	}

	@RequestMapping(value = "/getAccount", method = RequestMethod.GET)
	public ResponseEntity<ReturnVO> getAccount(@RequestParam(value = "partner") String partnerCode,
			HttpServletRequest request, HttpServletResponse response) {
		ReturnVO returnVO = new ReturnVO();
		returnVO.setIsData(false);
		returnVO.setTokenExpiry(false);
		try {
			List<AccountVO> accountVO = accountService.getAccount(request, partnerCode);
			if (accountVO != null) {
				returnVO.setIsData(true);
				returnVO.setMessage("Login");
				List<Object> dataList = new ArrayList<>();
				dataList = Arrays.asList(accountVO);
				returnVO.setDataList(dataList);
			} else {
				returnVO.setIsData(false);
				returnVO.setMessage("no Details");
			}
		} catch (JwtTokenMalformedException | JwtTokenMissingException e) {
			LOGGER.error(CLASS_NAME, "Method : getAccount - Token Error or Invalid token", e.getMessage());
			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setTokenExpiry(true);
			returnVO.setMessage("Not valid Token");
			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "Method : getAccount", e.getMessage());
			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setMessage("Invalid Token");
			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		}
		return new ResponseEntity<>(returnVO, HttpStatus.OK);
	}

	@RequestMapping(value = "/getCaseType", method = RequestMethod.GET)
	public ResponseEntity<ReturnVO> getCaseType(HttpServletRequest request, HttpServletResponse response) {
		ReturnVO returnVO = new ReturnVO();
		returnVO.setIsData(false);
		returnVO.setTokenExpiry(false);
		try {
			List<AppItemVO> appItemVO = caseService.getCaseType(request);
			if (appItemVO != null) {
				returnVO.setIsData(true);
				returnVO.setMessage("Login");
				List<Object> dataList = new ArrayList<>();
				dataList = Arrays.asList(appItemVO);
				returnVO.setDataList(dataList);
			} else {
				returnVO.setIsData(false);
				returnVO.setMessage("no Details");
			}
		} catch (JwtTokenMalformedException | JwtTokenMissingException e) {
			LOGGER.error(CLASS_NAME, "Method : getCaseType - Token Error or Invalid token", e.getMessage());
			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setTokenExpiry(true);
			returnVO.setMessage("Not valid Token");
			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "Method : getCaseType", e.getMessage());
			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setMessage("Invalid Token");
			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		}
		return new ResponseEntity<>(returnVO, HttpStatus.OK);
	}

	@RequestMapping(value = "/getCaseSubType", method = RequestMethod.GET)
	public ResponseEntity<ReturnVO> getCaseSubType(@RequestParam(value = "caseTypeId") Long caseTypeId,
			HttpServletRequest request, HttpServletResponse response) {
		ReturnVO returnVO = new ReturnVO();
		returnVO.setIsData(false);
		returnVO.setTokenExpiry(false);
		try {
			List<AppSubItemVO> appItemVO = caseService.getCaseSubType(request, caseTypeId);
			if (appItemVO != null) {
				returnVO.setIsData(true);
				returnVO.setMessage("Login");
				List<Object> dataList = new ArrayList<>();
				dataList = Arrays.asList(appItemVO);
				returnVO.setDataList(dataList);
			} else {
				returnVO.setIsData(false);
				returnVO.setMessage("no Details");
			}
		} catch (JwtTokenMalformedException | JwtTokenMissingException e) {
			LOGGER.error(CLASS_NAME, "Method : getCaseType - Token Error or Invalid token", e.getMessage());
			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setTokenExpiry(true);
			returnVO.setMessage("Not valid Token");
			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "Method : getCaseType", e.getMessage());
			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setMessage("Invalid Token");
			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		}
		return new ResponseEntity<>(returnVO, HttpStatus.OK);
	}

	@RequestMapping(value = "/getStatus", method = RequestMethod.GET)
	public ResponseEntity<ReturnVO> getStatus(HttpServletRequest request, HttpServletResponse response) {
		ReturnVO returnVO = new ReturnVO();
		returnVO.setIsData(false);
		returnVO.setTokenExpiry(false);
		try {
			AppUIScreenFilterVO appUIScreenFilter = caseQueryService.populateQueryStatusMap();
			if (appUIScreenFilter != null) {
				returnVO.setIsData(true);
				returnVO.setMessage("Login");
				List<Object> dataList = new ArrayList<>();
				dataList = Arrays.asList(appUIScreenFilter);
				returnVO.setDataList(dataList);
			} else {
				returnVO.setIsData(false);
				returnVO.setMessage("no Details");
			}
		} catch (JwtTokenMalformedException | JwtTokenMissingException e) {
			LOGGER.error(CLASS_NAME, "Method : getCaseType - Token Error or Invalid token", e.getMessage());
			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setTokenExpiry(true);
			returnVO.setMessage("Not valid Token");
			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "Method : getCaseType", e.getMessage());
			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setMessage("Invalid Token");
			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		}
		return new ResponseEntity<>(returnVO, HttpStatus.OK);
	}

	@RequestMapping(value = "/getCases", method = RequestMethod.GET)
	public ResponseEntity<ReturnVO> getCases(@RequestParam(required = false) String searchTerm,
			HttpServletRequest request, HttpServletResponse response) {
		ReturnVO returnVO = new ReturnVO();
		returnVO.setIsData(false);
		returnVO.setTokenExpiry(false);
		try {
			UserVO userVO = userService.getUserDetails(request);
			if (userVO != null) {
				List<Case> caseList = this.caseService.findCasesListFromHeader(searchTerm, userVO);
				if (caseList != null) {
					returnVO.setIsData(true);
					returnVO.setMessage("Login");
					List<Object> dataList = new ArrayList<>();
					dataList = Arrays.asList(caseList);
					returnVO.setDataList(dataList);
				} else {
					returnVO.setIsData(false);
					returnVO.setMessage("no Details");
				}
			}
		} catch (JwtTokenMalformedException | JwtTokenMissingException e) {
			LOGGER.error(CLASS_NAME, "Method : getCaseType - Token Error or Invalid token", e.getMessage());
			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setTokenExpiry(true);
			returnVO.setMessage("Not valid Token");
			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "Method : getCaseType", e.getMessage());
			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setMessage("Invalid Token");
			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		}
		return new ResponseEntity<>(returnVO, HttpStatus.OK);
	}
	@RequestMapping(value = "/getClients", method = RequestMethod.GET)
	public ResponseEntity<ReturnVO> getClients(HttpServletRequest request, HttpServletResponse response,@RequestParam (value="accountId")Long accountId) {
		ReturnVO returnVO = new ReturnVO();
		returnVO.setIsData(false);
		returnVO.setTokenExpiry(false);
		try {
			UserVO userVO = userService.getUserDetails(request);
			if (userVO != null) {
			List<DropDownVO> dropDownVO= userService.getClients(userVO,accountId);
			if (dropDownVO != null) {
				returnVO.setIsData(true);
				returnVO.setMessage("Login");
				List<Object> dataList = new ArrayList<>();
				dataList = Arrays.asList(dropDownVO);
				returnVO.setDataList(dataList);
			} else {
				returnVO.setIsData(false);
				returnVO.setMessage("no Details");
			}
		  }
		}catch (JwtTokenMalformedException | JwtTokenMissingException e) {
			LOGGER.error(CLASS_NAME, "Method : GetUser - Token Error or Invalid token", e.getMessage());
			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setTokenExpiry(true);
			returnVO.setMessage("Not valid Token");
			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "Method : GetUser", e.getMessage());
			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setMessage("Invalid Token");
			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		}
		return new ResponseEntity<>(returnVO, HttpStatus.OK);
	}
	@RequestMapping(value = "/getAppLabels", method = RequestMethod.GET)
	public ResponseEntity<ReturnVO> getAppLabels(HttpServletRequest request, HttpServletResponse response) {
		ReturnVO returnVO = new ReturnVO();
		returnVO.setIsData(false);
		returnVO.setTokenExpiry(false);
		try {
			List<DropDownVO> appLabelNames = this.caseService.getAppLabelNames();
			if (appLabelNames.size()>0) {
				returnVO.setIsData(true);
				List<Object> dataList = new ArrayList<>();
				dataList = Arrays.asList(appLabelNames);
				returnVO.setDataList(dataList);
			} else {
				returnVO.setIsData(false);
				returnVO.setMessage("no Details");
			}
		} catch (JwtTokenMalformedException | JwtTokenMissingException e) {
			LOGGER.error(CLASS_NAME, "Method : getAppLabels - Token Error or Invalid token", e.getMessage());
			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setTokenExpiry(true);
			returnVO.setMessage("Not valid Token");
			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "Method : getAppLabels", e.getMessage());
			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setMessage("Invalid Token");
			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		}
		return new ResponseEntity<>(returnVO, HttpStatus.OK);
	}
	@RequestMapping(value = "/getClientType", method = RequestMethod.GET)
	public ResponseEntity<ReturnVO> getClientType(HttpServletRequest request, HttpServletResponse response) {
		ReturnVO returnVO = new ReturnVO();
		returnVO.setIsData(false);
		returnVO.setTokenExpiry(false);
		try {
			List<DropDownVO> clientType = this.caseService.getClientType();
			if (clientType.size()>0) {
				returnVO.setIsData(true);
				List<Object> dataList = new ArrayList<>();
				dataList = Arrays.asList(clientType);
				returnVO.setDataList(dataList);
			} else {
				returnVO.setIsData(false);
				returnVO.setMessage("no Details");
			}
		} catch (JwtTokenMalformedException | JwtTokenMissingException e) {
			LOGGER.error(CLASS_NAME, "Method : getClientType - Token Error or Invalid token", e.getMessage());
			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setTokenExpiry(true);
			returnVO.setMessage("Not valid Token");
			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "Method : getClientType", e.getMessage());
			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setMessage("Invalid Token");
			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		}
		return new ResponseEntity<>(returnVO, HttpStatus.OK);
	}
	@RequestMapping(value = "/getCommunicationType", method = RequestMethod.GET)
	public ResponseEntity<ReturnVO> getCommunicationType(HttpServletRequest request, HttpServletResponse response) {

		ReturnVO returnVO = new ReturnVO();
		returnVO.setIsData(false);
		returnVO.setTokenExpiry(false);
		try {

			List<AppItemVO> userVO = caseQueryService.getCommunicationType(request);
			if (userVO != null) {
				returnVO.setIsData(true);
				returnVO.setMessage("Login");
				List<Object> dataList = new ArrayList<>();
				dataList = Arrays.asList(userVO);

				returnVO.setDataList(dataList);
			} else {
				returnVO.setIsData(false);
				returnVO.setMessage("no Details");
			}
		} catch (JwtTokenMalformedException | JwtTokenMissingException e) {

			LOGGER.error(CLASS_NAME, "Method : getAppLabels - Token Error or Invalid token", e.getMessage());

			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setTokenExpiry(true);
			returnVO.setMessage("Not valid Token");
			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		} catch (Exception e) {

			LOGGER.error(CLASS_NAME, "Method : getAppLabels", e.getMessage());

			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setMessage("Invalid Token");
			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		}
		return new ResponseEntity<>(returnVO, HttpStatus.OK);
	}

	
	@RequestMapping(value = "/getCommunicationSubType", method = RequestMethod.GET)
	public ResponseEntity<ReturnVO> getCommunicationSubType(@RequestParam(value = "commnTypeId") String commnTypeId,
			HttpServletRequest request, HttpServletResponse response) {
		ReturnVO returnVO = new ReturnVO();
		returnVO.setIsData(false);
		returnVO.setTokenExpiry(false);
		try {
			 List<DropDownVO> mapValue = caseService.getCommunicationSubType(request, commnTypeId);
			if (mapValue != null) {
				returnVO.setIsData(true);
				returnVO.setMessage("Login");
				List<Object> dataList = new ArrayList<>();
				dataList = Arrays.asList(mapValue);
				returnVO.setDataList(dataList);
			} else {
				returnVO.setIsData(false);
				returnVO.setMessage("no Details");
			}
		} catch (JwtTokenMalformedException | JwtTokenMissingException e) {
			LOGGER.error(CLASS_NAME, "Method : getClientType - Token Error or Invalid token", e.getMessage());
			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setTokenExpiry(true);
			returnVO.setMessage("Not valid Token");
			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "Method : getClientType", e.getMessage());
			returnVO = new ReturnVO();
			returnVO.setIsData(false);
			returnVO.setMessage("Invalid Token");
			return new ResponseEntity<>(returnVO, HttpStatus.CREATED);
		}
		return new ResponseEntity<>(returnVO, HttpStatus.OK);
	}


}
