package com.trivent.dto;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.springframework.beans.BeanUtils;

import com.trivent.dto.base.BaseContactVO;
import com.trivent.models.User;

public class UserVO extends BaseContactVO {

	private String loginId;
	private String password;
	private String currentPassword;
	private Long userId;

	public UserVO() {
	}

	public UserVO(User user) {
		BeanUtils.copyProperties(user, this);
		if (user.getUserProfile() != null) {
			BeanUtils.copyProperties(user.getUserProfile(), this);
		}
		this.setUserId(user.getId());
		this.setPassword(null);
	}

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		UserVO other = (UserVO) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getCurrentPassword() {
		return currentPassword;
	}

	public void setCurrentPassword(String currentPassword) {
		this.currentPassword = currentPassword;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

}
