package com.trivent.dto;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.springframework.beans.BeanUtils;

//import com.trivent.constants.AppConstants;
import com.trivent.dto.base.BaseVO;
//import com.trivent.entity.Account;
//import com.trivent.entity.AppItem;
//import com.trivent.entity.AppSubItem;
//import com.trivent.entity.Contact;
import com.trivent.models.CaseQueryResponseFiles;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.dto
 * 
 * @FileName 	:
 *				CaseQueryResponseFilesVO.java
 * @TypeName 	:
 * 				CaseQueryResponseFilesVO
 * @DateAndTime :
 *				Feb 8, 2018 - 5:38:31 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description : To list , save and edit the values through path
 *              variable(objects) of CaseQueryResponseFilesVO(used to interact with
 *              UI)
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public class CaseQueryResponseFilesVO extends BaseVO {

	@SuppressWarnings("unused")
	private static final long serialVersionUID = 6344727092398334094L;
	private Long caseQueryResponseId;
	private String fileName;
	private String fileExtension;
	private String fileDirectory;
	private Long fileSize;
	private String createdBy;

	public CaseQueryResponseFilesVO() {
	}

	public CaseQueryResponseFilesVO(CaseQueryResponseFiles caseQueryResponseFilesVO) {
		BeanUtils.copyProperties(caseQueryResponseFilesVO, this);
		if(caseQueryResponseFilesVO.getFileSize() != null) {
			this.setFileSize((caseQueryResponseFilesVO.getFileSize() / 1024) + 1);	
		}
	}

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		CaseQueryResponseFilesVO other = (CaseQueryResponseFilesVO) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/************************** Getters and Setters ***************************/

	public Long getCaseQueryResponseId() {
		return caseQueryResponseId;
	}

	public void setCaseQueryResponseId(Long caseQueryResponseId) {
		this.caseQueryResponseId = caseQueryResponseId;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFileExtension() {
		return fileExtension;
	}

	public void setFileExtension(String fileExtension) {
		this.fileExtension = fileExtension;
	}

	public String getFileDirectory() {
		return fileDirectory;
	}

	public void setFileDirectory(String fileDirectory) {
		this.fileDirectory = fileDirectory;
	}

	public Long getFileSize() {
		return fileSize;
	}

	public void setFileSize(Long fileSize) {
		this.fileSize = fileSize;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
}
