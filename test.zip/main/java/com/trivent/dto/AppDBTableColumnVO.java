package com.trivent.dto;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.springframework.beans.BeanUtils;

import com.trivent.constants.AppConstants;
import com.trivent.dto.base.BaseVO;
import com.trivent.models.AppDBTableColumn;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.dto
 * 
 * @FileName 	:
 *				AppDBTableColumnVO.java
 * @TypeName 	:
 * 				AppDBTableColumnVO
 * @DateAndTime :
 *				Feb 8, 2018 - 5:21:48 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description : To list , save and edit the values through path
 *              variable(objects) of App DBTable ColumnVO(used to interact with
 *              UI)
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public class AppDBTableColumnVO extends BaseVO {

  @SuppressWarnings("unused")
  private static final long serialVersionUID = 547786403186360280L;

  private String name = null;
  private String referenceTable = null;
  private String referenceTableColumn = null;
  private Integer size = null;
  private String dataType = null;
  private Integer seqNo = null;
  private String displayLabel = null;

  private Long appDBTableId = null;

  private boolean availableForAppUIScreen = false;
  private boolean availableForReport = false;

  public AppDBTableColumnVO() {
  }

  public AppDBTableColumnVO(AppDBTableColumn appDBTableColumn, Long appDBTableId) {
    BeanUtils.copyProperties(appDBTableColumn, this);
    this.setAppDBTableId(appDBTableId);
    this.setId(appDBTableColumn.getId());
    availableForAppUIScreen = appDBTableColumn.getAvailableForAppUIScreen() == AppConstants.YES;
    availableForReport = appDBTableColumn.getAvailableForReport() == AppConstants.YES;
  }

  /********************** hashcode, and equals methods **********************/

  @Override
  public int hashCode() {
    return new HashCodeBuilder().append(this.getId()).hashCode();
  }

  @Override
  public boolean equals(Object obj) {
    if (obj == null || obj.getClass() != getClass()) {
      return false;
    }
    AppDBTableColumnVO other = (AppDBTableColumnVO) obj;
    return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
  }

  /********************** Getters and Setters **********************/

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getReferenceTable() {
    return referenceTable;
  }

  public void setReferenceTable(String referenceTable) {
    this.referenceTable = referenceTable;
  }

  public String getReferenceTableColumn() {
    return referenceTableColumn;
  }

  public void setReferenceTableColumn(String referenceTableColumn) {
    this.referenceTableColumn = referenceTableColumn;
  }

  public Integer getSize() {
    return size;
  }

  public void setSize(Integer size) {
    this.size = size;
  }

  public String getDataType() {
    return dataType;
  }

  public void setDataType(String dataType) {
    this.dataType = dataType;
  }

  public String getDisplayLabel() {
    return displayLabel;
  }

  public void setDisplayLabel(String displayLabel) {
    this.displayLabel = displayLabel;
  }

  public Integer getSeqNo() {
    return seqNo;
  }

  public void setSeqNo(Integer seqNo) {
    this.seqNo = seqNo;
  }

  public boolean isAvailableForAppUIScreen() {
    return availableForAppUIScreen;
  }

  public void setAvailableForAppUIScreen(boolean availableForAppUIScreen) {
    this.availableForAppUIScreen = availableForAppUIScreen;
  }

  public boolean isAvailableForReport() {
    return availableForReport;
  }

  public void setAvailableForReport(boolean availableForReport) {
    this.availableForReport = availableForReport;
  }

  public Long getAppDBTableId() {
    return appDBTableId;
  }

  public void setAppDBTableId(Long appDBTableId) {
    this.appDBTableId = appDBTableId;
  }

}
