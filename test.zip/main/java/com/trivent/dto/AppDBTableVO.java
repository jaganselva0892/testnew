package com.trivent.dto;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.springframework.beans.BeanUtils;

import com.trivent.constants.AppConstants;
import com.trivent.dto.base.BaseVO;
import com.trivent.models.AppDBTable;
import com.trivent.models.AppDBTableColumn;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.dto
 * 
 * @FileName 	:
 *				AppDBTableVO.java
 * @TypeName 	:
 * 				AppDBTableVO
 * @DateAndTime :
 *				Feb 8, 2018 - 5:22:07 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description : To list , save and edit the values through path
 *              variable(objects) of App DBTableVO(used to interact with
 *              UI)
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public class AppDBTableVO extends BaseVO {

  @SuppressWarnings("unused")
private static final long serialVersionUID = 663173730525072997L;

  private String name = null;
  private Integer seqNo = null;
  private String displayLabel = null;

  private Boolean availableForAppUIScreen = false;
  private Boolean availableForReport = false;

  private List<AppDBTableColumnVO> appDBTableColumnVOs = null;

  public AppDBTableVO() {
  }

  public AppDBTableVO(AppDBTable appDBTable) {
    BeanUtils.copyProperties(appDBTable, this);
    this.setId(appDBTable.getId());
    if (appDBTable.getAppDBTableColumns() != null) {
      List<AppDBTableColumnVO> columnVOs = new ArrayList<>(appDBTable.getAppDBTableColumns().size());
      AppDBTableColumnVO appDBTableColumnVO = null;
      for (AppDBTableColumn appDBTableColumn : appDBTable.getAppDBTableColumns()) {
        appDBTableColumnVO = new AppDBTableColumnVO(appDBTableColumn, appDBTable.getId());
        columnVOs.add(appDBTableColumnVO);
      }
      this.setAppDBTableColumnVOs(columnVOs);
    }
    availableForAppUIScreen = appDBTable.getAvailableForAppUIScreen() == AppConstants.YES;
    availableForReport = appDBTable.getAvailableForReport() == AppConstants.YES;
  }

  /********************** hashcode, and equals methods **********************/

  @Override
  public int hashCode() {
    return new HashCodeBuilder().append(this.getId()).hashCode();
  }

  @Override
  public boolean equals(Object obj) {
    if (obj == null || obj.getClass() != getClass()) {
      return false;
    }
    AppDBTableVO other = (AppDBTableVO) obj;
    return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
  }

  /********************** Getters and Setters **********************/

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public List<AppDBTableColumnVO> getAppDBTableColumnVOs() {
    return appDBTableColumnVOs;
  }

  public void setAppDBTableColumnVOs(List<AppDBTableColumnVO> appDBTableColumnVOs) {
    this.appDBTableColumnVOs = appDBTableColumnVOs;
  }

  public Integer getSeqNo() {
    return seqNo;
  }

  public void setSeqNo(Integer seqNo) {
    this.seqNo = seqNo;
  }

  public String getDisplayLabel() {
    return displayLabel;
  }

  public Boolean getAvailableForAppUIScreen() {
    return availableForAppUIScreen;
  }

  public void setAvailableForAppUIScreen(Boolean availableForAppUIScreen) {
    this.availableForAppUIScreen = availableForAppUIScreen;
  }

  public Boolean getAvailableForReport() {
    return availableForReport;
  }

  public void setAvailableForReport(Boolean availableForReport) {
    this.availableForReport = availableForReport;
  }

  public void setDisplayLabel(String displayLabel) {
    this.displayLabel = displayLabel;
  }

}
