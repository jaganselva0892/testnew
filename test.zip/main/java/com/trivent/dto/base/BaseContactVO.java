package com.trivent.dto.base;

/**
 * @ProjectName : trivent
 * @PackageName : com.trivent.dto.base
 * 
 * @FileName : BaseContactVO.java
 * @TypeName : BaseContactVO
 * @DateAndTime : Feb 8, 2018 - 6:17:37 PM
 * 
 * @Author : karthik
 * 
 * @Description : To maintain common info of user details (Global Maintaining)
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
public class BaseContactVO extends BaseVO {

	@SuppressWarnings("unused")
	private static final long serialVersionUID = 2288845065875172011L;

	private String firstName = null;
	private String lastName = null;
	private String company = null;
	private String jobTitle = null;
	private String address1 = null;
	private String address2 = null;
	private String city = null;
	private String state = null;
	private String zipCode = null;
	private String phone = null;
	private String extn = null;
	private String fax = null;
	private String email = null;

	/********************** Getters and Setters **********************/

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getExtn() {
		return extn;
	}

	public void setExtn(String extn) {
		this.extn = extn;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

}
