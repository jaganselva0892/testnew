package com.trivent.dto.base;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.joda.time.DateTime;

import com.trivent.constants.AppConstants;

/**
 * @ProjectName : trivent
 * @PackageName : com.trivent.dto.base
 * 
 * @FileName : BaseCaseQueryVO.java
 * @TypeName : BaseCaseQueryVO
 * @DateAndTime : Feb 8, 2018 - 6:17:23 PM
 * 
 * @Author : seetha
 * 
 * @Description : To have common necessary details of query (email)related Info
 *              (Global Maintaining)
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
public class BaseCaseQueryVO extends BaseVO {
	
	@SuppressWarnings("unused")
	private static final long serialVersionUID = -4165693448942019989L;

	private String queryFrom = null;
	private String queryTo = null;
	private String queryCc = null;
	private String queryBcc = null;
	private Integer seqNo = null;

	private Boolean isInternal = false;
	private Boolean isVisible2Client = false;
	private Boolean isEmailNotify = false;
	private Boolean isNewQuery = false;

	private String ownerRoleType = null;
	private Character querySource = AppConstants.QUERY_SOURCE_PORTAL;

	private String callbackScreen = null;
	private DateTime createdDate;

	private String queryCreatedBy = null;
	
	private String timeZoneFormat = AppConstants.DATE_TIME_FORMAT;
	
	

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		BaseCaseQueryVO other = (BaseCaseQueryVO) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public Integer getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(Integer seqNo) {
		this.seqNo = seqNo;
	}

	public String getQueryFrom() {
		return queryFrom;
	}

	public void setQueryFrom(String queryFrom) {
		this.queryFrom = queryFrom;
	}

	public String getQueryTo() {
		return queryTo;
	}

	public void setQueryTo(String queryTo) {
		this.queryTo = queryTo;
	}

	public String getQueryCc() {
		return queryCc;
	}

	public void setQueryCc(String queryCc) {
		this.queryCc = queryCc;
	}

	public Boolean getIsInternal() {
		return isInternal;
	}

	public void setIsInternal(Boolean isInternal) {
		this.isInternal = isInternal;
	}

	public Boolean getIsVisible2Client() {
		return isVisible2Client;
	}

	public void setIsVisible2Client(Boolean isVisible2Client) {
		this.isVisible2Client = isVisible2Client;
	}

	public Boolean getIsEmailNotify() {
		return isEmailNotify;
	}

	public void setIsEmailNotify(Boolean isEmailNotify) {
		this.isEmailNotify = isEmailNotify;
	}

	public String getOwnerRoleType() {
		return ownerRoleType;
	}

	public void setOwnerRoleType(String ownerRoleType) {
		this.ownerRoleType = ownerRoleType;
	}

	public Character getQuerySource() {
		return querySource;
	}

	public void setQuerySource(Character querySource) {
		this.querySource = querySource;
	}

	public DateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(DateTime createdDate) {
		this.createdDate = createdDate;
	}

	public Boolean getIsNewQuery() {
		return isNewQuery;
	}

	public void setIsNewQuery(Boolean isNewQuery) {
		this.isNewQuery = isNewQuery;
	}

	public String getCallbackScreen() {
		return callbackScreen;
	}

	public void setCallbackScreen(String callbackScreen) {
		this.callbackScreen = callbackScreen;
	}

	public String getQueryCreatedBy() {
		return queryCreatedBy;
	}

	public void setQueryCreatedBy(String queryCreatedBy) {
		this.queryCreatedBy = queryCreatedBy;
	}

	public String getQueryBcc() {
		return queryBcc;
	}

	public void setQueryBcc(String queryBcc) {
		this.queryBcc = queryBcc;
	}

	public String getTimeZoneFormat() {
		return timeZoneFormat;
	}

	public void setTimeZoneFormat(String timeZoneFormat) {
		this.timeZoneFormat = timeZoneFormat;
	}

	
	
}