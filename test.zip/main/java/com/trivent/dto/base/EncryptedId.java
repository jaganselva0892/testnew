package com.trivent.dto.base;

import java.io.Serializable;

import com.trivent.utils.EncryptionUtils;

/**
 * @ProjectName : trivent
 * @PackageName : com.trivent.dto.base
 * 
 * @FileName : EncryptedId.java
 * @TypeName : EncryptedId
 * @DateAndTime : Feb 8, 2018 - 6:18:40 PM
 * 
 * @Author : seetha
 * 
 * @Description : To convert auto generate id to encrypted
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
public class EncryptedId implements Serializable {

	

	/**
	 * 
	 */
	private static final long serialVersionUID = -5266088295791074964L;
	private Long id = null;

	public EncryptedId(String encryptedId) {
		this.id = EncryptionUtils.decryptId(encryptedId);
	}

	public EncryptedId(Long id) {
		this.id = id;
	}

	public String getEncryptedId() {
		// Need to trigger URL encode. Hence call encryption utils.
		return EncryptionUtils.encryptId(id);
	}

	/********************** Getters and Setters **********************/

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	/********************** toString methods **********************/

	@Override
	public String toString() {
		return String.format("%s [id = %d]", this.getClass().getName(), this.getId());
	}

}
