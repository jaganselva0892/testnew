package com.trivent.dto;

import java.io.IOException;
import java.util.Calendar;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.springframework.beans.BeanUtils;
import org.springframework.web.multipart.MultipartFile;

import com.trivent.constants.AppConstants;
import com.trivent.dto.base.BaseVO;
import com.trivent.models.CaseFile;
import com.trivent.utils.CommonUtils;

/**
 * @ProjectName : trivent
 * @PackageName : com.trivent.dto
 * 
 * @FileName : CaseFileVO.java
 * @TypeName : CaseFileVO
 * @DateAndTime : Feb 8, 2018 - 5:38:01 PM
 * 
 * @Author : seetha
 * 
 * @Description : To list , save and edit the values through path
 *              variable(objects) of CaseFileVO(used to interact with UI)
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
public class CaseFileVO extends BaseVO {

	@SuppressWarnings("unused")
	private static final long serialVersionUID = -3422830464510211652L;

	private Long caseId = null;

	private String name = null;
	private String fileExtension = null;
	private String fileContentType = null;
	private Integer seqNo = null;
	private boolean fileZipped = false;
	private boolean isLatest = false;

	private String fileDescription = null;
	private String fileLocation = null;
	private String notes = null;
	private Integer version = null;
	private Integer filePageCount = null;
	private Long fileSize = null;
	private String rootPath = null;

	private String uploadedTime;

	private boolean fileDownloaded = false;
	private Calendar downloadedDateTime = null;
	private Integer downloadCount = null;
	private String action = null;
	private String fileRename = null;
	private String replicatedFileLocation = null;
	private String fileName = null;
	private String pageCountStatus = null;
	private Character uploadRemotely = null;
	private Integer fileType = 1;
	private Long sourceCaseFileId = null;
	private Long addRecID = null;

	private Character archived = AppConstants.NO;

	public CaseFileVO() {
	}

	public CaseFileVO(MultipartFile mpf, String rootPath, String filePathExtension) throws IOException {
		this.setName(mpf.getOriginalFilename());
		this.setFileExtension(CommonUtils.getFileExtenstion(name));
		this.setFileContentType(mpf.getContentType());
		this.setRootPath(rootPath);
		this.setFileLocation(filePathExtension);
	}

	public CaseFileVO(CaseFile caseFile) {
		BeanUtils.copyProperties(caseFile, this);
		this.setId(caseFile.getId());
		if (caseFile.getClientCase() != null) {
			this.setCaseId(caseFile.getClientCase().getId());
		}
		fileZipped = caseFile.getFileZipped() == AppConstants.YES;
		isLatest = caseFile.getIsLatest() == AppConstants.YES;
		this.setFileSize((caseFile.getFileSize() / 1024) + 1);
		this.setUploadedTime(CommonUtils.dateTimeToString(caseFile.getCreatedDate()));
		this.setReplicatedFileLocation(caseFile.getFileLocation());
		this.setFileName(caseFile.getName());
	}

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		CaseFileVO other = (CaseFileVO) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFileExtension() {
		return fileExtension;
	}

	public void setFileExtension(String fileExtension) {
		this.fileExtension = fileExtension;
	}

	public String getFileContentType() {
		return fileContentType;
	}

	public void setFileContentType(String fileContentType) {
		this.fileContentType = fileContentType;
	}

	public Integer getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(Integer seqNo) {
		this.seqNo = seqNo;
	}

	public boolean isFileZipped() {
		return fileZipped;
	}

	public void setFileZipped(boolean fileZipped) {
		this.fileZipped = fileZipped;
	}

	public boolean isLatest() {
		return isLatest;
	}

	public void setLatest(boolean isLatest) {
		this.isLatest = isLatest;
	}

	public String getFileDescription() {
		return fileDescription;
	}

	public void setFileDescription(String fileDescription) {
		this.fileDescription = fileDescription;
	}

	public String getFileLocation() {
		return fileLocation;
	}

	public void setFileLocation(String fileLocation) {
		this.fileLocation = fileLocation;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public Integer getFilePageCount() {
		return filePageCount;
	}

	public void setFilePageCount(Integer filePageCount) {
		this.filePageCount = filePageCount;
	}

	public Long getFileSize() {
		return fileSize;
	}

	public void setFileSize(Long fileSize) {
		this.fileSize = fileSize;
	}

	public String getRootPath() {
		return rootPath;
	}

	public void setRootPath(String rootPath) {
		this.rootPath = rootPath;
	}

	public String getUploadedTime() {
		return uploadedTime;
	}

	public void setUploadedTime(String uploadedTime) {
		this.uploadedTime = uploadedTime;
	}

	public boolean isFileDownloaded() {
		return fileDownloaded;
	}

	public void setFileDownloaded(boolean fileDownloaded) {
		this.fileDownloaded = fileDownloaded;
	}

	public Calendar getDownloadedDateTime() {
		return downloadedDateTime;
	}

	public void setDownloadedDateTime(Calendar downloadedDateTime) {
		this.downloadedDateTime = downloadedDateTime;
	}

	public Integer getDownloadCount() {
		return downloadCount;
	}

	public void setDownloadCount(Integer downloadCount) {
		this.downloadCount = downloadCount;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getFileRename() {
		return fileRename;
	}

	public void setFileRename(String fileRename) {
		this.fileRename = fileRename;
	}

	public String getReplicatedFileLocation() {
		return replicatedFileLocation;
	}

	public void setReplicatedFileLocation(String replicatedFileLocation) {
		this.replicatedFileLocation = replicatedFileLocation;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getPageCountStatus() {
		return pageCountStatus;
	}

	public void setPageCountStatus(String pageCountStatus) {
		this.pageCountStatus = pageCountStatus;
	}

	public Character getUploadRemotely() {
		return uploadRemotely;
	}

	public void setUploadRemotely(Character uploadRemotely) {
		this.uploadRemotely = uploadRemotely;
	}

	public Integer getFileType() {
		return fileType;
	}

	public void setFileType(Integer fileType) {
		this.fileType = fileType;
	}

	public Long getSourceCaseFileId() {
		return sourceCaseFileId;
	}

	public void setSourceCaseFileId(Long sourceCaseFileId) {
		this.sourceCaseFileId = sourceCaseFileId;
	}

	public Character getArchived() {
		return archived;
	}

	public void setArchived(Character archived) {
		this.archived = archived;
	}

	public Long getAddRecID() {
		return addRecID;
	}

	public void setAddRecID(Long addRecID) {
		this.addRecID = addRecID;
	}
}
