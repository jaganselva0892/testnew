package com.trivent.dto;

import java.util.List;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.dto.base.BaseVO;

public class CaseDetailsVO  extends BaseVO{
	
	private boolean newCaseRedirect = false;
	private CaseVO caseVO = null;
	private List<CaseFileVO> caseFileVOs = null;
	private List<RowVO> casesQueriesRowVO = null;
	private List<CaseResultFileVO> caseResultFileVOs = null;
	//private List<AppAuditLogHistoryVO> appAuditlogs = null;
	private String title = null;

	public CaseDetailsVO() {
	}
	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		CaseDetailsVO other = (CaseDetailsVO) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public CaseVO getCaseVO() {
		return caseVO;
	}

	public void setCaseVO(CaseVO caseVO) {
		this.caseVO = caseVO;
	}

	public List<CaseFileVO> getCaseFileVOs() {
		return caseFileVOs;
	}

	public void setCaseFileVOs(List<CaseFileVO> caseFileVOs) {
		this.caseFileVOs = caseFileVOs;
	}

	public List<CaseResultFileVO> getCaseResultFileVOs() {
		return caseResultFileVOs;
	}

	public void setCaseResultFileVOs(List<CaseResultFileVO> caseResultFileVOs) {
		this.caseResultFileVOs = caseResultFileVOs;
	}

	public boolean isNewCaseRedirect() {
		return newCaseRedirect;
	}

	public void setNewCaseRedirect(boolean newCaseRedirect) {
		this.newCaseRedirect = newCaseRedirect;
	}

	public List<RowVO> getCasesQueriesRowVO() {
		return casesQueriesRowVO;
	}

	public void setCasesQueriesRowVO(List<RowVO> casesQueriesRowVO) {
		this.casesQueriesRowVO = casesQueriesRowVO;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

}
