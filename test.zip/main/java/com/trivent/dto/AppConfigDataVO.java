package com.trivent.dto;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.springframework.beans.BeanUtils;

import com.trivent.dto.base.BaseVO;
import com.trivent.models.AppConfigData;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.dto
 * 
 * @FileName 	:
 *				AppConfigDataVO.java
 * @TypeName 	:
 * 				AppConfigDataVO
 * @DateAndTime :
 *				Feb 8, 2018 - 5:20:48 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description :To list , save and edit the values through path
 *              variable(objects) of App Config DataVO(used to interact with
 *              UI) 
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public class AppConfigDataVO extends BaseVO {

	@SuppressWarnings("unused")
	private static final long serialVersionUID = 6110498141023046342L;

	private String name;
	private String dataValue;
	
	private String strdataValue;

	public AppConfigDataVO() {
	}
	
	public AppConfigDataVO(AppConfigData appConfigData) {
		BeanUtils.copyProperties(appConfigData, this);
	}

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		AppConfigDataVO other = (AppConfigDataVO) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDataValue() {
		return dataValue;
	}

	public void setDataValue(String dataValue) {
		this.dataValue = dataValue;
	}
	
	public String getStrdataValue() {
		return strdataValue;
	}

	public void setStrdataValue(String strdataValue) {
		this.strdataValue = strdataValue;
	}

}
