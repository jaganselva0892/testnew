package com.trivent.dto;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.springframework.beans.BeanUtils;

import com.trivent.constants.AppConstants;
import com.trivent.dto.base.BaseVO;
import com.trivent.models.AppUIScreenField;
import com.trivent.models.Case;
import com.trivent.models.Production;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.dto
 * 
 * @FileName 	:
 *				ProductionVO.java
 * @TypeName 	:
 * 				ProductionVO
 * @DateAndTime :
 *				Feb 8, 2018 - 5:57:51 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description :  To list , save and edit the values through path
 *              variable(objects) of ProductionVO(used to interact with UI)
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public class ProductionVO extends BaseVO {

	/**
	 * 
	 */
	@SuppressWarnings("unused")
	private static final long serialVersionUID = -2517274307176385911L;

	private String caseId = null;
	private Long CaseIdInLong = null;
	private Case appCase = null;
	private String caseEncId = null;
	private String assignedTo = null;
	private String assignedBy = null;
	private Long assignTo = null;
	private Long productionStatus = null;
	private int completeProcess = 0;
	private Character qcApproval = AppConstants.NO;
	private boolean qcApprovalBool = false;
	private Character mdApproval = AppConstants.NO;
	private boolean mdApprovalBool = false;
	private Character isLatestUser = AppConstants.YES;
	private Character isActiveUser = AppConstants.YES;
	private Character isReview = AppConstants.NO;
	private String reviewComments = null;
	private boolean reviewStatus = false;
	private Integer reviewScore = 0;
	private List<ProductionFilesVO> productionFilesVO = null;
	private List<CaseFileVO> caseFileVOs;
	private List<RowVO> casesQueriesRowVOs;
	private Character isClientDocument = AppConstants.NO;
	private String isDeliver = null;
	private Calendar dateOfClarification = null;
	private String clientId = null;
	private String clientdocName = null;
	private Long scoreType = null;
	private String scoreDescription;
	private String callbackScreen = null;
	private List<AppUIScreenFieldVO> appUIScreenFieldVOs = null;
	private String notMandatory =null;
	private String parentCaseId = null;

	public ProductionVO() {
		isDeliver = AppConstants.PRODUCTION_FILE_NOT_DELIVERED_STATUS;
	}

	public ProductionVO(Production production) {
		BeanUtils.copyProperties(production, this);
	}

	public ProductionVO(Case appCase, List<AppUIScreenField> appUIScreenFields, String callbackScreen) {
		BeanUtils.copyProperties(appCase, this);
		this.setId(appCase.getId());
		this.callbackScreen = callbackScreen;
		int size = appUIScreenFields.size();
		if (appUIScreenFields.isEmpty()) {
			size = 1;
		}
		// Added on 13/07/2016
		// this.setIsCustomerDownloaded(appCase.getIsCustomerDownload());
		// this.setCaseFilesPageCount(appCase.getPageCount());
		AppUIScreenFieldVO appUIScreenFieldVO;
		List<AppUIScreenFieldVO> fieldVOs = new ArrayList<>(size);
		for (AppUIScreenField appUIScreenField : appUIScreenFields) {
			appUIScreenFieldVO = new AppUIScreenFieldVO(appUIScreenField, appUIScreenField.getAppUiScreen());
			fieldVOs.add(appUIScreenFieldVO);
		}
		this.setAppUIScreenFieldVOs(fieldVOs);
	}

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		ProductionVO other = (ProductionVO) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public String getCaseId() {
		return caseId;
	}

	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}

	public Long getAssignTo() {
		return assignTo;
	}

	public void setAssignTo(Long assignTo) {
		this.assignTo = assignTo;
	}

	public Long getProductionStatus() {
		return productionStatus;
	}

	public void setProductionStatus(Long productionStatus) {
		this.productionStatus = productionStatus;
	}

	public int getCompleteProcess() {
		return completeProcess;
	}

	public void setCompleteProcess(int completeProcess) {
		this.completeProcess = completeProcess;
	}

	public Character getQCApproval() {
		return qcApproval;
	}

	public void setQCApproval(Character qcApproval) {
		this.qcApproval = qcApproval;
	}

	public boolean getQCApprovalBool() {
		return qcApprovalBool;
	}

	public void setQCApprovalBool(boolean qcApprovalBool) {
		this.qcApprovalBool = qcApprovalBool;
	}

	public Character getMDApproval() {
		return mdApproval;
	}

	public void setMDApproval(Character mdApproval) {
		this.mdApproval = mdApproval;
	}

	public boolean getMDApprovalBool() {
		return mdApprovalBool;
	}

	public void setMDApprovalBool(boolean mdApprovalBool) {
		this.mdApprovalBool = mdApprovalBool;
	}

	public Character getIsLatestUser() {
		return isLatestUser;
	}

	public void setIsLatestUser(Character isLatestUser) {
		this.isLatestUser = isLatestUser;
	}

	public Character getIsActiveUser() {
		return isActiveUser;
	}

	public void setIsActiveUser(Character isActiveUser) {
		this.isActiveUser = isActiveUser;
	}

	public Character getIsReview() {
		return isReview;
	}

	public void setIsReview(Character isReview) {
		this.isReview = isReview;
	}

	public String getReviewComments() {
		return reviewComments;
	}

	public void setReviewComments(String reviewComments) {
		this.reviewComments = reviewComments;
	}

	public boolean getReviewStatus() {
		return reviewStatus;
	}

	public void setReviewStatus(boolean reviewStatus) {
		this.reviewStatus = reviewStatus;
	}

	public Integer getReviewScore() {
		return reviewScore;
	}

	public void setReviewScore(Integer reviewScore) {
		this.reviewScore = reviewScore;
	}

	public List<ProductionFilesVO> getProductionFilesVO() {
		return productionFilesVO;
	}

	public void setProductionFilesVO(List<ProductionFilesVO> productionFilesVO) {
		this.productionFilesVO = productionFilesVO;
	}

	public List<CaseFileVO> getCaseFileVOs() {
		return caseFileVOs;
	}

	public void setCaseFileVOs(List<CaseFileVO> caseFileVOs) {
		this.caseFileVOs = caseFileVOs;
	}

	public List<RowVO> getCasesQueriesRowVO() {
		return casesQueriesRowVOs;
	}

	public void setCasesQueriesRowVO(List<RowVO> casesQueriesRowVOs) {
		this.casesQueriesRowVOs = casesQueriesRowVOs;
	}

	public String getCaseEncryptedId() {
		return caseEncId;
	}

	public void setCaseEncryptedId(String caseEncId) {
		this.caseEncId = caseEncId;
	}

	public Character getIsClientDocument() {
		return isClientDocument;
	}

	public void setIsClientDocument(Character isClientDocument) {
		this.isClientDocument = isClientDocument;
	}

	public Case getAppCase() {
		return appCase;
	}

	public void setAppCase(Case appCase) {
		this.appCase = appCase;
	}

	public String getIsDeliver() {
		return isDeliver;
	}

	public void setIsDeliver(String isDeliver) {
		this.isDeliver = isDeliver;
	}

	public Calendar getDateOfClarification() {
		return dateOfClarification;
	}

	public void setDateOfClarification(Calendar dateOfClarification) {
		this.dateOfClarification = dateOfClarification;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getClientdocName() {
		return clientdocName;
	}

	public void setClientdocName(String clientdocName) {
		this.clientdocName = clientdocName;
	}

	public Long getCaseIdInLong() {
		return CaseIdInLong;
	}

	public void setCaseIdInLong(Long caseIdInLong) {
		CaseIdInLong = caseIdInLong;
	}

	public Long getScoreType() {
		return scoreType;
	}

	public void setScoreType(Long scoreType) {
		this.scoreType = scoreType;
	}

	public String getScoreDescription() {
		return scoreDescription;
	}

	public void setScoreDescription(String scoreDescription) {
		this.scoreDescription = scoreDescription;
	}

	public String getAssignedTo() {
		return assignedTo;
	}

	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}

	public String getAssignedBy() {
		return assignedBy;
	}

	public void setAssignedBy(String assignedBy) {
		this.assignedBy = assignedBy;

	}

	public String getCallbackScreen() {
		return callbackScreen;
	}

	public void setCallbackScreen(String callbackScreen) {
		this.callbackScreen = callbackScreen;
	}

	public List<AppUIScreenFieldVO> getAppUIScreenFieldVOs() {
		return appUIScreenFieldVOs;
	}

	public void setAppUIScreenFieldVOs(List<AppUIScreenFieldVO> appUIScreenFieldVOs) {
		this.appUIScreenFieldVOs = appUIScreenFieldVOs;
	}

	public String getParentCaseId() {
		return parentCaseId;
	}

	public void setParentCaseId(String parentCaseId) {
		this.parentCaseId = parentCaseId;
	}

	public String getNotMandatory() {
		return notMandatory;
	}

	public void setNotMandatory(String notMandatory) {
		this.notMandatory = notMandatory;
	}
	
	
}
