package com.trivent.dto;

import java.util.Objects;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.springframework.beans.BeanUtils;

import com.trivent.constants.AppConstants;
import com.trivent.dto.base.BaseVO;
import com.trivent.logging.LogManager;
import com.trivent.logging.Logger;
import com.trivent.models.ProdFile;
import com.trivent.models.Production;
import com.trivent.utils.CommonUtils;

/**
 * @ProjectName : trivent
 * @PackageName : com.trivent.dto
 * 
 * @FileName : ProductionFilesVO.java
 * @TypeName : ProductionFilesVO
 * @DateAndTime : Feb 8, 2018 - 5:57:08 PM
 * 
 * @Author : seetha
 * 
 * @Description : To list , save and edit the values through path
 *              variable(objects) of ProductionFilesVO(used to interact with UI)
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
public class ProductionFilesVO extends BaseVO {

	/**
	 * 
	 */
	@SuppressWarnings("unused")
	private static final long serialVersionUID = 2404520141927944597L;

	private Production productionId = null;
	private String fileContentType = null;
	private String fileDescription = null;
	private String fileExtension = null;
	private String assignedBy = null;
	private String fileLocation = null;
	private String fileName = null;
	private Integer filePageCount = 0;
	private Integer fileSeqNo = null;
	private Character fileZipped = AppConstants.NO;
	private String rootPath = null;
	private Long fileSize = null;
	private Integer version = null;
	private Character isLatest = AppConstants.YES;
	private Character isDeliverable = AppConstants.NO;
	private boolean isDeliverableBool = false;

	private Character isDelivered = AppConstants.NO;
	private boolean isDeliveredBool = false;
	private String uploadedTime;

	private Long prodId = null;
	
	private Character backup = AppConstants.NO;
	

	public ProductionFilesVO() {

	}

	private static final Logger LOGGER = LogManager.getLogger();
	private static final String CLASS_NAME = "DivisionController";

	public ProductionFilesVO(ProdFile prodFile) {
		BeanUtils.copyProperties(prodFile, this);
		this.setIsDeliverableBool((Objects.equals(prodFile.getIsDeliverable(), AppConstants.YES) ? true : false));
		this.setFileSize((prodFile.getFileSize() / 1024) + 1);
		this.setUploadedTime(CommonUtils.dateTimeToString(prodFile.getCreatedDate()));
		try {
			this.prodId = prodFile.getProduction().getId();
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "ProductionFilesVOProductionFilesVO", e);
		}
	}

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		ProductionFilesVO other = (ProductionFilesVO) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public Production getProduction() {
		return productionId;
	}

	public void setProduction(Production productionId) {
		this.productionId = productionId;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFileExtension() {
		return fileExtension;
	}

	public void setFileExtension(String fileExtension) {
		this.fileExtension = fileExtension;
	}

	public String getFileContentType() {
		return fileContentType;
	}

	public void setFileContentType(String fileContentType) {
		this.fileContentType = fileContentType;
	}

	public Character getFileZipped() {
		return fileZipped;
	}

	public void setFileZipped(Character fileZipped) {
		this.fileZipped = fileZipped;
	}

	public Integer getSeqNo() {
		return fileSeqNo;
	}

	public void setSeqNo(Integer fileSeqNo) {
		this.fileSeqNo = fileSeqNo;
	}

	public String getFileDescription() {
		return fileDescription;
	}

	public void setFileDescription(String fileDescription) {
		this.fileDescription = fileDescription;
	}

	public String getFileLocation() {
		return fileLocation;
	}

	public void setFileLocation(String fileLocation) {
		this.fileLocation = fileLocation;
	}

	public String getRootPath() {
		return rootPath;
	}

	public void setRootPath(String rootPath) {
		this.rootPath = rootPath;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public Integer getFilePageCount() {
		return filePageCount;
	}

	public void setFilePageCount(Integer filePageCount) {
		this.filePageCount = filePageCount;
	}

	public Character getIsLatest() {
		return isLatest;
	}

	public void setIsLatest(Character isLatest) {
		this.isLatest = isLatest;
	}

	public Long getFileSize() {
		return fileSize;
	}

	public void setFileSize(Long fileSize) {
		this.fileSize = fileSize;
	}

	public Character getIsDeliverable() {
		return isDeliverable;
	}

	public void setIsDeliverable(Character isDeliverable) {
		this.isDeliverable = isDeliverable;
	}

	public boolean getIsDeliverableBool() {
		return isDeliverableBool;
	}

	public void setIsDeliverableBool(boolean isDeliverableBool) {
		this.isDeliverableBool = isDeliverableBool;
	}

	public String getAssignedBy() {
		return assignedBy;
	}

	public void setAssignedBy(String assignedBy) {
		this.assignedBy = assignedBy;
	}

	public Long getProdId() {
		return prodId;
	}

	public void setProdId(Long prodId) {
		this.prodId = prodId;
	}

	public Character getIsDelivered() {
		return isDelivered;
	}

	public void setIsDelivered(Character isDelivered) {
		this.isDelivered = isDelivered;
	}

	public boolean isDeliveredBool() {
		return isDeliveredBool;
	}

	public void setDeliveredBool(boolean isDeliveredBool) {
		this.isDeliveredBool = isDeliveredBool;
	}

	public String getUploadedTime() {
		return uploadedTime;
	}

	public void setUploadedTime(String uploadedTime) {
		this.uploadedTime = uploadedTime;
	}

	public Character getBackup() {
		return backup;
	}

	public void setBackup(Character backup) {
		this.backup = backup;
	}

}
