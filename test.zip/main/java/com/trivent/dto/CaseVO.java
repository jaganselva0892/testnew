package com.trivent.dto;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.springframework.beans.BeanUtils;

import com.trivent.constants.AppConstants;
import com.trivent.dto.base.BaseVO;
import com.trivent.models.Account;
import com.trivent.models.AppUIScreenField;
import com.trivent.models.Case;
import com.trivent.models.Contact;
import com.trivent.models.StatusFlowRef;
import com.trivent.models.User;

/**
 * @ProjectName : trivent
 * @PackageName : com.trivent.dto
 * 
 * @FileName : CaseVO.java
 * @TypeName : CaseVO
 * @DateAndTime : Feb 8, 2018 - 5:40:21 PM
 * 
 * @Author : seetha
 * 
 * @Description :To list , save and edit the values through path
 *              variable(objects) of CaseVO(used to interact with UI)
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
public class CaseVO extends BaseVO {

	@SuppressWarnings("unused")
	private static final long serialVersionUID = -3422830464510211652L;

	private Long clientId = null;
	private Long accountId = null;
	private Long jobId = null;
	private Long parentCaseId = null;

	private Map<Long, String> jobMap = null;
	//private Map<Long, String> accountMap = null;
	private Map<Long, String> parentCaseMap = null;
	private Map<Long, String> typeMap = null;
	private List<ContactVO> contactVOs = null;
	
	List<CaseVO> caseList = null;

	private Map<String, String> csStatusMap = null;

	private List<AppUIScreenFieldVO> appUIScreenFieldVOs = null;
	private List<AppItemVO> caseServicesVOs = null;
	private List<AppItemVO> caseTypeVOs = null;
	// Added on 13/07/2016
	private Character isCustomerDownloaded = 'N';
	private Integer caseFilesPageCount = null;

	private String productionStatus = null;
	private String productionCompletePercentage = null;

	private String title;
	private String caseContactUserIds = null;
	
	private String lsProdStaff;
	private String lsProdLead;
	private String lsMD;
	private String lsQCReviewer;

	private String callbackScreen = null;

	private String assignedTo = null;

	private String strCaseId = null;
	private List<ProductionFilesVO> productionFilesVO = null;
	// private String name=null;
	private String name = null;
	private Long caseId = null;
	// Pagination Variables
	private int pageNo = 1;
	private int recordsPerPage = 50;
	private int totalPages = 0;
	private int currentRecords = 0;
	private long totalRecords = 0;

	private String caseCode = null;

	private String serviceReqShortCode;
	private Long caseFilesHistoryId = null;
	
	private String strparentCaseEncryId = null;
	private String caseOverview = null;
	private String caseNotes = null;
	
	private String clientType = null;

	private String cf_3_Text;
	private String cf_3_Number;
	
	private String clientNotes;
	
	private String cf_2_LongText;
	
	private String csDeliveryDate;
	
	private List<DropDownVO> accountMap = null;
	
	

	public CaseVO() {
	}

	public CaseVO(List<CaseVO> caseList) {
		BeanUtils.copyProperties(caseList, this);
		for (CaseVO caseVOs : caseList) {
			this.setId(caseVOs.getId());
		}
	}

	public CaseVO(Case appCase) {

		BeanUtils.copyProperties(appCase, this);
		this.setId(appCase.getId());

		this.setIsCustomerDownloaded(appCase.getIsCustomerDownload());
		this.setCaseFilesPageCount(appCase.getPageCount());

	}

	public CaseVO(Case appCase, List<AppUIScreenField> appUIScreenFields, String callbackScreen) {
		BeanUtils.copyProperties(appCase, this);
		this.setId(appCase.getId());
		this.callbackScreen = callbackScreen;
		int size = appUIScreenFields.size();
		if (appUIScreenFields.isEmpty()) {
			size = 1;
		}
		// Added on 13/07/2016
		this.setIsCustomerDownloaded(appCase.getIsCustomerDownload());
		this.setCaseFilesPageCount(appCase.getPageCount());
		AppUIScreenFieldVO appUIScreenFieldVO;
		List<AppUIScreenFieldVO> fieldVOs = new ArrayList<>(size);
		for (AppUIScreenField appUIScreenField : appUIScreenFields) {
			appUIScreenFieldVO = new AppUIScreenFieldVO(appUIScreenField, appUIScreenField.getAppUiScreen());
			fieldVOs.add(appUIScreenFieldVO);
		}
		this.setAppUIScreenFieldVOs(fieldVOs);
	}

	public CaseVO(Case appCase, List<AppUIScreenField> appUIScreenFields, List<AppItemVO> caseServicesVOs,
			List<AppItemVO> caseTypeVOs) {
		this(appCase, appUIScreenFields, null);
		this.setCaseServicesVOs(caseServicesVOs);
		this.setCaseTypeVOs(caseTypeVOs);
	}

	public void populate(List<Contact> contacts, User caseClient, List<Account> accounts,
			List<StatusFlowRef> csStatusFlowRefs, Character isVisible) {
		if (contacts != null && !contacts.isEmpty()) {
			this.contactVOs = new ArrayList<>(contacts.size());
			for (Contact contact : contacts) {
				this.contactVOs.add(new ContactVO(contact));

			}
		}
		if (accounts != null && !accounts.isEmpty()) {
			
			this.accountMap = new ArrayList<>(accounts.size());

			for (Account account : accounts) {
				if (isVisible == AppConstants.YES) {
					DropDownVO dropDownVO= new DropDownVO();
					dropDownVO.setValue(account.getId());
					dropDownVO.setText(account.getName() + " " + "-" + " " + account.getAccountCode());
					accountMap.add(dropDownVO);	
							
				} else {
					DropDownVO dropDownVO= new DropDownVO();
					dropDownVO.setValue(account.getId());
					dropDownVO.setText(account.getName());
					accountMap.add(dropDownVO);	
					
				}
			}

		}
		if (csStatusFlowRefs != null)

		{
			csStatusMap = new LinkedHashMap<>(csStatusFlowRefs.size());
			for (StatusFlowRef statusFlowRef : csStatusFlowRefs) {
				csStatusMap.put(statusFlowRef.getCustomerSupportStatus(), statusFlowRef.getCustomerSupportStatus());
			}
		}
		if (caseClient != null) {
			this.setClientId(caseClient.getId());
			this.setAccountId(caseClient.getAccount().getId());
		}
	}

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		CaseVO other = (CaseVO) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public Long getClientId() {
		return clientId;
	}

	public void setClientId(Long clientId) {
		this.clientId = clientId;
	}

	public Long getAccountId() {
		return accountId;
	}

	public void setAccountId(Long accountId) {
		this.accountId = accountId;
	}

	public Long getJobId() {
		return jobId;
	}

	public void setJobId(Long jobId) {
		this.jobId = jobId;
	}

	public Long getParentCaseId() {
		return parentCaseId;
	}

	public void setParentCaseId(Long parentCaseId) {
		this.parentCaseId = parentCaseId;
	}

	public Map<Long, String> getJobMap() {
		return jobMap;
	}

	public void setJobMap(Map<Long, String> jobMap) {
		this.jobMap = jobMap;
	}

	public Map<Long, String> getParentCaseMap() {
		return parentCaseMap;
	}

	public void setParentCaseMap(Map<Long, String> parentCaseMap) {
		this.parentCaseMap = parentCaseMap;
	}

	public Map<String, String> getCsStatusMap() {
		return csStatusMap;
	}

	public void setCsStatusMap(Map<String, String> csStatusMap) {
		this.csStatusMap = csStatusMap;
	}

	public Map<Long, String> getTypeMap() {
		return typeMap;
	}

	public void setTypeMap(Map<Long, String> typeMap) {
		this.typeMap = typeMap;
	}

	public List<CaseVO> getCaseList() {
		return caseList;
	}

	public void setCaseList(List<CaseVO> caseList) {
		this.caseList = caseList;
	}

	public List<ContactVO> getContactVOs() {
		return contactVOs;
	}

	public void setContactVOs(List<ContactVO> contactVOs) {
		this.contactVOs = contactVOs;
	}

	public List<AppUIScreenFieldVO> getAppUIScreenFieldVOs() {
		return appUIScreenFieldVOs;
	}

	public void setAppUIScreenFieldVOs(List<AppUIScreenFieldVO> appUIScreenFieldVOs) {
		this.appUIScreenFieldVOs = appUIScreenFieldVOs;
	}

	public List<AppItemVO> getCaseServicesVOs() {
		return caseServicesVOs;
	}

	public void setCaseServicesVOs(List<AppItemVO> caseServicesVOs) {
		this.caseServicesVOs = caseServicesVOs;
	}

	public List<AppItemVO> getCaseTypeVOs() {
		return caseTypeVOs;
	}

	public void setCaseTypeVOs(List<AppItemVO> caseTypeVOs) {
		this.caseTypeVOs = caseTypeVOs;
	}

	// Added on 13/07/2016
	public Character getIsCustomerDownloaded() {
		return isCustomerDownloaded;
	}

	public void setIsCustomerDownloaded(Character isCustomerDownloaded) {
		this.isCustomerDownloaded = isCustomerDownloaded;
	}

	/*
	 * Desc: getter setter for case files total page count Date:05Dec2016
	 */
	public Integer getCaseFilesPageCount() {
		return caseFilesPageCount;
	}

	public void setCaseFilesPageCount(Integer caseFilesPageCount) {
		this.caseFilesPageCount = caseFilesPageCount;
	}

	public String getproductionStatus() {
		return productionStatus;
	}

	public void setproductionStatus(String productionStatus) {
		this.productionStatus = productionStatus;
	}

	public String getproductionCompletePercentage() {
		return productionCompletePercentage;
	}

	public void setproductionCompletePercentage(String productionCompletePercentage) {
		this.productionCompletePercentage = productionCompletePercentage;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getCaseContactUserIds() {
		return caseContactUserIds;
	}

	public void setCaseContactUserIds(String caseContactUserIds) {
		this.caseContactUserIds = caseContactUserIds;
	}

	public String getCallbackScreen() {
		return callbackScreen;
	}

	public void setCallbackScreen(String callbackScreen) {
		this.callbackScreen = callbackScreen;
	}

	public String getAssignedTo() {
		return assignedTo;
	}

	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}

	public String getStrCaseId() {
		return strCaseId;
	}

	public void setStrCaseId(String strCaseId) {
		this.strCaseId = strCaseId;
	}

	public List<ProductionFilesVO> getProductionFilesVO() {
		return productionFilesVO;
	}

	public void setProductionFilesVO(List<ProductionFilesVO> productionFilesVO) {
		this.productionFilesVO = productionFilesVO;
	}

	public int getPageNo() {
		return pageNo;
	}

	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

	public int getRecordsPerPage() {
		return recordsPerPage;
	}

	public void setRecordsPerPage(int recordsPerPage) {
		this.recordsPerPage = recordsPerPage;
	}

	public int getTotalPages() {
		return totalPages;
	}

	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}

	public int getCurrentRecords() {
		return currentRecords;
	}

	public void setCurrentRecords(int currentRecords) {
		this.currentRecords = currentRecords;
	}

	public long getTotalRecords() {
		return totalRecords;
	}

	public void setTotalRecords(long totalRecords) {
		this.totalRecords = totalRecords;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public String getCaseCode() {
		return caseCode;
	}

	public void setCaseCode(String caseCode) {
		this.caseCode = caseCode;
	}

	public String getServiceReqShortCode() {
		return serviceReqShortCode;
	}

	public void setServiceReqShortCode(String serviceReqShortCode) {
		this.serviceReqShortCode = serviceReqShortCode;
	}

	public Long getCaseFilesHistoryId() {
		return caseFilesHistoryId;
	}

	public void setCaseFilesHistoryId(Long caseFilesHistoryId) {
		this.caseFilesHistoryId = caseFilesHistoryId;
	}

	public String getStrparentCaseEncryId() {
		return strparentCaseEncryId;
	}

	public void setStrparentCaseEncryId(String strparentCaseEncryId) {
		this.strparentCaseEncryId = strparentCaseEncryId;
	}

	public String getCaseOverview() {
		return caseOverview;
	}

	public void setCaseOverview(String caseOverview) {
		this.caseOverview = caseOverview;
	}

	public String getCaseNotes() {
		return caseNotes;
	}

	public void setCaseNotes(String caseNotes) {
		this.caseNotes = caseNotes;
	}

	public String getLsProdStaff() {
		return lsProdStaff;
	}

	public void setLsProdStaff(String lsProdStaff) {
		this.lsProdStaff = lsProdStaff;
	}

	public String getLsProdLead() {
		return lsProdLead;
	}

	public void setLsProdLead(String lsProdLead) {
		this.lsProdLead = lsProdLead;
	}

	public String getLsMD() {
		return lsMD;
	}

	public void setLsMD(String lsMD) {
		this.lsMD = lsMD;
	}

	public String getLsQCReviewer() {
		return lsQCReviewer;
	}

	public void setLsQCReviewer(String lsQCReviewer) {
		this.lsQCReviewer = lsQCReviewer;
	}

	public String getClientType() {
		return clientType;
	}

	public void setClientType(String clientType) {
		this.clientType = clientType;
	}

	public String getCf_3_Text() {
		return cf_3_Text;
	}

	public void setCf_3_Text(String cf_3_Text) {
		this.cf_3_Text = cf_3_Text;
	}

	public String getCf_3_Number() {
		return cf_3_Number;
	}

	public void setCf_3_Number(String cf_3_Number) {
		this.cf_3_Number = cf_3_Number;
	}

	public String getClientNotes() {
		return clientNotes;
	}

	public void setClientNotes(String clientNotes) {
		this.clientNotes = clientNotes;
	}

	public String getCf_2_LongText() {
		return cf_2_LongText;
	}

	public void setCf_2_LongText(String cf_2_LongText) {
		this.cf_2_LongText = cf_2_LongText;
	}

	public String getCsDeliveryDate() {
		return csDeliveryDate;
	}

	public void setCsDeliveryDate(String csDeliveryDate) {
		this.csDeliveryDate = csDeliveryDate;
	}
	
	public List<DropDownVO> getAccountMap() {
		return accountMap;
	}

	public void setAccountMap(List<DropDownVO> accountMap) {
		this.accountMap = accountMap;
	}
	
}