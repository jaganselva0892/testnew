package com.trivent.dto;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.springframework.beans.BeanUtils;

import com.trivent.constants.AppConstants;
import com.trivent.dto.base.BaseVO;
import com.trivent.models.AppItem;
import com.trivent.models.AppSubItem;
import com.trivent.models.Partner;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.dto
 * 
 * @FileName 	:
 *				AppItemVO.java
 * @TypeName 	:
 * 				AppItemVO
 * @DateAndTime :
 *				Feb 8, 2018 - 5:22:27 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description : To list , save and edit the values through path
 *              variable(objects) of AppItemVO(used to interact with
 *              UI)
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public class AppItemVO extends BaseVO {

	@SuppressWarnings("unused")
	private static final long serialVersionUID = -2701123033061009566L;

	private Long appListId = null;

	private String shortName;
	private String longName;
	private Integer seqNo;
	private boolean defaultItem = false;

	private List<AppSubItemVO> appSubItemVOs = null;

	Map<Long, String> partnerListMap;
	private String partner;
	private List<Long> partnerInLong;

	public List<Long> getPartnerInLong() {
		return partnerInLong;
	}

	public void setPartnerInLong(List<Long> partnerInLong) {
		this.partnerInLong = partnerInLong;
	}

	
	public AppItemVO() {
	}

	public AppItemVO(AppItem appItem, Long appListId) {
		BeanUtils.copyProperties(appItem, this);
		this.setDefaultItem(appItem.getDefaultItem() == AppConstants.YES);
		this.setAppListId(appListId);
		this.setId(appItem.getId());
	}

	public AppItemVO(AppItem appItem, Long appListId, List<AppSubItem> appSubItems) {
		this(appItem, appListId);
		List<AppSubItemVO> itemVOs = new ArrayList<>(appSubItems.size());
		for (AppSubItem appSubItem : appSubItems) {
			itemVOs.add(new AppSubItemVO(appSubItem));
		}
		this.setAppSubItemVOs(itemVOs);
	}
	
	
	public AppItemVO(List<Partner> partnerList, AppItem appItem, Long appListId) {
		BeanUtils.copyProperties(appItem, this);
		this.setDefaultItem(appItem.getDefaultItem() == AppConstants.YES);
		this.setAppListId(appListId);
		this.setId(appItem.getId());
		partnerListMap = new LinkedHashMap<>();
		for (Partner partner : partnerList) 
			partnerListMap.put(partner.getId(),partner.getName().concat("[").concat(partner.getPartnerCode()).concat("]"));
	}
	
	public AppItemVO(AppItem caseTypeappItem) {
		this.setLongName(caseTypeappItem.getLongName());
	}

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		AppItemVO other = (AppItemVO) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public Long getAppListId() {
		return appListId;
	}

	public void setAppListId(Long appListId) {
		this.appListId = appListId;
	}

	public String getShortName() {
		return shortName;
	}

	public void setShortName(String shortName) {
		this.shortName = shortName;
	}

	public String getLongName() {
		return longName;
	}

	public void setLongName(String longName) {
		this.longName = longName;
	}

	public Integer getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(Integer seqNo) {
		this.seqNo = seqNo;
	}

	public boolean isDefaultItem() {
		return defaultItem;
	}

	public void setDefaultItem(boolean defaultItem) {
		this.defaultItem = defaultItem;
	}

	public List<AppSubItemVO> getAppSubItemVOs() {
		return appSubItemVOs;
	}

	public void setAppSubItemVOs(List<AppSubItemVO> appSubItemVOs) {
		this.appSubItemVOs = appSubItemVOs;
	}
	
	public Map<Long, String> getPartnerListMap() {
		return partnerListMap;
	}

	public void setPartnerListMap(Map<Long, String> partnerListMap) {
		this.partnerListMap = partnerListMap;
	}

	public String getPartner() {
		return partner;
	}

	public void setPartner(String partner) {
		this.partner = partner;
	}


}
