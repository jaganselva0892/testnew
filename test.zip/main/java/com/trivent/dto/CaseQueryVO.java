package com.trivent.dto;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.springframework.beans.BeanUtils;

import com.trivent.constants.AppConstants;
import com.trivent.dto.base.BaseCaseQueryVO;
import com.trivent.models.Case;
import com.trivent.models.CaseQuery;
import com.trivent.models.CaseQueryResponse;
import com.trivent.utils.EncryptionUtils;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.dto
 * 
 * @FileName 	:
 *				CaseQueryVO.java
 * @TypeName 	:
 * 				CaseQueryVO
 * @DateAndTime :
 *				Feb 8, 2018 - 5:39:16 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description :To list , save and edit the values through path
 *              variable(objects) of CaseQueryVO(used to interact with
 *              UI) 
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public class CaseQueryVO extends BaseCaseQueryVO {

	@SuppressWarnings("unused")
	private static final long serialVersionUID = -4165693448942019989L;

	private Long caseId = null;
	private String caseEncryptedId = null;

	private String querySubject = null;
	private String subjectPrefix = "";
	private String status = AppConstants.STATUS_OPEN;

	private Long assignedToUserId = null;

	private List<CaseQueryResponseVO> caseQueryResponsesVO = null;
	private CaseQueryResponseVO caseQueryResponseVO = null;

	private String queryToEmail = null;
	private List<Case> caseList = null;

	private Character isQueryOpen = AppConstants.NO;
	private String queryPartnerBean = null;

	private String queryType = null;

	private String querySubType = null;

	public List<AppItemVO> queryCommTypeVOs = null;

	private String fromEmail = null;
	private String typeEmail = AppConstants.QUERY_TYPE_FROM_EMAIL_GROUP;
	public String customCreatedDate = null;
	public String loginUser = null;

	public CaseQueryVO() {
	}

	public CaseQueryVO(CaseQuery caseQuery) {
		BeanUtils.copyProperties(caseQuery, this);
		this.setId(caseQuery.getId());
		this.setEncryptedId(caseQuery.getEncryptedId());
	}

	public CaseQueryVO(CaseQuery caseQuery, String callbackScreen, List<CaseQueryResponse> caseQueryResponses) {
		BeanUtils.copyProperties(caseQuery, this);
		this.setId(caseQuery.getId());
		this.setCallbackScreen(callbackScreen);

		this.setIsInternal(caseQuery.getIsInternal() == AppConstants.YES);
		this.setIsVisible2Client(caseQuery.getIsVisible2Client() == AppConstants.YES);
		this.setIsEmailNotify(caseQuery.getIsEmailNotify() == AppConstants.YES);
		this.setIsNewQuery(caseQuery.getIsNewQuery() == AppConstants.YES);
		this.setQuerySource(caseQuery.getQuerySource());
		this.setIsQueryOpen((caseQuery.getIsQueryOpen() == null) ? AppConstants.NO : caseQuery.getIsQueryOpen());

		if (caseQuery.getClientCase() != null) {
			this.setCaseId(caseQuery.getClientCase().getId());
			this.setCaseEncryptedId(EncryptionUtils.encryptId(this.getCaseId()));
		}
		if (caseQuery.getAssignedTo() != null) {
			this.setAssignedToUserId(caseQuery.getAssignedTo().getId());
		}
		CaseQueryResponseVO caseQueryResponseVO = null;
		if (caseQueryResponses != null && !caseQueryResponses.isEmpty()) {
			this.caseQueryResponsesVO = new ArrayList<>(caseQueryResponses.size());
			for (CaseQueryResponse caseQueryResponse : caseQueryResponses) {
				caseQueryResponseVO = new CaseQueryResponseVO(caseQueryResponse);
				caseQueryResponsesVO.add(caseQueryResponseVO);
				caseQueryResponseVO.setQueryCreatedBy(caseQueryResponse.getCreatedBy().getLoginId());
			}
		}
		this.setCaseQueryResponseVO(new CaseQueryResponseVO());
	}

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		CaseQueryVO other = (CaseQueryVO) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public List<CaseQueryResponseVO> getCaseQueryResponsesVO() {
		return caseQueryResponsesVO;
	}

	public void setCaseQueryResponsesVO(List<CaseQueryResponseVO> caseQueryResponsesVO) {
		this.caseQueryResponsesVO = caseQueryResponsesVO;
	}

	public Long getAssignedToUserId() {
		return assignedToUserId;
	}

	public void setAssignedToUserId(Long assignedToUserId) {
		this.assignedToUserId = assignedToUserId;
	}

	public String getSubjectPrefix() {
		return subjectPrefix;
	}

	public void setSubjectPrefix(String subjectPrefix) {
		this.subjectPrefix = subjectPrefix;
	}

	public String getCaseEncryptedId() {
		return caseEncryptedId;
	}

	public void setCaseEncryptedId(String caseEncryptedId) {
		this.caseEncryptedId = caseEncryptedId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getQuerySubject() {
		return querySubject;
	}

	public void setQuerySubject(String querySubject) {
		this.querySubject = querySubject;
	}

	public CaseQueryResponseVO getCaseQueryResponseVO() {
		return caseQueryResponseVO;
	}

	public void setCaseQueryResponseVO(CaseQueryResponseVO caseQueryResponseVO) {
		this.caseQueryResponseVO = caseQueryResponseVO;
	}

	public String getQueryToEmail() {
		return queryToEmail;
	}

	public void setQueryToEmail(String queryToEmail) {
		this.queryToEmail = queryToEmail;
	}

	public List<Case> getCaseList() {
		return caseList;
	}

	public void setCaseList(List<Case> caseList) {
		this.caseList = caseList;
	}

	public Character getIsQueryOpen() {
		return isQueryOpen;
	}

	public void setIsQueryOpen(Character isQueryOpen) {
		this.isQueryOpen = isQueryOpen;
	}

	public String getQueryPartnerBean() {
		return queryPartnerBean;
	}

	public void setQueryPartnerBean(String queryPartnerBean) {
		this.queryPartnerBean = queryPartnerBean;
	}

	public CaseQueryVO(CaseQuery caseQuery, String callbackScreen, List<CaseQueryResponse> caseQueryResponses,
			List<AppItemVO> queryCommTypeVOs) {
		this(caseQuery, callbackScreen, caseQueryResponses);
		this.setQueryCommTypeVOs(queryCommTypeVOs);
	}

	public String getQueryType() {
		return queryType;
	}

	public void setQueryType(String queryType) {
		this.queryType = queryType;
	}

	public List<AppItemVO> getQueryCommTypeVOs() {
		return queryCommTypeVOs;
	}

	public void setQueryCommTypeVOs(List<AppItemVO> queryCommTypeVOs) {
		this.queryCommTypeVOs = queryCommTypeVOs;
	}

	/*
	 * Date:21Mar2016, Desc:Altered in email queue table for custom from email id
	 * (which should be same domain as configured smtp)
	 */
	public String getFromEmail() {
		return fromEmail;
	}

	public void setFromEmail(String fromEmail) {
		this.fromEmail = fromEmail;
	}

	public String getTypeEmail() {
		return typeEmail;
	}

	public void setTypeEmail(String typeEmail) {
		this.typeEmail = typeEmail;
	}

	public String getQuerySubType() {
		return querySubType;
	}

	public void setQuerySubType(String querySubType) {
		this.querySubType = querySubType;
	}

	public String getCustomCreatedDate() {
		return customCreatedDate;
	}

	public void setCustomCreatedDate(String customCreatedDate) {
		this.customCreatedDate = customCreatedDate;
	}

	public String getLoginUser() {
		return loginUser;
	}

	public void setLoginUser(String loginUser) {
		this.loginUser = loginUser;
	}
	
}