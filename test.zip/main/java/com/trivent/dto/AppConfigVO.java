package com.trivent.dto;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.springframework.beans.BeanUtils;
import org.springframework.web.multipart.MultipartFile;

import com.trivent.dto.base.BaseVO;
import com.trivent.models.AppConfig;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.dto
 * 
 * @FileName 	:
 *				AppConfigVO.java
 * @TypeName 	:
 * 				AppConfigVO
 * @DateAndTime :
 *				Feb 8, 2018 - 5:21:08 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description : To list , save and edit the values through path
 *              variable(objects) of AppConfigVO(used to interact with
 *              UI) 
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public class AppConfigVO extends BaseVO {

	@SuppressWarnings("unused")
	private static final long serialVersionUID = -2701123033061009566L;

	private Long appRefConfigId = null;

	private String name;
	private String linkUrl;
	private boolean menu = false;

	private String screen = null;
	
	private String searchTerm = null;

	private MultipartFile importFile = null;
	private String importScreen = null;

	private Long capabilityId = null;

	private Map<Long, String> appRefConfigIdList = new LinkedHashMap<Long, String>();

	private Map<Long, String> capabilityIdList = new LinkedHashMap<Long, String>();

	private List<AppConfigVO> appConfigMailVO = new ArrayList<AppConfigVO>();
	
	private List<AppConfigDataVO> appConfigDataVO = new ArrayList<AppConfigDataVO>();

	private boolean caseMail = false;

	private boolean queryMail = false;

	private boolean otherMail = false;
	
	private boolean welcomeMail = false;
	
	private boolean caseMailVisible = false;

	private boolean queryMailVisible = false;

	private boolean otherMailVisible = false;
	
	private boolean welcomeMailVisible = false;

	public AppConfigVO() {
	}

	public AppConfigVO(AppConfig appConfig) {
		BeanUtils.copyProperties(appConfig, this);
		if (appConfig != null) {
			this.setMenu(appConfig.isMenu());
			if (appConfig.getAppRefConfig() != null) {
				this.setAppRefConfigId(appConfig.getAppRefConfig().getId());
			}
			if (appConfig.getCapability() != null) {
				this.setCapabilityId(appConfig.getCapability().getId());
			}
			this.setId(appConfig.getId());
			this.setEncryptedId(appConfig.getEncryptedId());
		}
	}

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		AppConfigVO other = (AppConfigVO) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public Long getAppRefConfigId() {
		return appRefConfigId;
	}

	public void setAppRefConfigId(Long appRefConfigId) {
		this.appRefConfigId = appRefConfigId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isMenu() {
		return menu;
	}

	public void setMenu(boolean menu) {
		this.menu = menu;
	}

	public String getLinkUrl() {
		return linkUrl;
	}

	public void setLinkUrl(String linkUrl) {
		this.linkUrl = linkUrl;
	}

	public MultipartFile getImportFile() {
		return importFile;
	}

	public void setImportFile(MultipartFile importFile) {
		this.importFile = importFile;
	}

	public String getImportScreen() {
		return importScreen;
	}

	public void setImportScreen(String importScreen) {
		this.importScreen = importScreen;
	}

	public String getScreen() {
		return screen;
	}

	public void setScreen(String screen) {
		this.screen = screen;
	}

	public Long getCapabilityId() {
		return capabilityId;
	}

	public void setCapabilityId(Long capabilityId) {
		this.capabilityId = capabilityId;
	}

	public Map<Long, String> getAppRefConfigIdList() {
		return appRefConfigIdList;
	}

	public void setAppRefConfigIdList(Map<Long, String> appRefConfigIdList) {
		this.appRefConfigIdList = appRefConfigIdList;
	}

	public Map<Long, String> getCapabilityIdList() {
		return capabilityIdList;
	}

	public void setCapabilityIdList(Map<Long, String> capabilityIdList) {
		this.capabilityIdList = capabilityIdList;
	}

	public List<AppConfigVO> getAppConfigMailVO() {
		return appConfigMailVO;
	}

	public void setAppConfigMailVO(List<AppConfigVO> appConfigMailVO) {
		this.appConfigMailVO = appConfigMailVO;
	}

	public boolean isCaseMail() {
		return caseMail;
	}

	public void setCaseMail(boolean caseMail) {
		this.caseMail = caseMail;
	}

	public boolean isQueryMail() {
		return queryMail;
	}

	public void setQueryMail(boolean queryMail) {
		this.queryMail = queryMail;
	}

	public boolean isOtherMail() {
		return otherMail;
	}

	public void setOtherMail(boolean otherMail) {
		this.otherMail = otherMail;
	}

	public String getSearchTerm() {
		return searchTerm;
	}

	public void setSearchTerm(String searchTerm) {
		this.searchTerm = searchTerm;
	}

	public boolean isCaseMailVisible() {
		return caseMailVisible;
	}

	public void setCaseMailVisible(boolean caseMailVisible) {
		this.caseMailVisible = caseMailVisible;
	}

	public boolean isQueryMailVisible() {
		return queryMailVisible;
	}

	public void setQueryMailVisible(boolean queryMailVisible) {
		this.queryMailVisible = queryMailVisible;
	}

	public boolean isOtherMailVisible() {
		return otherMailVisible;
	}

	public void setOtherMailVisible(boolean otherMailVisible) {
		this.otherMailVisible = otherMailVisible;
	}

	public boolean isWelcomeMail() {
		return welcomeMail;
	}

	public void setWelcomeMail(boolean welcomeMail) {
		this.welcomeMail = welcomeMail;
	}

	public boolean isWelcomeMailVisible() {
		return welcomeMailVisible;
	}

	public void setWelcomeMailVisible(boolean welcomeMailVisible) {
		this.welcomeMailVisible = welcomeMailVisible;
	}
	
	public List<AppConfigDataVO> getAppConfigDataVO() {
		return appConfigDataVO;
	}

	public void setAppConfigDataVO(List<AppConfigDataVO> appConfigDataVO) {
		this.appConfigDataVO = appConfigDataVO;
	}

}
