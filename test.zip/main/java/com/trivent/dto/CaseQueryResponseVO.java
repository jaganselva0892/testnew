package com.trivent.dto;

import java.util.List;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.springframework.beans.BeanUtils;
import org.springframework.web.multipart.MultipartFile;

import com.trivent.constants.AppConstants;
import com.trivent.dto.base.BaseCaseQueryVO;
import com.trivent.models.CaseQueryResponse;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.dto
 * 
 * @FileName 	:
 *				CaseQueryResponseVO.java
 * @TypeName 	:
 * 				CaseQueryResponseVO
 * @DateAndTime :
 *				Feb 8, 2018 - 5:38:46 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description :  To list , save and edit the values through path
 *              variable(objects) of CaseQueryResponseVO(used to interact with
 *              UI)
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public class CaseQueryResponseVO extends BaseCaseQueryVO {

	@SuppressWarnings("unused")
	private static final long serialVersionUID = -4165693448942019989L;

	private Long caseId = null;
	private Long caseQueryId = null;

	private String queryDetails = null;
	private String queryDisplay = "";
	private String subjectPrefix = "";

	private Long queryTaskId = null;
	private Long taskAssignedToUserId = null;
	private char isValidUser = 'Y';
	private List<CaseQueryResponseFilesVO> caseQueryResponseFiles = null;
	private List<MultipartFile> queryAttachedFiles = null;
	private String queryPartnerBean = null;

	private String fromEmail = null;
	private String typeEmail = AppConstants.QUERY_TYPE_FROM_EMAIL_GROUP;
	private String role=null;
	private String editedQueryDetails = null;
	
	private Boolean isQiNotify = false;
	
	private Boolean isAppreciationNotify = false;
	
	public CaseQueryResponseVO() {
	}

	public CaseQueryResponseVO(CaseQueryResponse appCaseQueryResponse) {
		BeanUtils.copyProperties(appCaseQueryResponse, this);
		this.setId(appCaseQueryResponse.getId());

		this.setIsInternal(appCaseQueryResponse.getIsInternal() == AppConstants.YES);
		this.setIsVisible2Client(appCaseQueryResponse.getIsVisible2Client() == AppConstants.YES);
		this.setIsEmailNotify(appCaseQueryResponse.getIsEmailNotify() == AppConstants.YES);
		this.setIsQiNotify(appCaseQueryResponse.getIsQiNotify() == AppConstants.YES);
		this.setIsAppreciationNotify(appCaseQueryResponse.getIsAppreciationNotify() == AppConstants.YES);
		this.setIsNewQuery(appCaseQueryResponse.getIsNewQuery() == AppConstants.YES);
		this.setQuerySource(appCaseQueryResponse.getQuerySource());
		this.setQueryTaskId(appCaseQueryResponse.getTaskId());
		this.setRole(appCaseQueryResponse.getCreatedBy().getRole().getType());

	}

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		CaseQueryResponseVO other = (CaseQueryResponseVO) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public List<MultipartFile> getQueryAttachedFiles(){
		return queryAttachedFiles;
	}
	
	public void setQueryAttachedFiles(List<MultipartFile> queryAttachedFiles){
		this.queryAttachedFiles = queryAttachedFiles;
	}
	
    public String getSubjectPrefix() {
        return subjectPrefix;
    }

    public void setSubjectPrefix(String subjectPrefix) {
        this.subjectPrefix = subjectPrefix;
    }
    
	public List<CaseQueryResponseFilesVO> getCaseQueryResponseFiles() {
		return caseQueryResponseFiles;
	}

	public void setCaseQueryResponseFiles(List<CaseQueryResponseFilesVO> caseQueryResponseFiles) {
		this.caseQueryResponseFiles = caseQueryResponseFiles;
	}
	
	public String getQueryDisplay() {
		return queryDisplay;
	}

	public void setQueryDisplay(String queryDisplay) {
		this.queryDisplay = queryDisplay;
	}
	
	public char getIsValidUser() {
		return isValidUser;
	}

	public void setIsValidUser(char isValidUser) {
		this.isValidUser = isValidUser;
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public Long getCaseQueryId() {
		return caseQueryId;
	}

	public void setCaseQueryId(Long caseQueryId) {
		this.caseQueryId = caseQueryId;
	}

	public String getQueryDetails() {
		return queryDetails;
	}

	public void setQueryDetails(String queryDetails) {
		this.queryDetails = queryDetails;
	}

	/*
	 * Type: New, Code: #11, Description: Added get set property for
	 * queryDetails,taskAssignedToUserId, Date:19Sep2016
	 */
	public Long getQueryTaskId() {
		return queryTaskId;
	}

	public void setQueryTaskId(Long queryTaskId) {
		this.queryTaskId = queryTaskId;
	}

	public Long getQueryTaskAssignTo() {
		return taskAssignedToUserId;
	}

	public void setQueryTaskAssignTo(Long assignedToUserId) {
		this.taskAssignedToUserId = assignedToUserId;
	}
	
	
	public String getQueryPartnerBean() {
		return queryPartnerBean;
	}

	public void setQueryPartnerBean(String queryPartnerBean) {
		this.queryPartnerBean = queryPartnerBean;
	}
	/*
	 * Date:21Mar2016, Desc:Altered in email queue table for custom from email id (which should be same domain as configured smtp)
	 */
	public String getFromEmail() {
		return fromEmail;
	}

	public void setFromEmail(String fromEmail) {
		this.fromEmail = fromEmail;
	}

	public String getTypeEmail() {
		return typeEmail;
	}

	public void setTypeEmail(String typeEmail) {
		this.typeEmail = typeEmail;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getEditedQueryDetails() {
		return editedQueryDetails;
	}

	public void setEditedQueryDetails(String editedQueryDetails) {
		this.editedQueryDetails = editedQueryDetails;
	}
	public Boolean getIsQiNotify() {
		return isQiNotify;
	}

	public void setIsQiNotify(Boolean isQiNotify) {
		this.isQiNotify = isQiNotify;
	}

	public Boolean getIsAppreciationNotify() {
		return isAppreciationNotify;
	}

	public void setIsAppreciationNotify(Boolean isAppreciationNotify) {
		this.isAppreciationNotify = isAppreciationNotify;
	}

}
