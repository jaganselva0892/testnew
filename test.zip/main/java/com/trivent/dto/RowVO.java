package com.trivent.dto;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.dto.base.BaseVO;

/**
 * @ProjectName : trivent
 * @PackageName : com.trivent.dto
 * 
 * @FileName : RowVO.java
 * @TypeName : RowVO
 * @DateAndTime : Feb 8, 2018 - 6:07:31 PM
 * 
 * @Author : seetha
 * 
 * @Description : To list , save and edit the values through path
 *              variable(objects) of RowVO(used to interact with UI)
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
public class RowVO extends BaseVO {

	@SuppressWarnings("unused")
	private static final long serialVersionUID = -2701123033061009566L;

	private boolean isHeader = false;
	
	private List<String> columns = null;
	private String caseEncryptedId = null;
	private Map<String, String> valueMap = new HashMap<String, String>();
	private Map<String, Map<String, String>> valueMap1 = new HashMap<String, Map<String, String>>();
	private boolean flagForCase = false;

	private Map<String, String> columnsFields = new LinkedHashMap<String, String>();
	
	public RowVO() {
	}

	public RowVO(Long id, String encryptedId, StringBuilder caseEncryptedId, List<String> columns) {
		this.setId(id);
		this.setEncryptedId(encryptedId);
		this.setColumns(columns);
		this.setHeader(false);
		// this.setProductionEncryptedId(productionEncryptedId.toString());
		if (caseEncryptedId.length() > 0) {
			this.setCaseEncryptedId(caseEncryptedId.toString());
		}else {
			this.setCaseEncryptedId("");
		}
	}

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		RowVO other = (RowVO) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public List<String> getColumns() {
		return columns;
	}

	public void setColumns(List<String> columns) {
		this.columns = columns;
	}

	public boolean isHeader() {
		return isHeader;
	}

	public void setHeader(boolean isHeader) {
		this.isHeader = isHeader;
	}

	public String getCaseEncryptedId() {
		return caseEncryptedId;
	}

	public void setCaseEncryptedId(String caseEncryptedId) {
		this.caseEncryptedId = caseEncryptedId;
	}

	public Map<String, String> getValueMap() {
		return valueMap;
	}

	public void setValueMap(Map<String, String> valueMap) {
		this.valueMap = valueMap;
	}

	public Map<String, Map<String, String>> getValueMap1() {
		return valueMap1;
	}

	public void setValueMap1(Map<String, Map<String, String>> valueMap1) {
		this.valueMap1 = valueMap1;
	}

	public boolean isFlagForCase() {
		return flagForCase;
	}

	public void setFlagForCase(boolean flagForCase) {
		this.flagForCase = flagForCase;
	}

	public Map<String, String> getColumnsFields() {
		return columnsFields;
	}

	public void setColumnsFields(Map<String, String> columnsFields) {
		this.columnsFields = columnsFields;
	}

}
