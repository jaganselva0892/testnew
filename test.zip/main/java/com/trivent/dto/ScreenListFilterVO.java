package com.trivent.dto;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.joda.time.DateTime;

import com.trivent.constants.AppConstants;
import com.trivent.dto.base.BaseVO;
import com.trivent.models.AppUIScreenFilter;
import com.trivent.models.AppUIScreenView;
import com.trivent.utils.CommonUtils;

/**
 * @ProjectName : trivent
 * @PackageName : com.trivent.dto
 * 
 * @FileName : ScreenListFilterVO.java
 * @TypeName : ScreenListFilterVO
 * @DateAndTime : Feb 8, 2018 - 6:07:48 PM
 * 
 * @Author : seetha
 * 
 * @Description :To list , save and edit the values through path
 *              variable(objects) of ScreenListFilterVO(used to interact with
 *              UI)
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
public class ScreenListFilterVO extends BaseVO {

	@SuppressWarnings("unused")
	private static final long serialVersionUID = -3422830464510211652L;

	// Pagination Variables
	private int pageNo = 1;
	private int recordsPerPage = 50;
	private int totalPages = 0;
	private int currentRecords = 0;
	private long totalRecords = 0;
	private long totalPageCount = 0;

	// Soft Options
	private String sortOrder = AppConstants.SORT_PREF_DESC;
	private String sortByField = "createdDate";
	private String filterCriteria = AppConstants.FILTER_CRITERIA_AND;

	// View Options
	private String selectedViewType = null;

	private boolean screenFieldFilterOne = false;

	private List<AppUIScreenViewVO> appUIScreenViewVOs = null;
	private List<AppUIScreenFilterVO> appUIScreenFilterVOs = null;
	private List<AppUIScreenFieldVO> appUIScreenFieldVOs = null;

	private AppDBTableVO appDBTableVO = null;

	private String ltmesimpleDateFormat;

	private String ltmesimpleDateZoneid;

	private String roleType = null;

	private String isNewFilter = "N";

	// Sort By Column Header
	private Map<String, String> columnsFields = new LinkedHashMap<String, String>();
	private String sortByFieldColumn = "createdDate";
	private String sortByColumnEnable = "";
	private Object obj = null;

	public ScreenListFilterVO() {
	}

	public ScreenListFilterVO(List<AppUIScreenFilter> appUIScreenFilters, List<AppUIScreenView> appUIScreenViews,
			String psType) {
		int size = appUIScreenFilters.isEmpty() ? 1 : appUIScreenFilters.size();
		AppUIScreenFilterVO appUIScreenFilterVO;
		List<AppUIScreenFilterVO> filterVOs = new ArrayList<>(size);
		for (AppUIScreenFilter appUIScreenFilter : appUIScreenFilters) {
			appUIScreenFilterVO = new AppUIScreenFilterVO(appUIScreenFilter, appUIScreenFilter.getAppUiScreen());
			filterVOs.add(appUIScreenFilterVO);
		}
		this.setAppUIScreenFilterVOs(filterVOs);

		size = appUIScreenViews.isEmpty() ? 1 : appUIScreenViews.size();
		AppUIScreenViewVO appUIScreenViewVO;
		List<AppUIScreenViewVO> viewVOs = new ArrayList<>(size);
		for (AppUIScreenView appUIScreenView : appUIScreenViews) {
			appUIScreenViewVO = new AppUIScreenViewVO(appUIScreenView, appUIScreenView.getAppUiScreen());
			viewVOs.add(appUIScreenViewVO);
			if (selectedViewType == null) {
				selectedViewType = appUIScreenViewVO.getViewType();
			}
			if (appUIScreenViewVO.isViewDefault()) {
				selectedViewType = appUIScreenViewVO.getViewType();
			}
		}
		this.setAppUIScreenViewVOs(viewVOs);
	}

	public ScreenListFilterVO(List<AppUIScreenFilter> appUIScreenFilters, List<AppUIScreenView> appUIScreenViews) {
		int size = appUIScreenFilters.isEmpty() ? 1 : appUIScreenFilters.size();
		AppUIScreenFilterVO appUIScreenFilterVO;
		List<AppUIScreenFilterVO> filterVOs = new ArrayList<>(size);
		for (AppUIScreenFilter appUIScreenFilter : appUIScreenFilters) {
			appUIScreenFilterVO = new AppUIScreenFilterVO(appUIScreenFilter, appUIScreenFilter.getAppUiScreen());
			// filterVOs.add(appUIScreenFilterVO);
			if (appUIScreenFilterVO.getFilterDataType() != null && (appUIScreenFilterVO.getFilterDataType()
					.equals(CommonUtils.trimClassName(Calendar.class.getName()))
					|| appUIScreenFilterVO.getFilterDataType().equals(CommonUtils.trimClassName(Date.class.getName()))
					|| appUIScreenFilterVO.getFilterDataType()
							.equals(CommonUtils.trimClassName(DateTime.class.getName())))) {
				AppUIScreenFilterVO appUIScreenFilterVO1 = new AppUIScreenFilterVO(appUIScreenFilter,
						appUIScreenFilter.getAppUiScreen());
				appUIScreenFilterVO1.setDbFieldName("todatefield" + appUIScreenFilterVO1.getDbFieldName());
				appUIScreenFilterVO.setFilterName("From " + appUIScreenFilterVO.getFilterName());
				appUIScreenFilterVO1.setFilterName("To " + appUIScreenFilterVO1.getFilterName());
				filterVOs.add(appUIScreenFilterVO);
				filterVOs.add(appUIScreenFilterVO1);
			} else {
				filterVOs.add(appUIScreenFilterVO);
			}
		}
		this.setAppUIScreenFilterVOs(filterVOs);

		size = appUIScreenViews.isEmpty() ? 1 : appUIScreenViews.size();
		AppUIScreenViewVO appUIScreenViewVO;
		List<AppUIScreenViewVO> viewVOs = new ArrayList<>(size);
		for (AppUIScreenView appUIScreenView : appUIScreenViews) {
			appUIScreenViewVO = new AppUIScreenViewVO(appUIScreenView, appUIScreenView.getAppUiScreen());
			viewVOs.add(appUIScreenViewVO);
			if (selectedViewType == null) {
				selectedViewType = appUIScreenViewVO.getViewType();
			}
			if (appUIScreenViewVO.isViewDefault()) {
				selectedViewType = appUIScreenViewVO.getViewType();
			}
		}
		this.setAppUIScreenViewVOs(viewVOs);
	}

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		ScreenListFilterVO other = (ScreenListFilterVO) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public int getPageNo() {
		return pageNo;
	}

	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

	public int getRecordsPerPage() {
		return recordsPerPage;
	}

	public void setRecordsPerPage(int recordsPerPage) {
		this.recordsPerPage = recordsPerPage;
	}

	public int getTotalPages() {
		return totalPages;
	}

	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}

	public int getCurrentRecords() {
		return currentRecords;
	}

	public void setCurrentRecords(int currentRecords) {
		this.currentRecords = currentRecords;
	}

	public long getTotalRecords() {
		return totalRecords;
	}

	public void setTotalRecords(long totalRecords) {
		this.totalRecords = totalRecords;
	}

	public String getSortOrder() {
		return sortOrder;
	}

	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}

	public String getSortByField() {
		return sortByField;
	}

	public void setSortByField(String sortByField) {
		this.sortByField = sortByField;
	}

	public List<AppUIScreenFilterVO> getAppUIScreenFilterVOs() {
		return appUIScreenFilterVOs;
	}

	public void setAppUIScreenFilterVOs(List<AppUIScreenFilterVO> appUIScreenFilterVOs) {
		this.appUIScreenFilterVOs = appUIScreenFilterVOs;
	}

	public List<AppUIScreenViewVO> getAppUIScreenViewVOs() {
		return appUIScreenViewVOs;
	}

	public void setAppUIScreenViewVOs(List<AppUIScreenViewVO> appUIScreenViewVOs) {
		this.appUIScreenViewVOs = appUIScreenViewVOs;
	}

	public String getSelectedViewType() {
		return selectedViewType;
	}

	public void setSelectedViewType(String selectedViewType) {
		this.selectedViewType = selectedViewType;
	}

	public String getFilterCriteria() {
		return filterCriteria;
	}

	public void setFilterCriteria(String filterCriteria) {
		this.filterCriteria = filterCriteria;
	}

	public boolean isScreenFieldFilterOne() {
		return screenFieldFilterOne;
	}

	public void setScreenFieldFilterOne(boolean screenFieldFilterOne) {
		this.screenFieldFilterOne = screenFieldFilterOne;
	}

	public Map<String, String> getColumnsFields() {
		return columnsFields;
	}

	public void setColumnsFields(Map<String, String> columnsFields) {
		this.columnsFields = columnsFields;
	}

	public String getSortByFieldColumn() {
		return sortByFieldColumn;
	}

	public void setSortByFieldColumn(String sortByFieldColumn) {
		this.sortByFieldColumn = sortByFieldColumn;
	}

	public String getSortByColumnEnable() {
		return sortByColumnEnable;
	}

	public void setSortByColumnEnable(String sortByColumnEnable) {
		this.sortByColumnEnable = sortByColumnEnable;
	}

	public Object getObj() {
		return obj;
	}

	public void setObj(Object obj) {
		this.obj = obj;
	}

	public List<AppUIScreenFieldVO> getAppUIScreenFieldVOs() {
		return appUIScreenFieldVOs;
	}

	public void setAppUIScreenFieldVOs(List<AppUIScreenFieldVO> appUIScreenFieldVOs) {
		this.appUIScreenFieldVOs = appUIScreenFieldVOs;
	}

	public AppDBTableVO getAppDBTableVO() {
		return appDBTableVO;
	}

	public void setAppDBTableVO(AppDBTableVO appDBTableVO) {
		this.appDBTableVO = appDBTableVO;
	}

	public String getLtmesimpleDateFormat() {
		return ltmesimpleDateFormat;
	}

	public void setLtmesimpleDateFormat(String ltmesimpleDateFormat) {
		this.ltmesimpleDateFormat = ltmesimpleDateFormat;
	}

	public String getRoleType() {
		return roleType;
	}

	public void setRoleType(String roleType) {
		this.roleType = roleType;
	}

	public String getIsNewFilter() {
		return isNewFilter;
	}

	public void setIsNewFilter(String isNewFilter) {
		this.isNewFilter = isNewFilter;
	}

	public String getLtmesimpleDateZoneid() {
		return ltmesimpleDateZoneid;
	}

	public void setLtmesimpleDateZoneid(String ltmesimpleDateZoneid) {
		this.ltmesimpleDateZoneid = ltmesimpleDateZoneid;
	}

	public long getTotalPageCount() {
		return totalPageCount;
	}

	public void setTotalPageCount(long totalPageCount) {
		this.totalPageCount = totalPageCount;
	}

}