package com.trivent.dto;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.springframework.beans.BeanUtils;

import com.trivent.dto.base.BaseContactVO;
import com.trivent.models.Contact;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.dto
 * 
 * @FileName 	:
 *				ContactVO.java
 * @TypeName 	:
 * 				ContactVO
 * @DateAndTime :
 *				Feb 8, 2018 - 5:46:50 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description : To list , save and edit the values through path
 *              variable(objects) of ContactVO(used to interact with
 *              UI) 
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public class ContactVO extends BaseContactVO {

	@SuppressWarnings("unused")
	private static final long serialVersionUID = -4165693448942019989L;

	private Long entityId = null;
	private String entity = null;
	private Integer seqNo;
	private String type = Contact.TYPE_INDIVIDUAL;
	private Long userId = null;

	private String sourceScreenName = null;
	private Long caseId = null;
	
	private Map<Long, String> usersMap = null;
	
	private String contactType = null;
	
	private String encryptedUserId = null;
	
	private String name = null;

	public ContactVO() {
	}

	public ContactVO(Contact contact) {
		BeanUtils.copyProperties(contact, this);
		this.setId(contact.getId());
	}

	public static final List<ContactVO> populateContactVOs(List<Contact> contacts) {
		List<ContactVO> contactVOs = null;
		ContactVO contactVO = null;
		if (contacts != null) {
			contactVOs = new ArrayList<>(contacts.size());
			for (Contact contact : contacts) {
				contactVO = new ContactVO(contact);
				contactVOs.add(contactVO);
			}
		}
		return contactVOs;
	}

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		ContactVO other = (ContactVO) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public Long getEntityId() {
		return entityId;
	}

	public void setEntityId(Long entityId) {
		this.entityId = entityId;
	}

	public String getEntity() {
		return entity;
	}

	public void setEntity(String entity) {
		this.entity = entity;
	}

	public Integer getSeqNo() {
		return seqNo;
	}

	public void setSeqNo(Integer seqNo) {
		this.seqNo = seqNo;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getSourceScreenName() {
		return sourceScreenName;
	}

	public void setSourceScreenName(String sourceScreenName) {
		this.sourceScreenName = sourceScreenName;
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}
	
	public Map<Long, String> getUsersMap(){
		return usersMap;
	}
	
	public void setUsersMap(Map<Long, String> usersMap){
		this.usersMap = usersMap;
	}

	public String getContactType() {
		return contactType;
	}

	public void setContactType(String contactType) {
		this.contactType = contactType;
	}

	public String getEncryptedUserId() {
		return encryptedUserId;
	}

	public void setEncryptedUserId(String encryptedUserId) {
		this.encryptedUserId = encryptedUserId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
