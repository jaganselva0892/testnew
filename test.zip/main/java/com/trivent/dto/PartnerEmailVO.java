package com.trivent.dto;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.springframework.beans.BeanUtils;

import com.trivent.dto.base.BaseVO;
import com.trivent.models.Partner;
import com.trivent.models.PartnerEmails;

/**
 * @ProjectName : trivent
 * @PackageName : com.trivent.dto
 * 
 * @FileName : PartnerEmailVO.java
 * @TypeName : PartnerEmailVO
 * @DateAndTime : Feb 8, 2018 - 5:54:53 PM
 * 
 * @Author : seetha
 * 
 * @Description : To list , save and edit the values through path
 *              variable(objects) of PartnerEmailVO(used to interact with UI)
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
public class PartnerEmailVO extends BaseVO {

	@SuppressWarnings("unused")
	private static final long serialVersionUID = 9079557077988159342L;

	private String emailToList = null;
	private String emailCcList = null;
	private String emailBccList = null;
	private Long partnerID = null;
	private Long emailTemplateID = null;
	private String partnerCode = null;
	private String partnerName = null;
	private String type = null;

	private String lsPartnersubject = null;
	private String lsPartnermessage = null;

	public PartnerEmailVO() {

	}

	public PartnerEmailVO(PartnerEmails partnerEmails) {
		BeanUtils.copyProperties(partnerEmails, this);
		this.setId(partnerEmails.getId());
		Partner partner = partnerEmails.getPartner();
		if (partner != null) {
			this.setPartnerCode(partner.getPartnerCode());
			this.setPartnerName(partner.getName());
			this.setPartnerID(partner.getId());
		}
	}

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		PartnerEmailVO other = (PartnerEmailVO) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public String getEmailToList() {
		return emailToList;
	}

	public void setEmailToList(String emailToList) {
		this.emailToList = emailToList;
	}

	public String getEmailCcList() {
		return emailCcList;
	}

	public void setEmailCcList(String emailCcList) {
		this.emailCcList = emailCcList;
	}

	public String getEmailBccList() {
		return emailBccList;
	}

	public void setEmailBccList(String emailBccList) {
		this.emailBccList = emailBccList;
	}

	public Long getEmailTemplateID() {
		return emailTemplateID;
	}

	public void setEmailTemplateID(Long emailTemplateID) {
		this.emailTemplateID = emailTemplateID;
	}

	public Long getPartnerID() {
		return partnerID;
	}

	public void setPartnerID(Long partnerID) {
		this.partnerID = partnerID;
	}

	public String getPartnerCode() {
		return partnerCode;
	}

	public void setPartnerCode(String partnerCode) {
		this.partnerCode = partnerCode;
	}

	public String getPartnerName() {
		return partnerName;
	}

	public void setPartnerName(String partnerName) {
		this.partnerName = partnerName;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getLsPartnersubject() {
		return lsPartnersubject;
	}

	public void setLsPartnersubject(String lsPartnersubject) {
		this.lsPartnersubject = lsPartnersubject;
	}

	public String getLsPartnermessage() {
		return lsPartnermessage;
	}

	public void setLsPartnermessage(String lsPartnermessage) {
		this.lsPartnermessage = lsPartnermessage;
	}

}
