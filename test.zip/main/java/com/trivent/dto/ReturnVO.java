package com.trivent.dto;

/**
* FileName: ReturnVO.java
* Pojo's for message, Token and data
* @author Jagan 0010
* @version 1.0
*/
import java.util.List;

public class ReturnVO {

	private boolean isData;
	private String message;
	private Object data;
	private List<Object> dataList;
	private boolean tokenExpiry;
	private boolean isPageable;
	private PaginationVO paginationVO;

	

	/********************** Getters and Setters **********************/

	public boolean getIsData() {
		return isData;
	}

	public void setIsData(boolean isData) {
		this.isData = isData;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public List<Object> getDataList() {
		return dataList;
	}

	public void setDataList(List<Object> dataList) {
		this.dataList = dataList;
	}

	public boolean isTokenExpiry() {
		return tokenExpiry;
	}

	public void setTokenExpiry(boolean tokenExpiry) {
		this.tokenExpiry = tokenExpiry;
	}

	public boolean isPageable() {
		return isPageable;
	}

	public void setPageable(boolean isPageable) {
		this.isPageable = isPageable;
	}

	public PaginationVO getPaginationVO() {
		return paginationVO;
	}

	public void setPaginationVO(PaginationVO paginationVO) {
		this.paginationVO = paginationVO;
	}
}
