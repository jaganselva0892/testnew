package com.trivent.dto;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.springframework.beans.BeanUtils;

import com.trivent.dto.base.BaseVO;
import com.trivent.models.AppDBTable;
import com.trivent.models.AppDBTableColumn;
import com.trivent.models.AppUIScreen;
import com.trivent.models.AppUIScreenFilter;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.dto
 * 
 * @FileName 	:
 *				AppUIScreenFilterVO.java
 * @TypeName 	:
 * 				AppUIScreenFilterVO
 * @DateAndTime :
 *				Feb 8, 2018 - 5:35:47 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description : To list , save and edit the values through path
 *              variable(objects) of AppUIScreenFilterVO(used to interact with
 *              UI) 
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public class AppUIScreenFilterVO extends BaseVO {

	@SuppressWarnings("unused")
	private static final long serialVersionUID = 1518485370335684329L;

	private Long appUIScreenId = null;
	private String appUIScreenType = null;

	private String filterName = null;
	private String dbTableName = null;
	private String dbFieldName = null;
	private String filterDataType = null;
	private Integer filterSeq = null;

	private String value = "";
	private String filterVisible = null;
	// List & Items Value to display for drop down in UI
	private Map<String, String> listItemMap = null;
	
	// List & Items Value to display for drop down in UI
	private Map<String, Map<Long, String>> listItemRoleBy = null;

	// Display Label Map
	private Map<String, String> dbTableDisplayNameMap = null;
	private Map<String, String> dbTableColumnDisplayNameMap = null;

	public AppUIScreenFilterVO() {
	}

	public AppUIScreenFilterVO(AppUIScreenFilter appUIScreenFilter, AppUIScreen appUIScreen) {
		BeanUtils.copyProperties(appUIScreenFilter, this);
		this.setAppUIScreenId(appUIScreen.getId());
		this.setAppUIScreenType(appUIScreen.getScreenType());
		this.setId(appUIScreenFilter.getId());
	}

	public AppUIScreenFilterVO(AppUIScreenFilter appUIScreenFilter, AppUIScreen appUIScreen,
			List<AppDBTable> appDBTables) {
		this(appUIScreenFilter, appUIScreen);
		dbTableDisplayNameMap = new LinkedHashMap<>();
		for (AppDBTable appDBTable : appDBTables) {
			dbTableDisplayNameMap.put(appDBTable.getName(), appDBTable.getDisplayLabel());
		}
		this.setDbTableDisplayNameMap(dbTableDisplayNameMap);
	}

	public AppUIScreenFilterVO(AppUIScreenFilter appUIScreenFilter, AppUIScreen appUIScreen,
			List<AppDBTable> appDBTables, List<AppDBTableColumn> appDBTableColumns) {
		this(appUIScreenFilter, appUIScreen, appDBTables);
		dbTableColumnDisplayNameMap = new LinkedHashMap<>();
		for (AppDBTableColumn appDBTableColumn : appDBTableColumns) {
			dbTableColumnDisplayNameMap.put(appDBTableColumn.getName(), appDBTableColumn.getDisplayLabel());
		}
		this.setDbTableColumnDisplayNameMap(dbTableColumnDisplayNameMap);
	}

	public static List<AppUIScreenFilterVO> getCaseServiceReqVOs(List<AppUIScreenFilter> appUIScreenFilters) {
		int size = appUIScreenFilters.size();
		if (appUIScreenFilters.isEmpty()) {
			size = 1;
		}
		AppUIScreenFilterVO appUIScreenFilterVO;
		List<AppUIScreenFilterVO> filterVOs = new ArrayList<>(size);
		for (AppUIScreenFilter appUIScreenFilter : appUIScreenFilters) {
			appUIScreenFilterVO = new AppUIScreenFilterVO(appUIScreenFilter, appUIScreenFilter.getAppUiScreen());
			filterVOs.add(appUIScreenFilterVO);
		}
		return filterVOs;
	}

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		AppUIScreenFilterVO other = (AppUIScreenFilterVO) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public Long getAppUIScreenId() {
		return appUIScreenId;
	}

	public void setAppUIScreenId(Long appUIScreenId) {
		this.appUIScreenId = appUIScreenId;
	}

	public String getAppUIScreenType() {
		return appUIScreenType;
	}

	public void setAppUIScreenType(String appUIScreenType) {
		this.appUIScreenType = appUIScreenType;
	}

	public String getFilterName() {
		return filterName;
	}

	public void setFilterName(String filterName) {
		this.filterName = filterName;
	}

	public String getDbTableName() {
		return dbTableName;
	}

	public void setDbTableName(String dbTableName) {
		this.dbTableName = dbTableName;
	}

	public String getDbFieldName() {
		return dbFieldName;
	}

	public void setDbFieldName(String dbFieldName) {
		this.dbFieldName = dbFieldName;
	}

	public String getFilterDataType() {
		return filterDataType;
	}

	public void setFilterDataType(String filterDataType) {
		this.filterDataType = filterDataType;
	}

	public Integer getFilterSeq() {
		return filterSeq;
	}

	public void setFilterSeq(Integer filterSeq) {
		this.filterSeq = filterSeq;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public Map<String, String> getListItemMap() {
		return listItemMap;
	}

	public void setListItemMap(Map<String, String> listItemMap) {
		this.listItemMap = listItemMap;
	}

	public Map<String, String> getDbTableDisplayNameMap() {
		return dbTableDisplayNameMap;
	}

	public void setDbTableDisplayNameMap(Map<String, String> dbTableDisplayNameMap) {
		this.dbTableDisplayNameMap = dbTableDisplayNameMap;
	}

	public Map<String, String> getDbTableColumnDisplayNameMap() {
		return dbTableColumnDisplayNameMap;
	}

	public void setDbTableColumnDisplayNameMap(Map<String, String> dbTableColumnDisplayNameMap) {
		this.dbTableColumnDisplayNameMap = dbTableColumnDisplayNameMap;
	}

	public String getFilterVisible() {
		return filterVisible;
	}

	public void setFilterVisible(String filterVisible) {
		this.filterVisible = filterVisible;
	}

	public Map<String, Map<Long, String>> getListItemRoleBy() {
		return listItemRoleBy;
	}

	public void setListItemRoleBy(Map<String, Map<Long, String>> listItemRoleBy) {
		this.listItemRoleBy = listItemRoleBy;
	}
	
}
