package com.trivent.dto;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.springframework.beans.BeanUtils;

import com.trivent.constants.AppConstants;
import com.trivent.dto.base.BaseVO;
import com.trivent.models.AppUIScreen;
import com.trivent.models.AppUIScreenView;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.dto
 * 
 * @FileName 	:
 *				AppUIScreenViewVO.java
 * @TypeName 	:
 * 				AppUIScreenViewVO
 * @DateAndTime :
 *				Feb 8, 2018 - 5:36:07 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description :To list , save and edit the values through path
 *              variable(objects) of AppUIScreenViewVO(used to interact with
 *              UI)  
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public class AppUIScreenViewVO extends BaseVO {

  @SuppressWarnings("unused")
private static final long serialVersionUID = 1518485370335684329L;

  private Long appUIScreenId = null;
  private String appUIScreenType = null;

  private String viewName = null;
  private String viewEntity = null;
  private String viewType = null;
  private Integer seqNo = null;

  private boolean viewDefault = false;
  private boolean viewVisible = false;

  public AppUIScreenViewVO() {
  }

  public AppUIScreenViewVO(AppUIScreenView appUIScreenView, AppUIScreen appUIScreen) {
    BeanUtils.copyProperties(appUIScreenView, this);
    this.setAppUIScreenId(appUIScreen.getId());
    this.setAppUIScreenType(appUIScreen.getScreenType());
    this.setId(appUIScreenView.getId());
    this.setViewDefault(appUIScreenView.getIsDefault() == AppConstants.YES);
    this.setViewVisible(appUIScreenView.getIsVisible() == AppConstants.YES);
  }

  /********************** hashcode, and equals methods **********************/

  @Override
  public int hashCode() {
    return new HashCodeBuilder().append(this.getId()).hashCode();
  }

  @Override
  public boolean equals(Object obj) {
    if (obj == null || obj.getClass() != getClass()) {
      return false;
    }
    AppUIScreenViewVO other = (AppUIScreenViewVO) obj;
    return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
  }

  /********************** Getters and Setters **********************/

  public Long getAppUIScreenId() {
    return appUIScreenId;
  }

  public void setAppUIScreenId(Long appUIScreenId) {
    this.appUIScreenId = appUIScreenId;
  }

  public String getAppUIScreenType() {
    return appUIScreenType;
  }

  public void setAppUIScreenType(String appUIScreenType) {
    this.appUIScreenType = appUIScreenType;
  }

  public String getViewName() {
    return viewName;
  }

  public void setViewName(String viewName) {
    this.viewName = viewName;
  }

  public String getViewType() {
    return viewType;
  }

  public void setViewType(String viewType) {
    this.viewType = viewType;
  }

  public Integer getSeqNo() {
    return seqNo;
  }

  public void setSeqNo(Integer seqNo) {
    this.seqNo = seqNo;
  }

  public boolean isViewDefault() {
    return viewDefault;
  }

  public void setViewDefault(boolean viewDefault) {
    this.viewDefault = viewDefault;
  }

  public boolean isViewVisible() {
    return viewVisible;
  }

  public void setViewVisible(boolean viewVisible) {
    this.viewVisible = viewVisible;
  }

  public String getViewEntity() {
    return viewEntity;
  }

  public void setViewEntity(String viewEntity) {
    this.viewEntity = viewEntity;
  }

}