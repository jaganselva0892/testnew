package com.trivent.dto;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.springframework.beans.BeanUtils;

import com.trivent.dto.base.BaseVO;
import com.trivent.models.EmailTemplate;
import com.trivent.models.Partner;
import com.trivent.models.PartnerEmails;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.dto
 * 
 * @FileName 	:
 *				EmailTemplateVO.java
 * @TypeName 	:
 * 				EmailTemplateVO
 * @DateAndTime :
 *				Feb 8, 2018 - 5:49:04 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description : To list , save and edit the values through path
 *              variable(objects) of EmailTemplateVO for email triggering (used to interact with
 *              UI) 
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public class EmailTemplateVO extends BaseVO {

	@SuppressWarnings("unused")
	private static final long serialVersionUID = -3422830464510211652L;

	private String name = null;
	private String code = null;
	private String subject = null;
	private String message = null;
	private String intEmailToList = null;
	private String intEmailCcList = null;
	private String intEmailBccList = null;

	// Added for partner based tt/cc/bcc email config
	private List<PartnerEmailVO> partnerEmailVOs;

	private Long partnerId;
	private Map<Long, String> partnerMap;

	public EmailTemplateVO() {
	}

	public EmailTemplateVO(EmailTemplate emailTemplate) {
		if (emailTemplate != null) {
			BeanUtils.copyProperties(emailTemplate, this);
			this.setId(emailTemplate.getId());
			this.setPartnerId(emailTemplate.getPartner() == null ? null : emailTemplate.getPartner().getId());
		}
	}

	public EmailTemplateVO(EmailTemplate emailTemplate, List<Partner> partners) {
		BeanUtils.copyProperties(emailTemplate, this);
		this.setId(emailTemplate.getId());
		partnerMap = new LinkedHashMap<>(partners.size());
		for (Partner partner : partners) {
			partnerMap.put(partner.getId(), partner.getName());
		}
		this.setPartnerId(emailTemplate.getPartner() == null ? null : emailTemplate.getPartner().getId());
	}

	public EmailTemplateVO(EmailTemplate emailTemplate, List<Partner> partners, List<PartnerEmails> partnerEmails) {
		BeanUtils.copyProperties(emailTemplate, this);
		this.setId(emailTemplate.getId());
		partnerMap = new LinkedHashMap<>(partners.size());
		for (Partner partner : partners) {
			partnerMap.put(partner.getId(), partner.getName());
		}
		this.setPartnerId(emailTemplate.getPartner() == null ? null : emailTemplate.getPartner().getId());
		// PartnerEmails Added in List
		partnerEmailVOs = new ArrayList<>();
		for (PartnerEmails partnerEmail : partnerEmails) {
			PartnerEmailVO partnerEmailVO = new PartnerEmailVO(partnerEmail);
			partnerEmailVOs.add(partnerEmailVO);
		}
	}

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		EmailTemplateVO other = (EmailTemplateVO) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public Long getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(Long partnerId) {
		this.partnerId = partnerId;
	}

	public Map<Long, String> getPartnerMap() {
		return partnerMap;
	}

	public void setPartnerMap(Map<Long, String> partnerMap) {
		this.partnerMap = partnerMap;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getIntEmailToList() {
		return intEmailToList;
	}

	public void setIntEmailToList(String intEmailToList) {
		this.intEmailToList = intEmailToList;
	}

	public String getIntEmailCcList() {
		return intEmailCcList;
	}

	public void setIntEmailCcList(String intEmailCcList) {
		this.intEmailCcList = intEmailCcList;
	}

	public String getIntEmailBccList() {
		return intEmailBccList;
	}

	public void setIntEmailBccList(String intEmailBccList) {
		this.intEmailBccList = intEmailBccList;
	}

	public List<PartnerEmailVO> getPartnerEmailVOs() {
		return partnerEmailVOs;
	}

	public void setPartnerEmailVOs(List<PartnerEmailVO> partnerEmailVOs) {
		this.partnerEmailVOs = partnerEmailVOs;
	}

}
