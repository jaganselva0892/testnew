package com.trivent.dto;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.trivent.constants.AppConstants;
import com.trivent.dto.base.BaseVO;
import com.trivent.models.CaseFile;
import com.trivent.models.CaseResultFile;
import com.trivent.models.ProdFile;

/**
 * @ProjectName : trivent
 * @PackageName : com.trivent.dto
 * 
 * @FileName : FileVO.java
 * @TypeName : FileVO
 * @DateAndTime : Feb 8, 2018 - 5:50:50 PM
 * 
 * @Author : seetha
 * 
 * @Description : To list , save and edit the values through path
 *              variable(objects) of FileVO(used to interact with UI)
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
public class FileVO extends BaseVO {

	@SuppressWarnings("unused")
	private static final long serialVersionUID = -3422830464510211652L;

	private String name = null;
	private String path = null;
	private String action = null;
	private String rename = null;
	private String type = null;
	private Long accountId = null;
	private Long clientId = null;
	private Long caseId = null;
	private String fileName = null;
	private Long fileSize = null;
	private String fileExtension = null;
	private String fileContentType = null;
	private String uploadedTime;
	private String replicatedFileLocation = null;
	private Integer version = null;
	private String fileRename = null;
	private Long createdById = null;
	private String existingFileRenameTo = null;
	private String errorMessage = null;
	private Character productionFile = null;
	private Character additionalRecord = AppConstants.NO;

	private String lsServiceRequested = null;
	private String caseFileIds = null;

	private Character archived = AppConstants.NO;

	private Integer filePageCount = null;
	private String pageCountStatus;

	public FileVO() {
	}

	public FileVO(Long loginUserId, Long caseId, Long accountId, Long clientId, String fileName, String fileExtension,
			Long fileSize, String uploadedTime, String fileContentType, String replicatedFileLocation) {
		this.setCaseId(caseId);
		this.setAccountId(accountId);
		this.setClientId(clientId);
		this.setName(fileName);
		this.setFileExtension(fileExtension);
		this.setFileSize(fileSize);
		this.setUploadedTime(uploadedTime);
		this.setFileContentType(fileContentType);
		this.setReplicatedFileLocation(replicatedFileLocation);
		this.setCreatedById(loginUserId);
		this.setType(AppConstants.FTP_OBJECT_TYPE_CASE_FILES);
	}

	public FileVO(CaseFile caseFile, String action, String rename) {
		this.setId(caseFile.getId());
		name = caseFile.getName();
		path = caseFile.getFileLocation();
		type = AppConstants.FTP_OBJECT_TYPE_CASE_FILES;
		this.action = action;
		this.rename = rename;
	}

	public FileVO(CaseResultFile caseResultFile, String action, String rename) {
		this.setId(caseResultFile.getId());
		name = caseResultFile.getName();
		path = caseResultFile.getFileLocation();
		type = AppConstants.FTP_OBJECT_TYPE_CASE_RESULT_FILES;
		this.action = action;
		this.rename = rename;
	}

	public FileVO(ProdFile prodFile, String action, String rename) {
		this.setId(prodFile.getId());
		name = prodFile.getFileName();
		path = prodFile.getFileLocation();
		type = AppConstants.FTP_OBJECT_TYPE_PROD_FILES;
		this.action = action;
		this.rename = rename;
	}

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		FileVO other = (FileVO) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getRename() {
		return rename;
	}

	public void setRename(String rename) {
		this.rename = rename;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public Long getCaseId() {
		return caseId;
	}

	public void setCaseId(Long caseId) {
		this.caseId = caseId;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public Long getFileSize() {
		return fileSize;
	}

	public void setFileSize(Long fileSize) {
		this.fileSize = fileSize;
	}

	public String getFileExtension() {
		return fileExtension;
	}

	public void setFileExtension(String fileExtension) {
		this.fileExtension = fileExtension;
	}

	public String getFileContentType() {
		return fileContentType;
	}

	public void setFileContentType(String fileContentType) {
		this.fileContentType = fileContentType;
	}

	public String getUploadedTime() {
		return uploadedTime;
	}

	public void setUploadedTime(String uploadedTime) {
		this.uploadedTime = uploadedTime;
	}

	public String getReplicatedFileLocation() {
		return replicatedFileLocation;
	}

	public void setReplicatedFileLocation(String replicatedFileLocation) {
		this.replicatedFileLocation = replicatedFileLocation;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	public String getFileRename() {
		return fileRename;
	}

	public void setFileRename(String fileRename) {
		this.fileRename = fileRename;
	}

	public Long getAccountId() {
		return accountId;
	}

	public void setAccountId(Long accountId) {
		this.accountId = accountId;
	}

	public Long getClientId() {
		return clientId;
	}

	public void setClientId(Long clientId) {
		this.clientId = clientId;
	}

	public Long getCreatedById() {
		return createdById;
	}

	public void setCreatedById(Long createdById) {
		this.createdById = createdById;
	}

	public String getExistingFileRenameTo() {
		return existingFileRenameTo;
	}

	public void setExistingFileRenameTo(String existingFileRenameTo) {
		this.existingFileRenameTo = existingFileRenameTo;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public Character getProductionFile() {
		return productionFile;
	}

	public void setProductionFile(Character productionFile) {
		this.productionFile = productionFile;
	}

	public Character getArchived() {
		return archived;
	}

	public void setArchived(Character archived) {
		this.archived = archived;
	}

	public Character getAdditionalRecord() {
		return additionalRecord;
	}

	public void setAdditionalRecord(Character additionalRecord) {
		this.additionalRecord = additionalRecord;
	}

	public String getLsServiceRequested() {
		return lsServiceRequested;
	}

	public void setLsServiceRequested(String lsServiceRequested) {
		this.lsServiceRequested = lsServiceRequested;
	}

	public String getCaseFileIds() {
		return caseFileIds;
	}

	public void setCaseFileIds(String caseFileIds) {
		this.caseFileIds = caseFileIds;
	}

	public Integer getFilePageCount() {
		return filePageCount;
	}

	public void setFilePageCount(Integer filePageCount) {
		this.filePageCount = filePageCount;
	}

	public String getPageCountStatus() {
		return pageCountStatus;
	}

	public void setPageCountStatus(String pageCountStatus) {
		this.pageCountStatus = pageCountStatus;
	}

}
