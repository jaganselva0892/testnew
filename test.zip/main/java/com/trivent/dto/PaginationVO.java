package com.trivent.dto;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;

import com.trivent.constants.AppConstants;
import com.trivent.dto.base.BaseVO;




public class PaginationVO extends BaseVO {

  @SuppressWarnings("unused")
private static final long serialVersionUID = -3422830464510211652L;

  // Pagination Variables
  private int page = 1;
  private int limit = 50;
  private int totalPages = 0;
  private int currentRecords = 0;
  private long totalRecords = 0;

  // Soft Options
  private String sortOrder = AppConstants.SORT_PREF_DESC;
  private String sortByField = "createdDate";

  public PaginationVO() {
  }

  public Pageable getPageable() {
    Direction sortDirection = null;
    if (sortOrder.equals(AppConstants.SORT_PREF_ASC)) {
      sortDirection = Sort.Direction.ASC;
    } else {
      sortDirection = Sort.Direction.DESC;
    }
    Sort sortOption = new Sort(sortDirection, sortByField);
    return new PageRequest(page - 1, limit, sortOption);
  }

  /********************** hashcode, and equals methods **********************/

  @Override
  public int hashCode() {
    return new HashCodeBuilder().append(this.getId()).hashCode();
  }

  @Override
  public boolean equals(Object obj) {
    if (obj == null || obj.getClass() != getClass()) {
      return false;
    }
    PaginationVO other = (PaginationVO) obj;
    return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
  }

  /********************** Getters and Setters **********************/

  public int getPage() {
    return page;
  }

  public void setPage(int page) {
    this.page = page;
  }

  public int getLimit() {
    return limit;
  }

  public void setLimit(int limit) {
    this.limit = limit;
  }

  public int getTotalPages() {
    return totalPages;
  }

  public void setTotalPages(int totalPages) {
    this.totalPages = totalPages;
  }

  public int getCurrentRecords() {
    return currentRecords;
  }

  public void setCurrentRecords(int currentRecords) {
    this.currentRecords = currentRecords;
  }

  public long getTotalRecords() {
    return totalRecords;
  }

  public void setTotalRecords(long totalRecords) {
    this.totalRecords = totalRecords;
  }

  public String getSortOrder() {
    return sortOrder;
  }

  public void setSortOrder(String sortOrder) {
    this.sortOrder = sortOrder;
  }

  public String getSortByField() {
    return sortByField;
  }

  public void setSortByField(String sortByField) {
    this.sortByField = sortByField;
  }

}