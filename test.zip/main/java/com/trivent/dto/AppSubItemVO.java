package com.trivent.dto;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.springframework.beans.BeanUtils;

import com.trivent.constants.AppConstants;
import com.trivent.dto.base.BaseVO;
import com.trivent.models.AppItem;
import com.trivent.models.AppSubItem;
import com.trivent.models.Partner;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.dto
 * 
 * @FileName 	:
 *				AppSubItemVO.java
 * @TypeName 	:
 * 				AppSubItemVO
 * @DateAndTime :
 *				Feb 8, 2018 - 5:35:07 PM
 * 
 * @Author 		:
 * 				seetha
 * 
 * @Description : To list , save and edit the values through path
 *              variable(objects) of AppSubItemVO(used to interact with
 *              UI) 
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public class AppSubItemVO extends BaseVO {

  private Long appListId = null;
  private Long appItemId = null;

  private String shortName;
  private String longName;
  private Integer seqNo;
  private boolean defaultItem = false;

  private boolean value = false;
//Added on 12/07/2016 for services tooltips/url 
  private String toolTip;
  private String serviceLink;
  
  Map<Long, String> partnerListMap;
  private String partner;
  private List<Long> partnerInLong;
  
  public AppSubItemVO() {
  }

  public AppSubItemVO(AppSubItem appSubItem) {
    BeanUtils.copyProperties(appSubItem, this);
    this.setAppListId(appSubItem.getAppList().getId());
    this.setAppItemId(appSubItem.getAppItem().getId());
    this.setId(appSubItem.getId());
    this.setDefaultItem(appSubItem.isDefault());
  }
  
  public AppSubItemVO(List<Partner> partnerList, AppItem appItem, Long appListId) {
		BeanUtils.copyProperties(appItem, this);
		this.setDefaultItem(appItem.getDefaultItem() == AppConstants.YES);
		this.setAppListId(appListId);
		this.setId(appItem.getId());
		partnerListMap = new LinkedHashMap<>();
		for (Partner partner : partnerList) 
			partnerListMap.put(partner.getId(),partner.getName().concat("[").concat(partner.getPartnerCode()).concat("]"));
	}

  /********************** hashcode, and equals methods **********************/

  @Override
  public int hashCode() {
    return new HashCodeBuilder().append(this.getId()).hashCode();
  }

  @Override
  public boolean equals(Object obj) {
    if (obj == null || obj.getClass() != getClass()) {
      return false;
    }
    AppSubItemVO other = (AppSubItemVO) obj;
    return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
  }

  /********************** Getters and Setters **********************/

  public Long getAppListId() {
    return appListId;
  }

  public void setAppListId(Long appListId) {
    this.appListId = appListId;
  }

  public Long getAppItemId() {
    return appItemId;
  }

  public void setAppItemId(Long appItemId) {
    this.appItemId = appItemId;
  }

  public String getShortName() {
    return shortName;
  }

  public void setShortName(String shortName) {
    this.shortName = shortName;
  }

  public String getLongName() {
    return longName;
  }

  public void setLongName(String longName) {
    this.longName = longName;
  }

  public Integer getSeqNo() {
    return seqNo;
  }

  public void setSeqNo(Integer seqNo) {
    this.seqNo = seqNo;
  }

  public boolean isDefaultItem() {
    return defaultItem;
  }

  public void setDefaultItem(boolean defaultItem) {
    this.defaultItem = defaultItem;
  }

  public boolean isValue() {
    return value;
  }

  public void setValue(boolean value) {
    this.value = value;
  }

//Added on 12/07/2016 for services tooltips/url get/set
	public String getToolTip() {
		return toolTip;
	}

	public void setToolTip(String toolTip) {
		this.toolTip = toolTip;
	}

	public String getServiceLink() {
		return serviceLink;
	}

	public void setServiceLink(String serviceLink) {
		this.serviceLink = serviceLink;
	}

	public Map<Long, String> getPartnerListMap() {
		return partnerListMap;
	}

	public void setPartnerListMap(Map<Long, String> partnerListMap) {
		this.partnerListMap = partnerListMap;
	}

	public String getPartner() {
		return partner;
	}

	public void setPartner(String partner) {
		this.partner = partner;
	}

	public List<Long> getPartnerInLong() {
		return partnerInLong;
	}

	public void setPartnerInLong(List<Long> partnerInLong) {
		this.partnerInLong = partnerInLong;
	}
	
}
