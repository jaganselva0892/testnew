package com.trivent.dto;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.springframework.beans.BeanUtils;

import com.trivent.constants.AppConstants;
import com.trivent.dto.base.BaseVO;
import com.trivent.models.AppDBTable;
import com.trivent.models.AppDBTableColumn;
import com.trivent.models.AppUIScreen;
import com.trivent.models.AppUIScreenField;

/**
 * @ProjectName : trivent
 * @PackageName : com.trivent.dto
 * 
 * @FileName : AppUIScreenFieldVO.java
 * @TypeName : AppUIScreenFieldVO
 * @DateAndTime : Feb 8, 2018 - 5:35:29 PM
 * 
 * @Author : seetha
 * 
 * @Description : To list , save and edit the values through path
 *              variable(objects) of AppUIScreenFieldVO(used to interact with
 *              UI)
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
public class AppUIScreenFieldVO extends BaseVO {

	

	private Long appUIScreenId = null;
	private String appUIScreenType = null;
	private String appUIScreenName = null;

	private String attributeName = null;
	private String dbTableName = null;
	private String dbFieldName = null;
	private Integer attributeSize = 0;
	private String attributeDataType = null;
	private String attributeValidation = null;
	private String attributeHint = null;
	private Integer attributeUIColumn = null;
	private Integer attributeSeq = null;
	private String listName = null;

	private String entityPropertyType = null;

	private boolean attributeRequired = false;
	private boolean displayable = true;
	private boolean readOnly = false;

	private String value = "";
	private boolean booleanValue = false;
	private Integer hours = 0;
	private Integer minutes = 0;

	// List & Items Value to display for drop down in UI
	private Map<String, String> listItemMap = null;

	// Display Label Map
	private Map<String, String> dbTableDisplayNameMap = null;
	private Map<String, String> dbTableColumnDisplayNameMap = null;

	public AppUIScreenFieldVO() {
	}

	public AppUIScreenFieldVO(AppUIScreenField appUIScreenField, AppUIScreen appUIScreen) {
		BeanUtils.copyProperties(appUIScreenField, this);
		this.setAppUIScreenId(appUIScreen.getId());
		this.setAppUIScreenType(appUIScreen.getScreenType());
		this.setAppUIScreenName(appUIScreen.getScreenName());
		this.setId(appUIScreenField.getId());

		attributeRequired = appUIScreenField.getAttributeRequired() == AppConstants.YES;
		displayable = appUIScreenField.getDisplayable() == AppConstants.YES;
		readOnly = appUIScreenField.getReadOnly() == AppConstants.YES;
	}

	public AppUIScreenFieldVO(AppUIScreenField appUIScreenField, AppUIScreen appUIScreen,
			List<AppDBTable> appDBTables) {
		this(appUIScreenField, appUIScreen);
		dbTableDisplayNameMap = new LinkedHashMap<>();
		for (AppDBTable appDBTable : appDBTables) {
			dbTableDisplayNameMap.put(appDBTable.getName(), appDBTable.getDisplayLabel());
		}
		this.setDbTableDisplayNameMap(dbTableDisplayNameMap);
	}

	public AppUIScreenFieldVO(AppUIScreenField appUIScreenField, AppUIScreen appUIScreen, List<AppDBTable> appDBTables,
			List<AppDBTableColumn> appDBTableColumns) {
		this(appUIScreenField, appUIScreen, appDBTables);
		dbTableColumnDisplayNameMap = new LinkedHashMap<>();
		for (AppDBTableColumn appDBTableColumn : appDBTableColumns) {
			dbTableColumnDisplayNameMap.put(appDBTableColumn.getName(), appDBTableColumn.getDisplayLabel());
		}
		this.setDbTableColumnDisplayNameMap(dbTableColumnDisplayNameMap);
	}

	public static List<AppUIScreenFieldVO> getCaseServiceReqVOs(List<AppUIScreenField> appUIScreenFields) {
		int size = appUIScreenFields.size();
		if (appUIScreenFields.isEmpty()) {
			size = 1;
		}
		AppUIScreenFieldVO appUIScreenFieldVO;
		List<AppUIScreenFieldVO> fieldVOs = new ArrayList<>(size);
		for (AppUIScreenField appUIScreenField : appUIScreenFields) {
			appUIScreenFieldVO = new AppUIScreenFieldVO(appUIScreenField, appUIScreenField.getAppUiScreen());
			fieldVOs.add(appUIScreenFieldVO);
		}
		return fieldVOs;
	}

	/********************** hashcode, and equals methods **********************/

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || obj.getClass() != getClass()) {
			return false;
		}
		AppUIScreenFieldVO other = (AppUIScreenFieldVO) obj;
		return new EqualsBuilder().append(this.getId(), other.getId()).isEquals();
	}

	/********************** Getters and Setters **********************/

	public Long getAppUIScreenId() {
		return appUIScreenId;
	}

	public void setAppUIScreenId(Long appUIScreenId) {
		this.appUIScreenId = appUIScreenId;
	}

	public String getAttributeName() {
		return attributeName;
	}

	public void setAttributeName(String attributeName) {
		this.attributeName = attributeName;
	}

	public Integer getAttributeSize() {
		return attributeSize;
	}

	public void setAttributeSize(Integer attributeSize) {
		this.attributeSize = attributeSize;
	}

	public String getAttributeDataType() {
		return attributeDataType;
	}

	public void setAttributeDataType(String attributeDataType) {
		this.attributeDataType = attributeDataType;
	}

	public String getAttributeValidation() {
		return attributeValidation;
	}

	public void setAttributeValidation(String attributeValidation) {
		this.attributeValidation = attributeValidation;
	}

	public String getAttributeHint() {
		return attributeHint;
	}

	public void setAttributeHint(String attributeHint) {
		this.attributeHint = attributeHint;
	}

	public Integer getAttributeUIColumn() {
		return attributeUIColumn;
	}

	public void setAttributeUIColumn(Integer attributeUIColumn) {
		this.attributeUIColumn = attributeUIColumn;
	}

	public Integer getAttributeSeq() {
		return attributeSeq;
	}

	public void setAttributeSeq(Integer attributeSeq) {
		this.attributeSeq = attributeSeq;
	}

	public String getDbTableName() {
		return dbTableName;
	}

	public void setDbTableName(String dbTableName) {
		this.dbTableName = dbTableName;
	}

	public String getDbFieldName() {
		return dbFieldName;
	}

	public void setDbFieldName(String dbFieldName) {
		this.dbFieldName = dbFieldName;
	}

	public String getListName() {
		return listName;
	}

	public void setListName(String listName) {
		this.listName = listName;
	}

	public boolean isAttributeRequired() {
		return attributeRequired;
	}

	public void setAttributeRequired(boolean attributeRequired) {
		this.attributeRequired = attributeRequired;
	}

	public boolean isDisplayable() {
		return displayable;
	}

	public void setDisplayable(boolean displayable) {
		this.displayable = displayable;
	}

	public boolean isReadOnly() {
		return readOnly;
	}

	public void setReadOnly(boolean readOnly) {
		this.readOnly = readOnly;
	}

	public Map<String, String> getDbTableDisplayNameMap() {
		return dbTableDisplayNameMap;
	}

	public void setDbTableDisplayNameMap(Map<String, String> dbTableDisplayNameMap) {
		this.dbTableDisplayNameMap = dbTableDisplayNameMap;
	}

	public Map<String, String> getDbTableColumnDisplayNameMap() {
		return dbTableColumnDisplayNameMap;
	}

	public void setDbTableColumnDisplayNameMap(Map<String, String> dbTableColumnDisplayNameMap) {
		this.dbTableColumnDisplayNameMap = dbTableColumnDisplayNameMap;
	}

	public String getAppUIScreenType() {
		return appUIScreenType;
	}

	public void setAppUIScreenType(String appUIScreenType) {
		this.appUIScreenType = appUIScreenType;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public Integer getHours() {
		return hours;
	}

	public void setHours(Integer hours) {
		this.hours = hours;
	}

	public Integer getMinutes() {
		return minutes;
	}

	public void setMinutes(Integer minutes) {
		this.minutes = minutes;
	}

	public boolean isBooleanValue() {
		return booleanValue;
	}

	public void setBooleanValue(boolean booleanValue) {
		this.booleanValue = booleanValue;
	}

	public Map<String, String> getListItemMap() {
		return listItemMap;
	}

	public void setListItemMap(Map<String, String> listItemMap) {
		this.listItemMap = listItemMap;
	}

	public String getAppUIScreenName() {
		return appUIScreenName;
	}

	public void setAppUIScreenName(String appUIScreenName) {
		this.appUIScreenName = appUIScreenName;
	}

	public String getEntityPropertyType() {
		return entityPropertyType;
	}

	public void setEntityPropertyType(String entityPropertyType) {
		this.entityPropertyType = entityPropertyType;
	}

}
