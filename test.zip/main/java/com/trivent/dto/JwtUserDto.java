package com.trivent.dto;

/**
* FileName: JwtUserDto.java
* Pojo's for user credentials
* @author Jagan 0010
* @version 1.0
*/
public class JwtUserDto {

	private Long id;

	private String username;

	private String loginId;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
}
