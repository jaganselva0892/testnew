package com.trivent.dto;

/**
 * FileName: UserLoginVO.java Pojo's for user logged in token and token expiry
 * 
 * @author Jagan 0010
 * @version 1.0
 */

public class UserLoginVO {

	private String token;
	private String tokenExpiry;

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getTokenExpiry() {
		return tokenExpiry;
	}

	public void setTokenExpiry(String tokenExpiry) {
		this.tokenExpiry = tokenExpiry;
	}

}
