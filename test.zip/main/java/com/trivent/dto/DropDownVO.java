package com.trivent.dto;



public class DropDownVO {
	
	private String text = null;
	private Long  value = null;
	
	public DropDownVO() {
	}
	

	/********************** Getters and Setters **********************/
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public Long getValue() {
		return value;
	}
	public void setValue(Long value) {
		this.value = value;
	}

}
