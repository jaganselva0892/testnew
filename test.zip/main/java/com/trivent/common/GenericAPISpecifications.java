package com.trivent.common;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.domain.Specifications;
import org.springframework.stereotype.Component;

import com.trivent.constants.AppConstants;
import com.trivent.dto.AppUIScreenFilterVO;
import com.trivent.dto.ScreenListFilterVO;
import com.trivent.logging.LogManager;
import com.trivent.logging.Logger;
import com.trivent.models.Account;
import com.trivent.models.AppItem;
import com.trivent.models.AppList;
import com.trivent.models.AppSubItem;
import com.trivent.models.Case;
import com.trivent.models.CaseContacts;
import com.trivent.models.CaseFile;
import com.trivent.models.CaseResultFile;
import com.trivent.models.CaseServiceReq;
import com.trivent.models.Contact;
import com.trivent.models.Division;
import com.trivent.models.Job;
import com.trivent.models.Partner;
import com.trivent.models.ProdFile;
import com.trivent.models.Production;
import com.trivent.models.Role;
import com.trivent.models.Team;
import com.trivent.models.User;
import com.trivent.models.UserPartners;
import com.trivent.models.UserProfile;
import com.trivent.utils.CommonUtils;

/**
 * @FileName : GenericAPISpecifications.java
 * @ClassName : GenericAPISpecifications
 * @DateAndTime : Sep 3, 2018 - 3:12:12 PM
 * 
 * @Author : Boopathi
 * 
 * @Description : Created GenericAPISpecifications use this class.
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
@SuppressWarnings("hiding")
@Component
public class GenericAPISpecifications<T> {

	private static final Logger LOGGER = LogManager.getLogger();

	private static final String CLASS_NAME = GenericAPISpecifications.class.getName();

	private static String getLikePattern(final String pstrSearchTerm) {
		StringBuilder pattern = new StringBuilder();
		pattern.append(pstrSearchTerm.toLowerCase());
		pattern.insert(0, "%");
		pattern.append("%");
		return pattern.toString();
	}

	public Specification<T> dataTypeStringLike(final String pstrColumnName, final String pstrSearchTerm) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				String likePattern = getLikePattern(pstrSearchTerm);
				return cb.like(cb.lower(root.<String>get(pstrColumnName)), likePattern);
			}
		};
	}

	public Specification<T> dataTypeStringNotLike(final String pstrColumnName, final String pstrSearchTerm) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				String likePattern = getLikePattern(pstrSearchTerm);
				return cb.notLike(cb.lower(root.<String>get(pstrColumnName)), likePattern);
			}
		};
	}

	public Specification<T> dataTypeCharacter(final String columnName, final char searchTerm) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.equal(root.<Character>get(columnName), searchTerm);
			}
		};
	}

	public Specification<T> dataTypeNotCharacter(final String columnName, final char searchTerm) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.notEqual(root.<Character>get(columnName), searchTerm);
			}
		};
	}

	public Specification<T> dataTypeNull(final String columnName) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.and(cb.isNull(root.get(columnName)));
			}
		};
	}

	public Specification<T> dataTypeNotNull(final String columnName) {
		return new Specification<T>() {
			@Override
			public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				return cb.and(cb.isNotNull(root.get(columnName)));
			}
		};
	}

	public Specification<T> dataTypeList(final String pstrColumnName, final String pstrSearchTerm, String pstrClassName,
			String pstrCondition) {

		Specification<T> lspec = null;
		try {
			String CONDITION_AND = "and";

			JoinType ljtJoinType = CONDITION_AND.equalsIgnoreCase(pstrCondition) ? JoinType.INNER : JoinType.LEFT;

			Class<?> tableClass = Class.forName(pstrClassName);

			List<Field> fieldList = new ArrayList<>();
			Class<?> fieldClass = tableClass;
			while (null != fieldClass) {
				fieldList.addAll(Arrays.asList(fieldClass.getDeclaredFields()));
				fieldClass = fieldClass.getSuperclass();
			}

			if (StringUtils.isNotBlank(pstrSearchTerm)) {
				List<String> llstFilterValue = Arrays.stream(pstrSearchTerm.split(",")).collect(Collectors.toList());
				List<Field> tableFieldList = fieldList.stream()
						.filter(p -> null != p.getName() && p.getName().equalsIgnoreCase(pstrColumnName))
						.collect(Collectors.toList());

				if (!tableFieldList.isEmpty()) {

					Field tableField = tableFieldList.get(0);
					if (null != tableField) {
						lspec = (new Specification<T>() {

							@Override
							public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {

								Predicate lpreRestriction = cb.and(root.get(pstrColumnName).in(pstrSearchTerm));

								if (Account.class.getName().equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, Account> p = root.join(pstrColumnName, ljtJoinType);
									lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
								} else if (AppItem.class.getName().equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, AppItem> p = root.join(pstrColumnName, ljtJoinType);
									lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
								} else if (AppList.class.getName().equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, AppList> p = root.join(pstrColumnName, ljtJoinType);
									lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
								} else if (AppSubItem.class.getName()
										.equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, AppSubItem> p = root.join(pstrColumnName, ljtJoinType);
									lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
								} else if (Case.class.getName().equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, Case> p = root.join(pstrColumnName, ljtJoinType);
									lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
								} else if (CaseFile.class.getName().equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, CaseFile> p = root.join(pstrColumnName, ljtJoinType);
									lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
								} /*else if (CaseQuery.class.getName().equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, CaseQuery> p = root.join(pstrColumnName, ljtJoinType);
									lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
								}*/ else if (CaseResultFile.class.getName()
										.equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, CaseResultFile> p = root.join(pstrColumnName, ljtJoinType);
									lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
								} else if (CaseServiceReq.class.getName()
										.equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, CaseServiceReq> p = root.join(pstrColumnName, ljtJoinType);
									lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
								} /*else if (CaseTask.class.getName().equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, CaseTask> p = root.join(pstrColumnName, ljtJoinType);
									lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
								}*/ else if (Contact.class.getName().equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, Contact> p = root.join(pstrColumnName, ljtJoinType);
									lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
								} else if (Division.class.getName().equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, Division> p = root.join(pstrColumnName, ljtJoinType);
									lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
								} else if (Job.class.getName().equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, Job> p = root.join(pstrColumnName, ljtJoinType);
									lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
								} else if (Partner.class.getName().equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, Partner> p = root.join(pstrColumnName, ljtJoinType);
									lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
								} else if (Role.class.getName().equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, Role> p = root.join(pstrColumnName, ljtJoinType);
									lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
								} else if (Team.class.getName().equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, Team> p = root.join(pstrColumnName, ljtJoinType);
									lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
								} else if (User.class.getName().equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, User> p = root.join(pstrColumnName, ljtJoinType);
									lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
								} else if (UserProfile.class.getName()
										.equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, UserProfile> p = root.join(pstrColumnName, ljtJoinType);
									lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
								}/* else if (CaseQueryResponse.class.getName()
										.equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, UserProfile> p = root.join(pstrColumnName, ljtJoinType);
									lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
								} else if (ArchivalHistory.class.getName()
										.equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, ArchivalHistory> p = root.join(pstrColumnName, ljtJoinType);
									lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
								} else if (CaseQueryFlag.class.getName()
										.equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, CaseQueryFlag> p = root.join(pstrColumnName, ljtJoinType);
									lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
								} else if (CaseQueryResponseFiles.class.getName()
										.equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, CaseQueryResponseFiles> p = root.join(pstrColumnName, ljtJoinType);
									lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
								} */else if (CaseContacts.class.getName()
										.equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, CaseContacts> p = root.join(pstrColumnName, ljtJoinType);
									lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
								} else if (ProdFile.class.getName().equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, ProdFile> p = root.join(pstrColumnName, ljtJoinType);
									lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
								} /*else if (ProdAssigneeFlow.class.getName()
										.equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, ProdAssigneeFlow> p = root.join(pstrColumnName, ljtJoinType);
									lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
								} else if (ProdHistory.class.getName()
										.equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, ProdHistory> p = root.join(pstrColumnName, ljtJoinType);
									lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
								} else if (Production.class.getName()
										.equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, Production> p = root.join(pstrColumnName, ljtJoinType);
									lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
								} else if (PartnerEmails.class.getName()
										.equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, PartnerEmails> p = root.join(pstrColumnName, ljtJoinType);
									lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
								} */else if (UserPartners.class.getName()
										.equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, UserPartners> p = root.join(pstrColumnName, ljtJoinType);
									lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
								} else if (String.class.getName().equalsIgnoreCase(tableField.getType().getName())
										&& llstFilterValue.size() == 1) {

									String LSTR_QUERY_TYPE_FIELD = "query_type";
									if (LSTR_QUERY_TYPE_FIELD.equalsIgnoreCase(pstrColumnName)) {
										if (!AppConstants.QUERY_NON_CATEGORY.equalsIgnoreCase(llstFilterValue.get(0))) {
											lpreRestriction = cb.and(cb.isNull(root.get(pstrColumnName)));
										} else {
											String likePattern = getLikePattern(llstFilterValue.get(0));
											lpreRestriction = cb.like(cb.lower(root.get(pstrColumnName)), likePattern);
										}
									} else {
										String likePattern = getLikePattern(llstFilterValue.get(0));
										lpreRestriction = cb.like(cb.lower(root.get(pstrColumnName)), likePattern);
									}

								} else {
									lpreRestriction = cb.and(root.get(pstrColumnName).in(llstFilterValue));
								}

								return lpreRestriction;
							}
						});
					}
				}
			}

		} catch (Exception e) {

		}

		return lspec;
	}

	public Specification<T> getSpecificationQuerySearch(final String pstrColumnName, final String pstrSearchTerm,
			String pstrClassName) {
		String METHOD_NAME = "getSpecificationQuerySearch";

		Specifications<T> lspec = Specifications
				.where(this.dataTypeStringLike("deleted", String.valueOf(AppConstants.NO)));

		try {

			/*if (StringUtils.isNotBlank(pstrSearchTerm)) {
				String LOCAL_STRING_QUERY_SEARCH = "search";
				if (CaseQuery.class.getName().equalsIgnoreCase(pstrClassName)
						&& LOCAL_STRING_QUERY_SEARCH.equalsIgnoreCase(pstrColumnName)) {

					Specifications<T> lspecSearch = Specifications.where(new Specification<T>() {

						@Override
						public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {

							String likePattern = getLikePattern(pstrSearchTerm);
							Predicate lpreRestriction = cb.like(cb.lower(root.get("querySubject")), likePattern);

							return lpreRestriction;
						}
					});

					lspecSearch = lspecSearch.or(new Specification<T>() {

						@Override
						public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {

							String likePattern = getLikePattern(pstrSearchTerm);
							Predicate lpreRestriction = cb.like(cb.lower(root.get("status")), likePattern);

							return lpreRestriction;
						}
					});

					lspecSearch = lspecSearch.or(new Specification<T>() {

						@Override
						public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {

							String likePattern = getLikePattern(pstrSearchTerm);
							Predicate lpreRestriction = cb.like(cb.lower(root.get("query_type")), likePattern);

							return lpreRestriction;
						}
					});

					lspecSearch = lspecSearch.or(new Specification<T>() {

						@Override
						public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {

							String likePattern = getLikePattern(pstrSearchTerm);
							Predicate lpreRestriction = cb.like(cb.lower(root.get("querySubtype")), likePattern);

							return lpreRestriction;
						}
					});

					lspecSearch = lspecSearch.or(new Specification<T>() {

						@Override
						public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {

							String likePattern = getLikePattern(pstrSearchTerm);
							Predicate lpreRestriction = cb.like(cb.lower(root.get("queryPartnerBean")), likePattern);

							return lpreRestriction;
						}
					});

					lspecSearch = lspecSearch.or(new Specification<T>() {

						@Override
						public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {

							String likePattern = getLikePattern(pstrSearchTerm);

							Join<T, Account> p = root.join("account", JoinType.LEFT);
							Predicate lpreRestriction = cb.like(cb.lower(p.get("name")), likePattern);

							return lpreRestriction;
						}
					});

					lspecSearch = lspecSearch.or(new Specification<T>() {

						@Override
						public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {

							String likePattern = getLikePattern(pstrSearchTerm);

							Join<T, Case> p = root.join("clientCase", JoinType.LEFT);
							Predicate lpreRestriction = cb.like(cb.lower(p.get("name")), likePattern);

							return lpreRestriction;
						}
					});

					lspecSearch = lspecSearch.or(new Specification<T>() {

						@Override
						public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {

							String likePattern = getLikePattern(pstrSearchTerm);

							Join<T, User> p = root.join("client", JoinType.LEFT);
							Predicate lpreRestriction = cb.like(cb.lower(p.get("userProfile").get("firstName")),
									likePattern);

							return lpreRestriction;
						}
					});

					lspecSearch = lspecSearch.or(new Specification<T>() {

						@Override
						public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {

							String likePattern = getLikePattern(pstrSearchTerm);

							Join<T, User> p = root.join("client", JoinType.LEFT);
							Predicate lpreRestriction = cb.like(cb.lower(p.get("userProfile").get("lastName")),
									likePattern);

							return lpreRestriction;
						}
					});

					lspecSearch = lspecSearch.or(new Specification<T>() {

						@Override
						public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {

							String likePattern = getLikePattern(pstrSearchTerm);

							Join<T, User> p = root.join("assignedTo", JoinType.LEFT);
							Predicate lpreRestriction = cb.like(cb.lower(p.get("userProfile").get("firstName")),
									likePattern);

							return lpreRestriction;
						}
					});

					lspecSearch = lspecSearch.or(new Specification<T>() {

						@Override
						public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {

							String likePattern = getLikePattern(pstrSearchTerm);

							Join<T, User> p = root.join("assignedTo", JoinType.LEFT);
							Predicate lpreRestriction = cb.like(cb.lower(p.get("userProfile").get("lastName")),
									likePattern);

							return lpreRestriction;
						}
					});
					lspec = lspecSearch;
				}
			}
*/
		} catch (Exception e) {
			LOGGER.info(CLASS_NAME, METHOD_NAME, e.getMessage());
		}

		return lspec;
	}

	public Specification<T> getSpecification(ScreenListFilterVO screenListFilterVO, Specification<T> psSpec,
			String pstrClassName) {

		String METHOD_NAME = "getSpecification";

		Specifications<T> lspec = Specifications.where(psSpec);

		try {

			Class<?> tableClass = Class.forName(pstrClassName);

			List<Field> fieldList = new ArrayList<>();
			Class<?> fieldClass = tableClass;
			while (null != fieldClass) {
				fieldList.addAll(Arrays.asList(fieldClass.getDeclaredFields()));
				fieldClass = fieldClass.getSuperclass();
			}

			if (null != screenListFilterVO) {
				List<AppUIScreenFilterVO> llstAppUIScreenFilterVO = screenListFilterVO.getAppUIScreenFilterVOs();
				if (llstAppUIScreenFilterVO.isEmpty()) {
					lspec = Specifications.where(psSpec);
				} else {
					for (AppUIScreenFilterVO appUIScreenFilterVO : llstAppUIScreenFilterVO) {

						if (StringUtils.isNotBlank(appUIScreenFilterVO.getValue())) {
							List<String> llstFilterValue = Arrays.stream(appUIScreenFilterVO.getValue().split(","))
									.collect(Collectors.toList());
							List<Field> tableFieldList = fieldList.stream()
									.filter(p -> null != p.getName()
											&& p.getName().equalsIgnoreCase(appUIScreenFilterVO.getDbFieldName()))
									.collect(Collectors.toList());

							if (!tableFieldList.isEmpty()) {

								Field tableField = tableFieldList.get(0);
								if (null != tableField) {

									if (appUIScreenFilterVO.getFilterDataType()
											.equals(CommonUtils.trimClassName(Calendar.class.getName()))
											|| appUIScreenFilterVO.getFilterDataType()
													.equals(CommonUtils.trimClassName(Date.class.getName()))) {
										if (appUIScreenFilterVO.getDbFieldName().indexOf("todatefield") < 0) {

											Calendar fromDate = Calendar.getInstance();
											Calendar toDate = Calendar.getInstance();

											if (StringUtils.isNotBlank(appUIScreenFilterVO.getDbTableName())
													&& StringUtils.isNotEmpty(appUIScreenFilterVO.getDbTableName())
													&& StringUtils.isNotBlank(appUIScreenFilterVO.getFilterDataType())
													&& StringUtils.isNotEmpty(appUIScreenFilterVO.getFilterDataType())
													&& StringUtils.isNotBlank(appUIScreenFilterVO.getDbFieldName())
													&& StringUtils.isNotEmpty(appUIScreenFilterVO.getDbFieldName())) {

												for (AppUIScreenFilterVO appUIScreenFilterVOUpdate : llstAppUIScreenFilterVO) {
													if (appUIScreenFilterVO.getDbTableName().equalsIgnoreCase(
															appUIScreenFilterVOUpdate.getDbTableName())
															&& appUIScreenFilterVO.getFilterDataType().equalsIgnoreCase(
																	appUIScreenFilterVOUpdate.getFilterDataType())
															&& appUIScreenFilterVOUpdate.getDbFieldName()
																	.equalsIgnoreCase("todatefield".concat(
																			appUIScreenFilterVO.getDbFieldName()))) {

														fromDate = CommonUtils
																.stringToCalendar(appUIScreenFilterVO.getValue());
														fromDate.set(Calendar.HOUR, 0);
														fromDate.set(Calendar.MINUTE, 0);
														fromDate.set(Calendar.SECOND, 0);
														fromDate.set(Calendar.MILLISECOND, 0);
														fromDate.set(Calendar.AM_PM, Calendar.AM);

														toDate = CommonUtils.getCalendarEndOfDayTime(
																CommonUtils.stringToCalendar(StringUtils.isNotBlank(
																		appUIScreenFilterVOUpdate.getValue())
																		&& StringUtils.isNotEmpty(
																				appUIScreenFilterVOUpdate.getValue())
																						? appUIScreenFilterVOUpdate
																								.getValue()
																						: appUIScreenFilterVO
																								.getValue()));

														break;

													}
												}
											} else {
												fromDate = CommonUtils.stringToCalendar(appUIScreenFilterVO.getValue());
												fromDate.set(Calendar.HOUR, 0);
												fromDate.set(Calendar.MINUTE, 0);
												fromDate.set(Calendar.SECOND, 0);
												fromDate.set(Calendar.MILLISECOND, 0);
												fromDate.set(Calendar.AM_PM, Calendar.AM);

												toDate = CommonUtils.getCalendarEndOfDayTime(fromDate);

											}

											if (fromDate.compareTo(toDate) > -1) {

												Calendar tempDate = fromDate;
												fromDate = toDate;
												toDate = tempDate;
											}

											final Date ldtFrom = CommonUtils.getCalendarStartOfDayTime(fromDate)
													.getTime();
											final Date ldtTo = CommonUtils.getCalendarEndOfDayTime(toDate).getTime();

											lspec = lspec.and(new Specification<T>() {

												@Override
												public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query,
														CriteriaBuilder cb) {

													Predicate lpreRestriction = cb.between(
															root.get(appUIScreenFilterVO.getDbFieldName()), ldtFrom,
															ldtTo);
													return lpreRestriction;
												}
											});

										}

									} else {
										lspec = lspec.and(new Specification<T>() {

											@Override
											public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query,
													CriteriaBuilder cb) {

												Predicate lpreRestriction = cb
														.and(root.get(appUIScreenFilterVO.getDbFieldName())
																.in(appUIScreenFilterVO.getValue()));

												if (Account.class.getName()
														.equalsIgnoreCase(tableField.getType().getName())) {
													Join<T, Account> p = root.join(appUIScreenFilterVO.getDbFieldName(),
															JoinType.INNER);
													lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
												} else if (AppItem.class.getName()
														.equalsIgnoreCase(tableField.getType().getName())) {
													Join<T, AppItem> p = root.join(appUIScreenFilterVO.getDbFieldName(),
															JoinType.INNER);
													lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
												} else if (AppList.class.getName()
														.equalsIgnoreCase(tableField.getType().getName())) {
													Join<T, AppList> p = root.join(appUIScreenFilterVO.getDbFieldName(),
															JoinType.INNER);
													lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
												} else if (AppSubItem.class.getName()
														.equalsIgnoreCase(tableField.getType().getName())) {
													Join<T, AppSubItem> p = root
															.join(appUIScreenFilterVO.getDbFieldName(), JoinType.INNER);
													lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
												} else if (Case.class.getName()
														.equalsIgnoreCase(tableField.getType().getName())) {
													Join<T, Case> p = root.join(appUIScreenFilterVO.getDbFieldName(),
															JoinType.INNER);
													lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
												} else if (CaseFile.class.getName()
														.equalsIgnoreCase(tableField.getType().getName())) {
													Join<T, CaseFile> p = root
															.join(appUIScreenFilterVO.getDbFieldName(), JoinType.INNER);
													lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
												}/* else if (CaseQuery.class.getName()
														.equalsIgnoreCase(tableField.getType().getName())) {
													Join<T, CaseQuery> p = root
															.join(appUIScreenFilterVO.getDbFieldName(), JoinType.INNER);
													lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
												}*/ else if (CaseResultFile.class.getName()
														.equalsIgnoreCase(tableField.getType().getName())) {
													Join<T, CaseResultFile> p = root
															.join(appUIScreenFilterVO.getDbFieldName(), JoinType.INNER);
													lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
												} else if (CaseServiceReq.class.getName()
														.equalsIgnoreCase(tableField.getType().getName())) {
													Join<T, CaseServiceReq> p = root
															.join(appUIScreenFilterVO.getDbFieldName(), JoinType.INNER);
													lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
												} /*else if (CaseTask.class.getName()
														.equalsIgnoreCase(tableField.getType().getName())) {
													Join<T, CaseTask> p = root
															.join(appUIScreenFilterVO.getDbFieldName(), JoinType.INNER);
													lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
												} */else if (Contact.class.getName()
														.equalsIgnoreCase(tableField.getType().getName())) {
													Join<T, Contact> p = root.join(appUIScreenFilterVO.getDbFieldName(),
															JoinType.INNER);
													lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
												} else if (Division.class.getName()
														.equalsIgnoreCase(tableField.getType().getName())) {
													Join<T, Division> p = root
															.join(appUIScreenFilterVO.getDbFieldName(), JoinType.INNER);
													lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
												} else if (Job.class.getName()
														.equalsIgnoreCase(tableField.getType().getName())) {
													Join<T, Job> p = root.join(appUIScreenFilterVO.getDbFieldName(),
															JoinType.INNER);
													lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
												} else if (Partner.class.getName()
														.equalsIgnoreCase(tableField.getType().getName())) {
													Join<T, Partner> p = root.join(appUIScreenFilterVO.getDbFieldName(),
															JoinType.INNER);
													lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
												} else if (Role.class.getName()
														.equalsIgnoreCase(tableField.getType().getName())) {
													Join<T, Role> p = root.join(appUIScreenFilterVO.getDbFieldName(),
															JoinType.INNER);
													lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
												} else if (Team.class.getName()
														.equalsIgnoreCase(tableField.getType().getName())) {
													Join<T, Team> p = root.join(appUIScreenFilterVO.getDbFieldName(),
															JoinType.INNER);
													lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
												} else if (User.class.getName()
														.equalsIgnoreCase(tableField.getType().getName())) {
													Join<T, User> p = root.join(appUIScreenFilterVO.getDbFieldName(),
															JoinType.INNER);
													lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
												} else if (UserProfile.class.getName()
														.equalsIgnoreCase(tableField.getType().getName())) {
													Join<T, UserProfile> p = root
															.join(appUIScreenFilterVO.getDbFieldName(), JoinType.INNER);
													lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
												} /*else if (CaseQueryResponse.class.getName()
														.equalsIgnoreCase(tableField.getType().getName())) {
													Join<T, UserProfile> p = root
															.join(appUIScreenFilterVO.getDbFieldName(), JoinType.INNER);
													lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
												} else if (ArchivalHistory.class.getName()
														.equalsIgnoreCase(tableField.getType().getName())) {
													Join<T, ArchivalHistory> p = root
															.join(appUIScreenFilterVO.getDbFieldName(), JoinType.INNER);
													lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
												} else if (CaseQueryFlag.class.getName()
														.equalsIgnoreCase(tableField.getType().getName())) {
													Join<T, CaseQueryFlag> p = root
															.join(appUIScreenFilterVO.getDbFieldName(), JoinType.INNER);
													lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
												} else if (CaseQueryResponseFiles.class.getName()
														.equalsIgnoreCase(tableField.getType().getName())) {
													Join<T, CaseQueryResponseFiles> p = root
															.join(appUIScreenFilterVO.getDbFieldName(), JoinType.INNER);
													lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
												} */else if (CaseContacts.class.getName()
														.equalsIgnoreCase(tableField.getType().getName())) {
													Join<T, CaseContacts> p = root
															.join(appUIScreenFilterVO.getDbFieldName(), JoinType.INNER);
													lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
												} else if (ProdFile.class.getName()
														.equalsIgnoreCase(tableField.getType().getName())) {
													Join<T, ProdFile> p = root
															.join(appUIScreenFilterVO.getDbFieldName(), JoinType.INNER);
													lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
												} /*else if (ProdAssigneeFlow.class.getName()
														.equalsIgnoreCase(tableField.getType().getName())) {
													Join<T, ProdAssigneeFlow> p = root
															.join(appUIScreenFilterVO.getDbFieldName(), JoinType.INNER);
													lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
												} else if (ProdHistory.class.getName()
														.equalsIgnoreCase(tableField.getType().getName())) {
													Join<T, ProdHistory> p = root
															.join(appUIScreenFilterVO.getDbFieldName(), JoinType.INNER);
													lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
												} */else if (Production.class.getName()
														.equalsIgnoreCase(tableField.getType().getName())) {
													Join<T, Production> p = root
															.join(appUIScreenFilterVO.getDbFieldName(), JoinType.INNER);
													lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
												} /*else if (PartnerEmails.class.getName()
														.equalsIgnoreCase(tableField.getType().getName())) {
													Join<T, PartnerEmails> p = root
															.join(appUIScreenFilterVO.getDbFieldName(), JoinType.INNER);
													lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
												}*/ else if (UserPartners.class.getName()
														.equalsIgnoreCase(tableField.getType().getName())) {
													Join<T, UserPartners> p = root
															.join(appUIScreenFilterVO.getDbFieldName(), JoinType.INNER);
													lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
												} else if (String.class.getName()
														.equalsIgnoreCase(tableField.getType().getName())
														&& llstFilterValue.size() == 1) {
													String likePattern = getLikePattern(llstFilterValue.get(0));
													lpreRestriction = cb.like(
															cb.lower(root.get(appUIScreenFilterVO.getDbFieldName())),
															likePattern);
												} else if (Character.class.getName()
														.equalsIgnoreCase(tableField.getType().getName())) {
													List<Character> llstFilterValueChar = llstFilterValue.stream()
															.filter(p -> null != p && StringUtils.isNotBlank(p))
															.map(p -> p.charAt(0)).collect(Collectors.toList());
													lpreRestriction = cb
															.and(root.get(appUIScreenFilterVO.getDbFieldName())
																	.in(llstFilterValueChar));
												} else {
													lpreRestriction = cb
															.and(root.get(appUIScreenFilterVO.getDbFieldName())
																	.in(llstFilterValue));
												}

												return lpreRestriction;
											}
										});
									}

								}

							} else {
								tableFieldList = fieldList.stream()
										.filter(p -> null != p.getName() && p.getName()
												.equalsIgnoreCase(appUIScreenFilterVO.getFilterDataType()))
										.collect(Collectors.toList());
								if (!tableFieldList.isEmpty()) {
									Field tableField = tableFieldList.get(0);

									Class<?> tableClassSub = Class.forName(tableField.getType().getName());

									List<Field> fieldListSub = new ArrayList<>();
									Class<?> fieldClassSub = tableClassSub;
									while (null != fieldClassSub) {
										fieldListSub.addAll(Arrays.asList(fieldClassSub.getDeclaredFields()));
										fieldClassSub = fieldClassSub.getSuperclass();
									}

									List<Field> tableFieldListSub = fieldListSub.stream()
											.filter(p -> null != p.getName() && p.getName()
													.equalsIgnoreCase(appUIScreenFilterVO.getDbFieldName()))
											.collect(Collectors.toList());
									if (!tableFieldListSub.isEmpty()) {
										Field tableFieldSub1 = tableFieldListSub.get(0);

										if (null != tableFieldSub1) {

											{
												lspec = lspec.and(new Specification<T>() {

													@Override
													public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query,
															CriteriaBuilder cb) {

														Join<T, ?> root1 = root.join(tableField.getName(),
																JoinType.LEFT);
														Predicate lpreRestriction = cb
																.and(root1.get(appUIScreenFilterVO.getDbFieldName())
																		.in(appUIScreenFilterVO.getValue()));

														if (Account.class.getName()
																.equalsIgnoreCase(tableField.getType().getName())) {
															Join<T, Account> p = root1.join(
																	appUIScreenFilterVO.getDbFieldName(),
																	JoinType.INNER);
															lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
														} else if (AppItem.class.getName()
																.equalsIgnoreCase(tableField.getType().getName())) {
															Join<T, AppItem> p = root1.join(
																	appUIScreenFilterVO.getDbFieldName(),
																	JoinType.INNER);
															lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
														} else if (AppList.class.getName()
																.equalsIgnoreCase(tableField.getType().getName())) {
															Join<T, AppList> p = root1.join(
																	appUIScreenFilterVO.getDbFieldName(),
																	JoinType.INNER);
															lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
														} else if (AppSubItem.class.getName()
																.equalsIgnoreCase(tableField.getType().getName())) {
															Join<T, AppSubItem> p = root1.join(
																	appUIScreenFilterVO.getDbFieldName(),
																	JoinType.INNER);
															lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
														} else if (Case.class.getName()
																.equalsIgnoreCase(tableField.getType().getName())) {
															Join<T, Case> p = root1.join(
																	appUIScreenFilterVO.getDbFieldName(),
																	JoinType.INNER);
															lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
														} else if (CaseFile.class.getName()
																.equalsIgnoreCase(tableField.getType().getName())) {
															Join<T, CaseFile> p = root1.join(
																	appUIScreenFilterVO.getDbFieldName(),
																	JoinType.INNER);
															lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
														}/* else if (CaseQuery.class.getName()
																.equalsIgnoreCase(tableField.getType().getName())) {
															Join<T, CaseQuery> p = root1.join(
																	appUIScreenFilterVO.getDbFieldName(),
																	JoinType.INNER);
															lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
														}*/ else if (CaseResultFile.class.getName()
																.equalsIgnoreCase(tableField.getType().getName())) {
															Join<T, CaseResultFile> p = root1.join(
																	appUIScreenFilterVO.getDbFieldName(),
																	JoinType.INNER);
															lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
														} else if (CaseServiceReq.class.getName()
																.equalsIgnoreCase(tableField.getType().getName())) {
															Join<T, CaseServiceReq> p = root1.join(
																	appUIScreenFilterVO.getDbFieldName(),
																	JoinType.INNER);
															lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
														} /*else if (CaseTask.class.getName()
																.equalsIgnoreCase(tableField.getType().getName())) {
															Join<T, CaseTask> p = root1.join(
																	appUIScreenFilterVO.getDbFieldName(),
																	JoinType.INNER);
															lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
														}*/ else if (Contact.class.getName()
																.equalsIgnoreCase(tableField.getType().getName())) {
															Join<T, Contact> p = root1.join(
																	appUIScreenFilterVO.getDbFieldName(),
																	JoinType.INNER);
															lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
														} else if (Division.class.getName()
																.equalsIgnoreCase(tableField.getType().getName())) {
															Join<T, Division> p = root1.join(
																	appUIScreenFilterVO.getDbFieldName(),
																	JoinType.INNER);
															lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
														} else if (Job.class.getName()
																.equalsIgnoreCase(tableField.getType().getName())) {
															Join<T, Job> p = root1.join(
																	appUIScreenFilterVO.getDbFieldName(),
																	JoinType.INNER);
															lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
														} else if (Partner.class.getName()
																.equalsIgnoreCase(tableField.getType().getName())) {
															Join<T, Partner> p = root1.join(
																	appUIScreenFilterVO.getDbFieldName(),
																	JoinType.INNER);
															lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
														} else if (Role.class.getName()
																.equalsIgnoreCase(tableField.getType().getName())) {
															Join<T, Role> p = root1.join(
																	appUIScreenFilterVO.getDbFieldName(),
																	JoinType.INNER);
															lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
														} else if (Team.class.getName()
																.equalsIgnoreCase(tableField.getType().getName())) {
															Join<T, Team> p = root1.join(
																	appUIScreenFilterVO.getDbFieldName(),
																	JoinType.INNER);
															lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
														} else if (User.class.getName()
																.equalsIgnoreCase(tableField.getType().getName())) {
															Join<T, User> p = root1.join(
																	appUIScreenFilterVO.getDbFieldName(),
																	JoinType.INNER);
															lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
														} else if (UserProfile.class.getName()
																.equalsIgnoreCase(tableField.getType().getName())) {
															Join<T, UserProfile> p = root1.join(
																	appUIScreenFilterVO.getDbFieldName(),
																	JoinType.INNER);
															lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
														} /*else if (CaseQueryResponse.class.getName()
																.equalsIgnoreCase(tableField.getType().getName())) {
															Join<T, UserProfile> p = root1.join(
																	appUIScreenFilterVO.getDbFieldName(),
																	JoinType.INNER);
															lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
														} else if (ArchivalHistory.class.getName()
																.equalsIgnoreCase(tableField.getType().getName())) {
															Join<T, ArchivalHistory> p = root1.join(
																	appUIScreenFilterVO.getDbFieldName(),
																	JoinType.INNER);
															lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
														} else if (CaseQueryFlag.class.getName()
																.equalsIgnoreCase(tableField.getType().getName())) {
															Join<T, CaseQueryFlag> p = root1.join(
																	appUIScreenFilterVO.getDbFieldName(),
																	JoinType.INNER);
															lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
														} else if (CaseQueryResponseFiles.class.getName()
																.equalsIgnoreCase(tableField.getType().getName())) {
															Join<T, CaseQueryResponseFiles> p = root1.join(
																	appUIScreenFilterVO.getDbFieldName(),
																	JoinType.INNER);
															lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
														} */else if (CaseContacts.class.getName()
																.equalsIgnoreCase(tableField.getType().getName())) {
															Join<T, CaseContacts> p = root1.join(
																	appUIScreenFilterVO.getDbFieldName(),
																	JoinType.INNER);
															lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
														} else if (ProdFile.class.getName()
																.equalsIgnoreCase(tableField.getType().getName())) {
															Join<T, ProdFile> p = root1.join(
																	appUIScreenFilterVO.getDbFieldName(),
																	JoinType.INNER);
															lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
														}/* else if (ProdAssigneeFlow.class.getName()
																.equalsIgnoreCase(tableField.getType().getName())) {
															Join<T, ProdAssigneeFlow> p = root1.join(
																	appUIScreenFilterVO.getDbFieldName(),
																	JoinType.INNER);
															lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
														} else if (ProdHistory.class.getName()
																.equalsIgnoreCase(tableField.getType().getName())) {
															Join<T, ProdHistory> p = root1.join(
																	appUIScreenFilterVO.getDbFieldName(),
																	JoinType.INNER);
															lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
														} */else if (Production.class.getName()
																.equalsIgnoreCase(tableField.getType().getName())) {
															Join<T, Production> p = root1.join(
																	appUIScreenFilterVO.getDbFieldName(),
																	JoinType.INNER);
															lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
														} /*else if (PartnerEmails.class.getName()
																.equalsIgnoreCase(tableField.getType().getName())) {
															Join<T, PartnerEmails> p = root1.join(
																	appUIScreenFilterVO.getDbFieldName(),
																	JoinType.INNER);
															lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
														} */else if (UserPartners.class.getName()
																.equalsIgnoreCase(tableField.getType().getName())) {
															Join<T, UserPartners> p = root1.join(
																	appUIScreenFilterVO.getDbFieldName(),
																	JoinType.INNER);
															lpreRestriction = cb.and(p.get("id").in(llstFilterValue));
														} else if (String.class.getName()
																.equalsIgnoreCase(tableField.getType().getName())
																&& llstFilterValue.size() == 1) {
															String likePattern = getLikePattern(llstFilterValue.get(0));
															lpreRestriction = cb.like(
																	cb.lower(root1
																			.get(appUIScreenFilterVO.getDbFieldName())),
																	likePattern);
														} else {
															lpreRestriction = cb
																	.and(root1.get(appUIScreenFilterVO.getDbFieldName())
																			.in(llstFilterValue));
														}

														return lpreRestriction;
													}
												});
											}

										}
									}

								} else {
									/*String LOCAL_STRING_QUERY_SEARCH = "search";
									if (CaseQuery.class.getName().equalsIgnoreCase(pstrClassName)
											&& LOCAL_STRING_QUERY_SEARCH
													.equalsIgnoreCase(appUIScreenFilterVO.getDbFieldName())) {

										Specifications<T> lspecSearch = Specifications.where(new Specification<T>() {

											@Override
											public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query,
													CriteriaBuilder cb) {

												String likePattern = getLikePattern(llstFilterValue.get(0));
												Predicate lpreRestriction = cb.like(cb.lower(root.get("querySubject")),
														likePattern);

												return lpreRestriction;
											}
										});

										lspecSearch = lspecSearch.or(new Specification<T>() {

											@Override
											public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query,
													CriteriaBuilder cb) {

												String likePattern = getLikePattern(llstFilterValue.get(0));
												Predicate lpreRestriction = cb.like(cb.lower(root.get("status")),
														likePattern);

												return lpreRestriction;
											}
										});

										lspecSearch = lspecSearch.or(new Specification<T>() {

											@Override
											public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query,
													CriteriaBuilder cb) {

												String likePattern = getLikePattern(llstFilterValue.get(0));
												Predicate lpreRestriction = cb.like(cb.lower(root.get("query_type")),
														likePattern);

												return lpreRestriction;
											}
										});

										lspecSearch = lspecSearch.or(new Specification<T>() {

											@Override
											public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query,
													CriteriaBuilder cb) {

												String likePattern = getLikePattern(llstFilterValue.get(0));
												Predicate lpreRestriction = cb.like(cb.lower(root.get("querySubtype")),
														likePattern);

												return lpreRestriction;
											}
										});

										lspecSearch = lspecSearch.or(new Specification<T>() {

											@Override
											public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query,
													CriteriaBuilder cb) {

												String likePattern = getLikePattern(llstFilterValue.get(0));
												Predicate lpreRestriction = cb
														.like(cb.lower(root.get("queryPartnerBean")), likePattern);

												return lpreRestriction;
											}
										});

										lspecSearch = lspecSearch.or(new Specification<T>() {

											@Override
											public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query,
													CriteriaBuilder cb) {

												String likePattern = getLikePattern(llstFilterValue.get(0));

												Join<T, Account> p = root.join("account", JoinType.INNER);
												Predicate lpreRestriction = cb.like(cb.lower(p.get("name")),
														likePattern);

												return lpreRestriction;
											}
										});

										lspecSearch = lspecSearch.or(new Specification<T>() {

											@Override
											public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query,
													CriteriaBuilder cb) {

												String likePattern = getLikePattern(llstFilterValue.get(0));

												Join<T, Case> p = root.join("clientCase", JoinType.INNER);
												Predicate lpreRestriction = cb.like(cb.lower(p.get("name")),
														likePattern);

												return lpreRestriction;
											}
										});

										lspecSearch = lspecSearch.or(new Specification<T>() {

											@Override
											public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query,
													CriteriaBuilder cb) {

												String likePattern = getLikePattern(llstFilterValue.get(0));

												Join<T, User> p = root.join("client", JoinType.INNER);
												Predicate lpreRestriction = cb.like(
														cb.lower(p.get("userProfile").get("firstName")), likePattern);

												return lpreRestriction;
											}
										});

										lspecSearch = lspecSearch.or(new Specification<T>() {

											@Override
											public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query,
													CriteriaBuilder cb) {

												String likePattern = getLikePattern(llstFilterValue.get(0));

												Join<T, User> p = root.join("client", JoinType.INNER);
												Predicate lpreRestriction = cb.like(
														cb.lower(p.get("userProfile").get("lastName")), likePattern);

												return lpreRestriction;
											}
										});

										lspecSearch = lspecSearch.or(new Specification<T>() {

											@Override
											public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query,
													CriteriaBuilder cb) {

												String likePattern = getLikePattern(llstFilterValue.get(0));

												Join<T, User> p = root.join("assignedTo", JoinType.INNER);
												Predicate lpreRestriction = cb.like(
														cb.lower(p.get("userProfile").get("firstName")), likePattern);

												return lpreRestriction;
											}
										});

										lspecSearch = lspecSearch.or(new Specification<T>() {

											@Override
											public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query,
													CriteriaBuilder cb) {

												String likePattern = getLikePattern(llstFilterValue.get(0));

												Join<T, User> p = root.join("assignedTo", JoinType.INNER);
												Predicate lpreRestriction = cb.like(
														cb.lower(p.get("userProfile").get("lastName")), likePattern);

												return lpreRestriction;
											}
										});
									}*/
								}
							}
						}

					}
				}

			}

		} catch (Exception e) {
			LOGGER.info(CLASS_NAME, METHOD_NAME, e.getMessage());
		}
		psSpec = lspec;
		return psSpec;
	}

}
