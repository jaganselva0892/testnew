package com.trivent.common;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.Selection;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.poi.hssf.record.formula.functions.T;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;

import com.trivent.constants.AppConstants;
import com.trivent.dto.AppUIScreenFieldVO;
import com.trivent.dto.ScreenListFilterVO;
import com.trivent.logging.LogManager;
import com.trivent.logging.Logger;
import com.trivent.models.Account;
import com.trivent.models.AppItem;
import com.trivent.models.AppList;
import com.trivent.models.AppSubItem;
import com.trivent.models.Case;
import com.trivent.models.CaseContacts;
import com.trivent.models.CaseFile;
import com.trivent.models.CaseResultFile;
import com.trivent.models.CaseServiceReq;
import com.trivent.models.Contact;
import com.trivent.models.Division;
import com.trivent.models.Job;
import com.trivent.models.Partner;
import com.trivent.models.ProdFile;
import com.trivent.models.Production;
import com.trivent.models.Role;
import com.trivent.models.Team;
import com.trivent.models.User;
import com.trivent.models.UserPartners;
import com.trivent.models.UserProfile;

/**
 * @FileName : QueryAPIController.java
 * @ClassName : QueryAPIController
 * @DateAndTime : Sep 3, 2018 - 3:12:12 PM
 * 
 * @Author : Boopathi
 * 
 * @Description : Function are used to get ScreenFilter list data and row list
 *              data as convert to Json data.
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
public class FilterCommonUtils {

	private static final Logger LOGGER = LogManager.getLogger();

	private static final String CLASS_NAME = FilterCommonUtils.class.getName();

	/**
	 * @DateAndTime : sep 3, 2018 - 3:12:12 PM
	 * 
	 * @Author : Karthi
	 * 
	 * @Description : Method to constructPageSpecification for particular column
	 *              values
	 * 
	 * @param screenListFilterVO
	 * @return Pageable
	 */
	public static Pageable constructPageSpecification(ScreenListFilterVO screenListFilterVO) {

		if (null == screenListFilterVO || 0 > screenListFilterVO.getPageNo()) {
			return null;
		} else {

			Direction sortDirection = null;

			if (AppConstants.SORT_PREF_ASC.equalsIgnoreCase(screenListFilterVO.getSortOrder())) {
				sortDirection = Sort.Direction.ASC;
			} else {
				sortDirection = Sort.Direction.DESC;
			}
			Sort sortOption = new Sort(sortDirection, sortedByColumn(screenListFilterVO));

			int pageNo = screenListFilterVO.getPageNo() - 1;
			return new PageRequest(pageNo, screenListFilterVO.getRecordsPerPage(), sortOption);
		}
	}

	/**
	 * @DateAndTime : sep 3, 2018 - 3:12:12 PM
	 * 
	 * @Author : Karthi
	 * 
	 * @Description : Method to sortedByColumn by screenListFilterVO values
	 * 
	 * 
	 * @param screenListFilterVO
	 *            as ScreenListFilterVO Pojo class
	 * @return
	 */
	public static String sortedByColumn(ScreenListFilterVO screenListFilterVO) {

		String METHOD_NAME = "sortedByColumn";

		String sortedColumn = null;
		Class<?> propertyClass = null;

		try {
			if (screenListFilterVO.getObj() != null) {
				propertyClass = PropertyUtils.getPropertyType(screenListFilterVO.getObj(),
						screenListFilterVO.getSortByField());
			} else {
				sortedColumn = screenListFilterVO.getSortByField();
			}
		} catch (IllegalAccessException e) {
			sortedColumn = screenListFilterVO.getSortByField();
			LOGGER.info(CLASS_NAME, METHOD_NAME, e.getMessage());
		} catch (InvocationTargetException e) {
			sortedColumn = screenListFilterVO.getSortByField();
			LOGGER.info(CLASS_NAME, METHOD_NAME, e.getMessage());
		} catch (NoSuchMethodException e) {
			sortedColumn = screenListFilterVO.getSortByField();
			LOGGER.info(CLASS_NAME, METHOD_NAME, e.getMessage());
		}

		try {
			if (propertyClass != null) {
				if (propertyClass.equals(User.class)) {
					sortedColumn = screenListFilterVO.getSortByField() + ".UserProfile.firstName";
				} else if (propertyClass.equals(Partner.class)) {
					sortedColumn = screenListFilterVO.getSortByField() + ".name";
				} else if (propertyClass.equals(Account.class)) {
					sortedColumn = screenListFilterVO.getSortByField() + ".name";
				} else if (propertyClass.equals(UserProfile.class)) {
					sortedColumn = screenListFilterVO.getSortByField() + ".customerCode";
				} else {
					sortedColumn = screenListFilterVO.getSortByField();
				}
			} else {
				sortedColumn = screenListFilterVO.getSortByField();
			}

		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, METHOD_NAME, e);
		}

		return sortedColumn;
	}

	/**
	 * @DateAndTime : sep 3, 2018 - 3:12:12 PM
	 * 
	 * @Author : Karthi
	 * 
	 * @Description : Method to getListColumns for particular column values
	 * 
	 * @param screenListFilterVO
	 *            as screenListFilterVO POJO class
	 * @param root
	 * @return List<Selection<?>>
	 */
	public static List<Selection<?>> getListColumns(ScreenListFilterVO screenListFilterVO, Root<?> root,
			CriteriaBuilder builder) {

		String METHOD_NAME = "getListColumns";
		String SCREEN_NAME = "CaseQuery";
		String SCREEN_NAME_PROD_FILE = "ProdFile";

		List<Selection<?>> lselRoot = new ArrayList<Selection<?>>();

		try {

			Class<?> tableClass = Class.forName(root.getJavaType().getName());

			List<Field> fieldList = new ArrayList<>();
			Class<?> fieldClass = tableClass;
			while (null != fieldClass) {
				fieldList.addAll(Arrays.asList(fieldClass.getDeclaredFields()));
				fieldClass = fieldClass.getSuperclass();
			}

			if (null != screenListFilterVO) {
				List<AppUIScreenFieldVO> appUIScreenFieldVOList = screenListFilterVO.getAppUIScreenFieldVOs();
				if (appUIScreenFieldVOList.isEmpty()) {
					lselRoot.add(root);
				} else {
					lselRoot.add(root.get("id"));
					if (SCREEN_NAME.equalsIgnoreCase(screenListFilterVO.getAppDBTableVO().getName())) {
						Join<T, Case> pCase = root.join("clientCase", JoinType.LEFT);
						lselRoot.add(pCase.get("id"));
					} else if (SCREEN_NAME_PROD_FILE.equalsIgnoreCase(screenListFilterVO.getAppDBTableVO().getName())) {
						Join<T, Production> pProduction = root.join("productionId", JoinType.LEFT);
						lselRoot.add(pProduction.get("id"));
						lselRoot.add(root.get("fileDescription"));
						lselRoot.add(root.get("fileLocation"));
						lselRoot.add(root.get("fileName"));
						lselRoot.add(root.get("isDeliverable"));
						lselRoot.add(root.get("isDelivered"));
						lselRoot.add(root.get("fileContentType"));
						lselRoot.add(root.get("fileExtension"));
					}

					for (AppUIScreenFieldVO appUIScreenFieldVO : appUIScreenFieldVOList) {
						Selection<?> rootVal = root.get("id");

						List<Field> tableFieldList = fieldList.stream()
								.filter(p -> null != p.getName()
										&& p.getName().equalsIgnoreCase(appUIScreenFieldVO.getDbFieldName()))
								.collect(Collectors.toList());
						if (!tableFieldList.isEmpty()) {
							Field tableField = tableFieldList.get(0);
							if (null != tableField) {

								if (Account.class.getName().equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, Account> p = root.join(appUIScreenFieldVO.getDbFieldName(), JoinType.LEFT);
									rootVal = p.get("name");
								} else if (AppItem.class.getName().equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, AppItem> p = root.join(appUIScreenFieldVO.getDbFieldName(), JoinType.LEFT);
									rootVal = p.get("longName");
								} else if (AppList.class.getName().equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, AppList> p = root.join(appUIScreenFieldVO.getDbFieldName(), JoinType.LEFT);
									rootVal = p.get("name");
								} else if (AppSubItem.class.getName()
										.equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, AppSubItem> p = root.join(appUIScreenFieldVO.getDbFieldName(),
											JoinType.LEFT);
									rootVal = p.get("longName");
								} else if (Case.class.getName().equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, Case> p = root.join(appUIScreenFieldVO.getDbFieldName(), JoinType.LEFT);
									rootVal = p.get("name");
								} else if (CaseFile.class.getName().equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, CaseFile> p = root.join(appUIScreenFieldVO.getDbFieldName(), JoinType.LEFT);
									rootVal = p.get("name");
								}/* else if (CaseQuery.class.getName().equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, CaseQuery> p = root.join(appUIScreenFieldVO.getDbFieldName(),
											JoinType.LEFT);
									rootVal = p.get("querySubject");
								}*/ else if (CaseResultFile.class.getName()
										.equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, CaseResultFile> p = root.join(appUIScreenFieldVO.getDbFieldName(),
											JoinType.LEFT);
									rootVal = p.get("name");
								} else if (CaseServiceReq.class.getName()
										.equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, CaseServiceReq> p = root.join(appUIScreenFieldVO.getDbFieldName(),
											JoinType.LEFT);
									rootVal = p.get("serviceName");
								} /*else if (CaseTask.class.getName().equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, CaseTask> p = root.join(appUIScreenFieldVO.getDbFieldName(), JoinType.LEFT);
									rootVal = p.get("name");
								} */else if (Contact.class.getName().equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, Contact> p = root.join(appUIScreenFieldVO.getDbFieldName(), JoinType.LEFT);
									rootVal = builder.concat(p.get("firstName"),
											builder.concat(" ", p.get("lastName")));
								} else if (Division.class.getName().equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, Division> p = root.join(appUIScreenFieldVO.getDbFieldName(), JoinType.LEFT);
									rootVal = p.get("name");
								} else if (Job.class.getName().equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, Job> p = root.join(appUIScreenFieldVO.getDbFieldName(), JoinType.LEFT);
									rootVal = p.get("name");
								} else if (Partner.class.getName().equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, Partner> p = root.join(appUIScreenFieldVO.getDbFieldName(), JoinType.LEFT);
									rootVal = p.get("name");
								} else if (Role.class.getName().equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, Role> p = root.join(appUIScreenFieldVO.getDbFieldName(), JoinType.LEFT);
									rootVal = p.get("name");
								} else if (Team.class.getName().equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, Team> p = root.join(appUIScreenFieldVO.getDbFieldName(), JoinType.LEFT);
									rootVal = p.get("name");
								} else if (User.class.getName().equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, User> p = root.join(appUIScreenFieldVO.getDbFieldName(), JoinType.LEFT);
									Join<T, User> p1 = p.join("userProfile", JoinType.LEFT);
									rootVal = builder.concat(p1.get("firstName"),
											builder.concat(" ", p1.get("lastName")));
								} else if (UserProfile.class.getName()
										.equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, UserProfile> p = root.join(appUIScreenFieldVO.getDbFieldName(),
											JoinType.LEFT);
									rootVal = builder.concat(p.get("firstName"),
											builder.concat(" ", p.get("lastName")));
								} /*else if (CaseQueryResponse.class.getName()
										.equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, UserProfile> p = root.join(appUIScreenFieldVO.getDbFieldName(),
											JoinType.LEFT);
									rootVal = p.get("caseQuery").get("querySubject");
								} *//*else if (ArchivalHistory.class.getName()
										.equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, ArchivalHistory> p = root.join(appUIScreenFieldVO.getDbFieldName(),
											JoinType.LEFT);
									rootVal = p.get("fileName");
								} else if (CaseQueryFlag.class.getName()
										.equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, CaseQueryFlag> p = root.join(appUIScreenFieldVO.getDbFieldName(),
											JoinType.LEFT);
									rootVal = p.get("caseQueryFlagType");
								} else if (CaseQueryResponseFiles.class.getName()
										.equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, CaseQueryResponseFiles> p = root.join(appUIScreenFieldVO.getDbFieldName(),
											JoinType.LEFT);
									rootVal = p.get("fileName");
								} */else if (CaseContacts.class.getName()
										.equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, CaseContacts> p = root.join(appUIScreenFieldVO.getDbFieldName(),
											JoinType.LEFT);
									rootVal = p.get("name");
								} else if (ProdFile.class.getName().equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, ProdFile> p = root.join(appUIScreenFieldVO.getDbFieldName(), JoinType.LEFT);
									rootVal = p.get("fileName");
								} /*else if (ProdAssigneeFlow.class.getName()
										.equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, ProdAssigneeFlow> p = root.join(appUIScreenFieldVO.getDbFieldName(),
											JoinType.LEFT);
									Join<T, User> p1 = p.join("assignedBy", JoinType.LEFT);
									Join<T, User> p2 = p1.join("userProfile", JoinType.LEFT);
									rootVal = builder.concat(p2.get("firstName"),
											builder.concat(" ", p2.get("lastName")));
								} else if (ProdHistory.class.getName()
										.equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, ProdHistory> p = root.join(appUIScreenFieldVO.getDbFieldName(),
											JoinType.LEFT);
									rootVal = p.get("productionId").get("id");
								} else if (Production.class.getName()
										.equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, Production> p = root.join(appUIScreenFieldVO.getDbFieldName(),
											JoinType.LEFT);
									rootVal = p.get("caseId");
								} else if (PartnerEmails.class.getName()
										.equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, PartnerEmails> p = root.join(appUIScreenFieldVO.getDbFieldName(),
											JoinType.LEFT);
									rootVal = p.get("lsPartnersubject");
								} */else if (UserPartners.class.getName()
										.equalsIgnoreCase(tableField.getType().getName())) {
									Join<T, UserPartners> p = root.join(appUIScreenFieldVO.getDbFieldName(),
											JoinType.LEFT);
									Join<T, User> p1 = p.join("user", JoinType.LEFT);
									Join<T, User> p2 = p1.join("userProfile", JoinType.LEFT);
									rootVal = builder.concat(p2.get("firstName"),
											builder.concat(" ", p2.get("lastName")));
								} else {
									if (appUIScreenFieldVO.getDbFieldName().toLowerCase().indexOf("size") != -1) {
										rootVal = builder.concat(root.get(appUIScreenFieldVO.getDbFieldName()),
												" Byte(s)");
									} else if(appUIScreenFieldVO.getDbFieldName().equalsIgnoreCase("isDeliverable")){
										rootVal = builder.concat(root.get(appUIScreenFieldVO.getDbFieldName()),
												 AppConstants.SPACE_SEPARATOR + "chkboxTik");
									}else {
										rootVal = root.get(appUIScreenFieldVO.getDbFieldName());
									}
								}
								lselRoot.add(rootVal);
							}
						} else {
							tableFieldList = fieldList.stream()
									.filter(p -> null != p.getName()
											&& p.getName().equalsIgnoreCase(appUIScreenFieldVO.getAttributeDataType()))
									.collect(Collectors.toList());
							if (!tableFieldList.isEmpty()) {
								Field tableField = tableFieldList.get(0);

								Class<?> tableClassSub = Class.forName(tableField.getType().getName());

								List<Field> fieldListSub = new ArrayList<>();
								Class<?> fieldClassSub = tableClassSub;
								while (null != fieldClassSub) {
									fieldListSub.addAll(Arrays.asList(fieldClassSub.getDeclaredFields()));
									fieldClassSub = fieldClassSub.getSuperclass();
								}

								List<Field> tableFieldListSub = fieldListSub.stream()
										.filter(p -> null != p.getName()
												&& p.getName().equalsIgnoreCase(appUIScreenFieldVO.getDbFieldName()))
										.collect(Collectors.toList());
								if (!tableFieldListSub.isEmpty()) {
									Field tableFieldSub1 = tableFieldListSub.get(0);
									Join<T, ?> root1 = root.join(tableField.getName(), JoinType.LEFT);

									if (null != tableFieldSub1) {

										if (Account.class.getName()
												.equalsIgnoreCase(tableFieldSub1.getType().getName())) {
											Join<T, Account> p = root1.join(appUIScreenFieldVO.getDbFieldName(),
													JoinType.LEFT);
											rootVal = p.get("name");
										} else if (AppItem.class.getName()
												.equalsIgnoreCase(tableFieldSub1.getType().getName())) {
											Join<T, AppItem> p = root1.join(appUIScreenFieldVO.getDbFieldName(),
													JoinType.LEFT);
											rootVal = p.get("longName");
										} else if (AppList.class.getName()
												.equalsIgnoreCase(tableFieldSub1.getType().getName())) {
											Join<T, AppList> p = root1.join(appUIScreenFieldVO.getDbFieldName(),
													JoinType.LEFT);
											rootVal = p.get("name");
										} else if (AppSubItem.class.getName()
												.equalsIgnoreCase(tableFieldSub1.getType().getName())) {
											Join<T, AppSubItem> p = root1.join(appUIScreenFieldVO.getDbFieldName(),
													JoinType.LEFT);
											rootVal = p.get("longName");
										} else if (Case.class.getName()
												.equalsIgnoreCase(tableFieldSub1.getType().getName())) {
											Join<T, Case> p = root1.join(appUIScreenFieldVO.getDbFieldName(),
													JoinType.LEFT);
											rootVal = p.get("name");
										} else if (CaseFile.class.getName()
												.equalsIgnoreCase(tableFieldSub1.getType().getName())) {
											Join<T, CaseFile> p = root1.join(appUIScreenFieldVO.getDbFieldName(),
													JoinType.LEFT);
											rootVal = p.get("name");
										}/* else if (CaseQuery.class.getName()
												.equalsIgnoreCase(tableFieldSub1.getType().getName())) {
											Join<T, CaseQuery> p = root1.join(appUIScreenFieldVO.getDbFieldName(),
													JoinType.LEFT);
											rootVal = p.get("querySubject");
										}*/ else if (CaseResultFile.class.getName()
												.equalsIgnoreCase(tableFieldSub1.getType().getName())) {
											Join<T, CaseResultFile> p = root1.join(appUIScreenFieldVO.getDbFieldName(),
													JoinType.LEFT);
											rootVal = p.get("name");
										} else if (CaseServiceReq.class.getName()
												.equalsIgnoreCase(tableFieldSub1.getType().getName())) {
											Join<T, CaseServiceReq> p = root1.join(appUIScreenFieldVO.getDbFieldName(),
													JoinType.LEFT);
											rootVal = p.get("serviceName");
										} /*else if (CaseTask.class.getName()
												.equalsIgnoreCase(tableFieldSub1.getType().getName())) {
											Join<T, CaseTask> p = root1.join(appUIScreenFieldVO.getDbFieldName(),
													JoinType.LEFT);
											rootVal = p.get("name");
										}*/ else if (Contact.class.getName()
												.equalsIgnoreCase(tableFieldSub1.getType().getName())) {
											Join<T, Contact> p = root1.join(appUIScreenFieldVO.getDbFieldName(),
													JoinType.LEFT);
											rootVal = builder.concat(p.get("firstName"),
													builder.concat(" ", p.get("lastName")));
										} else if (Division.class.getName()
												.equalsIgnoreCase(tableFieldSub1.getType().getName())) {
											Join<T, Division> p = root1.join(appUIScreenFieldVO.getDbFieldName(),
													JoinType.LEFT);
											rootVal = p.get("name");
										} else if (Job.class.getName()
												.equalsIgnoreCase(tableFieldSub1.getType().getName())) {
											Join<T, Job> p = root1.join(appUIScreenFieldVO.getDbFieldName(),
													JoinType.LEFT);
											rootVal = p.get("name");
										} else if (Partner.class.getName()
												.equalsIgnoreCase(tableFieldSub1.getType().getName())) {
											Join<T, Partner> p = root1.join(appUIScreenFieldVO.getDbFieldName(),
													JoinType.LEFT);
											rootVal = p.get("name");
										} else if (Role.class.getName()
												.equalsIgnoreCase(tableFieldSub1.getType().getName())) {
											Join<T, Role> p = root1.join(appUIScreenFieldVO.getDbFieldName(),
													JoinType.LEFT);
											rootVal = p.get("name");
										} else if (Team.class.getName()
												.equalsIgnoreCase(tableFieldSub1.getType().getName())) {
											Join<T, Team> p = root1.join(appUIScreenFieldVO.getDbFieldName(),
													JoinType.LEFT);
											rootVal = p.get("name");
										} else if (User.class.getName()
												.equalsIgnoreCase(tableFieldSub1.getType().getName())) {
											Join<T, User> p = root1.join(appUIScreenFieldVO.getDbFieldName(),
													JoinType.LEFT);
											Join<T, User> p1 = p.join("userProfile", JoinType.LEFT);
											rootVal = builder.concat(p1.get("firstName"),
													builder.concat(" ", p1.get("lastName")));
										} else if (UserProfile.class.getName()
												.equalsIgnoreCase(tableFieldSub1.getType().getName())) {
											Join<T, UserProfile> p = root1.join(appUIScreenFieldVO.getDbFieldName(),
													JoinType.LEFT);
											rootVal = builder.concat(p.get("firstName"),
													builder.concat(" ", p.get("lastName")));
										} /*else if (CaseQueryResponse.class.getName()
												.equalsIgnoreCase(tableFieldSub1.getType().getName())) {
											Join<T, UserProfile> p = root1.join(appUIScreenFieldVO.getDbFieldName(),
													JoinType.LEFT);
											rootVal = p.get("caseQuery").get("querySubject");
										} else if (ArchivalHistory.class.getName()
												.equalsIgnoreCase(tableFieldSub1.getType().getName())) {
											Join<T, ArchivalHistory> p = root1.join(appUIScreenFieldVO.getDbFieldName(),
													JoinType.LEFT);
											rootVal = p.get("fileName");
										} else if (CaseQueryFlag.class.getName()
												.equalsIgnoreCase(tableFieldSub1.getType().getName())) {
											Join<T, CaseQueryFlag> p = root1.join(appUIScreenFieldVO.getDbFieldName(),
													JoinType.LEFT);
											rootVal = p.get("caseQueryFlagType");
										} else if (CaseQueryResponseFiles.class.getName()
												.equalsIgnoreCase(tableFieldSub1.getType().getName())) {
											Join<T, CaseQueryResponseFiles> p = root1
													.join(appUIScreenFieldVO.getDbFieldName(), JoinType.LEFT);
											rootVal = p.get("fileName");
										}*/ else if (CaseContacts.class.getName()
												.equalsIgnoreCase(tableFieldSub1.getType().getName())) {
											Join<T, CaseContacts> p = root1.join(appUIScreenFieldVO.getDbFieldName(),
													JoinType.LEFT);
											rootVal = p.get("name");
										} else if (ProdFile.class.getName()
												.equalsIgnoreCase(tableFieldSub1.getType().getName())) {
											Join<T, ProdFile> p = root1.join(appUIScreenFieldVO.getDbFieldName(),
													JoinType.LEFT);
											rootVal = p.get("fileName");
										} /*else if (ProdAssigneeFlow.class.getName()
												.equalsIgnoreCase(tableFieldSub1.getType().getName())) {
											Join<T, ProdAssigneeFlow> p = root1
													.join(appUIScreenFieldVO.getDbFieldName(), JoinType.LEFT);
											Join<T, User> p1 = p.join("assignedBy", JoinType.LEFT);
											Join<T, User> p2 = p1.join("userProfile", JoinType.LEFT);
											rootVal = builder.concat(p2.get("firstName"),
													builder.concat(" ", p2.get("lastName")));
										} else if (ProdHistory.class.getName()
												.equalsIgnoreCase(tableFieldSub1.getType().getName())) {
											Join<T, ProdHistory> p = root1.join(appUIScreenFieldVO.getDbFieldName(),
													JoinType.LEFT);
											rootVal = p.get("productionId").get("id");
										} */else if (Production.class.getName()
												.equalsIgnoreCase(tableFieldSub1.getType().getName())) {
											Join<T, Production> p = root1.join(appUIScreenFieldVO.getDbFieldName(),
													JoinType.LEFT);
											rootVal = p.get("caseId");
										}/* else if (PartnerEmails.class.getName()
												.equalsIgnoreCase(tableFieldSub1.getType().getName())) {
											Join<T, PartnerEmails> p = root1.join(appUIScreenFieldVO.getDbFieldName(),
													JoinType.LEFT);
											rootVal = p.get("lsPartnersubject");
										} */else if (UserPartners.class.getName()
												.equalsIgnoreCase(tableFieldSub1.getType().getName())) {
											Join<T, UserPartners> p = root1.join(appUIScreenFieldVO.getDbFieldName(),
													JoinType.LEFT);
											Join<T, User> p1 = p.join("user", JoinType.LEFT);
											Join<T, User> p2 = p1.join("userProfile", JoinType.LEFT);
											rootVal = builder.concat(p2.get("firstName"),
													builder.concat(" ", p2.get("lastName")));
										} else {
											if (appUIScreenFieldVO.getDbFieldName().toLowerCase()
													.indexOf("size") != -1) {
												rootVal = builder.concat(root.get(appUIScreenFieldVO.getDbFieldName()),
														" Byte(s)");
											} else {
												rootVal = root.get(appUIScreenFieldVO.getDbFieldName());
											}
										}
										lselRoot.add(rootVal);
									}
								}

							}
						}

					}
				}
			} else {
				lselRoot.add(root);
			}

		} catch (Exception e) {
			lselRoot = new ArrayList<Selection<?>>();
			lselRoot.add(root);
			LOGGER.info(CLASS_NAME, METHOD_NAME, e.getMessage());
		}

		return lselRoot;
	}
}
