package com.trivent.service;

import java.lang.reflect.InvocationTargetException;
import java.util.List;

import org.springframework.stereotype.Service;

import com.trivent.dto.RowVO;
import com.trivent.dto.ScreenListFilterVO;
import com.trivent.models.CaseFile;
import com.trivent.models.CaseResultFile;
import com.trivent.models.ProdFile;
import com.trivent.exceptions.*;

/**
 * @FileName : CaseFileService.java
 * @ClassName : CaseFileService
 * @DateAndTime : Feb 2, 2018 - 10:36:30 AM
 * 
 * @Author : Ramya
 * 
 * @Description : The name,parameter and exceptions of the method caseFile are
 *              described and used to
 *              add,delete,download,merge,get,list,save,update caseFiles and
 *              caseResultFiles.
 * @Tags :
 * @Git_Config : name email
 * 
 */
@Service
public interface CaseFileService {
	
	CaseFile getCaseFileData(Long caseFileId);
	
	CaseResultFile getCaseResultFileData(Long caseFileId);
	
	ProdFile getProdFileData(Long prodFileId);

	List<RowVO> listCaseFilesByCaseId(Long caseId, ScreenListFilterVO screenListFilterVO, String psType)
			throws TriventException, IllegalAccessException, InvocationTargetException;

	ScreenListFilterVO getDefaultScreenListFilterVO() throws TriventException;

}
