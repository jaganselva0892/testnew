package com.trivent.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.trivent.models.User;
import com.trivent.models.UserPartners;

/**
 * @FileName 	:
 *				UserPartnersService.java
 * @ClassName 	:
 * 				UserPartnersService
 * @DateAndTime :
 *				Feb 2, 2018 - 2:55:36 PM
 * 
 * @Author 		:
 * 				Karthi
 * 
 * @Description : 
 * 				The name,parameter of the method userPartners are described and used to get,save userPartner.
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Service
public interface UserPartnersService {


	List<UserPartners> getByUser(User user);

	
}
