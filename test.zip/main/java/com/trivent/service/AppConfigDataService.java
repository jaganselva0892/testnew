package com.trivent.service;

import java.util.List;

import com.trivent.dto.AppConfigDataVO;

/**
 * @FileName 	:
 *				AppConfigDataService.java
 * @ClassName 	:
 * 				AppConfigDataService
 * @DateAndTime :
 *				Nov 21, 2018 - 5:07:08 PM
 * 
 * @Author 		:
 * 				Karthi
 * 
 * @Description : 
 * 				The name,parameter of the method  appConfigData are described and used to list appConfigData and save appConfigData. 
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public interface AppConfigDataService {


	List<AppConfigDataVO> getAppConfigDataVOList(List<String> strNames);

	

}
