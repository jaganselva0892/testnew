package com.trivent.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.trivent.dto.RowVO;
import com.trivent.dto.ScreenListFilterVO;
import com.trivent.exceptions.TriventException;
import com.trivent.models.Production;

/**
 * @FileName : ProductionService.java
 * @ClassName : ProductionService
 * @DateAndTime : Nov 21, 2018 - 2:41:24 PM
 * 
 * @Author : Karthi
 * 
 * @Description : The name,parameter and exceptions of the method production are
 *              described and used to
 *              list,delete,get,save,filter,update,email,download production.
 * @Tags :
 * @Git_Config : name email
 * 
 */
@Service
public interface ProductionService {

	boolean caseAssignedbyCS(Long userId, Long caseId);

	ScreenListFilterVO getDefaultScreenListFilterVO() throws TriventException;

	List<RowVO> listProductionFilesByCaseId(Long caseId, ScreenListFilterVO screenListFilterVO, String psType) throws TriventException;

	Production getProductionByCase(Long caseID);

	
}