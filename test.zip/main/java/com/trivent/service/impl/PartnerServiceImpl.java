package com.trivent.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.domain.Specifications;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.trivent.constants.AppConstants;
import com.trivent.logging.LogManager;
import com.trivent.logging.Logger;
import com.trivent.models.Partner;
import com.trivent.repository.PartnerRepository;
import com.trivent.repository.specifications.GenericSpecifications;
import com.trivent.service.PartnerService;

/**
 * @FileName 	:
 *				PartnerServiceImpl.java
 * @ClassName 	:
 * 				PartnerServiceImpl
 * @DateAndTime :
 *				Feb 6, 2018 - 2:28:09 PM
 * 
 * @Author 		:
 * 				Ramya
 * 
 * @Description : 
 * 				Its to get partner list,delete,save,get new,get current session of partners.
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Service
public class PartnerServiceImpl implements PartnerService {

	
	private static final Logger LOGGER = LogManager.getLogger();
	
	private static final String CLASS_NAME = PartnerServiceImpl.class.getName();

	
	@Autowired
	private PartnerRepository partnerRepository;
	
	@Autowired
	private GenericSpecifications<Partner> partnerGSpecifications;


	/*(non-Javadoc)[Overriding Method]
	 * @OverridingMethod 	: @see com.trivent.service.PartnerService#getCurrentSessionPartner()
	 * 				
	 * @DateAndTime 		: Nov 21, 2018 - 2:28:09 PM
	 * 
	 * @Author 				: Karthi
	 * 
	 * @Description 		: To get the current session partner
	 * 				
	 * @Tags 				: 
	 *						@return Partner - partner
	 * @Git_Config 			: 
	 *		 				name
	 * 						email
	 * 
	 */
	@Override
	@Transactional
	public Partner getCurrentSessionPartner() {
		try
		{
			//String strPartnerCode = "x_ctn_partner";
			String strPartnerCode = "TZ";
			
			Partner partner = this.partnerRepository.findByPartnerCode(strPartnerCode.toUpperCase());
			return partner;
		}
		catch (Exception e) {
			LOGGER.error(CLASS_NAME, "getCurrentSessionPartner", e);
			return null;
		}
	}
	
	/*(non-Javadoc)[Overriding Method]
	 * @OverridingMethod 	: @see com.trivent.service.PartnerService#getPartnerListByPartnerCode(java.util.List)
	 * 				
	 * @DateAndTime 		: Feb 6, 2018 - 2:28:09 PM
	 * 
	 * @Author 				: Ramya
	 * 
	 * @Description 		: Its to get partner list by partner code
	 * 				
	 * @Tags 				: 
	 *						@param strPartnerCodes - get list by strPartnerCodes
	 *						@return List - partnerList
	 * @Git_Config 			: 
	 *		 				name
	 * 						email
	 * 
	 */
	@Override
	@Transactional(readOnly = true)
	public List<Partner> getPartnerListByPartnerCode(List<String> strPartnerCodes) {

		List<Partner> partnerList = new ArrayList<>();
		try {

			if (strPartnerCodes.size() > 0) {
				Specification<Partner> specification = null;
				Specifications<Partner> specifications = Specifications
						.where(this.partnerGSpecifications.dataTypeCharacter("deleted", AppConstants.NO));
				specification = this.partnerGSpecifications.dataTypeStringList("partnerCode", strPartnerCodes);
				specifications = specifications.and(specification);
				specification = specifications;
				partnerList = this.partnerRepository.findAll(specification);
			} else {
				LOGGER.warn(CLASS_NAME, "getPartnerListByPartnerCode", "strPartnerCodes size is 0 or empty");
			}

		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "getPartnerListByPartnerCode", e);
		} finally {

		}
		return partnerList;

	}

	
}
