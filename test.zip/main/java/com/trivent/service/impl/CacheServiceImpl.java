package com.trivent.service.impl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.trivent.constants.AppConstants;
import com.trivent.logging.LogManager;
import com.trivent.logging.Logger;
import com.trivent.models.Account;
import com.trivent.models.AppItem;
import com.trivent.models.AppList;
import com.trivent.models.AppSubItem;
import com.trivent.models.AppUIScreen;
import com.trivent.models.AppUIScreenField;
import com.trivent.models.AppUIScreenFilter;
import com.trivent.models.AppUIScreenView;
import com.trivent.models.Division;
import com.trivent.models.Partner;
import com.trivent.models.Role;
import com.trivent.models.StatusFlowRef;
import com.trivent.models.Team;
import com.trivent.models.User;
import com.trivent.repository.AccountRepository;
import com.trivent.repository.AppItemRepository;
import com.trivent.repository.AppListRepository;
import com.trivent.repository.AppSubItemRepository;
import com.trivent.repository.AppUIScreenFieldRepository;
import com.trivent.repository.AppUIScreenFilterRepository;
import com.trivent.repository.AppUIScreenRepository;
import com.trivent.repository.AppUIScreenViewRepository;
import com.trivent.repository.DivisionRepository;
import com.trivent.repository.PartnerRepository;
import com.trivent.repository.RoleRepository;
import com.trivent.repository.StatusFlowRefRepository;
import com.trivent.repository.TeamRepository;
import com.trivent.repository.UserRepository;
import com.trivent.service.CacheService;
import com.trivent.service.PartnerService;


/**
 * @FileName : CacheServiceImpl.java
 * @ClassName : CacheServiceImpl
 * @DateAndTime : Nov 21, 2018 - 6:47:48 PM
 * 
 * @Author : karthik
 * 
 * @Description : Function to implement cache related methods like fetching data
 *              from the cache Memory
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
@Service("cacheService")
public class CacheServiceImpl implements CacheService {

	
	@SuppressWarnings("unused")
	private static final Logger LOGGER = LogManager.getLogger();

	@SuppressWarnings("unused")
	private static final String CLASS_NAME = CacheServiceImpl.class.getName();

	@Autowired
	private AccountRepository accountRepository;
	
	@Autowired
	private AppListRepository appListRepository;
	
	@Autowired
	private StatusFlowRefRepository statusFlowRefRepository;
	
	@Autowired
	private AppItemRepository appItemRepository;
	
	@Autowired
	private AppSubItemRepository appSubItemRepository;
	
	@Autowired
	private PartnerService partnerService;
	
	@Autowired
	private AppUIScreenRepository appUIScreenRepository;
	
	@Autowired
	private AppUIScreenFieldRepository appUIScreenFieldRepository;
	
	@Autowired
	private AppUIScreenFilterRepository appUIScreenFilterRepository;
	
	@Autowired
	private AppUIScreenViewRepository appUIScreenViewRepository;
	
	@Autowired
	private RoleRepository roleRepository;
	
	@Autowired
	private TeamRepository teamRepository;
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private DivisionRepository divisionRepository;
	
	@Autowired
	private PartnerRepository partnerRepository;
	

	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.CacheService#findByAccountId(java.lang.Long)
	 * 
	 * @DateAndTime : Nov 21, 2018 - 6:47:48 PM
	 * 
	 * @Author : karthik
	 * 
	 * @Description : Method to find account by account Id
	 * 
	 * @Tags :
	 * 
	 * @param accountId inputs account id as Long
	 * 
	 * @return redirects to accountRepository
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override	
	@Transactional(readOnly = false)
	public Account findByAccountId(Long accountId) {
		return this.accountRepository.findOne(accountId);
	}

	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.CacheService#findByAppListName(java.lang.String)
	 * 
	 * @DateAndTime : Nov 21, 2018 - 6:47:48 PM
	 * 
	 * @Author : karthik
	 * 
	 * @Description : Method to find By App List Name
	 * 
	 * @Tags :
	 * 
	 * @param appListName inputs string value
	 * 
	 * @return redirects to appListRepository
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override		
	public AppList findByAppListName(String appListName) {
		return this.appListRepository.findByName(appListName);
	}
	

	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.CacheService#findByObjType(java.lang.String, char)
	 * 
	 * @DateAndTime : Nov 21, 2018 - 6:47:48 PM
	 * 
	 * @Author : karthik
	 * 
	 * @Description : Method to find StatusFlowRef By Obj Type
	 * 
	 * @Tags :
	 * 
	 * @param objType inputs obj type as string
	 * 
	 * @param isDeleted inputs character value
	 * 
	 * @return redirects to statusFlowRefRepository
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override	
	public List<StatusFlowRef> findByObjType(String objType, char isDeleted) {
		return this.statusFlowRefRepository.findByObjType(objType, isDeleted);
	}
	
	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.CacheService#findByItemId(java.lang.Long)
	 * 
	 * @DateAndTime : Nov 21, 2018 - 6:47:48 PM
	 * 
	 * @Author : karthik
	 * 
	 * @Description : Sorting subItems in ascending and descending order
	 * 
	 * @Tags :
	 * 
	 * @param appItemId inputs app Item id as long
	 * 
	 * @return returns App Sub Item in List
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override	
	public List<AppSubItem> findByItemId(Long appItemId) {

		AppItem appItem = this.appItemRepository.findOne(appItemId);
		if (appItem.getAppList().getSortPreference().equals(AppConstants.SORT_PREF_ASC)) {
			return this.appSubItemRepository.findBySubItemNameAsc(appItemId);
		} else if (appItem.getAppList().getSortPreference().equals(AppConstants.SORT_PREF_DESC)) {
			return this.appSubItemRepository.findBySubItemNameDesc(appItemId);
		} else if (appItem.getAppList().getSortPreference().equals(AppConstants.SORT_SEQ_NO)) {
			return this.appSubItemRepository.findByItemId(appItemId);
		} else {
			return this.appSubItemRepository.findByItemIdSame(appItemId);
		}

	}
	
	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.CacheService#findByListId(java.lang.Long)
	 * 
	 * @DateAndTime : Nov 21, 2018 - 6:47:48 PM
	 * 
	 * @Author : karthik
	 * 
	 * @Description : Sorting Items in ascending and descending order
	 * 
	 * @Tags :
	 * 
	 * @param appListId inputs app List id as long
	 * 
	 * @return returns AppItem in List
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override	
	public List<AppItem> findByListId(Long appListId) {
		AppList appList = this.appListRepository.findOne(appListId);
		if (appList.getSortPreference().equals(AppConstants.SORT_PREF_ASC)) {
			return this.appItemRepository.findByListName(appList.getId());
		} else if (appList.getSortPreference().equals(AppConstants.SORT_PREF_DESC)) {
			return this.appItemRepository.findByListNameDesc(appList.getId());
		} else if (appList.getSortPreference().equals(AppConstants.SORT_SEQ_NO)) {
			return this.appItemRepository.findByListId(appList.getId());
		} else {
			return this.appItemRepository.findByListIdSame(appList.getId());
		}
	}
	
	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.CacheService#findByScreenNameTypeRole(java.lang.Long,
	 * java.lang.String, java.lang.Long)
	 * 
	 * @DateAndTime : Nov 21, 2018 - 6:47:48 PM
	 * 
	 * @Author : karthik
	 * 
	 * @Description : Method to find By AppUI Screen Screen Name Type Role
	 * 
	 * @Tags :
	 * 
	 * @param screenName inputs screen name as Long
	 * 
	 * @param screenType inputs screen type as string
	 * 
	 * @param roleId inputs role id as long
	 * 
	 * @return returns appUI Screen details
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override	
	public AppUIScreen findByScreenNameTypeRole(Long screenName, String screenType, Long roleId) {
		AppUIScreen appUIScreen = new AppUIScreen();
		Partner currentSessionPartner = partnerService.getCurrentSessionPartner();
		List<AppUIScreen> dbAppUIScreenLsit = this.appUIScreenRepository.findByScreenNameTypeAndRoleUpdate(screenName,
				screenType, roleId);
		if (dbAppUIScreenLsit.size() != 0) {
			for (AppUIScreen dbAppUIScreen : dbAppUIScreenLsit) {
				if (currentSessionPartner != null) {
					if (StringUtils.isNotBlank(dbAppUIScreen.getPartner())
							&& StringUtils.isNotEmpty(dbAppUIScreen.getPartner())) {
						if (dbAppUIScreen.getPartner().trim()
								.equalsIgnoreCase(String.valueOf(currentSessionPartner.getId()))) {
							appUIScreen = dbAppUIScreen;
							break;
						}
					} else {
						appUIScreen = dbAppUIScreen;
					}
				}
			}
		}
		if (appUIScreen == null || appUIScreen.getId() == null) {
			return appUIScreen;
		}
		return appUIScreen;
	}
	
	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.CacheService#findFieldsByAppUIScreenId(java.lang.Long)
	 * 
	 * @DateAndTime : Nov 21, 2018 - 6:47:48 PM
	 * 
	 * @Author : karthik
	 * 
	 * @Description : Method to find Fields By AppUI Screen Id
	 * 
	 * @Tags :
	 * 
	 * @param appUIScreenId inputs screen id as long
	 * 
	 * @return redirects to appUIScreenFieldRepository
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override	
	public List<AppUIScreenField> findFieldsByAppUIScreenId(Long appUIScreenId) {
		return this.appUIScreenFieldRepository.findByAppUIScreenId(appUIScreenId);
	}
	
	
	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.CacheService#findFiltersByAppUIScreenId(java.lang.Long)
	 * 
	 * @DateAndTime : Feb 8, 2018 - 6:47:48 PM
	 * 
	 * @Author : kavipriya
	 * 
	 * @Description : Method to find Filters By AppUI Screen Id
	 * 
	 * @Tags :
	 * 
	 * @param appUIScreenId inputs UI screen id as Long
	 * 
	 * @return redirects to appUIScreenFilterRepository
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override	
	public List<AppUIScreenFilter> findFiltersByAppUIScreenId(Long appUIScreenId) {
		return this.appUIScreenFilterRepository.findByAppUIScreenId(appUIScreenId);
	}
	
	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.CacheService#findViewsByAppUIScreenId(java.lang.Long)
	 * 
	 * @DateAndTime : Feb 8, 2018 - 6:47:48 PM
	 * 
	 * @Author : kavipriya
	 * 
	 * @Description : Method to find Views By App UI ScreenId
	 * 
	 * @Tags :
	 * 
	 * @param appUIScreenId inputs app Ui screen Id as long
	 * 
	 * @return redirects to appUIScreenViewRepository
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override
	public List<AppUIScreenView> findViewsByAppUIScreenId(Long appUIScreenId) {
		return this.appUIScreenViewRepository.findByAppUIScreenId(appUIScreenId);
	}
	
	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.CacheService#findByRoleId(java.lang.Long)
	 * 
	 * @DateAndTime : Feb 8, 2018 - 6:47:48 PM
	 * 
	 * @Author : kavipriya
	 * 
	 * @Description : Method to find Role By Role id
	 * 
	 * @Tags :
	 * 
	 * @param roleId inputs role id as long
	 * 
	 * @return redirects to roleRepository
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override
	public Role findByRoleId(Long roleId) {
		return this.roleRepository.findOne(roleId);
	}
	

	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.CacheService#findByTeamId(java.lang.Long)
	 * 
	 * @DateAndTime : Feb 8, 2018 - 6:47:48 PM
	 * 
	 * @Author : kavipriya
	 * 
	 * @Description : method to find team By TeamId
	 * 
	 * @Tags :
	 * 
	 * @param teamId inputs team id as long
	 * 
	 * @return redirects to teamRepository
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override
	public Team findByTeamId(Long teamId) {
		return this.teamRepository.findOne(teamId);
	}
	
	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.CacheService#findByPartnerId(java.lang.Long)
	 * 
	 * @DateAndTime : Feb 8, 2018 - 6:47:48 PM
	 * 
	 * @Author : kavipriya
	 * 
	 * @Description : Method to find partner By PartnerId
	 * 
	 * @Tags :
	 * 
	 * @param partnerId inputs partner id as long
	 * 
	 * @return redirects to partnerRepository
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override
	public Partner findByPartnerId(Long partnerId) {
		return this.partnerRepository.findOne(partnerId);
	}
	
	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.CacheService#findByUserId(java.lang.Long)
	 * 
	 * @DateAndTime : Feb 8, 2018 - 6:47:48 PM
	 * 
	 * @Author : kavipriya
	 * 
	 * @Description : Method to find User By UserId
	 * 
	 * @Tags :
	 * 
	 * @param userId inputs user Id as Long
	 * 
	 * @return redirects to userRepository
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override
	public User findByUserId(Long userId) {
		return this.userRepository.findOne(userId);
	}
	
	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.CacheService#findDivisionName(java.lang.Long)
	 * 
	 * @DateAndTime : Feb 8, 2018 - 6:47:48 PM
	 * 
	 * @Author : kavipriya
	 * 
	 * @Description : Method to find Division by division id
	 * 
	 * @Tags :
	 * 
	 * @param divisionId inputs division id as long
	 * 
	 * @return redirects to divisionRepository
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override
	public Division findDivisionName(Long divisionId) {
		return this.divisionRepository.findOne(divisionId);
	}
	
	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.CacheService#findByRole(java.lang.String)
	 * 
	 * @DateAndTime : Feb 8, 2018 - 6:47:48 PM
	 * 
	 * @Author : kavipriya
	 * 
	 * @Description : Method to find Role By Role name
	 * 
	 * @Tags :
	 * 
	 * @param roleName inputs role name as string
	 * 
	 * @return redirects to roleRepository
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override
	public Role findByRole(String roleName) {
		return this.roleRepository.findByName(roleName);
	}
	
	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.CacheService#findAdminUser(java.lang.Long)
	 * 
	 * @DateAndTime : Feb 8, 2018 - 6:47:48 PM
	 * 
	 * @Author : kavipriya
	 * 
	 * @Description : Method to find Admin User from cache by role Id
	 * 
	 * @Tags :
	 * 
	 * @param roleId inputs role is as Long
	 * 
	 * @return redirects to userRepository
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override
	public User findAdminUser(Long roleId) {
		return this.userRepository.getAdminUser(roleId);
	}
}
