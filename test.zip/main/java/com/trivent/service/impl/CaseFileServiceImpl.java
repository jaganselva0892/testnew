package com.trivent.service.impl;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.ToIntFunction;


import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.domain.Specifications;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.trivent.constants.AppConstants;
import com.trivent.dto.AppUIScreenFilterVO;
import com.trivent.dto.RowVO;
import com.trivent.dto.ScreenListFilterVO;
import com.trivent.exceptions.TriventException;
import com.trivent.logging.LogManager;
import com.trivent.logging.Logger;
import com.trivent.models.Case;
import com.trivent.models.CaseFile;
import com.trivent.models.CaseResultFile;
import com.trivent.models.ProdFile;
import com.trivent.models.Role;
import com.trivent.models.User;
import com.trivent.repository.AppDBTableRepository;
import com.trivent.repository.CaseFileRepository;
import com.trivent.repository.CaseRepository;
import com.trivent.repository.CaseResultFileReprository;
import com.trivent.repository.ProdFileRepository;
import com.trivent.repository.specifications.GenericSpecifications;
import com.trivent.service.CaseFileService;
import com.trivent.service.UserService;
import com.trivent.utils.FilterUtils;

/**
 * @FileName : CaseFileServiceImpl.java
 * @ClassName : CaseFileServiceImpl
 * @DateAndTime : Feb 8, 2018 - 2:39:53 PM
 * 
 * @Author : Ramya
 * 
 * @Description : Its to get,list,delete,download,merge,save,update case files
 *              and case result files.
 * @Tags :
 * @Git_Config : name email
 * 
 */
@Service
public class CaseFileServiceImpl implements CaseFileService {

	private static final Logger LOGGER = LogManager.getLogger();

	private static final String CLASS_NAME = CaseFileServiceImpl.class.getName();

	@Autowired
	private CaseFileRepository caseFileRepository;

	@Autowired
	private CaseResultFileReprository caseResultFileRepository;


	@Autowired
	GenericSpecifications<CaseFile> genericSpecifications;

	@Autowired
	private ProdFileRepository prodFileRepository;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private FilterUtils<CaseFile> filterUtils;
	
	@SuppressWarnings("unused")
	@Autowired
	private AppDBTableRepository appDBTableRepository;
	
	@Autowired
	private CaseRepository caseRepository;
	
	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.CaseFileService#getCaseFileData(java.lang.Long)
	 * 
	 * @DateAndTime : Feb 8, 2018 - 2:39:54 PM
	 * 
	 * @Author : Ramya
	 * 
	 * @Description : Its to get case file data
	 * 
	 * @Tags :
	 * 
	 * @param caseFileId - get by using caseFileId
	 * 
	 * @return CaseFile - caseFile
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override
	@Transactional(readOnly = true)
	public CaseFile getCaseFileData(Long caseFileId) {

		CaseFile caseFile = new CaseFile();
		try {
			caseFile = this.caseFileRepository.findOne(caseFileId);
		} catch (Exception e) {
			caseFile = null;
			LOGGER.error(CLASS_NAME, "getCaseFileData - Error", e);
		}
		return caseFile;

	}
	
	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.CaseFileService#getCaseResultFileData(java.lang.Long)
	 * 
	 * @DateAndTime : Feb 8, 2018 - 2:39:54 PM
	 * 
	 * @Author : Ramya
	 * 
	 * @Description : Its to get case result file data
	 * 
	 * @Tags :
	 * 
	 * @param caseFileId - get files by caseFileId
	 * 
	 * @return CaseResultFile - caseResultFile
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override
	@Transactional(readOnly = true)
	public CaseResultFile getCaseResultFileData(Long caseFileId) {

		CaseResultFile caseResultFile = new CaseResultFile();
		try {
			caseResultFile = this.caseResultFileRepository.findOne(caseFileId);
		} catch (Exception e) {
			caseResultFile = null;
			LOGGER.error(CLASS_NAME, "getCaseResultFileData - Error", e);
		}
		return caseResultFile;

	}

	
	@Override
	@Transactional(readOnly = true)
	public ProdFile getProdFileData(Long prodFileId) {

		ProdFile prodFile = new ProdFile();
		try {
			prodFile = this.prodFileRepository.findOne(prodFileId);
		} catch (Exception e) {
			prodFile = null;
			LOGGER.error(CLASS_NAME, "getCaseFileData - Error", e);
		}
		return prodFile;
	}
	
	
	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.CaseFileService#listCaseFilesByCaseId(java.lang.Long,
	 * com.trivent.dto.ScreenListFilterVO, java.lang.String)
	 * 
	 * @DateAndTime : Feb 8, 2018 - 2:39:54 PM
	 * 
	 * @Author : Karthi
	 * 
	 * @Description : Its to list case files
	 * 
	 * @Tags :
	 * 
	 * @param caseId - get list by caseId
	 * 
	 * @param screenListFilterVO - get require field by path variable
	 * screenListFilterVO
	 * 
	 * @param psType - get list by type
	 * 
	 * @return List - updatedRowVOs
	 * 
	 * @throws TriventException
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override
	@Transactional(readOnly = true)
	public List<RowVO> listCaseFilesByCaseId(Long caseId, ScreenListFilterVO screenListFilterVO, String psType)
			throws TriventException, IllegalAccessException, InvocationTargetException {
		User loginUser = this.userService.getCurrentUser(null);
		//AppDBTable appdbTable = this.appDBTableRepository.findByName("CaseFile");
		String screenType = AppConstants.SCREEN_TYPE_LIST;
		ScreenListFilterVO screenListFilterVO1 = new ScreenListFilterVO();
		List<CaseFile> caseFiles = null;
		Specification<CaseFile> specification = null;
		Specifications<CaseFile> specifications = Specifications
				.where(this.genericSpecifications.dataTypeCharacter("deleted", AppConstants.NO));

		if (StringUtils.isNotBlank(psType) && StringUtils.isNotEmpty(psType)) {

			switch (psType) {

			case AppConstants.ARCHIVAL_FTP_ACTION_BACKUP:
				specifications = specifications
						.and(this.genericSpecifications.dataTypeCharacter("archived", AppConstants.YES));
				specifications = specifications
						.and(this.genericSpecifications.dataTypeCharacter("backup", AppConstants.NO));
				specifications = specifications
						.and(this.genericSpecifications.dataTypeStringEqual("curStatus", AppConstants.TRACE_SUCCESS));
				break;

			case AppConstants.ARCHIVAL_FTP_ACTION_ARCHIVE:
				specifications = specifications
						.and(this.genericSpecifications.dataTypeCharacter("archived", AppConstants.NO));
				specifications = specifications
						.and(this.genericSpecifications.dataTypeCharacter("backup", AppConstants.NO));
				specifications = specifications
						.and(this.genericSpecifications.dataTypeStringEqual("curStatus", AppConstants.TRACE_SUCCESS));
				break;

			case AppConstants.ARCHIVAL_FTP_ACTION_REMOVE:
				specifications = specifications
						.and(this.genericSpecifications.dataTypeCharacter("archived", AppConstants.YES));
				specifications = specifications
						.and(this.genericSpecifications.dataTypeCharacter("backup", AppConstants.YES));
				specifications = specifications
						.and(this.genericSpecifications.dataTypeCharacter("removeFile", AppConstants.NO));
				specifications = specifications
						.and(this.genericSpecifications.dataTypeStringEqual("curStatus", AppConstants.TRACE_SUCCESS));
				break;

			default:
				break;

			}
			BeanUtils.copyProperties(screenListFilterVO, screenListFilterVO1);
		} else {
			//AppDBTable appdbTableCF = this.appDBTableRepository.findByName("CaseFile");
			String screenTypeCF = AppConstants.SCREEN_TYPE_LIST;
			//screenListFilterVO1 = this.filterUtils.populateScreenListFilterVO(appdbTableCF.getId(), screenTypeCF);
			screenListFilterVO1 = this.filterUtils.populateScreenListFilterVO(new Long(14), screenTypeCF);
		}

		/* To List Case files of sub case in Files Upload tab */

		if (caseId != null) {
			Case appCase = caseRepository.findOne(caseId);
			if (appCase != null) {
				if (loginUser.getRole().getType().equals(Role.ROLE_TYPE_CUSTOMER)) {
					if (appCase.getParentCase() == null) {
						List<Long> longCaseids = new ArrayList<>();
						List<Case> clientCases = caseRepository.findByParentId(caseId);
						for (Case cases : clientCases) {
							Long prntCaseId = cases.getId();
							longCaseids.add(prntCaseId);
						}
						longCaseids.add(caseId);
						if (longCaseids.size() > 0) {
							Specification<CaseFile> specificationNew = this.genericSpecifications
									.dataTypeLongList("clientCase", longCaseids);
							specifications = specifications.and(specificationNew);
						}

					}
				} else {
					if (appCase.getParentCase() == null) {
						List<Long> longCaseids = new ArrayList<>();
						List<Case> clientCases = caseRepository.findByParentId(caseId);
						for (Case cases : clientCases) {
							Long prntCaseId = cases.getId();
							longCaseids.add(prntCaseId);
						}
						longCaseids.add(caseId);
						if (longCaseids.size() > 0) {
							Specification<CaseFile> specificationNew = this.genericSpecifications
									.dataTypeLongList("clientCase", longCaseids);
							specifications = specifications.and(specificationNew);
						}
					} else {
						Specification<CaseFile> specificationNew = this.genericSpecifications.dataTypeLong("clientCase",
								caseId);
						specifications = specifications.and(specificationNew);
					}
				}
			}
		}
		ScreenListFilterVO screenListFilterVONew = new ScreenListFilterVO();
		BeanUtils.copyProperties(screenListFilterVO1,screenListFilterVONew);
		if (screenListFilterVO1.getAppUIScreenFilterVOs().size() > 0) {

			String[] _curStatus = null;
			String[] pageCountStatus = null;

			for (AppUIScreenFilterVO appUIScreenFilterVO : screenListFilterVONew.getAppUIScreenFilterVOs()) {

				if (appUIScreenFilterVO.getDbFieldName().equalsIgnoreCase("curStatus")
						|| appUIScreenFilterVO.getDbFieldName().equalsIgnoreCase("tcurStatus")) {
					if (appUIScreenFilterVO.getDbFieldName().equalsIgnoreCase("curStatus")) {
						_curStatus = appUIScreenFilterVO.getValue() != null ? appUIScreenFilterVO.getValue().split(",")
								: "".split(",");
						List<String> _str = new ArrayList<String>();
						for (String _curstatus : _curStatus)
							if (!_curstatus.isEmpty())
								_str.add(_curstatus);

						if (_str.size() != 0) {
							specification = genericSpecifications.dataTypeStringList("curStatus", _str);
							specifications = specifications.and(specification);
						}
					}
				}

				if (appUIScreenFilterVO.getDbFieldName().equalsIgnoreCase("pageCountStatus")
						|| appUIScreenFilterVO.getDbFieldName().equalsIgnoreCase("tpageCountStatus")) {
					if (appUIScreenFilterVO.getDbFieldName().equalsIgnoreCase("pageCountStatus")) {
						pageCountStatus = appUIScreenFilterVO.getValue() != null
								? appUIScreenFilterVO.getValue().split(",")
								: "".split(",");
						List<String> _str = new ArrayList<String>();
						for (String _curstatus : pageCountStatus)
							if (!_curstatus.isEmpty())
								_str.add(_curstatus);

						if (_str.size() != 0) {
							specification = genericSpecifications.dataTypeStringList("pageCountStatus", _str);
							specifications = specifications.and(specification);
						}
					}
				}

			}

			if (_curStatus != null) {
				for (AppUIScreenFilterVO appUIScreenFilterVO : screenListFilterVONew.getAppUIScreenFilterVOs()) {
					if (appUIScreenFilterVO.getDbFieldName().equalsIgnoreCase("curStatus")) {
						appUIScreenFilterVO.setValue("");
					} else if (appUIScreenFilterVO.getDbFieldName().equalsIgnoreCase("curStatus")) {
						appUIScreenFilterVO.setValue("");
						appUIScreenFilterVO.setDbFieldName("");
						appUIScreenFilterVO.setFilterName("");
					}
				}
			}

			if (pageCountStatus != null) {
				for (AppUIScreenFilterVO appUIScreenFilterVO : screenListFilterVONew.getAppUIScreenFilterVOs()) {
					if (appUIScreenFilterVO.getDbFieldName().equalsIgnoreCase("pageCountStatus")) {
						appUIScreenFilterVO.setValue("");
					} else if (appUIScreenFilterVO.getDbFieldName().equalsIgnoreCase("pageCountStatus")) {
						appUIScreenFilterVO.setValue("");
						appUIScreenFilterVO.setDbFieldName("");
						appUIScreenFilterVO.setFilterName("");
					}
				}
			}
		}
		specifications = this.filterUtils.populateCaseViewSpecifications(screenListFilterVO, loginUser, specifications,
				true);

		specifications = this.filterUtils.populateCaseFilterSpecifications(screenListFilterVO1, specifications);
		specification = specifications;
		Page<CaseFile> requestedPage = this.caseFileRepository.findAll(specification,
				this.filterUtils.constructPageSpecification(screenListFilterVO));
		if (screenListFilterVO.getPageNo() > requestedPage.getTotalPages()) {
			screenListFilterVO.setPageNo(1);
			screenListFilterVO1.setPageNo(1);
			requestedPage = this.caseFileRepository.findAll(specification,
					this.filterUtils.constructPageSpecification(screenListFilterVO1));
		}
		caseFiles = requestedPage.getContent();
		screenListFilterVO.setTotalPages(requestedPage.getTotalPages());
		screenListFilterVO.setCurrentRecords(requestedPage.getNumberOfElements());
		screenListFilterVO.setTotalRecords(requestedPage.getTotalElements());
		List<RowVO> updatedRowVOs = new ArrayList<>();
		/*List<RowVO> rowVOs = this.filterUtils.listScreenDetails(appdbTable.getId(), screenType, caseFiles);*/
		List<RowVO> rowVOs = this.filterUtils.listScreenDetails(new Long(14), screenType, caseFiles);

		final List<CaseFile> caseFilesForPageCount = caseFileRepository.findAll(specification);
		final int sumofPageCount = caseFilesForPageCount.stream().mapToInt(new ToIntFunction<CaseFile>() {
			@Override
			public int applyAsInt(CaseFile o) {
				return ((o != null) && (o.getFilePageCount() != null)
						&& StringUtils.isNotBlank(o.getFilePageCount().toString())
						&& StringUtils.isNotEmpty(o.getFilePageCount().toString()) ? o.getFilePageCount() : 0);
			}
		}).sum();

		rowVOs.forEach(new Consumer<RowVO>() {
			@Override
			public void accept(RowVO row) {
				if (row.getId() != null) {
					row.getValueMap().put("totalCaseFiles", String.valueOf(caseFilesForPageCount.size()));
					row.getValueMap().put("caseFilePageCount", String.valueOf(sumofPageCount));
				}
				row.setValueMap(row.getValueMap());
			}
		});

		boolean repeatLoop = true;
		int loopIndex = 0;
		while (repeatLoop) {
			RowVO rowVO = rowVOs.get(loopIndex);
			Long caseFileId = rowVO.getId();
			if (caseFileId != null) {
				loopIndex += 1;
				rowVO = rowVOs.get(loopIndex);
			} else {
				repeatLoop = false;
				Map<String, String> caseDetailsMap = rowVO.getValueMap();
				if (caseId != null) {
					caseDetailsMap.put("caseId", caseId.toString());
					Case caseOne = this.caseRepository.findOne(caseId);
					caseDetailsMap.put("accountId", caseOne.getAccount().getId().toString());
					caseDetailsMap.put("clientId", caseOne.getClient().getId().toString());
					String roleType = loginUser.getRole().getName();
					String roleName = (roleType.equalsIgnoreCase("Customer")) ? "Y" : "N";
					caseDetailsMap.put("loginUserRole", roleName);
				}
				caseDetailsMap.put("loginUser", loginUser.getId().toString());
				rowVO.setValueMap(caseDetailsMap);
				break;
			}
		}
		updatedRowVOs.addAll(rowVOs);
		return updatedRowVOs;
	}
	
	
	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.CaseFileService#getDefaultScreenListFilterVO()
	 * 
	 * @DateAndTime : Feb 8, 2018 - 2:39:54 PM
	 * 
	 * @Author : Karthi
	 * 
	 * @Description : Its to get default screen list filter VO
	 * 
	 * @Tags :
	 * 
	 * @return ScreenListFilterVO - call another method
	 * 
	 * @throws TriventException
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override
	@Transactional(readOnly = true)
	public ScreenListFilterVO getDefaultScreenListFilterVO() throws TriventException {
		//AppDBTable appdbTable = this.appDBTableRepository.findByName("CaseFile");
		String screenType = AppConstants.SCREEN_TYPE_LIST;
		return this.filterUtils.populateScreenListFilterVO(new Long(14), screenType);
	}

	
}
