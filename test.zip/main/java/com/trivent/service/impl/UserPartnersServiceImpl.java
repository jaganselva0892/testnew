package com.trivent.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.trivent.constants.AppConstants;
import com.trivent.logging.LogManager;
import com.trivent.logging.Logger;
import com.trivent.models.User;
import com.trivent.models.UserPartners;
import com.trivent.repository.UserPartnersRepository;
import com.trivent.service.UserPartnersService;

/**
 * @FileName : UserPartnersServiceImpl.java
 * @ClassName : UserPartnersServiceImpl
 * @DateAndTime : Nov 21, 2018 - 12:17:42 PM
 * 
 * @Author : Karthi
 * 
 * @Description : To get the user and partner details and list them by user and
 *              partner
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
@Service
public class UserPartnersServiceImpl implements UserPartnersService {

	private static final Logger LOGGER = LogManager.getLogger();

	private static final String CLASS_NAME = UserPartnersServiceImpl.class.getName();

	@Autowired
	private UserPartnersRepository userPartnersRepository;

	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.UserPartnersService#getByUser(com.trivent.entity.User)
	 * 
	 * @DateAndTime : Nov 21, 2018 - 12:17:42 PM
	 * 
	 * @Author : Karthi
	 * 
	 * @Description : To get UserList
	 * 
	 * @Tags :
	 * 
	 * @param user - get list by user
	 * 
	 * @return List - userPartnersList
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override
	public List<UserPartners> getByUser(User user) {
		List<UserPartners> userPartnersList = new ArrayList<>();
		try {
			if (user != null) {
				List<User> userList = new ArrayList<>();
				userList.add(user);
				
				userPartnersList = this.userPartnersRepository.findAll(userList, AppConstants.NO, null);
			}

		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "getByUser", e);
		} finally {

		}
		return userPartnersList;
	}

	
}