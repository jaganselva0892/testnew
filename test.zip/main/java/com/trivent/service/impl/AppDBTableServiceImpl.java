package com.trivent.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import javax.persistence.metamodel.Attribute;
import javax.persistence.metamodel.EntityType;

import org.apache.commons.collections.keyvalue.MultiKey;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.trivent.constants.AppConstants;
import com.trivent.dto.AppDBTableColumnVO;
import com.trivent.dto.AppDBTableVO;
import com.trivent.models.AppDBTable;
import com.trivent.models.AppDBTableColumn;
import com.trivent.repository.AppDBTableColumnRepository;
import com.trivent.repository.AppDBTableRepository;
import com.trivent.repository.MetadataRepository;
import com.trivent.service.AppDBTableService;
import com.trivent.utils.CommonUtils;

/**
 * @FileName : AppDBTableServiceImpl.java
 * @ClassName : AppDBTableServiceImpl
 * @DateAndTime : Feb 8, 2018 - 12:45:58 PM
 * 
 * @Author : kavipriya
 * 
 * @Description : Function to implement App DB Table
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */

@Service
public class AppDBTableServiceImpl implements AppDBTableService {

	// ReplaceWithEmpty
	@Autowired
	AppDBTableRepository appDBTableRepository;

	// ReplaceWithEmpty
	@Autowired
	AppDBTableColumnRepository appDBTableColumnRepository;

	// ReplaceWithEmpty
	@Autowired
	MetadataRepository metadataRepository;

	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.AppDBTableService#getAppDBTable(java.lang.Long)
	 * 
	 * @DateAndTime : Feb 8, 2018 - 12:45:58 PM
	 * 
	 * @Author : kavipriya
	 * 
	 * @Description :Method to edit App DB table
	 * 
	 * @Tags :
	 * 
	 * @param appDBTableId
	 * 
	 * @return it redirects to App DB Table & column details edit
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override
	@Transactional(readOnly = true)
	public AppDBTableVO getAppDBTable(Long appDBTableId) {
		AppDBTable appDBTable = this.appDBTableRepository.findOne(appDBTableId);
		return new AppDBTableVO(appDBTable);
	}

	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.AppDBTableService#getAppDBTableByName(java.lang.String)
	 * 
	 * @DateAndTime : Feb 8, 2018 - 12:45:58 PM
	 * 
	 * @Author : kavipriya
	 * 
	 * @Description : Method to get App DB Table By Name
	 * 
	 * @Tags :
	 * 
	 * @param appDBTableName inputs DB table name
	 * 
	 * @return Returns the DB table
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override
	@Transactional(readOnly = true)
	public AppDBTableVO getAppDBTableByName(String appDBTableName) {
		AppDBTable appDBTable = this.appDBTableRepository.findByNameTable(appDBTableName);
		return new AppDBTableVO(appDBTable);
	}

	/********** App DB Table Columns **********/
	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.AppDBTableService#getAppDBTableColumn(java.lang.Long)
	 * 
	 * @DateAndTime : Feb 8, 2018 - 12:45:58 PM
	 * 
	 * @Author : kavipriya
	 * 
	 * @Description : Method to edit App DB table column by column id
	 * 
	 * @Tags :
	 * 
	 * @param appDBTableColumnId inputs app DB table column id
	 * 
	 * @return its redirects to App DB Table & column details edit page
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override
	@Transactional(readOnly = true)
	public AppDBTableColumnVO getAppDBTableColumn(Long appDBTableColumnId) {
		AppDBTableColumn appDBTableColumn = this.appDBTableColumnRepository.findOne(appDBTableColumnId);
		return new AppDBTableColumnVO(appDBTableColumn, appDBTableColumn.getDbTable().getId());
	}

	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.AppDBTableService#getAppDBTableColumnByName(java.lang.
	 * Long, java.lang.String)
	 * 
	 * @DateAndTime : Feb 8, 2018 - 12:45:58 PM
	 * 
	 * @Author : kavipriya
	 * 
	 * @Description : Method to get App DB Table Column By Name and table id
	 * 
	 * @Tags :
	 * 
	 * @param appDBTableId inputs app Db table Id as Long
	 * 
	 * @param appDBTableColName Inputs DB table column name
	 * 
	 * @return Returns value in List
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override
	@Transactional(readOnly = true)
	public List<AppDBTableColumnVO> getAppDBTableColumnByName(Long appDBTableId, String appDBTableColName) {
		List<AppDBTableColumn> appDBTableColumnList = this.appDBTableColumnRepository.findByNameTable(appDBTableId,
				appDBTableColName);
		List<AppDBTableColumnVO> appDBTableColumnVOList = new ArrayList<>();
		for (AppDBTableColumn appDBTableColumn : appDBTableColumnList) {
			appDBTableColumnVOList.add(new AppDBTableColumnVO(appDBTableColumn, appDBTableId));
		}
		return appDBTableColumnVOList;
	}

	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.AppDBTableService#getAppDBTableColumnByName(java.lang.
	 * String, java.lang.String)
	 * 
	 * @DateAndTime : Feb 8, 2018 - 12:45:58 PM
	 * 
	 * @Author : kavipriya
	 * 
	 * @Description : Method to get App DB Table Column By table and column Name
	 * 
	 * @Tags :
	 * 
	 * @param appDBTableName inputs table name as string
	 * 
	 * @param appDBTableColName inputs column name as string
	 * 
	 * @return returns value in List
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override
	@Transactional(readOnly = true)
	public List<AppDBTableColumnVO> getAppDBTableColumnByName(String appDBTableName, String appDBTableColName) {

		List<AppDBTableColumnVO> appDBTableColumnVOList = new ArrayList<>();
		AppDBTable appDBTable = this.appDBTableRepository.findByNameTable(appDBTableName);
		if (appDBTable != null) {
			List<AppDBTableColumn> appDBTableColumnList = this.appDBTableColumnRepository.findByNameTable(appDBTable,
					appDBTableColName);

			for (AppDBTableColumn appDBTableColumn : appDBTableColumnList) {
				appDBTableColumnVOList.add(new AppDBTableColumnVO(appDBTableColumn, appDBTable.getId()));
			}
		}
		return appDBTableColumnVOList;
	}

	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.AppDBTableService#getAppDbTableNames()
	 * 
	 * @DateAndTime : Feb 8, 2018 - 12:45:58 PM
	 * 
	 * @Author : kavipriya
	 * 
	 * @Description : not used
	 * 
	 * @Tags :
	 * 
	 * @return
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override
	public Map<Long, String> getAppDbTableNames() {
		return null;
	}

	/* Its to display list of App DB Tables */
	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.AppDBTableService#listAppDBTables()
	 * 
	 * @DateAndTime : Feb 8, 2018 - 12:45:58 PM
	 * 
	 * @Author : kavipriya
	 * 
	 * @Description : Method to list App DB Tables
	 * 
	 * @Tags :
	 * 
	 * @return redirects to appDBTableRepository
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override
	@Transactional(readOnly = true)
	public List<AppDBTable> listAppDBTables() {
		return this.appDBTableRepository.findAll(AppConstants.SEQ_NO_ORDER_BY_ASC);
	}

	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Feb 8, 2018 - 12:45:58 PM
	 * 
	 * @Author : kavipriya
	 * 
	 * @Description : Method to populate Attribute of the table
	 * 
	 * @Tags :
	 * @param entityType
	 *            inputs the entity type
	 * @param newAppDBTable
	 *            inputs App db table
	 * @param dbAppTableColumnMap
	 *            inputs the column Map
	 * @Git_Config : name email
	 * 
	 */
	private void populateAttribute(EntityType<?> entityType, AppDBTable newAppDBTable,
			Map<MultiKey, AppDBTableColumn> dbAppTableColumnMap) {
		MultiKey attributeKey = null;
		AppDBTableColumn newAppDBTableColumn = null;

		Map<String, Attribute<?, ?>> orderedAttributes = new TreeMap<>();
		for (Attribute<?, ?> attribute : entityType.getAttributes()) {
			orderedAttributes.put(attribute.getName(), attribute);
		}

		int seqNo = 0;
		for (Attribute<?, ?> attribute : orderedAttributes.values()) {
			attributeKey = new MultiKey(entityType.getName(), attribute.getName());
			newAppDBTableColumn = dbAppTableColumnMap.get(attributeKey);
			if (newAppDBTableColumn == null) {
				newAppDBTableColumn = new AppDBTableColumn();
				newAppDBTableColumn.setName(attribute.getName());
				newAppDBTableColumn.setAvailableForAppUIScreen(AppConstants.NO);
				newAppDBTableColumn.setAvailableForReport(AppConstants.NO);
			}
			Class<?> type = attribute.getJavaType();
			newAppDBTableColumn.setDisplayLabel(CommonUtils.camelCaseToReadable(attribute.getName()));
			newAppDBTableColumn.setDataType(CommonUtils.trimClassName(type.getName()));
			newAppDBTableColumn.setDbTable(newAppDBTable);
			newAppDBTableColumn.setReferenceTable("");
			newAppDBTableColumn.setReferenceTableColumn("");
			newAppDBTableColumn.setSize(1);
			newAppDBTableColumn.setSeqNo(seqNo);
			seqNo++;

			this.appDBTableColumnRepository.save(newAppDBTableColumn);
			dbAppTableColumnMap.remove(attributeKey);
		}
		return;
	}
	/* Business Logic */

	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Feb 8, 2018 - 12:45:58 PM
	 * 
	 * @Author : kavipriya
	 * 
	 * @Description : Method to populate Entity Attribute Map
	 * 
	 * @Tags :
	 * @param dbAppTables
	 *            inputs DB app tables
	 * @param dbAppTableMap
	 *            inputs DB app tableMAp
	 * @param dbAppTableColumnMap
	 *            inputs db App Table Column Map
	 * @Git_Config : name email
	 * 
	 */
	private void populateEntityAttributeMap(final List<AppDBTable> dbAppTables,
			final Map<String, AppDBTable> dbAppTableMap, final Map<MultiKey, AppDBTableColumn> dbAppTableColumnMap) {
		for (AppDBTable dbAppTable : dbAppTables) {
			dbAppTableMap.put(dbAppTable.getName(), dbAppTable);
			for (AppDBTableColumn dbAppTableColumn : dbAppTable.getAppDBTableColumns()) {
				dbAppTableColumnMap.put(new MultiKey(dbAppTable.getName(), dbAppTableColumn.getName()),
						dbAppTableColumn);
			}
		}
	}

	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.AppDBTableService#saveAppDBTable(com.trivent.dto.
	 * AppDBTableVO)
	 * 
	 * @DateAndTime : Feb 8, 2018 - 12:45:58 PM
	 * 
	 * @Author : kavipriya
	 * 
	 * @Description : Method to save App DB table
	 * 
	 * @Tags :
	 * 
	 * @param appDBTableVO stores the db app table details
	 * 
	 * @return its redirects to App DB Table & Column details save page
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override
	@Transactional
	public AppDBTableVO saveAppDBTable(AppDBTableVO appDBTableVO) {
		AppDBTable appDBTable;
		if (appDBTableVO.isNew()) {
			appDBTable = new AppDBTable();
		} else {
			appDBTable = this.appDBTableRepository.findOne(appDBTableVO.getId());
		}
		List<AppDBTableColumnVO> appDBTableColumnVOs = appDBTableVO.getAppDBTableColumnVOs();
		List<AppDBTableColumn> appDBTableColumns = null;
		if ((null != appDBTableColumnVOs) && !appDBTableColumnVOs.isEmpty()) {
			appDBTableColumns = new ArrayList<>(appDBTableColumnVOs.size());
			AppDBTableColumn appDBTableColumn = null;
			for (AppDBTableColumnVO appDBTableColumnVO : appDBTableColumnVOs) {
				appDBTableColumn = new AppDBTableColumn();
				BeanUtils.copyProperties(appDBTableColumnVO, appDBTableColumn);
				appDBTableColumns.add(appDBTableColumn);
			}
		}
		appDBTableVO.setAppDBTableColumnVOs(null);
		BeanUtils.copyProperties(appDBTableVO, appDBTable);
		appDBTable.setAppDBTableColumns(appDBTableColumns);
		appDBTable.setAvailableForAppUIScreen(
				appDBTableVO.getAvailableForAppUIScreen().booleanValue() ? AppConstants.YES : AppConstants.NO);
		appDBTable.setAvailableForReport(
				appDBTableVO.getAvailableForReport().booleanValue() ? AppConstants.YES : AppConstants.NO);
		appDBTable = this.appDBTableRepository.save(appDBTable);
		appDBTableVO.setId(appDBTable.getId());
		return appDBTableVO;
	}

	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.AppDBTableService#saveAppDBTableColumn(com.trivent.dto.
	 * AppDBTableColumnVO)
	 * 
	 * @DateAndTime : Feb 8, 2018 - 12:45:58 PM
	 * 
	 * @Author : kavipriya
	 * 
	 * @Description : Method to save App DB table column
	 * 
	 * @Tags :
	 * 
	 * @param appDBTableColumnVO stores the App DB table column details
	 * 
	 * @return its redirects to App DB Table & column details edit page
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override
	@Transactional
	public AppDBTableColumnVO saveAppDBTableColumn(AppDBTableColumnVO appDBTableColumnVO) {
		AppDBTableColumn appDBTableColumn;
		if (appDBTableColumnVO.isNew()) {
			appDBTableColumn = new AppDBTableColumn();
			AppDBTable appDBTable = this.appDBTableRepository.findOne(appDBTableColumnVO.getAppDBTableId());
			appDBTableColumn.setDbTable(appDBTable);
		} else {
			appDBTableColumn = this.appDBTableColumnRepository.findOne(appDBTableColumnVO.getId());
		}
		BeanUtils.copyProperties(appDBTableColumnVO, appDBTableColumn);
		appDBTableColumn.setAvailableForAppUIScreen(
				appDBTableColumnVO.isAvailableForAppUIScreen() ? AppConstants.YES : AppConstants.NO);
		appDBTableColumn
				.setAvailableForReport(appDBTableColumnVO.isAvailableForReport() ? AppConstants.YES : AppConstants.NO);
		appDBTableColumn = this.appDBTableColumnRepository.save(appDBTableColumn);
		appDBTableColumnVO.setId(appDBTableColumn.getId());
		return appDBTableColumnVO;
	}

	/********** Populate Meta Data **********/
	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.AppDBTableService#updateAppMetaData()
	 * 
	 * @DateAndTime : Feb 8, 2018 - 12:45:58 PM
	 * 
	 * @Author : kavipriya
	 * 
	 * @Description : Method to update metadata
	 * 
	 * @Tags :
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override
	@Transactional
	public void updateAppMetaData() {
		List<AppDBTable> dbAppTables = this.appDBTableRepository.findAll();
		Map<String, AppDBTable> dbAppTableMap = new HashMap<>(dbAppTables.size());
		Map<MultiKey, AppDBTableColumn> dbAppTableColumnMap = new HashMap<>();
		this.populateEntityAttributeMap(dbAppTables, dbAppTableMap, dbAppTableColumnMap);

		Map<String, EntityType<?>> orderedEntityTypes = new TreeMap<>();
		for (EntityType<?> entityType : this.metadataRepository.getEntityTypes()) {
			// Sort by Name
			orderedEntityTypes.put(entityType.getName(), entityType);
		}

		AppDBTable newAppDBTable = null;
		int seqNo = 0;
		for (EntityType<?> entityType : orderedEntityTypes.values()) {
			newAppDBTable = dbAppTableMap.get(entityType.getName());
			if (newAppDBTable == null) {
				newAppDBTable = new AppDBTable();
				newAppDBTable.setName(entityType.getName());
				newAppDBTable.setDisplayLabel(entityType.getName());
				newAppDBTable.setAvailableForAppUIScreen(AppConstants.NO);
				newAppDBTable.setAvailableForReport(AppConstants.NO);
			}
			newAppDBTable.setSeqNo(seqNo);
			seqNo++;

			dbAppTableMap.remove(entityType.getName());

			newAppDBTable = this.appDBTableRepository.save(newAppDBTable);
			this.populateAttribute(entityType, newAppDBTable, dbAppTableColumnMap);
		}
		// Remove unused AppTable
		for (Entry<MultiKey, AppDBTableColumn> entry : dbAppTableColumnMap.entrySet()) {
			this.appDBTableColumnRepository.delete(entry.getValue());
		}
		for (Entry<String, AppDBTable> entry : dbAppTableMap.entrySet()) {
			this.appDBTableRepository.delete(entry.getValue());
		}
	}

}