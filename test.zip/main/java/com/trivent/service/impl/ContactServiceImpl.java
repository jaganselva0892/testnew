package com.trivent.service.impl;

import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.trivent.repository.ContactRepository;
import com.trivent.repository.UserRepository;
import com.trivent.service.ContactService;
import com.trivent.service.UserService;
import com.trivent.constants.AppConstants;
import com.trivent.dto.ContactVO;
import com.trivent.dto.UserVO;
import com.trivent.dto.base.EncryptedId;
import com.trivent.logging.LogManager;
import com.trivent.logging.Logger;
import com.trivent.models.Contact;
import com.trivent.models.User;

@Service
public class ContactServiceImpl implements ContactService {
	
	@SuppressWarnings("unused")
	private static final Logger LOGGER = LogManager.getLogger();
	
	@SuppressWarnings("unused")
	private static final String CLASS_NAME = ContactServiceImpl.class.getName();
	
	@Autowired
	ContactRepository contactRepository;
	
	@Autowired
	private UserService userService;

	@Autowired
	private UserRepository userRepository;
	
	@Override
	@Transactional
	public ContactVO saveContacts(ContactVO contactVO,UserVO userVO) {
		Contact contact;
		if (contactVO.isNew()) {
			contact = new Contact();
		} else {
			contact = this.contactRepository.findOne(contactVO.getId());
		}
		BeanUtils.copyProperties(contactVO, contact);
		Long contactId = this.contactRepository.save_contacts(
				null,
				"INSERT",
				null,
				null,
				contact.getOptLockVersion(),
				'N',
				(contact.getAddress1()!=null) ? contact.getAddress1() : null,
				(contact.getAddress2()!=null) ? contact.getAddress2() : null,
				(contact.getCity()!=null) ? contact.getCity() : null,
				(contact.getCompany()!=null) ? contact.getCompany() : null,
				(contact.getEmail()!=null) ? contact.getEmail() : null,
				(contact.getFax()!=null) ? contact.getFax() : null,
				(contact.getFirstName()!=null) ? contact.getFirstName() : null,
				(contact.getJobTitle()!=null) ? contact.getJobTitle() : null,
				(contact.getLastName()!=null) ? contact.getLastName() : null,
				(contact.getPhone()!=null) ? contact.getPhone() : null,
				(contact.getState()!=null) ? contact.getState() : null,
				(contact.getZipCode()!=null) ? contact.getZipCode() : null,
				(contact.getEntity()!=null) ? contact.getEntity() : null,
				(contact.getEntityId()!=null) ? contact.getEntityId() : null,
				(contact.getSeqNo()!=null) ? contact.getSeqNo() : null,
				(contact.getType()!=null) ? contact.getType() : null,
				userVO.getId(),
				userVO.getId(),
				(contact.getExtn()!=null) ? contact.getExtn() : null,
				(contact.getUserId()!=null) ? contact.getUserId() : null,
				(contact.getContactType()!=null) ? contact.getContactType() : null);
		System.out.println("contactId"+contactId);
		contactVO.setId(contact.getId());
		return contactVO;

	}
	@Override
	@Transactional(readOnly = true)
	public ContactVO getNewContact(Long entityId, String entity, String screen, EncryptedId caseId,UserVO userVO) {
		Long accountId = null;
		entityId= new Long(5233);
		ContactVO contactVO = new ContactVO();
		contactVO.setEntity(entity);
		contactVO.setEntityId(entityId);
		Integer seqNo = this.contactRepository.getLastSeqNo(entity, entityId);
		if (seqNo == null) {
			seqNo = AppConstants.ZERO;
		}
		seqNo++;
		contactVO.setSeqNo(seqNo);
		contactVO.setSourceScreenName(screen);
		if (caseId != null) {
			contactVO.setCaseId(caseId.getId());
		}
		if (entity.equals("User")) {
			User user = this.userRepository.findOne(entityId);
			if (user.getType() != null) {
				if (user.getType().equals(AppConstants.TYPE_CLIENT)) {
					accountId = user.getAccount().getId();
				}
			}
		}
		Map<Long, String> usersMap = this.userService.getAccountClientUsers(accountId,userVO);
		contactVO.setUsersMap(usersMap);
		return contactVO;
	}
	@Override
	@Transactional(readOnly = true)
	public UserVO getUserDetails(Long userId) {
		User user = this.userRepository.findOne(userId);
		return new UserVO(user);
	}
}
