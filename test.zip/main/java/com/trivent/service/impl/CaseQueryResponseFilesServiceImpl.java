package com.trivent.service.impl;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.jasypt.encryption.StringEncryptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.trivent.constants.AppConstants;
import com.trivent.dto.CaseQueryResponseFilesVO;
import com.trivent.models.CaseQueryResponseFiles;
import com.trivent.logging.LogManager;
import com.trivent.logging.Logger;
import com.trivent.repository.CaseQueryResponseFilesRepository;
import com.trivent.repository.UserRepository;
import com.trivent.service.CaseQueryResponseFilesService;

/**
 * @FileName 	:
 *				CaseQueryResponseFilesServiceImpl.java
 * @ClassName 	:
 * 				CaseQueryResponseFilesServiceImpl
 * @DateAndTime :
 *				Feb 7, 2018 - 12:23:11 PM
 * 
 * @Author 		:
 * 				Ramya
 * 
 * @Description : 
 * 				Its to download attachment and save caseQueryfiles
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Service
public class CaseQueryResponseFilesServiceImpl implements CaseQueryResponseFilesService {

	
	private static final Logger LOGGER = LogManager.getLogger();
	
	private static final String CLASS_NAME = CaseQueryResponseFilesServiceImpl.class.getName();

	
	@Autowired
	UserRepository userRepository;

	
	@Autowired
	StringEncryptor stringEncryptor;

	
	@Autowired
	CaseQueryResponseFilesRepository caseQueryResponseFilesRepository;

	
	@Value("${email.save.to.this.location}")
	private String emailSaveLoc;

	/*(non-Javadoc)[Overriding Method]
	 * @OverridingMethod 	: @see com.trivent.service.CaseQueryResponseFilesService#downloadAttachmentFile(java.lang.Long, javax.servlet.http.HttpServletResponse)
	 * 				
	 * @DateAndTime 		: Feb 7, 2018 - 12:23:11 PM
	 * 
	 * @Author 				: Ramya
	 * 
	 * @Description 		: Its to downloadAttachmentsFile
	 * 				
	 * @Tags 				: 
	 *						@param queryResFileId - download by using queryResFileId
	 *						@param response - http response
	 * @Git_Config 			: 
	 *		 				name
	 * 						email
	 * 
	 */
	@Override
	@Transactional
	public void downloadAttachmentFile(Long queryResFileId, HttpServletResponse response) {
		CaseQueryResponseFiles caseQueryResponseFiles = this.caseQueryResponseFilesRepository.findOne(queryResFileId);
		Path filePath = Paths.get(
				this.emailSaveLoc + caseQueryResponseFiles.getFileDirectory() + caseQueryResponseFiles.getFileName());
          response.setHeader(AppConstants.RESPONSE_HEADER_CONTENT_DISP, AppConstants.RESPONSE_ATTACH_PREFIX
				+ caseQueryResponseFiles.getFileName() + AppConstants.RESPONSE_ATTACH_SUFFIX);

		try (InputStream is = new FileInputStream(filePath.toFile()); OutputStream os = response.getOutputStream()) {
			// Large File Copy - Use Apache IO
			IOUtils.copyLarge(is, os);
			response.flushBuffer();
		} catch (IOException ex) {
			LOGGER.error(CLASS_NAME, "downloadAttachmentFile", ex);
		}
		return;
	}

	/*(non-Javadoc)[Overriding Method]
	 * @OverridingMethod 	: @see com.trivent.service.CaseQueryResponseFilesService#saveCaseQueryResponseFile(java.lang.Long, com.trivent.dto.CaseQueryResponseFilesVO)
	 * 				
	 * @DateAndTime 		: Feb 7, 2018 - 12:23:11 PM
	 * 
	 * @Author 				: Ramya
	 * 
	 * @Description 		: Its to saveCaseQueryResponseFile
	 * 				
	 * @Tags 				: 
	 *						@param caseQueryResponseId - save by using caseQueryResponseId
	 *						@param caseQueryResponseFilesVO - get require field by path variable caseQueryResponseFilesVO
	 *						@return CaseQueryResponseFiles - caseQueryResponseFiles
	 * @Git_Config 			: 
	 *		 				name
	 * 						email
	 * 
	 */
	@Override
	@Transactional
	public CaseQueryResponseFiles saveCaseQueryResponseFile(Long caseQueryResponseId,
			CaseQueryResponseFilesVO caseQueryResponseFilesVO) {
		try {
			CaseQueryResponseFiles caseQueryResponseFiles = new CaseQueryResponseFiles();
			caseQueryResponseFiles.setCaseQueryResponseId(caseQueryResponseId);
			caseQueryResponseFiles.setFileName(caseQueryResponseFilesVO.getFileName());
			caseQueryResponseFiles.setFileExtension(caseQueryResponseFilesVO.getFileExtension());
			caseQueryResponseFiles.setFileDirectory(caseQueryResponseFilesVO.getFileDirectory());
			caseQueryResponseFiles.setIsDeleted(AppConstants.NO);
			caseQueryResponseFiles.setFileSize(caseQueryResponseFilesVO.getFileSize());
			caseQueryResponseFiles = this.caseQueryResponseFilesRepository.save(caseQueryResponseFiles);
			return caseQueryResponseFiles;
		} catch (Exception er) {
			LOGGER.error(CLASS_NAME, "saveCaseQueryResponseFile", er);
			return null;
		}
	}
}
