package com.trivent.service.impl;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Properties;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.domain.Specifications;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.trivent.constants.AppConstants;
import com.trivent.dto.AppConfigDataVO;
import com.trivent.dto.AppItemVO;
import com.trivent.dto.AppUIScreenFilterVO;
import com.trivent.dto.CaseQueryResponseFilesVO;
import com.trivent.dto.CaseQueryResponseVO;
import com.trivent.dto.CaseQueryVO;
import com.trivent.dto.RowVO;
import com.trivent.dto.ScreenListFilterVO;
import com.trivent.dto.UserVO;
import com.trivent.exceptions.TriventException;
import com.trivent.logging.LogManager;
import com.trivent.logging.Logger;
import com.trivent.models.Account;
import com.trivent.models.AppItem;
import com.trivent.models.AppList;
import com.trivent.models.AppUIScreenView;
import com.trivent.models.Case;
import com.trivent.models.CaseContacts;
import com.trivent.models.CaseQuery;
import com.trivent.models.CaseQueryFlag;
import com.trivent.models.CaseQueryResponse;
import com.trivent.models.EmailQueue;
import com.trivent.models.EmailTemplate;
import com.trivent.models.Partner;
import com.trivent.models.Role;
import com.trivent.models.User;
import com.trivent.models.UserProfile;
import com.trivent.repository.AppDBTableRepository;
import com.trivent.repository.AppItemRepository;
import com.trivent.repository.CaseContactsRepository;
import com.trivent.repository.CaseQueryFlagRepository;
import com.trivent.repository.CaseQueryRepository;
import com.trivent.repository.CaseQueryResponseRepository;
import com.trivent.repository.CaseRepository;
import com.trivent.repository.PartnerRepository;
import com.trivent.repository.ReportRepository;
import com.trivent.repository.RoleRepository;
import com.trivent.repository.UserRepository;
import com.trivent.repository.specifications.GenericSpecifications;
import com.trivent.service.AccountService;
import com.trivent.service.AppConfigDataService;
import com.trivent.service.AppConfigService;
import com.trivent.service.CacheService;
import com.trivent.service.CaseQueryResponseFilesService;
import com.trivent.service.CaseQueryService;
import com.trivent.service.CaseService;
import com.trivent.service.EmailService;
import com.trivent.service.EmailTemplateService;
import com.trivent.service.PartnerService;
import com.trivent.service.UserService;
import com.trivent.utils.CommonUtils;
import com.trivent.utils.FilterUtils;

/**
 * @FileName : CaseQueryServiceImpl.java
 * @ClassName : CaseQueryServiceImpl
 * @DateAndTime : Feb 8, 2018 - 10:31:47 AM
 * 
 * @Author : Ramya
 * 
 * @Description : Its to get caseQuery,list query,update,save,email,delete case
 *              Query.
 * @Tags :
 * @Git_Config : name email
 * 
 */
@Service
public class CaseQueryServiceImpl implements CaseQueryService {

	private static final Logger LOGGER = LogManager.getLogger();

	private static final String CLASS_NAME = CaseQueryServiceImpl.class.getName();

	private static final String METHOD_LIST_APP_QUERIES = "listAppQueries";

	@Autowired
	private CaseQueryResponseRepository caseQueryResponseRepository;

	@Autowired
	private CaseQueryRepository caseQueryRepository;

	@Autowired
	private UserService userService;

	@Autowired
	private GenericSpecifications<CaseQuery> genericSpecifications;

	@Autowired
	private GenericSpecifications<CaseQueryResponse> caseQueryResponseGenericSpecifications;

	@Autowired
	private AccountService accountService;

	@Autowired
	private CaseService caseService;

	@Autowired
	private FilterUtils<CaseQuery> filterUtils;

	@Autowired
	private CaseContactsRepository caseContactsRepository;

	@Autowired
	private AppItemRepository appItemRepository;

	@SuppressWarnings("unused")
	@Autowired
	private AppDBTableRepository appDBTableRepository;

	@Autowired
	private ReportRepository reportRepository;

	@Autowired
	private CaseRepository caseRepository;

	@Autowired
	private RoleRepository roleRepository;

	@Autowired
	private Properties applicationProperties;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private PartnerRepository partnerRepository;

	@Value("${email.internal.employee.code}")
	private String emailInternalTo;

	@Value("${email.emp.subject.prefix}")
	private String subjectPrefix;

	@Value("${email.save.to.this.location}")
	private String emailSaveLoc;

	@Autowired
	private CaseQueryFlagRepository caseQueryFlagRepository;

	@Autowired
	private CaseQueryResponseFilesService caseQueryResponseFilesService;

	@Autowired
	private GenericSpecifications<CaseQueryFlag> caseQueryFlagGenericSpecifications;

	@Autowired
	private PartnerService partnerService;

	@Autowired
	private AppConfigService appConfigService;

	@Autowired
	private AppConfigDataService appConfigDataService;

	@Autowired
	private EmailTemplateService emailTemplateService;

	@Autowired
	private EmailService emailService;
	
	@Autowired
	private CacheService cacheService;

	@Override
	public DateTime updateCaseQueryModifiedDate(Long queryId) {
		DateTime dateTme = new DateTime();
		try {
			List<CaseQueryResponse> caseQueryRes = this.caseQueryResponseRepository
					.getCaseQueryListOrderByModifiedDate(queryId, AppConstants.NO);
			if (caseQueryRes.size() != 0) {
				Optional<CaseQueryResponse> caseQueryResponse = caseQueryRes.stream().findFirst();
				if (caseQueryResponse.isPresent()) {
					CaseQueryResponse subCaseDetail = caseQueryResponse.get();
					DateTime caseQueryRespTime = subCaseDetail.getLastModifiedDate();
					dateTme = caseQueryRespTime;
				} else {
				}
			} else {
				CaseQuery caseQuery = this.caseQueryRepository.findOne(queryId);
				DateTime caseQueryTime = caseQuery.getLastModifiedDate();
				dateTme = caseQueryTime;
			}

		} catch (Exception ex) {
			LOGGER.error(CLASS_NAME, "updateCaseQueryLastModifiedDate", ex);
		}
		return dateTme;
	}

	@Override
	@Transactional
	public ScreenListFilterVO getDefaultScreenListFilterVO() throws TriventException {
		// AppDBTable appdbTable = this.appDBTableRepository.findByName("Case");
		String screenType = AppConstants.SCREEN_TYPE_LIST;
		return this.filterUtils.populateScreenListFilterVO(new Long(15), screenType);
	}

	@SuppressWarnings("deprecation")
	@Override
	@Transactional
	public List<RowVO> listQueries(ScreenListFilterVO screenListFilterVO, String type, String fromDate, String toDate,
			String partner, UserVO userVO) throws TriventException {
		User loginUser = this.userService.getCurrentUser(userVO);
		// AppDBTable appdbTable = this.appDBTableRepository.findByName("CaseQuery");
		String screenType = AppConstants.SCREEN_TYPE_LIST;
		List<CaseQuery> caseQueries = null;

		if (loginUser.getType().equals(AppConstants.TYPE_CLIENT)
				&& !screenListFilterVO.getSelectedViewType().equals(AppUIScreenView.VIEW_CLIENT)) {
			LOGGER.warn(CLASS_NAME, METHOD_LIST_APP_QUERIES, "Invalid UI View Configured. Client can't view task.");
			return new ArrayList<>(1);
		}

		Specification<CaseQuery> specification = null;
		Specifications<CaseQuery> specifications = Specifications
				.where(this.genericSpecifications.dataTypeCharacter("deleted", AppConstants.NO));

		// Global Search Functionality Start Here.....
		List<AppUIScreenFilterVO> appUIScreenFilterVOlist = new ArrayList<>();
		AppUIScreenFilterVO appUIScreenFilterVOSrearch = new AppUIScreenFilterVO();

		for (AppUIScreenFilterVO app : screenListFilterVO.getAppUIScreenFilterVOs()) {
			if (app.getDbFieldName().equalsIgnoreCase("search")) {
				appUIScreenFilterVOSrearch = app;
			} else {
				appUIScreenFilterVOlist.add(app);
			}
		}
		screenListFilterVO.setAppUIScreenFilterVOs(appUIScreenFilterVOlist);
		Specifications<CaseQueryResponse> specificationCaseRes = Specifications
				.where(this.caseQueryResponseGenericSpecifications.dataTypeCharacter("deleted", AppConstants.NO));

		if (appUIScreenFilterVOSrearch != null && StringUtils.isNotBlank(appUIScreenFilterVOSrearch.getValue())
				&& StringUtils.isNotEmpty(appUIScreenFilterVOSrearch.getValue())) {
			String globalSearch = appUIScreenFilterVOSrearch.getValue();
			if (!globalSearch.isEmpty()) {
				// Case Query Global Search
				Specifications<CaseQuery> specificationsSearch = Specifications
						.where(this.genericSpecifications.dataTypeCaseQueryLikePattern("querySubject", globalSearch));
				// Status
				specificationsSearch = specificationsSearch
						.or(this.genericSpecifications.dataTypeCaseQueryLikePattern("status", globalSearch));
				// Query Type
				specificationsSearch = specificationsSearch
						.or(this.genericSpecifications.dataTypeCaseQueryLikePattern("query_type", globalSearch));
				// QuerySubType
				specificationsSearch = specificationsSearch
						.or(this.genericSpecifications.dataTypeCaseQueryLikePattern("querySubtype", globalSearch));
				// QueryPartner
				specificationsSearch = specificationsSearch
						.or(this.genericSpecifications.dataTypeCaseQueryLikePattern("queryPartnerBean", globalSearch));

				// Account
				List<Account> accountList = this.accountService.getAccountByName(globalSearch);
				if (accountList.size() != 0)
					specificationsSearch = specificationsSearch
							.or(this.genericSpecifications.anyAccount("account", accountList));

				// Case
				List<Case> caseList = this.caseService.getCaseByName(globalSearch);
				if (caseList.size() != 0)
					specificationsSearch = specificationsSearch
							.or(this.genericSpecifications.dataTypeCaseList("clientCase", caseList));

				List<User> userList = this.userService.getUserByName(globalSearch);
				if (userList.size() != 0) {
					// Client
					specificationsSearch = specificationsSearch
							.or(this.genericSpecifications.anyUsers("client", userList));
					// AssignedTo
					specificationsSearch = specificationsSearch
							.or(this.genericSpecifications.anyUsers("assignedTo", userList));
				}

				// Case Response Global Search
				Specifications<CaseQueryResponse> specificationsCaseRes = Specifications.where(
						this.caseQueryResponseGenericSpecifications.dataTypeString("queryDetails", globalSearch));
				specificationsCaseRes = specificationsCaseRes
						.or(this.caseQueryResponseGenericSpecifications.dataTypeString("queryDisplay", globalSearch));
				specificationCaseRes = specificationCaseRes.and(specificationsCaseRes);

				List<CaseQueryResponse> caseQueryResponse = this.caseQueryResponseRepository
						.findAll(specificationCaseRes);
				List<Long> caseQueryIDList = new ArrayList<Long>();
				List<Long> caseQueryResIDList = new ArrayList<Long>();
				if (caseQueryResponse.size() > 0) {
					for (CaseQueryResponse caseQryResponse : caseQueryResponse)
						caseQueryResIDList.add(caseQryResponse.getId());

					// Lambda Expression
					/*
					 * caseQueryResponse.stream().filter(caseQryResponse -> caseQryResponse!=null)
					 * .forEach(caseQryResponse -> caseQueryResIDList.add(caseQryResponse.getId())
					 * );
					 */
				}
				if (caseQueryResIDList.size() > 0)
					caseQueryIDList = this.caseQueryResponseRepository.CaseQueryIDForGlobalSearch(caseQueryResIDList);

				if (caseQueryIDList.size() > 0)
					specificationsSearch = specificationsSearch
							.or(this.genericSpecifications.dataTypeLongList("id", caseQueryIDList));

				specifications = specifications.and(specificationsSearch);
			}
		}

		List<Partner> partnerList = this.filterUtils.hasPartnerFilter(loginUser);
		Specifications<CaseQuery> specificationsNew = null;
		for (Partner partner1 : partnerList) {
			// if ((partner1 != null) && (partner.equals(partner1.getId().toString())) ||
			// (partner.equals(partner1.getPartnerCode()))) {
			String filterPCode = "[" + partner1.getPartnerCode() + "-";
			Specification<CaseQuery> specificationnew = this.genericSpecifications
					.dataTypeCaseQueryLikePattern("querySubject", filterPCode);
			if (specificationsNew == null) {
				specificationsNew = Specifications.where(specificationnew);
			} else {
				specificationsNew = specificationsNew.or(specificationnew);
			}
		}
		// }

		specifications = specifications.and(specificationsNew);

		if (loginUser.getType().equalsIgnoreCase(AppConstants.TYPE_CLIENT)) {
			Specifications<CaseQuery> specificationOr1 = Specifications
					.where(this.genericSpecifications.dataTypeCharacter("isVisible2Client", AppConstants.YES));
			specifications = specifications.and(specificationOr1);

			Specifications<CaseQuery> specificationOr = Specifications
					.where(this.genericSpecifications.dataTypeString("queryTo", loginUser.getLoginId()));
			specificationOr = specificationOr.or(specification);
			specification = this.genericSpecifications.dataTypeUser("createdBy", loginUser);
			specificationOr = specificationOr.or(specification);
			specification = this.genericSpecifications.dataTypeUser("client", loginUser);
			specificationOr = specificationOr.or(specification);

			List<Long> caseQueryIds = new ArrayList<>();
			List<CaseContacts> caseContacts = this.caseContactsRepository.listCaseContactsByLoginUser(AppConstants.NO,
					loginUser);
			for (CaseContacts caseContact : caseContacts) {
				if (caseContact.getCaseid() != null) {
					List<CaseQuery> caseQueryList = this.caseQueryRepository
							.CaseCsQueriesByCaseIdAPI(caseContact.getCaseid().getId());
					for (CaseQuery caseQuery : caseQueryList) {
						Long caseQueryId = caseQuery.getId();
						caseQueryIds.add(caseQueryId);
					}
					// Lambda Expression
					/*
					 * caseQueryList.stream().filter(caseQuery -> caseQuery.getId()!=null)
					 * .forEach(caseQuery -> caseQueryIds.add(caseQuery.getId()) );
					 */
				}

			}
			if (caseQueryIds.size() > 0) {
				specificationOr = specificationOr.or(this.genericSpecifications.dataTypeLongList("id", caseQueryIds));
			}

			specifications = specifications.and(specificationOr);
		} else {
			if (!loginUser.getRole().getType().equalsIgnoreCase(Role.ROLE_TYPE_CS_ROLES)) {
				Specifications<CaseQuery> specificationNew = Specifications
						.where(this.genericSpecifications.dataTypeUser("assignedTo", loginUser));
				specificationNew = specificationNew.or(specification);
				specification = this.genericSpecifications.dataTypeString("queryFrom", loginUser.getLoginId());
				specificationNew = specificationNew.or(specification);
				specification = this.genericSpecifications.dataTypeString("queryTo", loginUser.getLoginId());
				specificationNew = specificationNew.or(specification);
				specification = this.genericSpecifications.dataTypeString("queryCc", loginUser.getLoginId());
				specificationNew = specificationNew.or(specification);
				specification = this.genericSpecifications.dataTypeString("queryBcc", loginUser.getLoginId());
				specificationNew = specificationNew.or(specification);
				specifications = specifications.and(specificationNew);
			}
		}
		if (loginUser.getRole().getType().equalsIgnoreCase(Role.ROLE_TYPE_CS_ROLES)) {
			if (screenListFilterVO.getSelectedViewType().equals(AppUIScreenView.VIEW_ASSIGNED)) {
				specification = this.genericSpecifications.dataTypeUser("assignedTo", loginUser);
			}
		}

		if ((type != null) && (partner == null) && (fromDate == null) && (toDate == null)) {
			Long appItem = this.appItemRepository.findAppItemIDByLongName(type);

			java.util.Date date = new java.util.Date();
			java.util.Date date1 = new java.util.Date();
			date1.setHours(0);
			date1.setMinutes(0);
			date1.setSeconds(0);
			Specifications<CaseQuery> specificationNew = null;
			if (!Objects.equals(type, AppConstants.QUERY_NON_CATEGORY)) {
				specificationNew = Specifications.where(
						this.genericSpecifications.dataTypeCaseQueryLikePattern("query_type", appItem.toString()));
			} else {
				specificationNew = Specifications
						.where(this.genericSpecifications.dataTypeParentTaskNull("query_type", null));
			}

			specificationNew = specificationNew.and(specification);
			specification = this.genericSpecifications.dataTypeDate("createdDate", date1, date);
			specificationNew = specificationNew.and(specification);
			specifications = specifications.and(specificationNew);

		}

		if ((type != null) && (partner != null) && (fromDate == null) && (toDate == null)) {
			Long appItem = this.appItemRepository.findAppItemIDByLongName(type);
			java.util.Date date = new java.util.Date();
			java.util.Date date1 = new java.util.Date();
			date1.setHours(0);
			date1.setMinutes(0);
			date1.setSeconds(0);
			Specifications<CaseQuery> specificationNew = null;
			if (!Objects.equals(type, AppConstants.QUERY_NON_CATEGORY)) {
				specificationNew = Specifications.where(
						this.genericSpecifications.dataTypeCaseQueryLikePattern("query_type", appItem.toString()));
			} else {
				specificationNew = Specifications
						.where(this.genericSpecifications.dataTypeParentTaskNull("query_type", null));
			}

			specificationNew = specificationNew.and(specification);
			specification = this.genericSpecifications.dataTypeDate("createdDate", date1, date);
			specificationNew = specificationNew.and(specification);
			specifications = specifications.and(specificationNew);
		}
		if ((type != null) && (partner == null) && (fromDate != null) && (toDate != null)) {
			Long appItem = this.appItemRepository.findAppItemIDByLongName(type);

			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss zzz");

			try {
				String fdate = formatter.format(new Date(fromDate));
				Date dfdate = formatter.parse(fdate);
				dfdate.setHours(0);
				dfdate.setMinutes(0);
				dfdate.setSeconds(0);

				String tdate = formatter.format(new Date(toDate));
				Date dtdate = formatter.parse(tdate);
				dtdate.setHours(23);
				dtdate.setMinutes(59);
				dtdate.setSeconds(59);

				Specifications<CaseQuery> specificationNew = null;
				if (!Objects.equals(type, AppConstants.QUERY_NON_CATEGORY)) {
					specificationNew = Specifications.where(
							this.genericSpecifications.dataTypeCaseQueryLikePattern("query_type", appItem.toString()));
				} else {
					specificationNew = Specifications
							.where(this.genericSpecifications.dataTypeParentTaskNull("query_type", null));
				}

				specificationNew = specificationNew.and(specification);
				specification = this.genericSpecifications.dataTypeDate("createdDate", dfdate, dtdate);
				specificationNew = specificationNew.and(specification);
				specifications = specifications.and(specificationNew);

			} catch (ParseException ex) {
				LOGGER.error(CLASS_NAME, "dateFilter", ex);
			}
		}
		if ((type != null) && (partner != null) && (fromDate != null) && (toDate != null)) {
			Long appItem = this.appItemRepository.findAppItemIDByLongName(type);

			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss zzz");
			try {
				String fdate = formatter.format(new Date(fromDate));
				Date dfdate = formatter.parse(fdate);
				dfdate.setHours(0);
				dfdate.setMinutes(0);
				dfdate.setSeconds(0);
				String tdate = formatter.format(new Date(toDate));
				Date dtdate = formatter.parse(tdate);
				dtdate.setHours(23);
				dtdate.setMinutes(59);
				dtdate.setSeconds(59);
				Specifications<CaseQuery> specificationNew = null;
				if (!Objects.equals(type, AppConstants.QUERY_NON_CATEGORY)) {
					specificationNew = Specifications.where(
							this.genericSpecifications.dataTypeCaseQueryLikePattern("query_type", appItem.toString()));
				} else {
					specificationNew = Specifications
							.where(this.genericSpecifications.dataTypeParentTaskNull("query_type", null));
				}

				specificationNew = specificationNew.and(specification);
				specification = this.genericSpecifications.dataTypeDate("createdDate", dfdate, dtdate);
				specificationNew = specificationNew.and(specification);
				specifications = specifications.and(specificationNew);
			} catch (ParseException ex) {
				LOGGER.error(CLASS_NAME, "PartnerWithDateFilter", ex);
			}
		}

		specifications = this.filterUtils.populateCaseViewSpecifications(screenListFilterVO, loginUser, specifications);

		specifications = this.filterUtils.populateCaseFilterSpecifications(screenListFilterVO, specifications);

		Specification<CaseQuery> specificationnew = this.genericSpecifications.dataTypeCharacter("deleted",
				AppConstants.NO);
		specifications = specifications.and(specificationnew);

		// Convert the list of specifications to single specification
		specification = specifications;

		Page<CaseQuery> requestedPage = this.caseQueryRepository.findAll(specification,
				this.filterUtils.constructPageSpecification(screenListFilterVO));

		if (screenListFilterVO.getPageNo() > requestedPage.getTotalPages()) {
			// Reset the page no, if any other filter has been changed.
			screenListFilterVO.setPageNo(1);
			requestedPage = this.caseQueryRepository.findAll(specification,
					this.filterUtils.constructPageSpecification(screenListFilterVO));
		}

		if (appUIScreenFilterVOSrearch != null && StringUtils.isNotBlank(appUIScreenFilterVOSrearch.getDbFieldName())) {
			screenListFilterVO.getAppUIScreenFilterVOs().add(appUIScreenFilterVOSrearch);
		}

		// Pagination Items
		caseQueries = requestedPage.getContent();

		// Pagination Values
		screenListFilterVO.setTotalPages(requestedPage.getTotalPages());
		screenListFilterVO.setCurrentRecords(requestedPage.getNumberOfElements());
		screenListFilterVO.setTotalRecords(requestedPage.getTotalElements());
		// Dynamic valueMap for dynamically generated columns
		List<RowVO> updateRowVOs = new ArrayList<>();
		List<RowVO> updatedRowVOs = new ArrayList<>();
		List<RowVO> rowVOs = this.filterUtils.listScreenDetails(new Long(15), screenType, caseQueries);

		List<Long> lllQueryId = rowVOs.stream().parallel().filter(p -> p.getId() != null).sequential()
				.map(p -> new Long(p.getId())).collect(Collectors.toCollection(ArrayList::new));

		List<String> llsFlag = new ArrayList<String>();
		List<RowVO> rowVOsReturn = new ArrayList<RowVO>();
		List<RowVO> rowVOsReturn1 = new ArrayList<RowVO>();
		llsFlag.add(AppConstants.CASE_QUERY_TYPE_FLAG);
		if (lllQueryId != null && !lllQueryId.isEmpty() && lllQueryId.size() > 0) {
			List<Object[]> queryDetails = this.reportRepository.ListCaseQueryDetails(loginUser.getId(), llsFlag,
					lllQueryId);
			if (queryDetails != null && !queryDetails.isEmpty() && queryDetails.size() > 0) {
				for (RowVO rowVO : rowVOs) {
					if (rowVO.getId() == null) {
						rowVOsReturn.add(rowVO);
						continue;
					}
					final Long rowId = rowVO.getId();
					List<Object[]> queryUpdate = queryDetails.stream().parallel().filter(
							p -> p != null && p[0] != null && p[0].toString().equalsIgnoreCase(rowId.toString()))
							.map(p -> p).collect(Collectors.toCollection(ArrayList::new));

					if (queryUpdate != null && !queryUpdate.isEmpty() && queryUpdate.size() > 0) {
						Map<String, String> queryFlagMap = rowVO.getValueMap();

						if (queryFlagMap == null || queryFlagMap.isEmpty() || queryFlagMap.size() == 0) {
							queryFlagMap = new HashMap<>();
						}
						Object[] objQueryDetail = queryUpdate.get(0);

						String fileDownload = (objQueryDetail != null && objQueryDetail[2] != null
								&& new Long(objQueryDetail[2].toString()) > 0) ? "Y" : "N";
						queryFlagMap.put(AppConstants.FILE_DOWNLOAD_ICON, fileDownload);

						String strQueryFlag = (objQueryDetail != null && objQueryDetail[3] != null
								&& new Long(objQueryDetail[3].toString()) > 0) ? "Y" : "N";
						queryFlagMap.put(AppConstants.QUERY_FLAG, strQueryFlag);

						strQueryFlag = (objQueryDetail != null && objQueryDetail[4] != null
								&& new Long(objQueryDetail[4].toString()) > 0) ? "N" : "Y";
						queryFlagMap.put(AppConstants.QUERY_OPEN, strQueryFlag);

						rowVO.setValueMap(queryFlagMap);
						if (strQueryFlag.equalsIgnoreCase("N")) {
							rowVOsReturn.add(rowVO);
						} else {
							rowVOsReturn1.add(rowVO);
						}

					} else {
						rowVOsReturn1.add(rowVO);
					}
				}

				rowVOsReturn.addAll(rowVOsReturn1);

				updatedRowVOs.addAll(rowVOsReturn);
				updateRowVOs.addAll(rowVOsReturn);

			}
		}
		return updateRowVOs;
	}

	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.CaseQueryService#savecaseQuery(com.trivent.dto.
	 * CaseQueryVO)
	 * 
	 * @DateAndTime : Feb 8, 2018 - 10:31:47 AM
	 * 
	 * @Author : Ramya
	 * 
	 * @Description : Its to save case Query
	 * 
	 * @Tags :
	 * 
	 * @param caseQueryVO - get required field by path variable caseQueryVO
	 * 
	 * @return CaseQueryVO - caseQueryVO
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@SuppressWarnings("unused")
	@Override
	@Transactional
	public CaseQueryVO savecaseQuery(CaseQueryVO caseQueryVO, UserVO userVO) {
		CaseQuery caseQuery = null;
		CaseQueryResponse caseQueryResponse = null;
		User assignedToUser = null;
		User queryToUser = null;
		User preUserAssignedTo = null;
		String queryEmailSendBean = null;

		User loginUser = this.userService.getCurrentUser(userVO);
		if (caseQueryVO.isNew()) {
			caseQuery = new CaseQuery();
			BeanUtils.copyProperties(caseQueryVO, caseQuery);
			if (caseQueryVO.getCaseId() != null) {
				Case clientCase = this.caseRepository.findOne(caseQueryVO.getCaseId());

				// Temperory ParentCase Caseid Override Here
				if (clientCase.getId() != null) {
					if (clientCase.getParentCase() == null) {
						caseQuery.setClientCase(clientCase);
					} else {
						Case appCaseNew = caseRepository.findOne(clientCase.getParentCase().getId());
						caseQuery.setClientCase(appCaseNew);
					}
				}

				// caseQuery.setClientCase(clientCase);
				caseQuery.setAccount(clientCase.getAccount());
				caseQuery.setClient(clientCase.getClient());
				caseQuery.setSeqNo(this.caseQueryRepository.getNextQuerySeqNoByCaseId(caseQueryVO.getCaseId()) + 1);
				queryEmailSendBean = clientCase.getAccount().getPartner().getPartnerCode().toLowerCase();
				String contactEmail = clientCase.getEmailId();
				if (loginUser.getType().equalsIgnoreCase(AppConstants.TYPE_CLIENT)) {
					if (!StringUtils.isEmpty(contactEmail)) {
						String clientEmail = clientCase.getClient().getLoginId();
						contactEmail = contactEmail.replaceAll(";", ",");
						String[] arrContactEmail = contactEmail.split(",");
						String strQueryCC = "";
						for (String strContact : arrContactEmail) {
							if (!strContact.equals(clientEmail)) {
								strQueryCC = (strQueryCC == "") ? strContact : strQueryCC + "," + strContact;
							}
						}
						String queryCC = caseQueryVO.getQueryCc();
						queryCC = (StringUtils.isEmpty(queryCC)) ? contactEmail : queryCC + "," + contactEmail;
						caseQueryVO.setQueryCc(queryCC);
					}
				}
			}
			caseQuery.setIsInternal(caseQueryVO.getIsInternal() ? AppConstants.YES : AppConstants.NO);
			caseQuery.setIsVisible2Client(caseQueryVO.getIsVisible2Client() ? AppConstants.YES : AppConstants.NO);
			caseQuery.setIsEmailNotify(caseQueryVO.getIsEmailNotify() ? AppConstants.YES : AppConstants.NO);
			caseQuery.setIsNewQuery(AppConstants.YES);
			caseQuery.setOwnerRoleType(loginUser.getRole().getType());
			if (loginUser.getType().equalsIgnoreCase(AppConstants.TYPE_CLIENT)) {
				caseQueryVO.setQueryFrom(loginUser.getLoginId());
				caseQueryVO.setQuerySource(AppConstants.QUERY_SOURCE_PORTAL);
				caseQuery.setAccount(loginUser.getAccount());
				caseQuery.setClient(loginUser);
				caseQueryResponse = new CaseQueryResponse();
				caseQueryResponse.setQueryTo(caseQueryVO.getQueryTo());
				caseQueryResponse.setQueryCc(caseQueryVO.getQueryCc());
				caseQueryResponse.setQueryBcc(caseQueryVO.getQueryBcc());

			}

			caseQueryResponse = new CaseQueryResponse();
			caseQueryResponse.setQueryFrom(caseQueryVO.getQueryFrom());
			CaseQueryResponseVO caseQueryResponseVO = caseQueryVO.getCaseQueryResponseVO();
			StringBuffer outBuffer = new StringBuffer();
			String queryDetails = outBuffer.toString();
			if(caseQueryResponseVO!=null) {
				queryDetails = caseQueryResponseVO.getQueryDetails();
				final String name = CommonUtils.uniCodeToString(queryDetails);
				caseQueryResponseVO.setQueryDetails(name);
				caseQueryResponse.setQueryDetails(name);
			}
			
			caseQueryVO.setCaseQueryResponseVO(caseQueryResponseVO);
			// caseQueryResponse.setQueryDetails(caseQueryVO.getCaseQueryResponseVO().getQueryDetails());
			caseQueryResponse.setQueryTo(caseQueryVO.getQueryTo());
			caseQueryResponse.setQueryCc(caseQueryVO.getQueryCc());
			caseQueryResponse.setQueryBcc(caseQueryVO.getQueryBcc());
			if (caseQueryVO.getCaseId() != null) {
				Case clientCase = this.caseRepository.findOne(caseQueryVO.getCaseId());
				caseQueryResponse.setClientCase(clientCase);
				caseQueryResponse.setAccount(clientCase.getAccount());
				caseQueryResponse.setClient(clientCase.getClient());
				caseQueryResponse
						.setSeqNo(this.caseQueryRepository.getNextQuerySeqNoByCaseId(caseQueryVO.getCaseId()) + 1);
			}
			caseQueryResponse.setIsInternal(caseQueryVO.getIsInternal() ? AppConstants.YES : AppConstants.NO);
			caseQueryResponse
					.setIsVisible2Client(caseQueryVO.getIsVisible2Client() ? AppConstants.YES : AppConstants.NO);
			caseQueryResponse.setIsEmailNotify(caseQueryVO.getIsEmailNotify() ? AppConstants.YES : AppConstants.NO);
			caseQueryResponse.setIsNewQuery(AppConstants.YES);
			caseQueryResponse.setOwnerRoleType(loginUser.getRole().getType());
			if (loginUser.getType().equalsIgnoreCase(AppConstants.TYPE_CLIENT)) {
				caseQueryResponse.setQueryFrom(loginUser.getLoginId());
				caseQueryResponse.setQuerySource(AppConstants.QUERY_SOURCE_PORTAL);
			}
		} else {
			caseQuery = this.caseQueryRepository.findOne(caseQueryVO.getId());
			caseQuery.setStatus(caseQueryVO.getStatus());

			// added on 19/01/2017 Query communication type
			caseQuery.setQueryType(caseQueryVO.getQueryType());
			caseQuery.setQuerySubType(caseQueryVO.getQuerySubType());

			preUserAssignedTo = caseQuery.getAssignedTo();
			/*
			 * Type: New, Code:#11, Description: Added case id in saving object if case is
			 * mapped in query, Date:19Sep2016
			 */
			if (caseQueryVO.getCaseId() != null) {
				Case clientCase = this.caseRepository.findOne(caseQueryVO.getCaseId());
				// Temperory ParentCase Caseid Override Here
				if (clientCase.getId() != null) {
					if (clientCase.getParentCase() == null) {
						caseQuery.setClientCase(clientCase);
					} else {
						Case appCaseNew = caseRepository.findOne(clientCase.getParentCase().getId());
						caseQuery.setClientCase(appCaseNew);
					}
				}

				// caseQuery.setClientCase(clientCase);
				queryEmailSendBean = clientCase.getAccount().getPartner().getPartnerCode().toLowerCase();
				String contactEmail = clientCase.getEmailId();
				if (loginUser.getType().equalsIgnoreCase(AppConstants.TYPE_CLIENT)) {
					if (!StringUtils.isEmpty(contactEmail)) {
						String clientEmail = clientCase.getClient().getLoginId();
						contactEmail = contactEmail.replaceAll(";", ",");
						String[] arrContactEmail = contactEmail.split(",");
						String strQueryCC = "";
						for (String strContact : arrContactEmail) {
							if (!strContact.equals(clientEmail)) {
								strQueryCC = (strQueryCC == "") ? strContact : strQueryCC + "," + strContact;
							}
						}
						String queryCC = caseQueryVO.getQueryCc();
						queryCC = (StringUtils.isEmpty(queryCC)) ? contactEmail : queryCC + "," + contactEmail;
						caseQueryVO.setQueryCc(queryCC);
					}
				}
			} else {
				queryEmailSendBean = this.getPartnerCodeforQueryByEmailId(caseQueryVO.getQueryTo(), userVO);

			}
			if (queryEmailSendBean == null) {
				queryEmailSendBean = caseQueryVO.getQueryPartnerBean();
			}
		}
		if (queryEmailSendBean == null) {
			queryEmailSendBean = this.getPartnerCodeforQueryByEmailId(caseQueryVO.getQueryTo(), userVO);
		}
		if (caseQueryVO.getQueryPartnerBean() == null) {
			caseQuery.setQueryPartnerBean(queryEmailSendBean);
			caseQueryVO.setQueryPartnerBean(queryEmailSendBean);
		} else {
			caseQuery.setQueryPartnerBean(caseQueryVO.getQueryPartnerBean());
		}
		// temparilrly hide
		/*
		 * if (caseQueryVO.getAssignedToUserId() != null) { assignedToUser =
		 * this.cacheService.findByUserId(caseQueryVO.getAssignedToUserId()); if
		 * (!Objects.equals(preUserAssignedTo, assignedToUser)) { if
		 * (Objects.equals(caseQuery.getClientCase(), null)) {
		 * this.caseService.sendAssignedToEmailAlert(assignedToUser, null, null,
		 * caseQuery, "caseQuery", userVO); } else {
		 * this.caseService.sendAssignedToEmailAlert(assignedToUser,
		 * caseQuery.getClientCase(), null, caseQuery, "caseQuery", userVO); } }
		 * caseQuery.setAssignedTo(assignedToUser); } else { Role role =
		 * this.roleRepository.findOne(loginUser.getRole().getId()); String roleName =
		 * this.applicationProperties.getProperty(AppConstants.ROLE_NAME); String[]
		 * arrRoleName = roleName.split(","); for (String tempNameForRoleList :
		 * arrRoleName) { if (role.getName().equalsIgnoreCase(tempNameForRoleList)) {
		 * caseQuery.setAssignedTo(queryToUser); } } }
		 */
		// caseQuery = this.caseQueryRepository.save(caseQuery);
		Long maxCaseQryId = this.caseQueryRepository.findMaxID();
		Long qrySubId = maxCaseQryId + 1;
		if (caseQueryVO.isNew() && maxCaseQryId != null) {
			// Update the Subject for NEW entry
			String strEmailId = loginUser.getLoginId();
			String strRoleType = loginUser.getRole().getType();
			if (strRoleType.equals("Customer")) {
				strEmailId = loginUser.getLoginId();
			} else {
				String[] strQueryTo = caseQueryVO.getQueryTo().split(",");
				for (String tempQuery : strQueryTo) {
					strEmailId = tempQuery;
				}
			}
			String strPartnerCode = this.getPartnerCodeforQueryByEmailId(strEmailId, userVO);
			if ((strPartnerCode != null) && (strPartnerCode != this.emailInternalTo)) {
				this.subjectPrefix = strPartnerCode.toUpperCase().trim() + "-";
			}
			if ((caseQuery != null) && (caseQuery.getClientCase() != null)
					&& (caseQuery.getClientCase().getClient() != null)
					&& (caseQuery.getClientCase().getClient().getAccount() != null)
					&& (caseQuery.getClientCase().getClient().getAccount().getPartner() != null)
					&& (caseQuery.getClientCase().getClient().getAccount().getPartner().getPartnerCode() != null)) {
				String subPrefix = caseQuery.getClientCase().getClient().getAccount().getPartner().getPartnerCode()
						.toUpperCase();
				caseQuery.setQuerySubject(
						"[" + subPrefix + "-" + qrySubId + "] " + caseQueryVO.getQuerySubject());
				caseQueryVO.setQuerySubject(
						"[" + subPrefix + "-" + qrySubId + "] " + caseQueryVO.getQuerySubject());
			} else {
				caseQuery.setQuerySubject(
						"[" + this.subjectPrefix + qrySubId + "] " + caseQueryVO.getQuerySubject());
				caseQueryVO.setQuerySubject(
						"[" + this.subjectPrefix + qrySubId + "] " + caseQueryVO.getQuerySubject());
			}
			// this.caseQueryRepository.save(caseQuery);
		}

		Long caseQueryId = this.caseQueryRepository.save_case_query(null, "INSERT", null, null, 0, 'N',
				caseQuery.getIsEmailNotify(), caseQuery.getIsInternal(), caseQuery.getIsNewQuery(),
				caseQuery.getIsVisible2Client(), caseQuery.getOwnerRoleType(), caseQuery.getQueryCc(),
				caseQuery.getQueryFrom(), caseQuery.getQuerySource(), caseQuery.getQueryTo(), caseQuery.getSeqNo(),
				caseQuery.getQuerySubject(), caseQuery.getStatus(), loginUser.getId(), loginUser.getId(),
				(caseQuery.getAccount() != null) ? caseQuery.getAccount().getId() : null,
				(caseQuery.getAssignedTo() != null) ? caseQuery.getAssignedTo().getId() : null,
				(caseQuery.getClient() != null) ? caseQuery.getClient().getId() : null,
				(caseQuery.getClientCase() != null) ? caseQuery.getClientCase().getId() : null, caseQuery.getQueryBcc(),
				caseQuery.getQueryPartnerBean(), caseQuery.getIsQueryOpen(), caseQuery.getQueryType(),
				caseQuery.getQuerySubType());
		System.out.println("caseQueryId" + caseQueryId);

		/* temporarary */
		/*
		 * if ((caseQueryResponse != null) && caseQueryResponse.isNew()) {
		 * caseQueryResponse.setCaseQuery(caseQuery); caseQueryResponse =
		 * this.caseQueryResponseRepository.save(caseQueryResponse);
		 * 
		 * List<MultipartFile> queryAttachments =
		 * caseQueryVO.getCaseQueryResponseVO().getQueryAttachedFiles(); DateFormat
		 * dateFormat = new SimpleDateFormat("yyyy-MM-dd"); Date date = new Date();
		 * String curDate = dateFormat.format(date); Long millis =
		 * System.currentTimeMillis(); String customTempPath = curDate + "/" +
		 * millis.toString() + "/"; for (MultipartFile mpf : queryAttachments) {
		 * this.saveQueryAttachmentFromPortal(caseQueryResponse.getId(), mpf,
		 * customTempPath); }
		 * caseQueryVO.getCaseQueryResponseVO().setId(caseQueryResponse.getId()); } else
		 * { /* Type: New, Code:#11, Description: update case id in saving object of
		 * query response Date:19Sep2016
		 * 
		 * List<CaseQueryResponse> queryResponseList = this.caseQueryResponseRepository
		 * .findAllByCaseQueryId(caseQueryVO.getId(), AppConstants.NO); if
		 * (caseQueryVO.getCaseId() != null) { for (CaseQueryResponse queryResponse :
		 * queryResponseList) { Case clientCase =
		 * this.caseRepository.findOne(caseQueryVO.getCaseId());
		 * queryResponse.setClientCase(clientCase);
		 * this.caseQueryResponseRepository.save(queryResponse); } } else { for
		 * (CaseQueryResponse queryResponse : queryResponseList) {
		 * queryResponse.setClientCase(null);
		 * this.caseQueryResponseRepository.save(queryResponse); } } }
		 */
		caseQueryVO.setId(caseQuery.getId());

		/*
		 * if (caseQueryVO.getIsEmailNotify().equals(true)) {
		 * this.emailForNewCaseQuery(caseQueryVO, userVO); } else { String strEmailId =
		 * loginUser.getLoginId(); String strRoleType = loginUser.getRole().getType();
		 * if (strRoleType.equals("Customer")) { strEmailId = loginUser.getLoginId(); }
		 * else { strEmailId = caseQueryVO.getQueryTo(); }
		 * this.updateQueryReadStatus(caseQueryVO.getId(), strEmailId, "", userVO); }
		 */
		return caseQueryVO;
	}

	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Feb 8, 2018 - 10:31:47 AM
	 * 
	 * @Author : Ramya
	 * 
	 * @Description : Its to get partner code for query by emailId
	 * 
	 * @Tags :
	 * @param psEmailIds
	 *            - get partner code by using psEmailIds
	 * @return String - returnCode
	 * @Git_Config : name email
	 * 
	 */
	public String getPartnerCodeforQueryByEmailId(String psEmailIds, UserVO userVO) {
		String returnCode = null;
		try {
			// String actPartnerCode = (String)
			// this.session.getAttribute(BrandingConstants.PARTNER);
			String actPartnerCode = "TZ";
			try {
				User loginUser = userService.getCurrentUser(userVO);
				if (loginUser.getRole().getType().equals(AppConstants.ROLE_CUSTOMER)) {
					return actPartnerCode;
				}

			} catch (Exception e) {
				LOGGER.error(CLASS_NAME, "getPartnerCodeforQueryByEmailId", e);
			}
			if (psEmailIds != null) {
				String[] arrEmailIds = psEmailIds.split(",");
				User loginUser = userService.getCurrentUser(userVO);
				try {
					User actUser = this.userRepository.findOne(loginUser.getId());
					if (actUser.getRole().getType().equals(AppConstants.ROLE_CUSTOMER)) {
						return actPartnerCode;
					}
					for (String tempEmailId : arrEmailIds) {
						User tpUser = this.userRepository.findByLoginId(tempEmailId.trim());
						if (tpUser != null) {
							if (tpUser.getRole().getType().equals(AppConstants.ROLE_CUSTOMER)) {
								Object[] objPartner = this.partnerRepository.findPartnerbyEmail(tempEmailId.trim());
								returnCode = objPartner[0].toString();
								return returnCode;
							} else {
								returnCode = this.emailInternalTo;
							}
						} else {
							returnCode = actPartnerCode;
						}
					}
					return returnCode;
				} catch (Exception ex) {
					return null;
				}
			} else {
				returnCode = this.emailInternalTo;
			}
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "getPartnerCodeforQueryByEmailId", e);
		}
		return returnCode;
	}

	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Feb 8, 2018 - 10:31:47 AM
	 * 
	 * @Author : Ramya
	 * 
	 * @Description : Its to save query attachment from portal
	 * 
	 * @Tags :
	 * @param caseQueryResponseID
	 *            - save by using caseQueryResponseID
	 * @param multipartFile
	 *            - save by part file
	 * @param customTempPath
	 *            - save by using tempPath
	 * @Git_Config : name email
	 * 
	 */
	public void saveQueryAttachmentFromPortal(Long caseQueryResponseID, MultipartFile multipartFile,
			String customTempPath) {

		String attFileName = multipartFile.getOriginalFilename();
		String customFilePath = this.emailSaveLoc + "/" + customTempPath;
		String filePath = customTempPath;
		LOGGER.debug(CLASS_NAME, "savecaseQueryResponse", filePath);
		if ((attFileName != "") && (attFileName != null)) {
			try {
				LOGGER.debug(CLASS_NAME, "savecaseQueryResponse", customFilePath);
				Path targetFilePath = Paths.get(customFilePath);
				LOGGER.debug(CLASS_NAME, "savecaseQueryResponse", targetFilePath.toString());
				if (!Files.exists(targetFilePath)) {
					LOGGER.debug(CLASS_NAME, "savecaseQueryResponse", targetFilePath.toString());
					Files.createDirectories(targetFilePath);
				}

				File customFile = new File(customFilePath + "/" + attFileName);
				multipartFile.transferTo(customFile);
				String directoryName = filePath;
				String contentType = multipartFile.getContentType();
				CaseQueryResponseFilesVO caseQueryResponseFilesVO = new CaseQueryResponseFilesVO();
				caseQueryResponseFilesVO.setFileName(attFileName);
				caseQueryResponseFilesVO.setFileDirectory(directoryName);
				caseQueryResponseFilesVO.setFileSize(multipartFile.getSize());
				this.caseQueryResponseFilesService.saveCaseQueryResponseFile(caseQueryResponseID,
						caseQueryResponseFilesVO);
				LOGGER.debug(CLASS_NAME, "savecaseQueryResponse", "Directory Name      :" + directoryName);
				LOGGER.debug(CLASS_NAME, "savecaseQueryResponse", "File Name           :" + attFileName);
				LOGGER.debug(CLASS_NAME, "savecaseQueryResponse", "File content type   :" + contentType);
			} catch (Exception er) {
				LOGGER.debug(CLASS_NAME, "savecaseQueryResponse", "Error in Query response attachment save");
				LOGGER.error(CLASS_NAME, "saveQueryAttachmentFromPortal", er);
			}
		}
	}

	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Feb 8, 2018 - 10:31:47 AM
	 * 
	 * @Author : Ramya
	 * 
	 * @Description : Its to update the query status
	 * 
	 * @Tags :
	 * @param caseQueryId
	 *            - update by caseQueryId
	 * @param toEmailIds
	 *            - get toEmailIds to update
	 * @param ccEmailIds
	 *            - get ccEmailIds to update
	 * @Git_Config : name email
	 * 
	 */
	public void updateQueryReadStatus(Long caseQueryId, String toEmailIds, String ccEmailIds, UserVO userVO) {
		try {
			if (toEmailIds != null) {
				String[] strToMailIds = toEmailIds.split(",");
				for (String strToMailId : strToMailIds) {
					if (!StringUtils.isEmpty(strToMailId) && !StringUtils.isWhitespace(strToMailId)) {
						User userdetail = this.userRepository.findByLoginId(strToMailId);
						if (userdetail != null) {
							List<CaseQueryFlag> caseQueryFlags = this.caseQueryFlagRepository
									.getCaseQueryFlagByCaseQueryId(caseQueryId, userdetail);
							if (caseQueryFlags.size() == 0) {
								CaseQueryFlag caseQueryFlag = new CaseQueryFlag();
								caseQueryFlag.setCaseQueryId(caseQueryId);
								caseQueryFlag.setCaseQueryFlagType("UNREAD");
								caseQueryFlag.setClient(userdetail);
								this.caseQueryFlagRepository.save(caseQueryFlag);
							}
						}
					}
				}
			}
			if (ccEmailIds != null) {
				String[] strCCMailIds = ccEmailIds.split(",");
				for (String strCCMailId : strCCMailIds) {
					if (!StringUtils.isEmpty(strCCMailId) && !StringUtils.isWhitespace(strCCMailId)) {
						User userdetail = this.userRepository.findByLoginId(strCCMailId);
						if (userdetail != null) {
							List<CaseQueryFlag> caseQueryFlags = this.caseQueryFlagRepository
									.getCaseQueryFlagByCaseQueryId(caseQueryId, userdetail);
							if (caseQueryFlags.size() == 0) {
								CaseQueryFlag caseQueryFlag = new CaseQueryFlag();
								caseQueryFlag.setCaseQueryId(caseQueryId);
								caseQueryFlag.setCaseQueryFlagType("UNREAD");
								caseQueryFlag.setClient(userdetail);
								this.caseQueryFlagRepository.save(caseQueryFlag);
							}
						}
					}
				}
			}

			User loginUser = this.userService.getCurrentUser(userVO);
			if (loginUser != null) {
				if (loginUser.getRole().getType().equalsIgnoreCase(Role.ROLE_TYPE_CUSTOMER)) {

					List<User> userList = this.userService.getUserListByRoleType(Role.ROLE_TYPE_CS_ROLES);

					if (userList.size() > 0) {
						Specification<CaseQueryFlag> specification = null;
						Specifications<CaseQueryFlag> specifications = Specifications.where(
								this.caseQueryFlagGenericSpecifications.dataTypeCharacter("deleted", AppConstants.NO));

						specification = this.caseQueryFlagGenericSpecifications.dataTypeLong("caseQueryId",
								caseQueryId);
						specifications = specifications.and(specification);

						specification = this.caseQueryFlagGenericSpecifications.anyUsers("client", userList);
						specifications = specifications.and(specification);

						specification = specifications;
						List<CaseQueryFlag> caseQueryFlagList = this.caseQueryFlagRepository.findAll(specification);

						for (final User user : userList) {

							try {

								boolean isRead = true;
								if (caseQueryFlagList.size() > 0) {
									List<Object> caseQueryFlagListFilter = caseQueryFlagList.stream()
											.filter(new Predicate<CaseQueryFlag>() {
												@Override
												public boolean test(CaseQueryFlag e) {
													return (e != null) && (e.getClient() != null)
															&& (e.getClient().getId() != null)
															&& e.getClient().getId().equals(user.getId());
												}
											}).collect(Collectors.toList());

									if (caseQueryFlagListFilter.size() > 0) {
										isRead = false;
									}
								}

								if (isRead) {
									CaseQueryFlag caseQueryFlag = new CaseQueryFlag();
									caseQueryFlag.setCaseQueryId(caseQueryId);
									caseQueryFlag.setCaseQueryFlagType("UNREAD");
									caseQueryFlag.setClient(user);
									this.caseQueryFlagRepository.save(caseQueryFlag);
								}

							} catch (Exception e) {
								LOGGER.error(CLASS_NAME, "updateQueryReadStatus", e);
							} finally {

							}
						}
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "updateQueryReadStatus", e);
		} finally {

		}
	}

	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.CaseQueryService#emailForNewCaseQuery(com.trivent.dto.
	 * CaseQueryVO)
	 * 
	 * @DateAndTime : Feb 8, 2018 - 10:31:47 AM
	 * 
	 * @Author : Ramya
	 * 
	 * @Description : Its to email new query
	 * 
	 * @Tags :
	 * 
	 * @param caseQueryVO - get required field by path variable caseQueryVO
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@SuppressWarnings("unused")
	@Override
	public void emailForNewCaseQuery(CaseQueryVO caseQueryVO, UserVO userVO) {
		this.emailForQuery(caseQueryVO, userVO);
		if (true) {
			return;
		}
		User loginUser = this.userService.getCurrentUser(userVO);
		Role actUserRole = this.roleRepository.findOne(loginUser.getRole().getId());
		String toEmailIds = caseQueryVO.getQueryTo();
		Map<String, Object> emailValueMap = new HashMap<>();
		Case clientCase = null;
		Partner partner = this.partnerService.getCurrentSessionPartner();
		if (caseQueryVO.getQueryPartnerBean() != null) {
			Partner queryPartner = this.partnerRepository
					.findByPartnerCode(caseQueryVO.getQueryPartnerBean().toUpperCase());
			if (queryPartner != null) {
				partner = queryPartner;
			}
		}
		EmailTemplate emailTemplate = null;
		emailValueMap.put("SUBJECT", caseQueryVO.getQuerySubject());
		emailValueMap.put("MESSAGE_BODY", caseQueryVO.getCaseQueryResponseVO().getQueryDetails());
		if (caseQueryVO.getCaseId() != null) {
			clientCase = this.caseRepository.findOne(caseQueryVO.getCaseId());
			emailValueMap.put("CASE_NAME", clientCase.getName());
			if (clientCase.getClient().getRole().getType().equalsIgnoreCase(Role.ROLE_CUSTOMER)) {
				emailValueMap.put("CLIENT_NAME", clientCase.getClient().getUserProfile().getFirstName());
			} else {
				emailValueMap.put("CLIENT_NAME", clientCase.getClient().getUserProfile().getFirstName() + " "
						+ clientCase.getClient().getUserProfile().getLastName());
			}
			// Partner Signature in Email - Start
			emailValueMap.put("PARTNER_NAME", clientCase.getAccount().getPartner().getName());
			emailValueMap.put("PARTNER_ADDRESS",
					clientCase.getAccount().getPartner().getAddress1() + ", "
							+ clientCase.getAccount().getPartner().getAddress2() + ", "
							+ clientCase.getAccount().getPartner().getCity() + ", "
							+ clientCase.getAccount().getPartner().getState() + ", "
							+ clientCase.getAccount().getPartner().getZipCode());
			emailValueMap.put("PARTNER_EMAIL", clientCase.getAccount().getPartner().getEmail());

			if (!StringUtils.equals(loginUser.getRole().getName(), AppConstants.FIELD_CUSTOMER)) {
				emailTemplate = this.emailTemplateService.findEmailTemplateByCode(
						this.applicationProperties.getProperty(AppConstants.CLIENT_CASE_QUERY_EMAIL));
			} else {
				emailTemplate = this.emailTemplateService.findEmailTemplateByCode(
						this.applicationProperties.getProperty(AppConstants.QUERY_CREATED_BY_CLIENT_EMAIL_TEMPLATE));
			}

		} else {
			String userFullName = null;

			String[] strQueryTo = caseQueryVO.getQueryTo().split(",");
			if (strQueryTo.length == 1) {
				User user = this.userRepository.findByLoginId(caseQueryVO.getQueryTo());
				if (!Objects.equals(user, null)) {

					UserProfile queryToUserProfile = this.userRepository.findByLoginId(caseQueryVO.getQueryTo())
							.getUserProfile();
					if (queryToUserProfile != null) {
						if (!StringUtils.isEmpty(queryToUserProfile.getLastName())
								&& !user.getRole().getType().equalsIgnoreCase(Role.ROLE_CUSTOMER)) {
							userFullName = queryToUserProfile.getFirstName() + " " + queryToUserProfile.getLastName();
						} else {
							userFullName = queryToUserProfile.getFirstName();
						}
					} else if (strQueryTo.length > 1) {
						userFullName = AppConstants.ALL;
					} else {
						userFullName = caseQueryVO.getQueryTo();
					}

				} else {
					userFullName = caseQueryVO.getQueryTo();
				}
			} else if (strQueryTo.length > 1) {
				userFullName = AppConstants.ALL;
			}

			emailValueMap.put("CLIENT_NAME", userFullName);
			emailValueMap.put("USER", userFullName);
			// Partner Signature in Email - End
			emailValueMap.put("PARTNER_NAME", partner.getName());
			emailValueMap.put("PARTNER_ADDRESS", partner.getAddress1() + ", " + partner.getAddress2() + ", "
					+ partner.getCity() + ", " + partner.getState() + ", " + partner.getZipCode());
			emailValueMap.put("PARTNER_EMAIL", partner.getEmail());
			// Partner Signature in Email - End
			if (!StringUtils.equals(loginUser.getRole().getName(), AppConstants.FIELD_CUSTOMER)) {
				emailTemplate = this.emailTemplateService.findEmailTemplateByCode(
						this.applicationProperties.getProperty(AppConstants.CLIENT_CASE_QUERY_EMAIL_WITHOUT_CASE));
			} else {
				emailTemplate = this.emailTemplateService.findEmailTemplateByCode(this.applicationProperties
						.getProperty(AppConstants.QUERY_CREATED_BY_CLIENT_EMAIL_TEMPLATE_WITHOUT_CASE));
			}

		}
		emailValueMap.put("CURRENT_DATE", Calendar.getInstance());

		Calendar calendar = Calendar.getInstance();
		calendar.clear(Calendar.MILLISECOND);
		String ccEmailIds = emailTemplate.getIntEmailCcList();
		if (!StringUtils.isEmpty(caseQueryVO.getQueryCc())) {
			if (!StringUtils.isEmpty(ccEmailIds)) {
				ccEmailIds = ccEmailIds.concat(",").concat(caseQueryVO.getQueryCc());
			} else {
				ccEmailIds = caseQueryVO.getQueryCc();
			}
		}
		String bccEmailIds = caseQueryVO.getQueryBcc();
		String messageSubject = emailTemplate.getSubject();
		String messageBody = emailTemplate.getMessage();

		if (!StringUtils.isEmpty(toEmailIds)) {
			if (!StringUtils.isEmpty(emailTemplate.getIntEmailToList())) {
				toEmailIds = toEmailIds + "," + emailTemplate.getIntEmailToList();
			}
		} else {
			toEmailIds = emailTemplate.getIntEmailToList();
		}

		try {
			String userFullName = null;
			String[] strQueryTo = caseQueryVO.getQueryTo().split(",");
			if (StringUtils.isNotBlank(caseQueryVO.getQueryTo()) && StringUtils.isNotEmpty(caseQueryVO.getQueryTo())) {
				if (strQueryTo.length == 1) {
					User user = this.userRepository.findByLoginId(caseQueryVO.getQueryTo());

					if (!Objects.equals(user, null)) {
						UserProfile queryToUserProfile = this.userRepository.findByLoginId(caseQueryVO.getQueryTo())
								.getUserProfile();
						if (queryToUserProfile != null) {
							if (!StringUtils.isEmpty(queryToUserProfile.getLastName())
									&& !user.getRole().getType().equalsIgnoreCase(Role.ROLE_CUSTOMER)) {
								userFullName = queryToUserProfile.getFirstName() + " "
										+ queryToUserProfile.getLastName();
							} else {
								userFullName = queryToUserProfile.getFirstName();
							}
						} else {
							userFullName = caseQueryVO.getQueryTo();
						}
					} else {
						userFullName = caseQueryVO.getQueryTo();
					}
				} else if (strQueryTo.length > 1) {
					userFullName = AppConstants.ALL;
				}
				emailValueMap.put("USER", userFullName);
				emailValueMap.put("CLIENT_NAME", userFullName);

				if (toEmailIds.indexOf(caseQueryVO.getQueryTo()) < 0) {
					toEmailIds = caseQueryVO.getQueryTo() + "," + toEmailIds;
				}
			}

		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "Email template user name update", e);
		}

		if (actUserRole.getName().equals(AppConstants.FIELD_CUSTOMER)
				|| actUserRole.getName().equals(AppConstants.PRODUCTION)
				|| actUserRole.getName().equals(AppConstants.MANAGERS)) {
			toEmailIds = emailTemplate.getIntEmailToList();

			toEmailIds = this.emailTemplateService.getPartnerEmails(emailTemplate, AppConstants.PARTNER_EMAIL_TYPE_TO,
					toEmailIds, caseQueryVO.getQueryPartnerBean());
			ccEmailIds = this.emailTemplateService.getPartnerEmails(emailTemplate, AppConstants.PARTNER_EMAIL_TYPE_CC,
					ccEmailIds, caseQueryVO.getQueryPartnerBean());

			messageSubject = this.emailTemplateService.getPartnerEmails(emailTemplate,
					AppConstants.PARTNER_EMAIL_TYPE_SUBJECT, messageSubject, caseQueryVO.getQueryPartnerBean());

			emailTemplate.setSubject(messageSubject);

			messageBody = this.emailTemplateService.getPartnerEmails(emailTemplate,
					AppConstants.PARTNER_EMAIL_TYPE_MESSAGE, messageBody, caseQueryVO.getQueryPartnerBean());

			emailTemplate.setMessage(messageBody);

			emailValueMap.put("CLIENT_SUPPORT", "Customer Support");

			EmailQueue emailQueue = new EmailQueue(toEmailIds, ccEmailIds, messageSubject, messageBody);
			if (!StringUtils.isEmpty(bccEmailIds)) {
				emailQueue.setBccEmailIds(bccEmailIds);
			}
			emailQueue.populate(loginUser, loginUser.getAccount(), null, emailValueMap);
			emailQueue.setEmailQueueType("Query");
			emailQueue.setEmailQueueDesc(caseQueryVO.getCaseQueryResponseVO().getId().toString());
			emailQueue.setEmailOutBeanPrefix(caseQueryVO.getQueryPartnerBean());
			if (!StringUtils.isEmpty(emailQueue.getToEmailIds())) {
				if (this.appConfigService.getCustomerMailPermission(emailQueue, AppConstants.APP_CONFIG_QUERY_MAIL,
						userVO)) // Added
				// for Customer mail send configuration on 17 June 2017
				{
					this.emailService.queueEmail(emailQueue, userVO);
				}
			}
			this.updateQueryReadStatus(caseQueryVO.getId(), toEmailIds, ccEmailIds, userVO);

		} else {
			toEmailIds = this.emailTemplateService.getPartnerEmails(emailTemplate, AppConstants.PARTNER_EMAIL_TYPE_TO,
					toEmailIds, caseQueryVO.getQueryPartnerBean());
			ccEmailIds = this.emailTemplateService.getPartnerEmails(emailTemplate, AppConstants.PARTNER_EMAIL_TYPE_CC,
					ccEmailIds, caseQueryVO.getQueryPartnerBean());

			messageSubject = this.emailTemplateService.getPartnerEmails(emailTemplate,
					AppConstants.PARTNER_EMAIL_TYPE_SUBJECT, messageSubject, caseQueryVO.getQueryPartnerBean());

			emailTemplate.setSubject(messageSubject);

			messageBody = this.emailTemplateService.getPartnerEmails(emailTemplate,
					AppConstants.PARTNER_EMAIL_TYPE_MESSAGE, messageBody, caseQueryVO.getQueryPartnerBean());

			emailTemplate.setMessage(messageBody);

			EmailQueue emailQueue = new EmailQueue(toEmailIds, ccEmailIds, messageSubject, messageBody);
			if (!StringUtils.isEmpty(bccEmailIds)) {
				emailQueue.setBccEmailIds(bccEmailIds);
			}
			emailQueue.populate(loginUser, loginUser.getAccount(), null, emailValueMap);
			emailQueue.setEmailQueueType("Query");
			emailQueue.setEmailQueueDesc(caseQueryVO.getCaseQueryResponseVO().getId().toString());
			emailQueue.setEmailOutBeanPrefix(caseQueryVO.getQueryPartnerBean());
			if (!StringUtils.isEmpty(emailQueue.getToEmailIds())) {
				if (this.appConfigService.getCustomerMailPermission(emailQueue, AppConstants.APP_CONFIG_QUERY_MAIL,
						userVO)) // Added
				// for Customer mail send configuration on 17 June 2017
				{
					this.emailService.queueEmail(emailQueue, userVO);
				}
			}

			this.updateQueryReadStatus(caseQueryVO.getId(), toEmailIds, ccEmailIds, userVO);
		}
	}

	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Feb 8, 2018 - 10:31:47 AM
	 * 
	 * @Author : Ramya
	 * 
	 * @Description : Its to get email for query
	 * 
	 * @Tags :
	 * @param caseQueryVO
	 *            - get required field by path variable caseQueryVO
	 * @Git_Config : name email
	 * 
	 */
	@Transactional(readOnly = false)
	private void emailForQuery(CaseQueryVO caseQueryVO, UserVO userVO) {

		try {
			this.emailForQueryTemplateFetch(caseQueryVO, userVO);
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "emailForQuery", e);
		} finally {

		}
	}

	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Feb 8, 2018 - 10:31:47 AM
	 * 
	 * @Author : Ramya
	 * 
	 * @Description : Function to save task is generated in query response template
	 *              and update generated task id in query response table against the
	 *              query response id and get email for query template.
	 * 
	 * @Tags :
	 * @param objQuery
	 *            - refer obj as entityClass
	 * @Git_Config : name email
	 * 
	 */
	@Transactional(readOnly = false)
	private void emailForQueryTemplateFetch(Object objQuery, UserVO userVO) {
		try {
			User loginUser = this.userService.getCurrentUser(userVO);
			String strToEmailIds = StringUtils.EMPTY;
			String strCCEmailIds = StringUtils.EMPTY;
			String strBCCEmailIds = StringUtils.EMPTY;
			Long lgQueryId = null;

			String strEmailQueueDes = StringUtils.EMPTY;
			String strEmailQueuePre = StringUtils.EMPTY;

			Case clientCase = new Case();
			Partner partner = new Partner();

			boolean isCaseQuery = false;
			boolean isClientSupport = false;
			CaseQuery caseQueryAssignedTo = new CaseQuery();

			Map<String, Object> emailValueMap = new HashMap<>();

			emailValueMap.put("CURRENT_DATE", Calendar.getInstance());

			emailValueMap.put("USER", AppConstants.ALL);
			emailValueMap.put("CLIENT_NAME", AppConstants.ALL);
			emailValueMap.put("CLIENT_SUPPORT", AppConstants.ALL);

			emailValueMap.put("PARTNER_NAME", StringUtils.EMPTY);
			emailValueMap.put("PARTNER_ADDRESS", StringUtils.EMPTY);
			emailValueMap.put("PARTNER_EMAIL", StringUtils.EMPTY);

			emailValueMap.put("CASE_NAME", StringUtils.EMPTY);

			emailValueMap.put("SUBJECT", StringUtils.EMPTY);
			emailValueMap.put("MESSAGE_BODY", StringUtils.EMPTY);

			if ((loginUser != null) && (loginUser.getUserProfile() != null)
					&& (loginUser.getUserProfile().getFirstName() != null)) {
				emailValueMap.put("USER", loginUser.getUserProfile().getFirstName());
			}

			String lsPartnerCode = this.emailInternalTo;
			if (objQuery instanceof CaseQueryResponseVO) {

				CaseQueryResponseVO caseQueryResponseVO = (CaseQueryResponseVO) objQuery;

				String queryDetails = CommonUtils.uniCodeToString(caseQueryResponseVO.getQueryDetails());
				emailValueMap.put("MESSAGE_BODY", queryDetails);
				// emailValueMap.put("MESSAGE_BODY", queryDetailsDecode);

				// ===========================================================================================
				// Begin - Get contacts from the query
				// ===========================================================================================

				strToEmailIds = caseQueryResponseVO.getQueryTo();

				// ===========================================================================================
				// End - Get contacts from the query
				// ===========================================================================================

				// ===========================================================================================
				// Begin - Query Fetch for the Query Response
				// ===========================================================================================

				List<Long> caseQueryIdList = new ArrayList<>();
				caseQueryIdList.add(caseQueryResponseVO.getCaseQueryId());

				char isDeleted = AppConstants.NO;

				Specification<CaseQuery> specification = null;
				Specifications<CaseQuery> specifications = Specifications
						.where(this.genericSpecifications.dataTypeCharacter("deleted", isDeleted));

				specification = this.genericSpecifications.dataTypeLongList("id", caseQueryIdList);
				specifications = specifications.and(specification);

				specification = specifications;
				List<CaseQuery> caseQueryList = this.caseQueryRepository.findAll(specification);

				// ===========================================================================================
				// End - Query Fetch for the Query Response
				// ===========================================================================================

				// ===========================================================================================
				// Begin - Partner Fetch for the Query
				// ===========================================================================================

				if ((caseQueryList != null) && (caseQueryList.size() > 0)) {

					List<String> partnerCodes = new ArrayList<>();
					for (CaseQuery caseQuery : caseQueryList) {

						caseQueryAssignedTo = caseQuery;
						if (caseQuery.getId().equals(caseQueryResponseVO.getCaseQueryId())) {
							emailValueMap.put("SUBJECT", caseQuery.getQuerySubject());
						}

						if (caseQuery.getQueryPartnerBean() != null) {
							partnerCodes.add(caseQuery.getQueryPartnerBean());
						}

					}

					List<Partner> partnerList = this.partnerService.getPartnerListByPartnerCode(partnerCodes);
					if ((partnerList != null) && (partnerList.size() > 0)) {
						for (Partner partner2 : partnerList) {
							partner = partner2;
							break;
						}
					} else {
						partner = this.partnerService.getCurrentSessionPartner();
					}
				} else {
					partner = this.partnerService.getCurrentSessionPartner();
				}

				// ===========================================================================================
				// End - Partner Fetch for the Query
				// ===========================================================================================

				if (StringUtils.isNotEmpty(strCCEmailIds) && StringUtils.isNotBlank(strCCEmailIds)) {
					strCCEmailIds = strCCEmailIds.concat(",").concat(caseQueryResponseVO.getQueryCc());
				} else {
					strCCEmailIds = caseQueryResponseVO.getQueryCc();
				}
				if (StringUtils.isNotEmpty(strBCCEmailIds) && StringUtils.isNotBlank(strBCCEmailIds)) {
					strBCCEmailIds = strCCEmailIds.concat(",").concat(caseQueryResponseVO.getQueryBcc());
				} else {
					strBCCEmailIds = caseQueryResponseVO.getQueryBcc();
				}

				strEmailQueueDes = caseQueryResponseVO.getId().toString();
				strEmailQueuePre = caseQueryResponseVO.getQueryPartnerBean();

				lgQueryId = caseQueryResponseVO.getCaseQueryId();

				if (StringUtils.equals(loginUser.getRole().getType(), Role.ROLE_TYPE_CUSTOMER)
						|| StringUtils.equals(loginUser.getRole().getType(), Role.ROLE_TYPE_OTHER_ROLES)
						|| StringUtils.equals(loginUser.getRole().getType(), Role.ROLE_TYPE_ADMIN_ROLES)) {

					emailValueMap.put("CLIENT_SUPPORT", "Customer Support");
					emailValueMap.put("USER", "Customer Support");
					emailValueMap.put("CLIENT_NAME", "Customer Support");

				} else {
					isClientSupport = true;
				}

				// ===========================================================================================
				// Begin - Check the Case Query or Not
				// ===========================================================================================

				lsPartnerCode = caseQueryResponseVO.getQueryPartnerBean();
				if (StringUtils.equals(loginUser.getType(), User.USER_TYPE_CLIENT)) {

					lsPartnerCode = loginUser.getAccount().getPartner().getPartnerCode();

				}
				if (caseQueryResponseVO.getCaseId() != null) {

					List<Long> caseIdList = new ArrayList<>();
					caseIdList.add(caseQueryResponseVO.getCaseId());

					List<Case> caseList = this.caseService.getCaseListByCaseIds(caseIdList);

					if ((caseList != null) && (caseList.size() > 0)) {

						isCaseQuery = true;

						for (Case case1 : caseList) {
							clientCase = case1;
							break;
						}
						lsPartnerCode = clientCase.getAccount().getPartner().getPartnerCode();
						emailValueMap.put("CASE_NAME", clientCase.getName());

					}
				}

				// ===========================================================================================
				// End - Check the Case Query or Not
				// ===========================================================================================

			} else if (objQuery instanceof CaseQueryVO) {

				CaseQueryVO caseQueryVO = (CaseQueryVO) objQuery;

				BeanUtils.copyProperties(caseQueryVO, caseQueryAssignedTo);

				String queryDetails = CommonUtils
						.uniCodeToString(caseQueryVO.getCaseQueryResponseVO().getQueryDetails());
				emailValueMap.put("MESSAGE_BODY", queryDetails);
				// emailValueMap.put("MESSAGE_BODY",
				// caseQueryVO.getCaseQueryResponseVO().getQueryDetails());
				emailValueMap.put("SUBJECT", caseQueryVO.getQuerySubject());

				// ===========================================================================================
				// Begin - Get contacts from the query
				// ===========================================================================================

				strToEmailIds = caseQueryVO.getQueryTo();

				// ===========================================================================================
				// End - Get contacts from the query
				// ===========================================================================================

				// ===========================================================================================
				// Begin - Partner Fetch for the Query
				// ===========================================================================================

				List<String> partnerCodes = new ArrayList<>();
				if ((caseQueryVO != null) && (caseQueryVO.getQueryPartnerBean() != null)) {
					partnerCodes.add(caseQueryVO.getQueryPartnerBean());
				}

				List<Partner> partnerList = this.partnerService.getPartnerListByPartnerCode(partnerCodes);
				if ((partnerList != null) && (partnerList.size() > 0)) {
					for (Partner partner2 : partnerList) {
						partner = partner2;
						break;
					}
				} else {
					partner = this.partnerService.getCurrentSessionPartner();
				}

				// ===========================================================================================
				// End - Partner Fetch for the Query
				// ===========================================================================================

				if (StringUtils.isNotEmpty(strCCEmailIds) && StringUtils.isNotBlank(strCCEmailIds)) {
					strCCEmailIds = strCCEmailIds.concat(",").concat(caseQueryVO.getQueryCc());
				} else {
					strCCEmailIds = caseQueryVO.getQueryCc();
				}
				if (StringUtils.isNotEmpty(strBCCEmailIds) && StringUtils.isNotBlank(strBCCEmailIds)) {
					strBCCEmailIds = strCCEmailIds.concat(",").concat(caseQueryVO.getQueryBcc());
				} else {
					strBCCEmailIds = caseQueryVO.getQueryBcc();
				}

				if (caseQueryVO.getCaseQueryResponseVO() != null) {
					if (caseQueryVO.getCaseQueryResponseVO().getId() != null) {
						strEmailQueueDes = caseQueryVO.getCaseQueryResponseVO().getId().toString();
					}
				}
				strEmailQueuePre = caseQueryVO.getQueryPartnerBean();

				lgQueryId = caseQueryVO.getId();

				if (StringUtils.equals(loginUser.getRole().getType(), Role.ROLE_TYPE_CUSTOMER)) {

					emailValueMap.put("CLIENT_SUPPORT", "Customer Support");
					emailValueMap.put("USER", "Customer Support");
					emailValueMap.put("CLIENT_NAME", "Customer Support");

				} else {
					isClientSupport = true;
				}

				// ===========================================================================================
				// Begin - Check the Case Query or Not
				// ===========================================================================================

				lsPartnerCode = caseQueryVO.getQueryPartnerBean();
				if (StringUtils.equals(loginUser.getType(), User.USER_TYPE_CLIENT)) {

					lsPartnerCode = loginUser.getAccount().getPartner().getPartnerCode();

				}

				if (caseQueryVO.getCaseId() != null) {

					List<Long> caseIdList = new ArrayList<>();
					caseIdList.add(caseQueryVO.getCaseId());

					List<Case> caseList = this.caseService.getCaseListByCaseIds(caseIdList);

					if ((caseList != null) && (caseList.size() > 0)) {

						isCaseQuery = true;

						for (Case case1 : caseList) {
							clientCase = case1;
							break;
						}
						lsPartnerCode = clientCase.getAccount().getPartner().getPartnerCode();
						emailValueMap.put("CASE_NAME", clientCase.getName());

					}
				}

				// ===========================================================================================
				// End - Check the Case Query or Not
				// ===========================================================================================

			} else {
				return;
			}

			if ((partner != null) && (partner.getId() != null)) {

				emailValueMap.put("PARTNER_NAME", partner.getName());

				emailValueMap.put("PARTNER_ADDRESS", partner.getAddress1() + ", " + partner.getAddress2() + ", "
						+ partner.getCity() + ", " + partner.getState() + ", " + partner.getZipCode());

				emailValueMap.put("PARTNER_EMAIL", partner.getEmail());

			}

			// ===========================================================================================
			// Begin - CLIENT_SUPPORT template title set
			// ===========================================================================================

			if (isClientSupport) {

				if (StringUtils.isEmpty(strToEmailIds) || StringUtils.isBlank(strToEmailIds)) {
					throw new TriventException(
							this.applicationProperties.getProperty(AppConstants.QUERY_SENT_TO_CHK_NULL));
				}

				String[] strEmailIdsArray = strToEmailIds.replaceAll(";", ",").split(",");

				String strUserFullName = AppConstants.ALL;
				if (StringUtils.isNotBlank(strToEmailIds) && StringUtils.isNotBlank(strToEmailIds)) {

					if (strEmailIdsArray.length > 0) {
						User user = new User();
						List<User> userList = this.userService.getUserListByLoginIds(Arrays.asList(strEmailIdsArray));
						if ((userList != null) && (userList.size() > 0)) {
							boolean isUserClient = false;
							for (String strMailId : Arrays.asList(strEmailIdsArray)) {
								for (User user1 : userList) {
									if (user1.getLoginId().equalsIgnoreCase(strMailId)) {
										isUserClient = true;
										if (StringUtils.equals(user1.getRole().getType(), Role.ROLE_TYPE_CUSTOMER)) {
										}
										user = user1;
										break;
									}
								}
								if (isUserClient) {
									break;
								}
							}
						}
						if ((user != null) && (user.getId() != null)) {
							UserProfile userProfile = user.getUserProfile();
							if (userProfile != null) {
								if (StringUtils.isNotEmpty(userProfile.getLastName())
										&& StringUtils.isNotBlank(userProfile.getLastName())
										&& !user.getRole().getType().equalsIgnoreCase(Role.ROLE_CUSTOMER)) {
									strUserFullName = userProfile.getFirstName() + " " + userProfile.getLastName();
								} else {
									strUserFullName = userProfile.getFirstName();
								}
							}
						}
					}
				}

				if (StringUtils.isEmpty(strUserFullName) || StringUtils.isBlank(strUserFullName)
						|| StringUtils.equalsIgnoreCase(strUserFullName, AppConstants.ALL)) {
					if ((clientCase != null) && (clientCase.getId() != null)) {
						List<Case> caseList = new ArrayList<>();
						caseList.add(clientCase);
						List<CaseContacts> caseContactsList = this.caseService.getCaseContactsByCase(caseList);
						if ((caseContactsList != null) && (caseContactsList.size() > 0)) {
							for (CaseContacts caseContacts : caseContactsList) {
								strUserFullName = caseContacts.getName();
								break;
							}
						}
					}
				}

				if (((StringUtils.isEmpty(strUserFullName) && StringUtils.isBlank(strUserFullName))
						|| StringUtils.equalsIgnoreCase(strUserFullName, AppConstants.ALL))
						&& StringUtils.isNotEmpty(strToEmailIds) && StringUtils.isNotBlank(strToEmailIds)) {

					if (strEmailIdsArray.length == 1) {
						strUserFullName = strEmailIdsArray[0];
					} else if (strEmailIdsArray.length > 1) {
						strUserFullName = AppConstants.ALL;
					}

				}

				emailValueMap.put("CLIENT_SUPPORT", strUserFullName);
				emailValueMap.put("CLIENT_NAME", strUserFullName);

				if ((loginUser != null) && (loginUser.getLoginId() != null) && (caseQueryAssignedTo != null)
						&& (caseQueryAssignedTo.getAssignedTo() != null)
						&& (caseQueryAssignedTo.getAssignedTo().getLoginId() != null)
						&& !loginUser.getLoginId().equalsIgnoreCase(caseQueryAssignedTo.getAssignedTo().getLoginId())) {

					try {

						List<String> strConfigDatas = new ArrayList<String>();
						strConfigDatas.add(this.applicationProperties
								.getProperty("application.configuration.case.query.assignto.notification.response"));

						List<AppConfigDataVO> appConfigDataVOList = appConfigDataService
								.getAppConfigDataVOList(strConfigDatas);

						for (final AppConfigDataVO appConfigDataVO : appConfigDataVOList) {

							if (appConfigDataVO.getName().equalsIgnoreCase(applicationProperties.getProperty(
									"application.configuration.case.query.assignto.notification.response"))) {
								if (appConfigDataVO.getDataValue().equalsIgnoreCase("1")) {
									if (StringUtils.isNotEmpty(strToEmailIds)
											&& StringUtils.isNotBlank(strToEmailIds)) {
										strToEmailIds = strToEmailIds + ","
												+ caseQueryAssignedTo.getAssignedTo().getLoginId();
									} else {
										strToEmailIds = caseQueryAssignedTo.getAssignedTo().getLoginId();
									}
								}

							}
						}

					} catch (Exception e) {
						LOGGER.error(CLASS_NAME, "Case Query Assign to Notification in Response", e);
					}
				}
			}

			// ===========================================================================================
			// End - CLIENT_SUPPORT template title set
			// ===========================================================================================

			// ===========================================================================================
			// Begin - Initialize email template
			// ===========================================================================================

			EmailTemplate emailTemplate = null;

			if (isCaseQuery) {
				if (!StringUtils.equals(loginUser.getRole().getType(), Role.ROLE_TYPE_CUSTOMER)) {
					emailTemplate = this.emailTemplateService.findEmailTemplateByCode(
							this.applicationProperties.getProperty(AppConstants.CLIENT_CASE_QUERY_EMAIL),
							lsPartnerCode);
				} else {
					emailTemplate = this.emailTemplateService.findEmailTemplateByCode(
							this.applicationProperties.getProperty(AppConstants.QUERY_CREATED_BY_CLIENT_EMAIL_TEMPLATE),
							lsPartnerCode);
				}
			} else {

				if (!StringUtils.equals(loginUser.getRole().getType(), Role.ROLE_TYPE_CUSTOMER)) {
					emailTemplate = this.emailTemplateService.findEmailTemplateByCode(
							this.applicationProperties.getProperty(AppConstants.CLIENT_CASE_QUERY_EMAIL_WITHOUT_CASE),
							lsPartnerCode);
				} else {
					emailTemplate = this.emailTemplateService
							.findEmailTemplateByCode(
									this.applicationProperties.getProperty(
											AppConstants.QUERY_CREATED_BY_CLIENT_EMAIL_TEMPLATE_WITHOUT_CASE),
									lsPartnerCode);
				}
			}

			// ===========================================================================================
			// End - Initialize email template
			// ===========================================================================================

			if ((emailTemplate != null) && (emailTemplate.getCreatedDate() != null)) {

				// ===========================================================================================
				// Begin - Fetch Default values from template
				// ===========================================================================================

				if (StringUtils.isNotEmpty(emailTemplate.getIntEmailCcList())
						&& StringUtils.isNotBlank(emailTemplate.getIntEmailCcList())) {
					if (StringUtils.isNotEmpty(strCCEmailIds) && StringUtils.isNotBlank(strCCEmailIds)) {
						strCCEmailIds = emailTemplate.getIntEmailCcList().concat(",").concat(strCCEmailIds);
					} else {
						strCCEmailIds = emailTemplate.getIntEmailCcList();
					}
				}

				String strMessageSubject = emailTemplate.getSubject();
				String strMessageBody = emailTemplate.getMessage();

				if (StringUtils.isNotEmpty(strToEmailIds) && StringUtils.isNotBlank(strToEmailIds)) {
					if (StringUtils.isNotEmpty(emailTemplate.getIntEmailToList())
							&& StringUtils.isNotBlank(emailTemplate.getIntEmailToList())) {
						strToEmailIds = strToEmailIds + "," + emailTemplate.getIntEmailToList();
					}
				} else {
					strToEmailIds = emailTemplate.getIntEmailToList();
				}

				if (StringUtils.isNotEmpty(strBCCEmailIds) && StringUtils.isNotBlank(strBCCEmailIds)) {
					if (StringUtils.isNotEmpty(emailTemplate.getIntEmailBccList())
							&& StringUtils.isNotBlank(emailTemplate.getIntEmailBccList())) {
						strBCCEmailIds = strBCCEmailIds + "," + emailTemplate.getIntEmailBccList();
					}
				} else {
					strBCCEmailIds = emailTemplate.getIntEmailBccList();
				}

				// ===========================================================================================
				// End - Fetch Default values from template
				// ===========================================================================================

				if (StringUtils.isEmpty(strToEmailIds) || StringUtils.isBlank(strToEmailIds)) {
					throw new TriventException(
							this.applicationProperties.getProperty(AppConstants.QUERY_SENT_TO_CHK_NULL));
				}

				EmailQueue emailQueue = new EmailQueue();

				emailQueue = new EmailQueue(strToEmailIds, strCCEmailIds, strMessageSubject, strMessageBody);

				if (StringUtils.isNotEmpty(strBCCEmailIds) && StringUtils.isNotBlank(strBCCEmailIds)) {
					emailQueue.setBccEmailIds(strBCCEmailIds);
				}
				emailQueue.populate(loginUser, loginUser.getAccount(), null, emailValueMap);

				emailQueue.setEmailQueueType("Query");
				emailQueue.setEmailQueueDesc(strEmailQueueDes);
				emailQueue.setEmailOutBeanPrefix(strEmailQueuePre);

				if (!StringUtils.isEmpty(emailQueue.getToEmailIds())) {
					if (this.appConfigService.getCustomerMailPermission(emailQueue, AppConstants.APP_CONFIG_QUERY_MAIL,
							userVO)) {
						this.emailService.queueEmail(emailQueue, userVO);
					}
				}
			}
			this.updateQueryReadStatus(lgQueryId, strToEmailIds, strCCEmailIds, userVO);

		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "emailForQueryTemplateFetch", e);
		} finally {

		}

	}

	@Override
	@Transactional
	public AppUIScreenFilterVO populateQueryStatusMap() {
		AppUIScreenFilterVO appUIScreenFilter = new AppUIScreenFilterVO();
		Map<String, String> statusMap = new LinkedHashMap<>(4);
		statusMap.put(AppConstants.EMPTY_STRING, AppConstants.CASE_FILTER_ANY);
		statusMap.put(AppConstants.STATUS_OPEN, AppConstants.STATUS_OPEN);
		statusMap.put(AppConstants.STATUS_WIP, AppConstants.STATUS_WIP);
		statusMap.put(AppConstants.STATUS_CLOSED, AppConstants.STATUS_CLOSED);
		appUIScreenFilter.setListItemMap(statusMap);
		return appUIScreenFilter;
	}

	@Override
	public List<AppItemVO> getCommunicationType(HttpServletRequest request) {
		List<AppItemVO> queryCommTypeVOs = new ArrayList<AppItemVO>();
		try {
			AppList queryCommType = this.cacheService.findByAppListName(AppList.QUERY_COMMUNICATION_TYPE);
			List<AppItem> queryCommTypeItems = this.cacheService.findByListId(queryCommType.getId());
			//List<AppItemVO> queryCommTypeVOs = new ArrayList<>(queryCommTypeItems.size());
			for (AppItem queryCommTypeItem : queryCommTypeItems) {
				queryCommTypeVOs.add(new AppItemVO(queryCommTypeItem, queryCommType.getId()));
			}

		}catch (Exception e) {
			LOGGER.error(CLASS_NAME, "getCommunicationType", e);
		}
		
		return queryCommTypeVOs;
	}

}