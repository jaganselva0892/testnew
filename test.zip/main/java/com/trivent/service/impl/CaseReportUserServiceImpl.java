package com.trivent.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.domain.Specifications;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.trivent.constants.AppConstants;
import com.trivent.logging.LogManager;
import com.trivent.logging.Logger;
import com.trivent.models.CaseReportUser;
import com.trivent.repository.CaseReportUserRepository;
import com.trivent.repository.specifications.GenericSpecifications;
import com.trivent.service.CaseReportUserService;

/**
 * @FileName : CaseReportUserServiceImpl.java
 * @ClassName : CaseReportUserServiceImpl
 * @DateAndTime : Nov 21, 2018 - 12:26:52 PM
 * 
 * @Author : Karthi
 * 
 * @Description : Its to get case report user list,save,send,update,delete.
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
@Service
public class CaseReportUserServiceImpl implements CaseReportUserService {

	private static final Logger LOGGER = LogManager.getLogger();

	private static final String CLASS_NAME = CaseReportUserServiceImpl.class.getName();

	@Autowired
	private CaseReportUserRepository caseReportUserRepository;

	@Autowired
	private GenericSpecifications<CaseReportUser> caseReportUserGS;

	@Override
	@Transactional(readOnly = false)
	public List<CaseReportUser> saveCaseReportUser(List<CaseReportUser> caseReportUser) {

		try {
			caseReportUser = this.caseReportUserRepository.save(caseReportUser);
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "saveCaseReportUser", e);
		} finally {

		}

		return caseReportUser;
	}

	@Override
	@Transactional(readOnly = false)
	public List<CaseReportUser> getCaseReportUser(Long pnCaseId) {

		List<CaseReportUser> caseReportUser = new ArrayList<CaseReportUser>();
		try {
			if (pnCaseId != null) {
				Specification<CaseReportUser> specification = null;
				Specifications<CaseReportUser> specifications = Specifications
						.where(this.caseReportUserGS.dataTypeCharacter("deleted", AppConstants.NO));
				specifications = specifications.and(this.caseReportUserGS.dataTypeLong("caseId", pnCaseId));
				specification = specifications;
				caseReportUser = this.caseReportUserRepository.findAll(specification);
			}
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "getCaseReportUser", e);
		} finally {

		}
		return caseReportUser;
	}
	
	@Override
	@Transactional(readOnly = false)
	public List<CaseReportUser> getCaseReportUserByClienType(Long clientType,Long caseId) {
		List<CaseReportUser> caseReportUser = new ArrayList<CaseReportUser>();
		try {
			if (clientType != null) {
				Specification<CaseReportUser> specification = null;
				Specifications<CaseReportUser> specifications = Specifications
						.where(this.caseReportUserGS.dataTypeCharacter("deleted", AppConstants.NO));
				if(caseId!=null)
					specifications = specifications.and(this.caseReportUserGS.dataTypeLong("caseId", caseId));
				if(clientType!=null)
					specifications = specifications.and(this.caseReportUserGS.dataTypeLong("clientType", clientType));
					
				specification = specifications;
				caseReportUser = this.caseReportUserRepository.findAll(specification);
			}
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "getCaseReportUser", e);
		} finally {

		}
		return caseReportUser;
	}

}