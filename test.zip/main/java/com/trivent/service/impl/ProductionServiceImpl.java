package com.trivent.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.domain.Specifications;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.trivent.constants.AppConstants;
import com.trivent.dto.RowVO;
import com.trivent.dto.ScreenListFilterVO;
import com.trivent.exceptions.TriventException;
import com.trivent.logging.LogManager;
import com.trivent.logging.Logger;
import com.trivent.models.Case;
import com.trivent.models.ProdFile;
import com.trivent.models.Production;
import com.trivent.models.Role;
import com.trivent.models.User;
import com.trivent.repository.AppDBTableRepository;
import com.trivent.repository.CaseRepository;
import com.trivent.repository.ProdFileRepository;
import com.trivent.repository.ProductionRepository;
import com.trivent.repository.specifications.GenericSpecifications;
import com.trivent.service.ProductionService;
import com.trivent.service.UserService;
import com.trivent.utils.FilterUtils;

/**
 * @FileName : ProductionServiceImpl.java
 * @ClassName : ProductionServiceImpl
 * @DateAndTime : Feb 6, 2018 - 10:03:29 AM
 * 
 * @Author : Ramya
 * 
 * @Description : To get the production list,assigned cases,non assigned
 *              cases,get production files,get users,download files,delete
 *              files.
 * @Tags :
 * @Git_Config : name email
 * 
 */
@Service
public class ProductionServiceImpl implements ProductionService {

	@SuppressWarnings("unused")
	private static final Logger LOGGER = LogManager.getLogger();

	@SuppressWarnings("unused")
	private static final String CLASS_NAME = ProductionServiceImpl.class.getName();

	@Autowired
	private UserService userService;
	
	@Autowired
	private FilterUtils<ProdFile> filterUtilsProdFile;
	
	@SuppressWarnings("unused")
	@Autowired
	private AppDBTableRepository appDBTableRepository;
	
	@Autowired
	private GenericSpecifications<ProdFile> genericSpecificationsProdFile;
	
	@Autowired
	private ProdFileRepository prodFileRepository;
	
	@Autowired
	private GenericSpecifications<Production> genericSpecificationsProduction;
	
	@Autowired
	private CaseRepository caseRepository;
	
	@Autowired
	private ProductionRepository productionRepository;


	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.ProductionService#caseAssignedbyCS(java.lang.Long,
	 * java.lang.Long)
	 * 
	 * @DateAndTime : Feb 6, 2018 - 10:03:30 AM
	 * 
	 * @Author : Ramya
	 * 
	 * @Description : Function to get cases assigned by CS
	 * 
	 * @Tags :
	 * 
	 * @param userId - assignee by using userId
	 * 
	 * @param caseId - assignee by using caseId
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override
	@Transactional(readOnly = true)
	public ScreenListFilterVO getDefaultScreenListFilterVO() throws TriventException {
		//AppDBTable appdbTable = this.appDBTableRepository.findByName("ProdFile");
		String screenType = AppConstants.SCREEN_TYPE_LIST;
		//return this.filterUtilsProdFile.populateScreenListFilterVO(appdbTable.getId(), screenType);
		return this.filterUtilsProdFile.populateScreenListFilterVO(new Long(256), screenType);
	}
	
	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.ProductionService#caseAssignedbyCS(java.lang.Long,
	 * java.lang.Long)
	 * 
	 * @DateAndTime : Feb 6, 2018 - 10:03:30 AM
	 * 
	 * @Author : Ramya
	 * 
	 * @Description : Function to get cases assigned by CS
	 * 
	 * @Tags :
	 * 
	 * @param userId - assignee by using userId
	 * 
	 * @param caseId - assignee by using caseId
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override
	@Transactional(readOnly = false)
	public boolean caseAssignedbyCS(Long userId, Long caseId) {
		boolean isSaved = true;
		/*try {
			User loginUser = this.auditorAwareService.getCurrentAuditor();
			Production production = new Production();
			boolean isProd = false;
			Production prod = productionRepository.getProductionByCaseId(AppConstants.NO, caseId);
			User appUser = userRepository.findOne(userId);
			if (prod != null && appUser != null) {
				List<AppUserWorkTime> appUserWorkTimeList = appUserWorkTimeRepository
						.WorkTimesByProcesss(AppConstants.PRODUCTION, prod.getId());
				if (appUserWorkTimeList.size() > 0) {
					for (AppUserWorkTime appUserWorkTime : appUserWorkTimeList) {
						List<AppUserWorkTimeDetail> appUserWorkTimeDetailList = appUserWorkTimeDetailRepository
								.listTimeDetailsByWork(AppConstants.NO, appUserWorkTime);
						if (appUserWorkTimeDetailList.size() > 0) {
							for (AppUserWorkTimeDetail appUserWorkTimeDetail : appUserWorkTimeDetailList) {
								if (appUserWorkTimeDetail.gettoTime() == null) {
									isSaved = false;
									return isSaved;
								}
							}
						}
					}
				}
			}
			List<Production> existProductionList = this.productionRepository.getProductionByCaseIdList(AppConstants.NO,
					caseId);
			for (Production existProduction : existProductionList) {
				this.disableAssigneeProduction(existProduction);
				isProd = true;
				production = existProduction;
			}

			if (existProductionList.size() <= 0) {
				existProductionList = this.productionRepository.getProductionByCaseIdList(AppConstants.YES, caseId);
				for (Production existProduction : existProductionList) {
					isProd = true;
					production = existProduction;
				}
				if (isProd) {
					production = this.productionRepository.findOne(production.getId());
					production.setDeleted(AppConstants.NO);
					production = this.saveProduction(production);
				}
			}

			String listName = this.applicationProperties.getProperty(AppConstants.PRODUCTION_NEW_STATUS);
			AppList prodStatusAppList = this.cacheService.findByAppListName(AppList.PRODUCTION_STATUS);
			AppItem appItem = this.appItemRepository.findByLongName(listName, prodStatusAppList.getId());
			if (!isProd) {
				// Save Process in producion header
				production = new Production();
				this.caseRepository.findOne(caseId);
				production.setCaseId(caseId);
				production.setCompleteProcess(initialCompleteProcess);
				production.setProductionStatus(appItem.getId());
				production = this.saveProduction(production);
			}

			ProdAssigneeFlow prodAssigneeFlow = new ProdAssigneeFlow();
			prodAssigneeFlow.setAssignee(userId);
			prodAssigneeFlow.setProduction(production.getId());
			prodAssigneeFlow.setAssignedBy(loginUser);
			prodAssigneeFlow = this.saveFlowForAssignee(prodAssigneeFlow, userId, production.getId());

			try {
				if ((userId != null) && isProd) {
					User user = this.userRepository.getOne(userId);
					if ((user != null) && (user.getRole() != null)) {
						Role role = this.roleRepository.getOne(user.getRole().getId());
						if ((role != null) && (role.getType() != null)) {
							if (role.getType().equals(Role.ROLE_TYPE_CS_ROLES)) {
								production.setDeleted('Y');
								production = this.saveProduction(production);
								List<ProdAssigneeFlow> listMyCasesProduction = this.prodAssineeFlowRepository
										.listAssignedByProduction(AppConstants.NO, production.getId());
								for (ProdAssigneeFlow prodAssigneeFlow2 : listMyCasesProduction) {
									ProdAssigneeFlow ProdAssigneeFlowUpdate = this.prodAssineeFlowRepository
											.findOne(prodAssigneeFlow2.getId());
									ProdAssigneeFlowUpdate.setDeleted(AppConstants.YES);
									this.saveAssigneeProductionNew(ProdAssigneeFlowUpdate);
								}
							}
						}
					}
				}
			} catch (Exception e) {
				LOGGER.error(CLASS_NAME, "Production delete status update for production to cs reassign Production", e);
			}

		} catch (Exception ex) {
			LOGGER.error(CLASS_NAME, "caseAssignedbyCS", ex);
		}*/
		return isSaved;
	}

	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.ProductionService#listProductionFilesByCaseId(java.lang.
	 * Long, com.trivent.dto.ScreenListFilterVO)
	 * 
	 * @DateAndTime : Feb 6, 2018 - 10:03:31 AM
	 * 
	 * @Author : Ramya
	 * 
	 * @Description : Function to list production files by caseID
	 * 
	 * @Tags :
	 * 
	 * @param caseId - get list by caseId
	 * 
	 * @param screenListFilterVO - get required field
	 * 
	 * @return List - updatedRowVOs
	 * 
	 * @throws TriventException
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override
	@Transactional(readOnly = true)
	public List<RowVO> listProductionFilesByCaseId(Long caseId, ScreenListFilterVO screenListFilterVO ,String psType)
			throws TriventException {
		User loginUser = this.userService.getCurrentUser(null);
		//AppDBTable appdbTable = this.appDBTableRepository.findByName("ProdFile");
		ScreenListFilterVO screenListFilterVO1 = new ScreenListFilterVO();
		String screenType = AppConstants.SCREEN_TYPE_LIST;
		List<ProdFile> prodFiles = null;
		Specification<Production> specification = null;
		Specification<ProdFile> specification1 = null;
		//Specifications<ProdFile> specificationsProdFile = null;
		Specifications<ProdFile> specificationsProdFile = Specifications
			.where(this.genericSpecificationsProdFile.dataTypeCharacter("deleted", AppConstants.NO));
		Specifications<Production> specifications = Specifications
				.where(this.genericSpecificationsProduction.dataTypeCharacter("deleted", AppConstants.NO));
		if (loginUser.getRole().getType().equalsIgnoreCase(Role.ROLE_TYPE_CS_ROLES)) {
			specifications = specifications
					.or(this.genericSpecificationsProduction.dataTypeCharacter("deleted", AppConstants.YES));
		}
		
		if (StringUtils.isNotBlank(psType) && StringUtils.isNotEmpty(psType)) {
			switch (psType) {
			case AppConstants.ARCHIVAL_FTP_ACTION_BACKUP:
				specificationsProdFile = specificationsProdFile
						.and(this.genericSpecificationsProdFile.dataTypeCharacter("backup", AppConstants.NO));
				break;
			case AppConstants.ARCHIVAL_FTP_ACTION_REMOVE:
				specificationsProdFile = specificationsProdFile
						.and(this.genericSpecificationsProdFile.dataTypeCharacter("backup", AppConstants.YES));
				specificationsProdFile = specificationsProdFile
						.and(this.genericSpecificationsProdFile.dataTypeCharacter("removed", AppConstants.NO));
				break;
			default:
				break;
			}
			BeanUtils.copyProperties(screenListFilterVO, screenListFilterVO1);
		} else {
			//AppDBTable appdbTablePF = this.appDBTableRepository.findByName("ProdFile");
			String screenTypePF = AppConstants.SCREEN_TYPE_LIST;
			//screenListFilterVO1 = this.filterUtilsProdFile.populateScreenListFilterVO(appdbTablePF.getId(), screenTypePF);
			screenListFilterVO1 = this.filterUtilsProdFile.populateScreenListFilterVO(new Long(256), screenTypePF);
		}
		
		if (caseId != null) {
			Case appCase = this.caseRepository.findOne(caseId);
			if (appCase.getParentCase() == null) {
				List<Long> longCaseids = new ArrayList<>();
				List<Case> clientCases = this.caseRepository.findByParentId(caseId);
				for (Case cases : clientCases) {
					Long prntCaseId = cases.getId();
					longCaseids.add(prntCaseId);
				}
				longCaseids.add(caseId);
				if (longCaseids.size() > 0) {

					specifications = specifications
							.or(this.genericSpecificationsProduction.dataTypeCharacter("deleted", AppConstants.YES));

					Specification<Production> specificationNew = this.genericSpecificationsProduction
							.dataTypeLongList("caseId", longCaseids);
					specifications = specifications.and(specificationNew);
					specification = specifications;
				}
			} else {
				Specification<Production> specificationNew = this.genericSpecificationsProduction.dataTypeLong("caseId",
						caseId);
				specifications = specifications.and(specificationNew);
				specification = specifications;
			}
		}
		List<Production> prodList = this.productionRepository.findAll(specification);
		specificationsProdFile = Specifications
				.where(this.genericSpecificationsProdFile.dataTypeCharacter("deleted", AppConstants.NO));
		Specification<ProdFile> specificationNewPF = this.genericSpecificationsProdFile
				.dataTypeProductionList("productionId", prodList);
		specificationsProdFile = specificationsProdFile.and(specificationNewPF);
		if (prodList.isEmpty()) {
			prodFiles = new ArrayList<>();
			//return this.filterUtilsProdFile.listScreenDetails(appdbTable.getId(), screenType, prodFiles);
			return this.filterUtilsProdFile.listScreenDetails(new Long(256), screenType, prodFiles);
		}
		specificationsProdFile = this.filterUtilsProdFile.populateCaseViewSpecifications(screenListFilterVO, loginUser,
				specificationsProdFile, true);
		specificationsProdFile = this.filterUtilsProdFile.populateCaseFilterSpecifications(screenListFilterVO,
				specificationsProdFile);
		specification1 = specificationsProdFile;

		Page<ProdFile> requestedPage = this.prodFileRepository.findAll(specification1,
				this.filterUtilsProdFile.constructPageSpecification(screenListFilterVO));
		if (screenListFilterVO.getPageNo() > requestedPage.getTotalPages()) {
			screenListFilterVO.setPageNo(1);
			requestedPage = this.prodFileRepository.findAll(specification1,
					this.filterUtilsProdFile.constructPageSpecification(screenListFilterVO));
		}
		prodFiles = requestedPage.getContent();
		screenListFilterVO.setTotalPages(requestedPage.getTotalPages());
		screenListFilterVO.setCurrentRecords(requestedPage.getNumberOfElements());
		screenListFilterVO.setTotalRecords(requestedPage.getTotalElements());
		List<RowVO> updatedRowVOs = new ArrayList<>();
		//List<RowVO> rowVOs = this.filterUtilsProdFile.listScreenDetails(new Long(256), screenType, prodFiles);
		List<RowVO> rowVOs = this.filterUtilsProdFile.listScreenDetails(new Long(256), screenType, prodFiles);
		boolean repeatLoop = true;
		int loopIndex = 0;
		while (repeatLoop) {
			RowVO rowVO = rowVOs.get(loopIndex);
			Long prodFileId = rowVO.getId();
			if (prodFileId != null) {
				loopIndex += 1;
				rowVO = rowVOs.get(loopIndex);
			} else {
				repeatLoop = false;
				Map<String, String> prodDetailsMap = rowVO.getValueMap();
				prodDetailsMap.put("caseId", caseId.toString());
				Production production = this.productionRepository.getProductionPercentageupdate(caseId);
				if (production != null) {
					prodDetailsMap.put("productionId", production.getId().toString());
				} else {
					prodDetailsMap.put("productionId", "");
				}
				prodDetailsMap.put("loginId", loginUser.getId().toString());
				rowVO.setValueMap(prodDetailsMap);
				break;
			}
		}
		updatedRowVOs.addAll(rowVOs);
		return updatedRowVOs;
	}
	@Override
	@Transactional
	public Production getProductionByCase(Long caseID) {
		try {

			Production production = this.productionRepository.getProductionPercentageupdate(caseID);
			return production;
		} catch (Exception ex) {
			LOGGER.error(CLASS_NAME, "getProductionByCase", ex);
			return null;
		}
	}

}
