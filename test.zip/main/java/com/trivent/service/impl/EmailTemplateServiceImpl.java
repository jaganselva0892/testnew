package com.trivent.service.impl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.trivent.constants.AppConstants;
import com.trivent.logging.LogManager;
import com.trivent.logging.Logger;
import com.trivent.models.EmailTemplate;
import com.trivent.models.Partner;
import com.trivent.models.PartnerEmails;
import com.trivent.repository.EmailTemplateRepository;
import com.trivent.repository.PartnerEmailRepository;
import com.trivent.repository.PartnerRepository;
import com.trivent.service.EmailTemplateService;
import com.trivent.utils.FilterUtils;

/**
 * @FileName 	:
 *				EmailTemplateServiceImpl.java
 * @ClassName 	:
 * 				EmailTemplateServiceImpl
 * @DateAndTime :
 *				Feb 6, 2018 - 5:32:54 PM
 * 
 * @Author 		:
 * 				Ramya
 * 
 * @Description : 
 * 				Its to get email template,find by partner,code,id and list and save and delete emailTemplate.
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Service
public class EmailTemplateServiceImpl implements EmailTemplateService {

	
	@SuppressWarnings("unused")
	private static final Logger LOGGER = LogManager.getLogger();

	
	@SuppressWarnings("unused")
	private static final String CLASS_NAME = EmailTemplateServiceImpl.class.getName();

	
	@Autowired
	private EmailTemplateRepository emailTemplateRepository;

	
	@Value("${email.internal.employee.code}")
	private String emailInternalTo;

	
	@SuppressWarnings("unused")
	@Autowired
	private FilterUtils<EmailTemplate> filterUtils;
	
	
	@Autowired
	private PartnerRepository partnerRepository;
	
	@Autowired
	private PartnerEmailRepository partnerEmailRepository;

	
	/*(non-Javadoc)[Overriding Method]
	 * @OverridingMethod 	: @see com.trivent.service.EmailTemplateService#findEmailTemplateByCode(java.lang.String)
	 * 				
	 * @DateAndTime 		: Feb 6, 2018 - 5:32:54 PM
	 * 
	 * @Author 				: Ramya
	 * 
	 * @Description 		: Its to find email by template Code
	 * 				
	 * @Tags 				: 
	 *						@param templateCode - get email by using templateCode
	 *						@return  EmailTemplate - emailTemplates
	 * @Git_Config 			: 
	 *		 				name
	 * 						email
	 * 
	 */
	@Override
	@Transactional(readOnly = true)
	public EmailTemplate findEmailTemplateByCode(String templateCode) {
		List<EmailTemplate> emailTemplates = this.emailTemplateRepository.findByCode(templateCode);
		if (!emailTemplates.isEmpty()) {
			return emailTemplates.get(0);
		}
		return null;
	}

	/*(non-Javadoc)[Overriding Method]
	 * @OverridingMethod 	: @see com.trivent.service.EmailTemplateService#getPartnerEmails(com.trivent.entity.EmailTemplate, java.lang.String, java.lang.String, java.lang.String)
	 * 				
	 * @DateAndTime 		: Feb 6, 2018 - 5:32:54 PM
	 * 
	 * @Author 				: Ramya
	 * 
	 * @Description 		: Its to get partner email
	 * 				
	 * @Tags 				: 
	 *						@param emailTemplate - get email by emailTemplate
	 *						@param psType - get email by type
	 *						@param psValue - get email by value
	 *						@param partnerCode - get email by partner Code
	 *						@return String - returnValue
	 * @Git_Config 			: 
	 *		 				name
	 * 						email
	 * 
	 */
	@Override
	@Transactional
	public String getPartnerEmails(EmailTemplate emailTemplate, String psType, String psValue, String partnerCode) {
		String returnValue = psValue;
		try {
			if (this.emailInternalTo.equals(partnerCode.toLowerCase())) {
				return psValue;
			}
			if (StringUtils.isNotEmpty(partnerCode) && StringUtils.isNotBlank(partnerCode)) {

				Partner partner = this.partnerRepository.findByPartnerCode(partnerCode.toUpperCase());
				PartnerEmails partnerEmails = this.partnerEmailRepository.getByParterTemplate(AppConstants.NO, partner,
						emailTemplate);
				if (partnerEmails != null) {
					if (psType.equals(AppConstants.PARTNER_EMAIL_TYPE_TO)) {
						returnValue = partnerEmails.getEmailToList();
					} else if (psType.equals(AppConstants.PARTNER_EMAIL_TYPE_CC)) {
						returnValue = partnerEmails.getEmailCcList();
					} else if (psType.equals(AppConstants.PARTNER_EMAIL_TYPE_BCC)) {
						returnValue = partnerEmails.getEmailBccList();
					} else if (psType.equals(AppConstants.PARTNER_EMAIL_TYPE_SUBJECT)) {
						returnValue = partnerEmails.getLsPartnersubject();
					} else if (psType.equals(AppConstants.PARTNER_EMAIL_TYPE_MESSAGE)) {
						returnValue = partnerEmails.getLsPartnermessage();
					}
		
				}
			}
			if (StringUtils.isEmpty(returnValue)) {
				returnValue = psValue;
			}
			return returnValue;
		} catch (Exception ex) {
			LOGGER.error(CLASS_NAME, "getPartnerEmails - Partner Based", ex);
			return psValue;
		}
	}
	
	/*(non-Javadoc)[Overriding Method]
	 * @OverridingMethod 	: @see com.trivent.service.EmailTemplateService#findEmailTemplateByCode(java.lang.String, java.lang.String)
	 * 				
	 * @DateAndTime 		: Feb 6, 2018 - 5:32:54 PM
	 * 
	 * @Author 				: Ramya
	 * 
	 * @Description 		: Its to find email template by code
	 * 				
	 * @Tags 				: 
	 *						@param templateCode - find email by using templateCode
	 *						@param psPartnerCode - find email by using partnerCode
	 *						@return EmailTemplate - emailTemplate
	 * @Git_Config 			: 
	 *		 				name
	 * 						email
	 * 
	 */
	@Override
	@Transactional(readOnly = true)
	public EmailTemplate findEmailTemplateByCode(String templateCode, String psPartnerCode) {

		EmailTemplate emailTemplate = new EmailTemplate();
		try {

			List<EmailTemplate> emailTemplates = this.emailTemplateRepository.findByCode(templateCode);
			if ((emailTemplates.size() > 0) && !emailTemplates.isEmpty()) {

			    BeanUtils.copyProperties(emailTemplates.get(0), emailTemplate);

				String lsToEmailIds = emailTemplate.getIntEmailToList();
				String lsCcEmailIds = emailTemplate.getIntEmailCcList();
				String lsBccEmailIds = emailTemplate.getIntEmailBccList();
				String lsMessageSubject = emailTemplate.getSubject();
				String lsMessageBody = emailTemplate.getMessage();

				lsToEmailIds = this.getPartnerEmails(emailTemplates.get(0), AppConstants.PARTNER_EMAIL_TYPE_TO,
						lsToEmailIds, psPartnerCode);
				lsCcEmailIds = this.getPartnerEmails(emailTemplates.get(0), AppConstants.PARTNER_EMAIL_TYPE_CC,
						lsCcEmailIds, psPartnerCode);
				lsBccEmailIds = this.getPartnerEmails(emailTemplates.get(0), AppConstants.PARTNER_EMAIL_TYPE_BCC,
						lsBccEmailIds, psPartnerCode);
				lsMessageSubject = this.getPartnerEmails(emailTemplates.get(0), AppConstants.PARTNER_EMAIL_TYPE_SUBJECT,
						lsMessageSubject, psPartnerCode);
				lsMessageBody = this.getPartnerEmails(emailTemplates.get(0), AppConstants.PARTNER_EMAIL_TYPE_MESSAGE,
						lsMessageBody, psPartnerCode);

				emailTemplate.setIntEmailToList(lsToEmailIds);
				emailTemplate.setIntEmailCcList(lsCcEmailIds);
				emailTemplate.setIntEmailBccList(lsBccEmailIds);
				emailTemplate.setSubject(lsMessageSubject);
				emailTemplate.setMessage(lsMessageBody);
			}

		} catch (Exception e) {
			emailTemplate = null;
			LOGGER.error(CLASS_NAME, "findEmailTemplateByCode - Partner Based", e);
		}
		return emailTemplate;
	}

	
}
