package com.trivent.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.trivent.logging.LogManager;
import com.trivent.logging.Logger;
import com.trivent.models.EmailQueue;
import com.trivent.repository.EmailQueueRepository;
import com.trivent.repository.specifications.GenericSpecifications;
import com.trivent.service.EmailQueueService;

/**
 * @FileName 	:
 *				EmailQueueServiceImpl.java
 * @ClassName 	:
 * 				EmailQueueServiceImpl
 * @DateAndTime :
 *				Feb 6, 2018 - 6:10:11 PM
 * 
 * @Author 		:
 * 				Ramya
 * 
 * @Description : 
 * 				Its to get emailQueue,default screen filter,list and save emailQueue.
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Service
public class EmailQueueServiceImpl implements EmailQueueService {

	
	@SuppressWarnings("unused")
	private static final Logger LOGGER = LogManager.getLogger();

	
	@SuppressWarnings("unused")
	private static final String CLASS_NAME = EmailQueueServiceImpl.class.getName();

	
	@Autowired
	private EmailQueueRepository emailQueueRepository;

	
	@Autowired
	GenericSpecifications<EmailQueue> genericSpecifications;

	
	/*(non-Javadoc)[Overriding Method]
	 * @OverridingMethod 	: @see com.trivent.service.EmailQueueService#saveEmailQueue(com.trivent.entity.EmailQueue)
	 * 				
	 * @DateAndTime 		: Feb 6, 2018 - 6:10:11 PM
	 * 
	 * @Author 				: Ramya
	 * 
	 * @Description 		: Its to save Email Queue
	 * 				
	 * @Tags 				: 
	 *						@param emailQueue - save email queue by parameter
	 *						@return EmailQueue
	 * @Git_Config 			: 
	 *		 				name
	 * 						email
	 * 
	 */
	@Override
	@Transactional
	public EmailQueue saveEmailQueue(EmailQueue emailQueue) {
		return this.emailQueueRepository.save(emailQueue);
	}

	

}
