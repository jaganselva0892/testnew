package com.trivent.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.domain.Specifications;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.trivent.constants.AppConstants;
import com.trivent.dto.UserVO;
import com.trivent.logging.LogManager;
import com.trivent.logging.Logger;
import com.trivent.models.Account;
import com.trivent.models.AppConfig;
import com.trivent.models.Case;
import com.trivent.models.EmailQueue;
import com.trivent.models.Partner;
import com.trivent.models.User;
import com.trivent.repository.AccountRepository;
import com.trivent.repository.AppConfigRepository;
import com.trivent.repository.AppSequenceRefRepository;
import com.trivent.repository.MetadataRepository;
import com.trivent.repository.PartnerRepository;
import com.trivent.repository.UserRepository;
import com.trivent.repository.specifications.GenericSpecifications;
import com.trivent.service.AppConfigService;
import com.trivent.service.EmailService;

/**
 * @ProjectName : trivent
 * @PackageName : com.trivent.service.impl
 * 
 * @FileName : AppConfigServiceImpl.java
 * @TypeName : AppConfigServiceImpl
 * @DateAndTime : Feb 8, 2018 - 10:18:21 AM
 * 
 * @Author : seetha
 * 
 * @Description : to give status and time confirgation for auto archival
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
@Service
public class AppConfigServiceImpl implements AppConfigService {

	private static final Logger LOGGER = LogManager.getLogger();

	private static final String CLASS_NAME = AppConfigServiceImpl.class.getName();

	@Autowired
	private UserRepository userRepository;

	@Autowired
	GenericSpecifications<Case> genericSpecifications;

	@Autowired
	private AccountRepository accountRepository;

	@Autowired
	private AppConfigRepository appConfigRepository;

	@Value("${email.internal.employee.code}")
	private String emailInternalTo;

	@Autowired
	AppSequenceRefRepository appSequenceRefRepository;

	@Autowired
	PartnerRepository partnerRepository;

	@Autowired
	MetadataRepository metadataRepository;

	@Autowired
	private EmailService emailService;

	@Autowired
	GenericSpecifications<User> userGenericSpecifications;

	@Autowired
	GenericSpecifications<Account> accountGenericSpecifications;

	@Autowired
	GenericSpecifications<Partner> partnerGenericSpecifications;

	@Autowired
	GenericSpecifications<AppConfig> appConfigGenericSpecifications;

	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @FileName : AppConfigServiceImpl.java
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.AppConfigService#getCustomerMailPermission(com.trivent.
	 * entity.EmailQueue, java.lang.String)
	 * 
	 * @DateAndTime : Feb 8, 2018 - 10:18:22 AM
	 * 
	 * @Author : seetha
	 * 
	 * @Description : to get Customer Mail Permission
	 * 
	 * @Tags :
	 * 
	 * @param emailQueue - to get to , cc and email info details
	 * 
	 * @param emailType - to identify type of email
	 * 
	 * @return boolean value - if emailQueue and emailType is not matched appConfig
	 * data returns false
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override
	@Transactional(readOnly = true)
	public boolean getCustomerMailPermission(EmailQueue emailQueue, String emailType,UserVO userVO) {

		boolean blReturn = true;
		try {

			LOGGER.debug(CLASS_NAME, "Mail send check permission function Start", "Start the function");
			String mailIds = StringUtils.EMPTY;

			if (StringUtils.isNotEmpty(emailQueue.getToEmailIds())
					&& StringUtils.isNotBlank(emailQueue.getToEmailIds())) {
				mailIds = emailQueue.getToEmailIds();
			}
			if (StringUtils.isNotEmpty(emailQueue.getCcEmailIds())
					&& StringUtils.isNotBlank(emailQueue.getCcEmailIds())) {
				if (StringUtils.isNotEmpty(mailIds) && StringUtils.isNotBlank(mailIds)) {
					mailIds += "," + emailQueue.getCcEmailIds();
				} else {
					mailIds = emailQueue.getCcEmailIds();
				}
			}
			if (StringUtils.isNotEmpty(emailQueue.getBccEmailIds())
					&& StringUtils.isNotBlank(emailQueue.getBccEmailIds())) {
				if (StringUtils.isNotEmpty(mailIds) && StringUtils.isNotBlank(mailIds)) {
					mailIds += "," + emailQueue.getBccEmailIds();
				} else {
					mailIds = emailQueue.getBccEmailIds();
				}
			}
			mailIds = mailIds.replace(',', ';');
			String mailIdsList[] = mailIds.split(";");
			List<String> mailListId = new ArrayList<>();
			for (String mailId : mailIdsList) {
			    mailListId.add(mailId);
					}

			if (mailListId.size() > 0) {
				Specification<User> specification = null;

				Specifications<User> specifications = Specifications
						.where(this.userGenericSpecifications.anyUsersLogin("loginId", mailListId));

				specification = specifications;

				List<User> userList = this.userRepository.findAll(specification);

				List<Long> accountListId = new ArrayList<>();
				List<String> accountstrListId = new ArrayList<>();
				List<String> userstrListId = new ArrayList<>();
				for (User user : userList) {
					if ((user != null) && user.getType().equals(User.USER_TYPE_CLIENT) && (user.getAccount() != null)
							&& (user.getAccount().getId() != null)) {
						accountListId.add(user.getAccount().getId());
						accountstrListId.add(user.getAccount().getId().toString());
						userstrListId.add(user.getId().toString());
					}
				}

				if (accountListId.size() > 0) {
					Specification<Account> specificationAccount = null;

					Specifications<Account> specificationsAccount = Specifications
							.where(this.accountGenericSpecifications.dataTypeLongList("id", accountListId));

					specificationAccount = specificationsAccount;

					List<Account> accountList = this.accountRepository.findAll(specificationAccount);

					List<Long> partnerListId = new ArrayList<>();
					List<String> partnerstrListId = new ArrayList<>();
					for (Account account : accountList) {
						if ((account != null) && (account.getPartner() != null)
								&& (account.getPartner().getId() != null)) {
							partnerListId.add(account.getPartner().getId());
							partnerstrListId.add(account.getPartner().getId().toString());
						}
					}

					if (!this.appConfigCheck(emailType, partnerstrListId, AppConstants.APP_CONFIG_MAIL_SEND_PARTNER)) {
						blReturn = false;
						LOGGER.info(CLASS_NAME, "Mail send check permission function Start Partner not have permission",
								"Partner not have permission");
					} else {
						if (!this.appConfigCheck(emailType, accountstrListId,
								AppConstants.APP_CONFIG_MAIL_SEND_ACCOUNT)) {
							blReturn = false;
							LOGGER.info(CLASS_NAME,
									"Mail send check permission function Start Partner not have permission",
									"Account not have permission");
						} else {
							if (!emailType.equalsIgnoreCase(AppConstants.APP_CONFIG_WELCOME_MAIL)) {
								if (!this.appConfigCheck(emailType, userstrListId,
										AppConstants.APP_CONFIG_MAIL_SEND_CLIENT)) {
									blReturn = false;
									LOGGER.info(CLASS_NAME,
											"Mail send check permission function Start Partner not have permission",
											"User not have permission");
								}
							}

						}
					}
				}

			}

		} catch (Exception e) {
			blReturn = false;
			LOGGER.error(CLASS_NAME, "Mail send check permission function", e);
		}

		if (!blReturn) {
			try {
				emailQueue.setStatus(EmailQueue.STATUS_PERMISSION);
				this.emailService.queueEmailSave(emailQueue,userVO);
			} catch (Exception e) {
				LOGGER.error(CLASS_NAME, "Mail Save Queue Function Error", e);
			}
		}
		return blReturn;

	}
	
	
	/**
	 * [Methods]
	 * 
	 * @FileName : AppConfigServiceImpl.java
	 * 
	 * @DateAndTime : Feb 8, 2018 - 10:18:21 AM
	 * 
	 * @Author : seetha
	 * 
	 * @Description : to Check app Config data
	 * 
	 * @Tags :
	 * @param emailType
	 *            - to identify emailType with appConfig mail type
	 * @param idList
	 *            - to check any config is checked
	 * @param typeScreen
	 *            - to show which screen to display
	 * @return - boolean value if is mail type is in app config then boolean returns
	 *         true
	 * @Git_Config : name email
	 * 
	 */
	private boolean appConfigCheck(String emailType, List<String> idList, String typeScreen) {

		boolean blReturn = false;
		try {
			Specification<AppConfig> specificationAppConfig = null;

			Specifications<AppConfig> specificationsAppConfig = Specifications
					.where(this.appConfigGenericSpecifications.dataTypeCharacter("deleted", AppConstants.NO));

			specificationAppConfig = this.appConfigGenericSpecifications.dataTypeStringEqual("screen", typeScreen);

			specificationsAppConfig = specificationsAppConfig.and(specificationAppConfig);

			specificationAppConfig = specificationsAppConfig;

			List<AppConfig> appConfigList = this.appConfigRepository.findAll(specificationAppConfig);

			if ((idList.size() > 0) && (appConfigList.size() > 0)) {
				specificationAppConfig = null;

				specificationsAppConfig = Specifications
						.where(this.appConfigGenericSpecifications.dataTypeStringList("name", idList));

				specificationAppConfig = this.appConfigGenericSpecifications.anyAppConfig("appRefConfig",
						appConfigList);

				specificationsAppConfig = specificationsAppConfig.and(specificationAppConfig);

				specificationAppConfig = this.appConfigGenericSpecifications.dataTypeCharacter("deleted",
						AppConstants.NO);

				specificationsAppConfig = specificationsAppConfig.and(specificationAppConfig);

				specificationAppConfig = specificationsAppConfig;

				appConfigList = this.appConfigRepository.findAll(specificationAppConfig);

				for (AppConfig appConfig : appConfigList) {
					if (appConfig.getLinkUrl() != null) {
						String[] emailTypes = appConfig.getLinkUrl().split(",");
						for (String mailType : emailTypes) {
							if (emailType.trim().equalsIgnoreCase(mailType.trim())) {
								blReturn = true;
								break;
							}
						}
					}
				}
			}

		} catch (Exception e) {
			blReturn = false;
			LOGGER.error(CLASS_NAME, "appConfigCheck", e);
		}
		return blReturn;
	}

	
}