package com.trivent.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.domain.Specifications;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.trivent.constants.AppConstants;
import com.trivent.dto.AppConfigDataVO;
import com.trivent.logging.LogManager;
import com.trivent.logging.Logger;
import com.trivent.models.AppConfigData;
import com.trivent.repository.AppConfigDataRepository;
import com.trivent.repository.specifications.GenericSpecifications;
import com.trivent.service.AppConfigDataService;

/**
 * @ProjectName :
 *				trivent
 * @PackageName :
 *				com.trivent.service.impl
 * 
 * @FileName 	:
 *				AppConfigDataServiceImpl.java
 * @TypeName 	:
 * 				AppConfigDataServiceImpl
 * @DateAndTime :
 *				Nov 21, 2018 - 10:07:04 AM
 * 
 * @Author 		:
 * 				Karthi
 * 
 * @Description : to give status and time confirgation for auto archival
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Service
public class AppConfigDataServiceImpl implements AppConfigDataService {

	private static final Logger LOGGER = LogManager.getLogger();

	private static final String CLASS_NAME = AppConfigDataServiceImpl.class.getName();

	@Autowired
	private AppConfigDataRepository appConfigDataRepository;
	
	@Autowired
	private GenericSpecifications<AppConfigData> appConfigDataGenericSpecifications;

	

	/*(non-Javadoc)[Overriding Method]
	 * @FileName 			: AppConfigDataServiceImpl.java
	 * 
	 * @OverridingMethod 	: @see com.trivent.service.AppConfigDataService#getAppConfigDataVOList(java.util.List)
	 * 				
	 * @DateAndTime 		: Feb 8, 2018 - 10:07:04 AM
	 * 
	 * @Author 				: Karthik
	 * 
	 * @Description 		: to get AppConfigDataVO List
	 * 				
	 * @Tags 				: 
	 *						@param strNames - to get list of config names
	 *						@return
	 * @Git_Config 			: 
	 *		 				name
	 * 						email
	 * 
	 */
	@Override
	@Transactional(readOnly = true)
	public List<AppConfigDataVO> getAppConfigDataVOList(List<String> strNames) {

		List<AppConfigDataVO> appConfigDataVOList = new ArrayList<>();
		try {

			Specification<AppConfigData> specificationAppConfigData = null;

			Specifications<AppConfigData> specificationsAppConfigData = Specifications
					.where(this.appConfigDataGenericSpecifications.dataTypeCharacter("deleted", AppConstants.NO));

			specificationAppConfigData = this.appConfigDataGenericSpecifications.dataTypeStringList("name", strNames);
			specificationsAppConfigData = specificationsAppConfigData.and(specificationAppConfigData);

			specificationAppConfigData = specificationsAppConfigData;

			List<AppConfigData> appConfigList = this.appConfigDataRepository.findAll(specificationAppConfigData);

			for (AppConfigData appConfigData : appConfigList) 
				appConfigDataVOList.add(new AppConfigDataVO(appConfigData));

		} catch (Exception e) {
			appConfigDataVOList = new ArrayList<>();
			LOGGER.error(CLASS_NAME, "getAppConfigDataVO", e);
		} 
		return appConfigDataVOList;
	}

	

}