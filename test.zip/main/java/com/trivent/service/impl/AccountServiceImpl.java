package com.trivent.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.domain.Specifications;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.trivent.constants.AppConstants;
import com.trivent.dto.AccountVO;
import com.trivent.exceptions.JwtTokenMissingException;
import com.trivent.logging.LogManager;
import com.trivent.logging.Logger;
import com.trivent.models.Account;
import com.trivent.models.Partner;
import com.trivent.models.UserAuth;
import com.trivent.repository.AccountRepository;
import com.trivent.repository.PartnerRepository;
import com.trivent.repository.UserAuthRepository;
import com.trivent.repository.specifications.GenericSpecifications;
import com.trivent.service.AccountService;

@Service
public class AccountServiceImpl implements AccountService {

	private static final Logger LOGGER = LogManager.getLogger();

	private static final String CLASS_NAME = CaseServiceImpl.class.getName();

	@Autowired
	private AccountRepository accountRepository;

	@Autowired
	private GenericSpecifications<Account> accountGSpecifications;

	@Autowired
	private UserAuthRepository userAuthRepository;

	@Value("${login_token_expiry_time}")
	private int loginTokenExpiryTime;

	@Value("${jwt.header}")
	private String tokenHeader;

	@Autowired
	private PartnerRepository partnerRepository;

	@Override
	@Transactional
	public List<Account> getAccountByName(String searchText) {

		List<Account> accountList = new ArrayList<>();
		try {

			if (searchText != null && !searchText.isEmpty()) {
				Specification<Account> specification = null;
				Specifications<Account> specifications = Specifications
						.where(this.accountGSpecifications.dataTypeCharacter("deleted", AppConstants.NO));

				specification = this.accountGSpecifications.dataTypeString("name", searchText);
				specifications = specifications.and(specification);

				specification = specifications;
				accountList = this.accountRepository.findAll(specification);
			} else {
				LOGGER.warn(CLASS_NAME, "getAccountByName", "searchText String is empty");
			}

		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "getAccountByName", e);
		} finally {

		}
		return accountList;

	}

	@Override
	@Transactional
	public List<AccountVO> getAccount(HttpServletRequest request, String strPartnerCode) {
		List<AccountVO> accountVOlist = new ArrayList<AccountVO>();
		try {
			char isDeleted = AppConstants.NO;
			String header = request.getHeader(this.tokenHeader);
			String ipAddress = request.getHeader("X-FORWARDED-FOR");
			if (ipAddress == null) {
				ipAddress = request.getRemoteAddr();
			}
			if (header == null || !header.startsWith("Bearer ")) {
				throw new JwtTokenMissingException("No JWT token found in request headers");
			}
			String authToken = header.substring(7);
			UserAuth userAuth = userAuthRepository.findByTokenIP(authToken.trim(), AppConstants.NO);
			AccountVO accountVO = new AccountVO();
			if (userAuth != null) {
				Partner getCurrentSessionPartner = partnerRepository.findByPartnerCode(strPartnerCode);
				List<Account> account = accountRepository.getAllAccount(getCurrentSessionPartner, isDeleted);
				for (Account accounts : account) {
					accountVO = new AccountVO(accounts);
					accountVOlist.add(accountVO);
				}
			} else {
				accountVO = null;
			}
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "getAccount", e);
		}
		return accountVOlist;
	}
}
