package com.trivent.service.impl;

import java.lang.reflect.InvocationTargetException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Properties;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.domain.Specifications;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.trivent.constants.AppConstants;
import com.trivent.dto.AppConfigDataVO;
import com.trivent.dto.AppItemVO;
import com.trivent.dto.AppSubItemVO;
import com.trivent.dto.AppUIScreenFieldVO;
import com.trivent.dto.AppUIScreenFilterVO;
import com.trivent.dto.CaseDetailsVO;
import com.trivent.dto.CaseVO;
import com.trivent.dto.DropDownVO;
import com.trivent.dto.RowVO;
import com.trivent.dto.ScreenListFilterVO;
import com.trivent.dto.UserVO;
import com.trivent.exceptions.TriventException;
import com.trivent.logging.LogManager;
import com.trivent.logging.Logger;
import com.trivent.models.Account;
import com.trivent.models.AppDBTable;
import com.trivent.models.AppItem;
import com.trivent.models.AppLabels;
import com.trivent.models.AppList;
import com.trivent.models.AppSequenceRef;
import com.trivent.models.AppServiceDesc;
import com.trivent.models.AppSubItem;
import com.trivent.models.AppUIScreen;
import com.trivent.models.AppUIScreenField;
import com.trivent.models.AppUIScreenView;
import com.trivent.models.Capability;
import com.trivent.models.Case;
import com.trivent.models.CaseContacts;
import com.trivent.models.CaseLabels;
import com.trivent.models.CaseQuery;
import com.trivent.models.CaseReportUser;
import com.trivent.models.CaseServiceReq;
import com.trivent.models.CaseServiceReqDetail;
import com.trivent.models.CaseTask;
import com.trivent.models.Contact;
import com.trivent.models.EmailQueue;
import com.trivent.models.EmailTemplate;
import com.trivent.models.Partner;
import com.trivent.models.Permission;
import com.trivent.models.Production;
import com.trivent.models.Role;
import com.trivent.models.StatusFlowRef;
import com.trivent.models.User;
import com.trivent.repository.AccountRepository;
import com.trivent.repository.AppDBTableRepository;
import com.trivent.repository.AppItemRepository;
import com.trivent.repository.AppLabelsRepository;
import com.trivent.repository.AppListRepository;
import com.trivent.repository.AppSequenceRefRepository;
import com.trivent.repository.AppServiceDescRepository;
import com.trivent.repository.AppSubItemRepository;
import com.trivent.repository.CapabilityRepository;
import com.trivent.repository.CaseContactsRepository;
import com.trivent.repository.CaseLabelsRepository;
import com.trivent.repository.CaseReportUserRepository;
import com.trivent.repository.CaseRepository;
import com.trivent.repository.CaseServiceReqDetailRepository;
import com.trivent.repository.CaseServiceReqRepository;
import com.trivent.repository.CaseTaskRepository;
import com.trivent.repository.ContactRepository;
import com.trivent.repository.PermissionRepository;
import com.trivent.repository.ProductionRepository;
import com.trivent.repository.ReportRepository;
import com.trivent.repository.RoleRepository;
import com.trivent.repository.StatusFlowRefRepository;
import com.trivent.repository.UserRepository;
import com.trivent.repository.specifications.GenericSpecifications;
import com.trivent.service.AppConfigDataService;
import com.trivent.service.AppConfigService;
import com.trivent.service.CacheService;
import com.trivent.service.CaseReportUserService;
import com.trivent.service.CaseService;
import com.trivent.service.EmailService;
import com.trivent.service.EmailTemplateService;
import com.trivent.service.PartnerService;
import com.trivent.service.ProductionService;
import com.trivent.service.UserService;
import com.trivent.utils.CommonUtils;
import com.trivent.utils.FilterUtils;

/**
 * @FileName : CaseServiceImpl.java
 * @ClassName : CaseServiceImpl
 * @DateAndTime : Nov 21, 2018 - 12:26:52 PM
 * 
 * @Author : Karthi
 * 
 * @Description : Its to get case list,case type,case
 *              service,caseVO,caseDetails,caseEntity,save,send,update,delete
 *              case.
 * @Tags :
 * @Git_Config : name email
 * 
 */
@Service
public class CaseServiceImpl implements CaseService {

	private static final Logger LOGGER = LogManager.getLogger();

	private static final String CLASS_NAME = CaseServiceImpl.class.getName();

	private static final String METHOD_GET_CASE = "getCase";
	
	private static final String METHOD_SAVE_CASE = "saveCase";


	@SuppressWarnings("unused")
	@Autowired
	private JmsTemplate jmsTemplate;

	@Autowired
	private UserService userService;

	@Autowired
	private CaseRepository caseRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private ProductionService productionService;

	@Autowired
	private CacheService cacheService;

	@Autowired
	private AppListRepository appListRepository;

	@Autowired
	private Properties applicationProperties;

	@Autowired
	private StatusFlowRefRepository statusFlowRefRepository;

	@Autowired
	private AppConfigDataService appConfigDataService;

	@Autowired
	private GenericSpecifications<AppItem> appItemGSpecifications;

	@Autowired
	private AppItemRepository appItemRepository;

	@Autowired
	private ProductionRepository productionRepository;

	@Autowired
	private CaseLabelsRepository caseLabelsRepository;

	@Autowired
	private CaseReportUserService caseReportUserService;

	@SuppressWarnings("unused")
	@Autowired
	private AppDBTableRepository appDBTableRepository;

	@Autowired
	private AppSequenceRefRepository appSequenceRefRepository;

	@Autowired
	private GenericSpecifications<Contact> contactGSpecifications;

	@Autowired
	private ContactRepository contactRepository;

	@Autowired
	private CaseServiceReqRepository caseServiceReqRepository;

	@Autowired
	private CaseServiceReqDetailRepository caseServiceReqDetailRepository;

	@Autowired
	private FilterUtils<Case> filterUtils;

	@Autowired
	private PartnerService partnerService;

	@Autowired
	private AppServiceDescRepository appServiceDescRepository;

	@Autowired
	private RoleRepository roleRepository;

	@Autowired
	private CapabilityRepository capabilityRepository;

	@Autowired
	private PermissionRepository permissionRepository;

	@Autowired
	private CaseContactsRepository caseContactsRepository;

	@Autowired
	private AccountRepository accountRepository;

	@Autowired
	private GenericSpecifications<Case> caseGSpecifications;

	@Autowired
	private ReportRepository reportRepository;

	@Autowired
	private GenericSpecifications<AppItem> appItemGenericSpecifications;
	
	@Autowired
	private CaseReportUserRepository caseReportUserRepository;
	
	@Autowired
	private CaseTaskRepository caseTaskRepository;

	@Value("${email.internal.employee.code}")
	private String emailInternalTo;

	@Autowired
	private AppConfigService appConfigService;
	
	@Autowired
	private GenericSpecifications<CaseContacts> caseContactsGSpecifications;

	@Autowired
	private EmailTemplateService emailTemplateService;
	
	@Autowired
	private EmailService emailService;
	
	@Autowired
	private AppSubItemRepository appSubItemRepository;
	@Autowired
	private AppLabelsRepository appLabelsRepository;


	@SuppressWarnings("unused")
	@Override
	@Transactional
	public CaseVO saveCase(CaseVO caseVO, UserVO userVO) throws TriventException {
		if (caseVO.isNew()) {
			return this.saveNewCase(caseVO, userVO);
		}

		try {
			// Update the case labels
			User loginUser = this.userService.getCurrentUser(userVO);
			Case appCase = this.getCase(caseVO.getId());

			Case appCase1 = this.caseRepository.getOne(caseVO.getId());
			User appCasePreviousAssignedTo = appCase1.getAssignedTo();
			CaseVO caseVOForAssign = new CaseVO();
			this.updateObjectFromAppUIScreenFieldVOValues(caseVOForAssign, caseVO.getAppUIScreenFieldVOs());
			if (caseVOForAssign.getAssignedTo() != null && StringUtils.isNotBlank(caseVOForAssign.getAssignedTo())
					&& StringUtils.isNotEmpty(caseVOForAssign.getAssignedTo())
					&& !caseVOForAssign.getAssignedTo().equalsIgnoreCase("undefined")) {
				User appUser = userRepository.findOne(Long.parseLong(caseVOForAssign.getAssignedTo()));
				if (appUser != null) {
					// Save in production header table
					if (!Objects.equals(appUser, null)) {
						if (!Objects.equals(appCasePreviousAssignedTo, appUser)) {
							boolean isSaved = this.productionService.caseAssignedbyCS(appUser.getId(),
									appCase1.getId());
							if (isSaved == false) {
								caseVO.setStatusMsg(AppConstants.ASSIGNED_FAIL_TIMER_RUNNING);
								return caseVO;
							}
						}
					}
				}
			}

			String presentCsStatus = appCase.getCsStatus();

			this.updateObjectFromAppUIScreenFieldVOValues(appCase, caseVO.getAppUIScreenFieldVOs());
			User appCaseNowAssignedTo = appCase.getAssignedTo();

			if (!StringUtils.equals(appCase.getCsStatus(), presentCsStatus)) {

				StatusFlowRef selectedStatusFlowRef = this.statusFlowRefRepository
						.findByCsStatus(StatusFlowRef.OBJ_TYPE_CASE, appCase.getCsStatus(), AppConstants.NO);
				appCase.setClientStatus(selectedStatusFlowRef.getCustomerStatus());

				try // Check with the status in configurable option on 22 Aug 2017
				{
					Calendar today = Calendar.getInstance();
					List<String> strConfigDatas = new ArrayList<>();
					strConfigDatas.add(
							this.applicationProperties.getProperty("application.configuration.case.csstatus.change"));
					strConfigDatas.add(this.applicationProperties
							.getProperty("application.configuration.case.csstatus.csDeliveryDate"));
					strConfigDatas.add(this.applicationProperties
							.getProperty("application.configuration.case.csstatus.csEstimateSendDate"));
					strConfigDatas.add(this.applicationProperties
							.getProperty("application.configuration.case.csstatus.produtionEstimateSendDate"));
					strConfigDatas.add(this.applicationProperties
							.getProperty("application.configuration.case.csstatus.estimateApprovalReceivedDate"));
					strConfigDatas.add(this.applicationProperties
							.getProperty("application.configuration.case.csstatus.revisedEstimateSendDate"));
					strConfigDatas.add(this.applicationProperties
							.getProperty("application.configuration.prodstatus.change.basedon.csstatus.change"));
					strConfigDatas.add(this.applicationProperties
							.getProperty("application.configuration.case.csstatus.partialDeliveryDate"));
					List<AppConfigDataVO> appConfigDataVOList = this.appConfigDataService
							.getAppConfigDataVOList(strConfigDatas);

					List<Long> appItemIds = new ArrayList<>();
					for (final AppConfigDataVO appConfigDataVO : appConfigDataVOList) {
						appItemIds = new ArrayList<>();
						if (appConfigDataVO.getName().equalsIgnoreCase(this.applicationProperties
								.getProperty("application.configuration.case.csstatus.csDeliveryDate"))) {
							String[] strIds = appConfigDataVO.getDataValue().split(",");
							for (String strId : strIds) {
								if (NumberUtils.isNumber(strId)) {
									appItemIds.add(new Long(strId));
								}
							}
							if (appItemIds.size() > 0) {

								Specification<AppItem> specificationAppItem = null;
								Specifications<AppItem> specificationsAppItem = Specifications
										.where(this.appItemGSpecifications.dataTypeLongList("id", appItemIds));
								specificationAppItem = specificationsAppItem;
								List<AppItem> appItemList = this.appItemRepository.findAll(specificationAppItem);
								for (AppItem appItem : appItemList) {
									if (StringUtils.equals(appCase.getCsStatus(), appItem.getLongName())) {
										appCase.setFileDeliveryDate(today);
										// Update Partial Delivery Agent
										if (caseVO.getCf_3_Number() != null
												&& StringUtils.isNotBlank(caseVO.getCf_3_Number())
												&& StringUtils.isNotEmpty(caseVO.getCf_3_Number())) {
											appCase.setCf_3_Number(Integer.parseInt(caseVO.getCf_3_Number()));
										} else {
											if (loginUser != null)
												appCase.setCf_3_Number(Integer.parseInt(loginUser.getId().toString()));
										}
										break;
									}
								}
							}
						} else if (appConfigDataVO.getName().equalsIgnoreCase(this.applicationProperties
								.getProperty("application.configuration.case.csstatus.csEstimateSendDate"))) {
							String[] strIds = appConfigDataVO.getDataValue().split(",");
							for (String strId : strIds) {
								if (NumberUtils.isNumber(strId)) {
									appItemIds.add(new Long(strId));
								}
							}
							if (appItemIds.size() > 0) {

								Specification<AppItem> specificationAppItem = null;

								Specifications<AppItem> specificationsAppItem = Specifications
										.where(this.appItemGSpecifications.dataTypeLongList("id", appItemIds));

								specificationAppItem = specificationsAppItem;

								List<AppItem> appItemList = this.appItemRepository.findAll(specificationAppItem);
								for (AppItem appItem : appItemList) {
									if (StringUtils.equals(appCase.getCsStatus(), appItem.getLongName())) {
										appCase.setCf_3_Date(today);
										break;
									}
								}
							}
						} else if (appConfigDataVO.getName().equalsIgnoreCase(this.applicationProperties
								.getProperty("application.configuration.case.csstatus.estimateApprovalReceivedDate"))) {
							String[] strIds = appConfigDataVO.getDataValue().split(",");
							for (String strId : strIds) {
								if (NumberUtils.isNumber(strId)) {
									appItemIds.add(new Long(strId));
								}
							}
							if (appItemIds.size() > 0) {
								Specification<AppItem> specificationAppItem = null;
								Specifications<AppItem> specificationsAppItem = Specifications
										.where(this.appItemGSpecifications.dataTypeLongList("id", appItemIds));
								specificationAppItem = specificationsAppItem;
								List<AppItem> appItemList = this.appItemRepository.findAll(specificationAppItem);
								for (AppItem appItem : appItemList) {
									if (StringUtils.equals(appCase.getCsStatus(), appItem.getLongName())) {
										appCase.setEstApprovedDate(today);
										break;
									}
								}
							}

						} else if (appConfigDataVO.getName().equalsIgnoreCase(this.applicationProperties
								.getProperty("application.configuration.case.csstatus.revisedEstimateSendDate"))) {
							String[] strIds = appConfigDataVO.getDataValue().split(",");
							for (String strId : strIds) {
								if (NumberUtils.isNumber(strId)) {
									appItemIds.add(new Long(strId));
								}
							}
							if (appItemIds.size() > 0) {
								Specification<AppItem> specificationAppItem = null;
								Specifications<AppItem> specificationsAppItem = Specifications
										.where(this.appItemGSpecifications.dataTypeLongList("id", appItemIds));
								specificationAppItem = specificationsAppItem;
								List<AppItem> appItemList = this.appItemRepository.findAll(specificationAppItem);
								for (AppItem appItem : appItemList) {
									if (StringUtils.equals(appCase.getCsStatus(), appItem.getLongName())) {
										appCase.setRevisedEstiamteSendDate(today);
										break;
									}
								}
							}

						} else if (appConfigDataVO.getName().equalsIgnoreCase(this.applicationProperties
								.getProperty("application.configuration.case.csstatus.change"))) {
							String[] strIds = appConfigDataVO.getDataValue().split(",");
							for (String strId : strIds) {
								if (NumberUtils.isNumber(strId)) {
									appItemIds.add(new Long(strId));
								}
							}
							if (appItemIds.size() > 0) {

								Specification<AppItem> specificationAppItem = null;

								Specifications<AppItem> specificationsAppItem = Specifications
										.where(this.appItemGSpecifications.dataTypeLongList("id", appItemIds));

								specificationAppItem = specificationsAppItem;

								List<AppItem> appItemList = this.appItemRepository.findAll(specificationAppItem);
								for (AppItem appItem : appItemList) {
									if (StringUtils.equals(presentCsStatus, appItem.getLongName())) {
										// this.fileArchival.archivalTodelete(appCase,
										// AppConstants.ARCHIVAL_IS_CASE_FILE);
										break;
									}
								}
							}

						} else if (appConfigDataVO.getName().equalsIgnoreCase(this.applicationProperties
								.getProperty("application.configuration.prodstatus.change.basedon.csstatus.change"))) {
							/* Prod Status based on cs status */
							if (appConfigDataVO.getDataValue() != null) {
								String[] strIds = appConfigDataVO.getDataValue().split(",");
								for (String strId : strIds) {
									if (NumberUtils.isNumber(strId)) {
										appItemIds.add(new Long(strId));
									}
								}
								if (appItemIds.size() > 0) {
									Specification<AppItem> specificationAppItem = null;
									Specifications<AppItem> specificationsAppItem = Specifications
											.where(this.appItemGSpecifications.dataTypeLongList("id", appItemIds));
									specificationAppItem = specificationsAppItem;
									List<AppItem> appItemList = this.appItemRepository.findAll(specificationAppItem);
									for (AppItem appItem : appItemList) {
										if (StringUtils.equals(appCase.getCsStatus(), appItem.getLongName())) {
											if (!Objects.equals(appCaseNowAssignedTo, null)) {
												this.modifyProdStatus(appCase.getId());
												break;
											}
										}
									}
								}
							}
						} else if (appConfigDataVO.getName().equalsIgnoreCase(this.applicationProperties
								.getProperty("application.configuration.case.csstatus.partialDeliveryDate"))) {
							String[] strIds = appConfigDataVO.getDataValue().split(",");
							for (String strId : strIds) {
								if (NumberUtils.isNumber(strId)) {
									appItemIds.add(new Long(strId));
								}
							}
							if (appItemIds.size() > 0) {
								Specification<AppItem> specificationAppItem = null;
								Specifications<AppItem> specificationsAppItem = Specifications
										.where(this.appItemGSpecifications.dataTypeLongList("id", appItemIds));
								specificationAppItem = specificationsAppItem;
								List<AppItem> appItemList = this.appItemRepository.findAll(specificationAppItem);
								for (AppItem appItem : appItemList) {
									if (StringUtils.equals(appCase.getCsStatus(), appItem.getLongName())) {
										appCase.setFileMigrationDate(today);
										// Update Partial Delivery Agent
										if (caseVO.getCf_3_Text() != null
												&& StringUtils.isNotBlank(caseVO.getCf_3_Text())
												&& StringUtils.isNotEmpty(caseVO.getCf_3_Text())) {
											appCase.setCf_3_Text(caseVO.getCf_3_Text());
										} else {
											if (loginUser != null)
												appCase.setCf_3_Text(loginUser.getId().toString());
										}
										break;
									}
								}
							}
						}

					}
				} catch (Exception e) {
					LOGGER.error(CLASS_NAME, "archival file based on status configure", e);
				}
			}

			if (loginUser.getRole().getType().equals(Role.ROLE_TYPE_CS_ROLES) && (caseVO.getTitle() != null)) {
				List<CaseLabels> caseLabels = this.caseLabelsRepository.findLabelsByCaseID(caseVO.getId(),
						AppConstants.NO);
				for (CaseLabels caseLabels2 : caseLabels) {
					CaseLabels caseLabel = this.caseLabelsRepository.findOne(caseLabels2.getId());
					caseLabel.setDeleted(AppConstants.YES);
					//this.caseLabelsRepository.save(caseLabel);
					//call Procedure to save Case Labels
					long caseLabelID = this.caseLabelsRepository.save_case_labels(null, "INSERT", caseLabel.getAppLabelId(), caseLabel.getCaseId(), caseLabel.getCreatedDate(), 
							userVO.getId(), caseLabel.getLastModifiedDate(), userVO.getId(), caseLabel.getOptLockVersion(), 'N');
				}

				String[] lblCases = caseVO.getTitle().split(",");
				for (String lblCase : lblCases) {
					boolean isNew = true;
					for (CaseLabels caseLabels2 : caseLabels) {
						if (lblCase.equals(caseLabels2.getAppLabelId().toString())) {
							isNew = false;
							CaseLabels caseLabel = this.caseLabelsRepository.findOne(caseLabels2.getId());
							caseLabel.setDeleted(AppConstants.NO);
							//this.caseLabelsRepository.save(caseLabel);
							//call Procedure to save Case Labels
							long caseLabelID = this.caseLabelsRepository.save_case_labels(null, "INSERT", caseLabel.getAppLabelId(), caseLabel.getCaseId(), caseLabel.getCreatedDate(), 
									userVO.getId(), caseLabel.getLastModifiedDate(), userVO.getId(), caseLabel.getOptLockVersion(), 'N');
							break;
						}
					}
					if (isNew) {
						if (StringUtils.isNumericSpace(lblCase)) {
							CaseLabels caseLabelss = new CaseLabels();
							caseLabelss.setAppLabelId(Long.parseLong(lblCase));
							caseLabelss.setCaseId(caseVO.getId());
							//caseLabelss = this.caseLabelsRepository.save(caseLabelss);
							//call Procedure to save Case Labels
							long caseLabelID = this.caseLabelsRepository.save_case_labels(null, "INSERT", caseLabelss.getAppLabelId(), caseLabelss.getCaseId(), caseLabelss.getCreatedDate(), 
									userVO.getId(), caseLabelss.getLastModifiedDate(), userVO.getId(), caseLabelss.getOptLockVersion(), 'N');
						}
					}
				}

			}
			this.updateCaseDateFields(appCase, presentCsStatus);
			if (appCase.getPageCount() != null) {
				if (appCase.getPageCount() > Integer
						.parseInt(this.applicationProperties.getProperty(AppConstants.TOTAL_PAGE_COUNT_SIZE))) {
					appCase.setEstimateRequest('Y');
				}
			}

			// Update date of clarification in production table
			if (appCase.getDateOfClarrification() != null) {
				appCase.setDateOfClarrification(appCase.getDateOfClarrification());
				Production prod = this.productionRepository.getProductionByCaseId(AppConstants.NO, caseVO.getId());
				if (prod != null) {
					prod.setDateOfClarification(appCase.getDateOfClarrification());
					//this.productionRepository.save(prod);
					//call Procedure to save Case Labels
					this.productionRepository.save_case_production(null, "INSERT", prod.getCaseId(), prod.getProductionStatus(), prod.getCompleteProcess(), prod.getOptLockVersion(),
							'N', prod.getCreatedDate(), userVO.getId(), prod.getCreatedDate(), userVO.getId(), prod.getIsDeliver(), prod.getIsActive(), prod.getprodDeliveryDate().getTime(),
							prod.getReviewStatus(),	prod.getprodDeliveryDate().getTime(), null);
				}
			}

			this.caseRepository.save(appCase);
			if (appCase.getPageCount() == null) {
				int pageCount1 = this.caseRepository.totalPageCountFROMCaseFile(appCase.getId());
				this.caseRepository.totalPageCountCaseId(pageCount1, appCase.getId());
			}

			Long caseId;
			if (appCase.getParentCase() != null) {
				caseId = appCase.getParentCase().getId();
				Case subCase = this.getCase(caseId);
				subCase.setName(appCase.getName());
				this.caseRepository.save(subCase);
			} else {
				caseId = appCase.getId();
			}
			List<Case> caseList = this.caseRepository.findByParentId(caseId);
			for (Case caseOne : caseList) {
				Case subCase = this.getCase(caseOne.getId());
				subCase.setName(appCase.getName());
				this.caseRepository.save(subCase);
			}
			appCase = this.getCase(appCase.getId());
			if (!StringUtils.equals(appCase.getCsStatus(), presentCsStatus)) {
				@SuppressWarnings("unused")
				StatusFlowRef selectedStatusFlowRef = this.statusFlowRefRepository
						.findByCsStatus(StatusFlowRef.OBJ_TYPE_CASE, appCase.getCsStatus(), AppConstants.NO);
				// this.sendStatusFlowEmailAlert(selectedStatusFlowRef, appCase);
			}

			try {
				Long clientType = null;
				// ClientType Fields Added
				if (caseVO.getClientType() != null && StringUtils.isNotBlank(caseVO.getClientType())
						&& StringUtils.isNotEmpty(caseVO.getClientType())) {
					try {
						clientType = new Long(caseVO.getClientType());
					} catch (Exception e) {
						LOGGER.error(CLASS_NAME, "appListRepository.clientTypeAssign", e);
					}
				} else {
					try {
						AppList appList = this.appListRepository.findByName("Client Type");
						List<AppItem> appItems = this.appItemRepository.findByListName(appList.getId());
						for (AppItem appItem : appItems) {
							if (appItem.getShortName().equalsIgnoreCase("EC")) {
								clientType = appItem.getId();
							}
						}
					} catch (Exception e) {
						LOGGER.error(CLASS_NAME, "appListRepository.clientTypeAssign", e);
					}
				}
				List<CaseReportUser> CaseReportUserList = this.caseReportUserService.getCaseReportUser(appCase.getId());
				if (CaseReportUserList.isEmpty()) {
					CaseReportUser caseReportUser = new CaseReportUser();
					caseReportUser.setProdUser(caseVO.getLsProdStaff());
					caseReportUser.setProdLead(caseVO.getLsProdLead());
					caseReportUser.setProdMd(caseVO.getLsMD());
					caseReportUser.setProdQc(caseVO.getLsQCReviewer());
					caseReportUser.setCaseId(caseVO.getId());
					try {
						if (clientType != null) {
							caseReportUser.setClientType(clientType);
						}
					} catch (Exception e) {
						LOGGER.error(CLASS_NAME, "caseReportUserService.getCaseReportUser", e);
					}
					CaseReportUserList = new ArrayList<CaseReportUser>();
					CaseReportUserList.add(caseReportUser);
				} else {
					for (CaseReportUser caseReportUser : CaseReportUserList) {
						caseReportUser.setProdUser(caseVO.getLsProdStaff());
						caseReportUser.setProdLead(caseVO.getLsProdLead());
						caseReportUser.setProdMd(caseVO.getLsMD());
						caseReportUser.setProdQc(caseVO.getLsQCReviewer());
						caseReportUser.setCaseId(caseVO.getId());
						try {
							if (clientType != null) {
								caseReportUser.setClientType(clientType);
							}
						} catch (Exception e) {
							LOGGER.error(CLASS_NAME, "caseReportUserService.getCaseReportUser", e);
						}
					}
				}
				this.caseReportUserService.saveCaseReportUser(CaseReportUserList);
			} catch (Exception e) {
				LOGGER.error(CLASS_NAME, "caseReportUserService.getCaseReportUser", e);
			} finally {

			}

			// Save case contact details
			this.saveCaseContacts(caseVO.getCaseContactUserIds(), appCase.getId(),userVO);

		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "saveCase", e);
		}

		return caseVO;
	}

	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Nov 21, 2018 - 12:26:53 PM
	 * 
	 * @Author : Karthi
	 * 
	 * @Description : Its to save new case
	 * 
	 * @Tags :
	 * @param caseVO
	 *            - get required field by path variable caseVO
	 * @return CaseVO - caseVO
	 * @throws TriventException
	 * @Git_Config : name email
	 * 
	 */
	@SuppressWarnings("unused")
	private CaseVO saveNewCase(CaseVO caseVO, UserVO userVO) throws TriventException {
		Case appCase = new Case();
	try {
		/*************** Convert String to Unicode start ***************/
		if (caseVO.getAppUIScreenFieldVOs() != null) {
			for (AppUIScreenFieldVO appUIScreenFieldVO : caseVO.getAppUIScreenFieldVOs()) {
				if (appUIScreenFieldVO.getDbFieldName().equalsIgnoreCase("name")) {
					if (appUIScreenFieldVO.getValue() != null && StringUtils.isNotBlank(appUIScreenFieldVO.getValue())
							&& StringUtils.isNotEmpty(appUIScreenFieldVO.getValue())) {
						StringBuffer CaseOver = new StringBuffer();
						String CaseName = CaseOver.toString();
						CaseName = appUIScreenFieldVO.getValue();
						final String CaseNameNew = CommonUtils.uniCodeToString(CaseName);
						caseVO.setName(CaseNameNew);
						appUIScreenFieldVO.setValue(CaseNameNew);
					}
				} else if (appUIScreenFieldVO.getDbFieldName().equalsIgnoreCase("caseOverview")) {
					if (appUIScreenFieldVO.getValue() != null && StringUtils.isNotBlank(appUIScreenFieldVO.getValue())
							&& StringUtils.isNotEmpty(appUIScreenFieldVO.getValue())) {
						StringBuffer outBuffer = new StringBuffer();
						String queryDetails = outBuffer.toString();
						queryDetails = appUIScreenFieldVO.getValue();
						final String caseOverViewNew = CommonUtils.uniCodeToString(queryDetails);
						caseVO.setCaseOverview(caseOverViewNew);
						appUIScreenFieldVO.setValue(caseOverViewNew);
					}
				} else if (appUIScreenFieldVO.getDbFieldName().equalsIgnoreCase("clientNotes")) {
					if (appUIScreenFieldVO.getValue() != null && StringUtils.isNotBlank(appUIScreenFieldVO.getValue())
							&& StringUtils.isNotEmpty(appUIScreenFieldVO.getValue())) {
						StringBuffer outBuffer = new StringBuffer();
						String specInst = outBuffer.toString();
						specInst = appUIScreenFieldVO.getValue();
						final String caseSpecInt = CommonUtils.uniCodeToString(specInst);
						caseVO.setClientNotes(caseSpecInt);
						appUIScreenFieldVO.setValue(caseSpecInt);
					}
				} else if (appUIScreenFieldVO.getDbFieldName().equalsIgnoreCase("cf_2_LongText")) {
					if (appUIScreenFieldVO.getValue() != null && StringUtils.isNotBlank(appUIScreenFieldVO.getValue())
							&& StringUtils.isNotEmpty(appUIScreenFieldVO.getValue())) {
						StringBuffer outBuffer = new StringBuffer();
						String issuFocus = outBuffer.toString();
						issuFocus = appUIScreenFieldVO.getValue();
						final String caseIssuFocus = CommonUtils.uniCodeToString(issuFocus);
						caseVO.setCf_2_LongText(caseIssuFocus);
						appUIScreenFieldVO.setValue(caseIssuFocus);
					}
				}
			}
		}
		/*************** Convert String to Unicode End ***************/
		BeanUtils.copyProperties(caseVO, appCase);

		/* To save additional rec as Sub Case - start */
		if (caseVO.getParentCaseId() != null) {
			Case appCasee = caseRepository.findOne(caseVO.getParentCaseId());
			appCase.setParentCase(appCasee);
			appCase.setServiceRequestedShortCode(caseVO.getServiceReqShortCode());
			if (appCasee.getAccount() != null && appCasee.getClient() != null) {
				caseVO.setAccountId(appCasee.getAccount().getId());
				caseVO.setClientId(appCasee.getClient().getId());
				appCase.setAccount(appCasee.getAccount());
				appCase.setClient(appCasee.getClient());
				appCase.setType(appCasee.getType());
				appCase.setSubType(appCasee.getSubType());
				appCase.setClientNotes(caseVO.getCaseNotes());
				Calendar today = Calendar.getInstance();
				if (appCase.getFileReceivedDate() == null) {
					appCase.setFileReceivedDate(today);
				}
			}
		} /* end */
		List<StatusFlowRef> statusFlowRefs = this.cacheService.findByObjType(StatusFlowRef.OBJ_TYPE_CASE,
				AppConstants.NO);		
		StatusFlowRef statusFlowRef = statusFlowRefs.get(0);

		// Client Status & Client Support Status to be fetched from the status
		// flow ref table 1st entry.
		appCase.setClientStatus(statusFlowRef.getCustomerStatus());
		appCase.setCsStatus(statusFlowRef.getCustomerSupportStatus());
		CaseVO updatedCaseVO = new CaseVO();
		if (caseVO.getAppUIScreenFieldVOs() != null) {
			this.updateObjectFromAppUIScreenFieldVOValues(appCase, caseVO.getAppUIScreenFieldVOs());
			updatedCaseVO = this.getNewCase(userVO);
			updatedCaseVO.getAppUIScreenFieldVOs();
		}
		User loginUser = this.userService.getCurrentUser(userVO);
		User client = null;
		if (loginUser.getType().equalsIgnoreCase(AppConstants.TYPE_CLIENT)) {
			Account account = this.cacheService.findByAccountId(caseVO.getAccountId());			
			appCase.setAccount(account);
			client = this.userRepository.findOne(caseVO.getClientId());
			appCase.setClient(client);
		}
		client = appCase.getClient();
		// Case Code Logic
		if (appCase.getParentCase() == null) {
			String caseCodePrefix = client.getUserProfile().getCustomerCode().trim();			
			AppSequenceRef appSequenceRef = this.appSequenceRefRepository
					.getSequenceRefByTypeAndCode(AppSequenceRef.OBJECT_TYPE_CASE, caseCodePrefix);
			int nextSeq = 1;
			if (appSequenceRef == null) {
				appSequenceRef = new AppSequenceRef(AppSequenceRef.OBJECT_TYPE_CASE, caseCodePrefix, nextSeq);
			} else {
				nextSeq = appSequenceRef.getObjCodeSeq() + 1;
				appSequenceRef.setObjCodeSeq(nextSeq);
			}
			boolean isDuplicate = true;
			while (isDuplicate) {
				isDuplicate = false;
				String caseCodeChkDup = String.format(AppConstants.CODE_PATTERN_CASE, appSequenceRef.getObjCode(),
						appSequenceRef.getObjCodeSeq());				
				List<Case> appCaseDup = caseRepository.findByCaseCode(caseCodeChkDup);
				
				if (appCaseDup.size() == 0) {
					appSequenceRef.setObjCodeSeq(nextSeq);
				} else {
					isDuplicate = true;
					nextSeq += 1;
					appSequenceRef.setObjCodeSeq(nextSeq);
				}
			}
			//this.appSequenceRefRepository.save(appSequenceRef);
			//Call Procedure to Save appSequenceRef
			if(appSequenceRef.getId()!=null) {
				this.appSequenceRefRepository.updateAppSequenceRefbyID(appSequenceRef.getId(), appSequenceRef.getOptLockVersion(), appSequenceRef.getObjCode(), appSequenceRef.getObjCodeSeq(), appSequenceRef.getObjType());				
			}else {
				Long appSeqRefId  = this.appSequenceRefRepository.save_app_sequence_ref_procedure(null, "INSERT", null,
						null, appSequenceRef.getOptLockVersion(), appSequenceRef.getObjCode(), 
						appSequenceRef.getObjCodeSeq(),appSequenceRef.getObjType(),new Long(userVO.getId()), new Long(userVO.getId()));
			}
			
			String caseCode = String.format(AppConstants.CODE_PATTERN_CASE, caseCodePrefix, nextSeq);
			appCase.setCaseCode(caseCode);
		} else { /* For Saving Case code in sub case */
			String caseCodePrefix = appCase.getCaseCode();
			AppSequenceRef appSequenceRef = this.appSequenceRefRepository
					.getSequenceRefByTypeAndCode(AppSequenceRef.OBJECT_TYPE_CASE, caseCodePrefix);
			int nextSeq = 1;
			if (appSequenceRef == null) {
				appSequenceRef = new AppSequenceRef(AppSequenceRef.OBJECT_TYPE_CASE, caseCodePrefix, nextSeq);
			} else {
				nextSeq = appSequenceRef.getObjCodeSeq() + 1;
				appSequenceRef.setObjCodeSeq(nextSeq);
			}
			boolean isDuplicate = true;
			while (isDuplicate) {
				isDuplicate = false;
				String addAdditionalCaseCode = String.format(AppConstants.CODE_PATTERN_CASE,
						appSequenceRef.getObjCode() + "_", nextSeq);
				List<Case> appCaseDup = caseRepository.findByCaseCode(addAdditionalCaseCode);				
				if (appCaseDup.size() == 0) {
					appSequenceRef.setObjCodeSeq(nextSeq);
				} else {
					isDuplicate = true;
					nextSeq += 1;
				}
			}
			//this.appSequenceRefRepository.save(appSequenceRef);
			//Procedure Call
			if(appSequenceRef.getId()!=null) {
				this.appSequenceRefRepository.updateAppSequenceRefbyID(appSequenceRef.getId(), appSequenceRef.getOptLockVersion(), appSequenceRef.getObjCode(), appSequenceRef.getObjCodeSeq(), appSequenceRef.getObjType());				
			}else {
				Long appSeqRefId  = this.appSequenceRefRepository.save_app_sequence_ref_procedure(null, "INSERT", null,
						null, appSequenceRef.getOptLockVersion(), appSequenceRef.getObjCode(), 
						appSequenceRef.getObjCodeSeq(),appSequenceRef.getObjType(),new Long(userVO.getId()), new Long(userVO.getId()));
			}			
			String caseCode = String.format(AppConstants.CODE_PATTERN_CASE, caseCodePrefix + "_", nextSeq);
			appCase.setCaseCode(caseCode);
		}

		StringBuilder serviceShortCode = new StringBuilder();
		Integer seqNo = 0;
		List<CaseServiceReq> caseServiceReqs = new ArrayList<>();
		if (caseVO.getCaseServicesVOs() != null) {
			for (AppItemVO appItemVO : caseVO.getCaseServicesVOs()) {
				for (AppSubItemVO appSubItemVO : appItemVO.getAppSubItemVOs()) {
					if (appSubItemVO.isValue()) {
						CaseServiceReq caseServiceReq = new CaseServiceReq();
						caseServiceReq.setServiceName(appSubItemVO.getLongName());
						caseServiceReq.setServiceNameShortCode(appSubItemVO.getShortName());
						caseServiceReq.setAccount(appCase.getAccount());
						caseServiceReq.setClient(appCase.getClient());
						caseServiceReq.setClientCase(appCase);
						caseServiceReq.setSeqNo(seqNo);
						caseServiceReq.setSubItemId(appSubItemVO.getId());
						seqNo++;
						caseServiceReqs.add(caseServiceReq);
						serviceShortCode.append(AppConstants.COMMA_SEPARATOR)
								.append(caseServiceReq.getServiceNameShortCode());
					}
				}
			}
			if (serviceShortCode.length() > 0) {				
				serviceShortCode.deleteCharAt(0);
			}

			appCase.setServiceRequestedShortCode(serviceShortCode.toString());
			if (StringUtils.isEmpty(appCase.getServiceRequestedShortCode())) {
				updatedCaseVO.setStatusMsg(AppConstants.MSG_CASE_SERVICE_NOT_SELECTED);
				return updatedCaseVO;
			}
		}
		if ((caseVO.getCaseContactUserIds() != null) && StringUtils.isNotBlank(caseVO.getCaseContactUserIds())
				&& StringUtils.isNotEmpty(caseVO.getCaseContactUserIds())) {
			try {
				String[] arrCaseContactIds = caseVO.getCaseContactUserIds().split(",");
				List<Long> contactIdList = new ArrayList<>();
				for (String strCaseContactIds : arrCaseContactIds) {
					Long contactId = Long.parseLong(strCaseContactIds);
					contactIdList.add(contactId);
				}

				Specification<Contact> specification = null;
				Specifications<Contact> specifications = Specifications
						.where(this.contactGSpecifications.dataTypeLongList("id", contactIdList));
				specification = specifications;
				List<Contact> contactList = this.contactRepository.findAll(specification);
				List<Long> userListId = new ArrayList<>();
				String emailList = StringUtils.EMPTY;
				for (Contact contact : contactList) {
					if (StringUtils.isEmpty(emailList) || StringUtils.isBlank(emailList)) {
						emailList = contact.getEmail();
					} else {
						emailList += ";" + contact.getEmail();
					}
					if (contact.getUserId() != null) {
						userListId.add(contact.getUserId());
					}
				}
				appCase.setEmailId(emailList);
			} catch (Exception e) {
				LOGGER.error(CLASS_NAME, "email update", e);
			}

		}
		if (appCase.getParentCase() != null) {
			appCase.setClientStatus(AppConstants.NEW_STATUS);
			appCase.setCsStatus(AppConstants.NEW_STATUS);
		}
		if (appCase != null) {
			if (appCase.getParentCase() != null) {
				Case prntCase = caseRepository.findOne(appCase.getParentCase().getId());
				appCase.setBatesReference(prntCase.getBatesReference());
				appCase.setPdfReference(prntCase.getPdfReference());
				// appCase.setClientNotes(prntCase.getClientNotes());
				appCase.setCf_2_LongText(prntCase.getCf_2_LongText());
				appCase.setCf_2_Text(prntCase.getCf_2_Text());
				appCase.setCf_1_Text(prntCase.getCf_1_Text());
			}
		}
		//appCase = this.caseRepository.save(appCase);
		//Procedure to Save Case Details	
		//this.inserCaseDetailsUsingProcedure("INSERT", appCase, userVO);
		//appCase.setCsDeliveryDate(Calendar.getInstance());
		Long appCaseID = this.caseRepository.save_cases(
				null,
				"INSERT",
				appCase.getDelayReasons(), 
				new Long(userVO.getId()), 
				new Long(userVO.getId()), 
				appCase.getAccount().getId(), 
				(appCase.getClient()!=null) ? appCase.getClient().getUserProfile().getId() : null, 
				appCase.getName(),
				appCase.getIsFileDownloaded(), 
				appCase.getType(), 
				appCase.getOptLockVersion(), 
				(appCase.getAssignedTo()!=null) ? appCase.getAssignedTo().getUserProfile().getId() : null,
				(appCase.getJob()!=null) ? appCase.getJob().getId() : null,
				(appCase.getParentCase()!=null) ? appCase.getParentCase().getId() : null, 
				appCase.getPageCount(), 
				new Long(appCase.getApprovedHours()), 
				new Long(appCase.getDeviationHours()),
				new Long(appCase.getDiscountHours()), 
				new Long(appCase.getEstimateHours()) , 
				new Long(appCase.getIndirectHours()), 
				new Long(appCase.getInvoiceHours()), 
				new Long(appCase.getProductionHours()),								
				(appCase.getProductionStatus()!=null) ? appCase.getProductionStatus().getId() : 0,
				(appCase.getBalanceDue()!=null) ? appCase.getBalanceDue() : null,
				(appCase.getDepsumPages()!=null) ? appCase.getDepsumPages() : 0, 
				(appCase.getDownloadCount()!=null) ? appCase.getDownloadCount() : 0,
				(appCase.getCf_1_Hours()!=null) ? appCase.getCf_1_Hours() : 0,
			    (appCase.getCf_2_Hours()!=null) ? appCase.getCf_2_Hours() : 0,
			    (appCase.getCf_3_Hours()!=null) ? appCase.getCf_3_Hours() : 0,
			    (appCase.getCf_1_Number()!=null) ? appCase.getCf_1_Number()  : 0,
				(appCase.getCf_2_Number()!=null) ? appCase.getCf_2_Number() : 0, 
				(appCase.getCf_3_Number()!=null) ? appCase.getCf_3_Number() : 0, 
				(appCase.getCf_1_LongText()!=null) ? appCase.getCf_1_LongText() : null , 
				(appCase.getCf_2_LongText()!=null) ? appCase.getCf_2_LongText() : null, 
				(appCase.getCf_3_LongText()!=null) ? appCase.getCf_3_LongText() : null,
				(appCase.getClientPriority()!=null) ? appCase.getClientPriority() : null, 
				(appCase.getClientStatus()!=null) ? appCase.getClientStatus() : null, 
				(appCase.getCsPriority()!=null) ? appCase.getCsPriority() : null, 
				(appCase.getCsStatus()!=null) ? appCase.getCsStatus() : null, 
				"" /*prefix_case_id*/,
				(appCase.getSubType()!=null) ? appCase.getSubType() : null , 
				(appCase.getExpeditedDeliveryDate() !=null) ? appCase.getExpeditedDeliveryDate() : null/*expedited_date*/,
				(appCase.getCaseCode()!=null) ? appCase.getCaseCode()  : null,
				(appCase.getServiceRequestedShortCode()!=null) ? appCase.getServiceRequestedShortCode() : null,
				(appCase.getCf_1_Text()!=null) ? appCase.getCf_1_Text()  : null, 
				(appCase.getCf_2_Text() !=null) ? appCase.getCf_2_Text() : null, 
				(appCase.getCf_3_Text()!=null) ? appCase.getCf_3_Text() : null,
				(appCase.getIsDemand() !=null) ? appCase.getIsDemand().toString() : null, 
				(appCase.getIsCustomerDownload()!=null) ? appCase.getIsCustomerDownload().toString() : null, 
				(appCase.getDeleted()!=null) ? appCase.getDeleted() : 'N',
				(appCase.getExpeditedRequest()!=null) ? appCase.getExpeditedRequest() : null,
				(appCase.getEstimateRequest()!=null) ? appCase.getEstimateRequest() : null,
				(appCase.getBatesReference()!=null) ? appCase.getBatesReference() : null,
				(appCase.getIsInvoiced()!=null) ? appCase.getIsInvoiced() : null,
				(appCase.getPdfReference()!=null) ? appCase.getPdfReference() : null, 
				(appCase.getCf_1_YesNo()!=null) ? appCase.getCf_1_YesNo() : null, 
				(appCase.getCf_2_YesNo()!=null) ? appCase.getCf_2_YesNo() : null ,
				(appCase.getCf_3_YesNo()!=null) ? appCase.getCf_3_YesNo() : null,
				null, 
				null, 
				appCase.getExpeditedDeliveryDate(),
				appCase.getFileDeliveryDate(),
				appCase.getFileMigrationDate(),
				appCase.getFileReceivedDate(), 
				appCase.getProdDeliveryDate(), 
				appCase.getProdEndDate(), 
				appCase.getProdStartDate(),
				appCase.getDateOfClarrification(),
				appCase.getEstApprovedDate(),
				appCase.getEstProvisionDate(),
				appCase.getAddRecordDate(), 
				appCase.getCsEstimateSendDate(),
				appCase.getProductionEstimateSendDate(),
				appCase.getEstimateApprovalReceivedDate(), 
				appCase.getRevisedEstiamteSendDate(), 
				appCase.getCsDeliveryDate(),
				appCase.getDownloadedDateTime(),
				appCase.getCf_1_Date(), 
				appCase.getCf_2_Date(),
				appCase.getCf_3_Date(),
				appCase.getCf_4_Date(),
				appCase.getCf_5_Date(),
				appCase.getCf_6_Date(),
				appCase.getCf_7_Date(),
				appCase.getCf_8_Date(),
			    (appCase.getCaseOverview()!=null) ? appCase.getCaseOverview() : null, 
			    (appCase.getClientNotes()!=null) ? appCase.getClientNotes() : null,
				(appCase.getCsNotes()!=null) ? appCase.getCsNotes() : null,
				(appCase.getExpeditedRequestReason()!=null) ? appCase.getExpeditedRequestReason() : null,
				(appCase.getEmailId()!=null) ? appCase.getEmailId() : null,
				(appCase.getContactName()!=null) ? appCase.getContactName() : null, 
				(appCase.getDescription()!=null) ? appCase.getDescription() : null);		
		System.out.println("appCaseID"+appCaseID);
		
		// Update Case in Case Services Req
		for (CaseServiceReq caseServiceReq : caseServiceReqs) {
			caseServiceReq.setClientCase(appCase);			
		  //Call Procedure to save Case Service Req Details		
		  //caseServiceReqs = this.caseServiceReqRepository.save(caseServiceReqs);		
		  Long caseServiceReqsId = this.caseServiceReqRepository.save_case_service_req(null, "INSERT", 
						null,
						null, 
						0, 
						'N', 
						caseServiceReq.getNotes(), 
						caseServiceReq.getSeqNo(), 
						caseServiceReq.getServiceName(),
						new Long(caseServiceReq.getEstimateHours()),
						new Long(caseServiceReq.getProductionHours()),
						new Long(caseServiceReq.getApprovedHours()), 
						new Long(caseServiceReq.getDiscountHours()), 
						new Long(caseServiceReq.getIndirectHours()), 
						new Long(caseServiceReq.getInvoiceHours()), 
						new Long(caseServiceReq.getDeviationHours()),
						userVO.getId(), 
						userVO.getId(), 
						(caseServiceReq.getAccount()!=null) ? caseServiceReq.getAccount().getId() : null, 
						(caseServiceReq.getClient().getUserProfile()!=null) ? caseServiceReq.getClient().getUserProfile().getId() : null, 
						appCaseID,
						caseServiceReq.getQualityScore(),
						caseServiceReq.getServiceNameShortCode(), 
						(caseServiceReq.getApprovedDate()!=null) ? caseServiceReq.getApprovedDate().getTime() : null,
						(caseServiceReq.getDeliverDate()!=null) ? caseServiceReq.getDeliverDate().getTime() : null,
						(caseServiceReq.getEstimateDate()!=null) ? caseServiceReq.getEstimateDate().getTime() : null,
						(caseServiceReq.getEstimateonHours()!=null) ? new Long(caseServiceReq.getEstimateonHours()) : null, 
						(caseServiceReq.getReestimateHours()!=null) ? new Long(caseServiceReq.getReestimateHours()) : null,
						(caseServiceReq.getApproveStatus()!=null) ? caseServiceReq.getApproveStatus().getId():null, 
						caseServiceReq.getAuditScore(), 
						caseServiceReq.getSubItemId(),
						caseServiceReq.getAdditionalRecId()); 
				System.out.println("caseServiceReqsId"+caseServiceReqsId);	
				
				CaseServiceReqDetail caseServiceReqDetail = new CaseServiceReqDetail();
				BeanUtils.copyProperties(caseServiceReq, caseServiceReqDetail, "id");
				caseServiceReqDetail.setAppCase(caseServiceReq.getClientCase());
				caseServiceReqDetail.setCaseServiceReqId(caseServiceReq.getId());
			//	caseServiceReqDetail = caseServiceReqDetailRepository.save(caseServiceReqDetail);
				
			//Call Procedure to save Case Service Req Details			
			 Long caseServiceReqsDetailsId = this.caseServiceReqDetailRepository.case_service_req_detail(null, "INSERT", 
					 null, 
					 null,
					 userVO.getId(),
					 userVO.getId(), 
					 0, 
					 'N',
					 caseServiceReq.getNotes(),
					 caseServiceReq.getSeqNo(), 
					 caseServiceReq.getServiceName(), 
					 new Long(caseServiceReq.getEstimateHours()),
					 new Long(caseServiceReq.getProductionHours()),
					 new Long(caseServiceReq.getApprovedHours()), 
					 new Long(caseServiceReq.getDiscountHours()), 
					 new Long(caseServiceReq.getIndirectHours()), 
					 new Long(caseServiceReq.getInvoiceHours()), 
					 new Long(caseServiceReq.getDeviationHours()),
					 caseServiceReq.getQualityScore(), 
					 caseServiceReq.getServiceNameShortCode(),
					 (caseServiceReq.getApprovedDate()!=null) ? caseServiceReq.getApprovedDate().getTime() : null,
					 (caseServiceReq.getDeliverDate()!=null) ? caseServiceReq.getDeliverDate().getTime() : null,
					 (caseServiceReq.getEstimateDate()!=null) ? caseServiceReq.getEstimateDate().getTime() : null,
					 new Long(caseServiceReq.getEstimateonHours()), 	
					 new Long(caseServiceReq.getReestimateHours()),
					 (caseServiceReq.getApproveStatus()!=null) ? caseServiceReq.getApproveStatus().getId():null, 
					 caseServiceReq.getAuditScore(), 
					 caseServiceReq.getSubItemId(),
					 caseServiceReq.getAdditionalRecId(),
					 appCaseID,
					 caseServiceReqsId);
			 System.out.println("caseServiceReqsDetailsId"+caseServiceReqsDetailsId);				
		}
		//Call Procedure to save Case Service Req Details		
		//caseServiceReqs = this.caseServiceReqRepository.save(caseServiceReqs);	
		
		/* To Save Case Service Req Detail */
		/*if (caseServiceReqs != null && caseServiceReqs.size() > 0) {
			for (CaseServiceReq caseServiceRequest : caseServiceReqs) {
				CaseServiceReqDetail caseServiceReqDetail = new CaseServiceReqDetail();
				BeanUtils.copyProperties(caseServiceRequest, caseServiceReqDetail, "id");
				caseServiceReqDetail.setAppCase(caseServiceRequest.getClientCase());
				caseServiceReqDetail.setCaseServiceReqId(caseServiceRequest.getId());
			//	caseServiceReqDetail = caseServiceReqDetailRepository.save(caseServiceReqDetail);
				
			//Call Procedure to save Case Service Req Details			
			 Long caseServiceReqsId = this.caseServiceReqDetailRepository.case_service_req_detail(null, "INSERT", 
					 null, 
					 null,
					 userVO.getId(),
					 userVO.getId(), 
					 0, 
					 'N',
					 caseServiceRequest.getNotes(),
					 caseServiceRequest.getSeqNo(), 
					 caseServiceRequest.getServiceName(), 
					 new Long(caseServiceRequest.getEstimateHours()),
					 new Long(caseServiceRequest.getProductionHours()),
					 new Long(caseServiceRequest.getApprovedHours()), 
					 new Long(caseServiceRequest.getDiscountHours()), 
					 new Long(caseServiceRequest.getIndirectHours()), 
					 new Long(caseServiceRequest.getInvoiceHours()), 
					 new Long(caseServiceRequest.getDeviationHours()),
					 caseServiceRequest.getQualityScore(), 
					 caseServiceRequest.getServiceNameShortCode(),
					 (caseServiceRequest.getApprovedDate()!=null) ? caseServiceRequest.getApprovedDate().getTime() : null,
					 (caseServiceRequest.getDeliverDate()!=null) ? caseServiceRequest.getDeliverDate().getTime() : null,
					 (caseServiceRequest.getEstimateDate()!=null) ? caseServiceRequest.getEstimateDate().getTime() : null,
					 new Long(caseServiceRequest.getEstimateonHours()), 	
					 new Long(caseServiceRequest.getReestimateHours()),
					 (caseServiceRequest.getApproveStatus()!=null) ? caseServiceRequest.getApproveStatus().getId():null, 
					 caseServiceRequest.getAuditScore(), 
					 caseServiceRequest.getSubItemId(),
					 caseServiceRequest.getAdditionalRecId(),
					 appCaseID,
					 caseServiceRequest.getId());
			 System.out.println("caseServiceReqsId"+caseServiceReqsId);
			}
		}*/

		//appCase = this.getCase(appCase.getId());
		appCase = this.getCase(appCaseID);
		// Send email if required for the case at file upload status.
		//this.sendStatusFlowEmailAlert(statusFlowRef, appCase);

		caseVO.setId(appCase.getId());
		if(loginUser!=null) {
			User user = this.userService.getUserById(loginUser.getId());
			Role role = user.getRole();
			if (role.getType().equals(Role.ROLE_TYPE_CS_ROLES) && (caseVO.getTitle() != null)) {			
				String[] lblCases = caseVO.getTitle().split(",");
				for (String lblCase : lblCases) {
					if (StringUtils.isNumericSpace(lblCase)) {
						CaseLabels caseLabels = new CaseLabels();
						caseLabels.setAppLabelId(Long.parseLong(lblCase));
						caseLabels.setCaseId(caseVO.getId());
					//	caseLabels = this.caseLabelsRepository.save(caseLabels);
						long caseLabelID = this.caseLabelsRepository.save_case_labels(null, "INSERT",caseLabels.getAppLabelId(),caseLabels.getCaseId(),null,userVO.getId(),null,userVO.getId(),caseLabels.getOptLockVersion(),'N');
					}
				}
			}
		}	

		// Save case Contacts
		this.saveCaseContacts(caseVO.getCaseContactUserIds(), caseVO.getId(),userVO);
		
		List<CaseReportUser> CaseReportUserList = new ArrayList<>();
		// ClientType Fields Added
		if (caseVO.getClientType() != null && StringUtils.isNotBlank(caseVO.getClientType())
				&& StringUtils.isNotBlank(caseVO.getClientType())) {
			CaseReportUser caseReportUser = new CaseReportUser();
			caseReportUser.setCaseId(caseVO.getId());
			caseReportUser.setClientType(new Long(caseVO.getClientType()));
			//CaseReportUserList.add(caseReportUser);
			//this.caseReportUserService.saveCaseReportUser(CaseReportUserList);
			//call Procedure to savae Case Report USer Details
		Long caseReportId =	this.caseReportUserRepository.save_case_report_users(null, "INSERT",null,null,caseReportUser.getOptLockVersion(),'N',userVO.getId(),userVO.getId(),caseReportUser.getCaseId(),caseReportUser.getProdUser(),caseReportUser.getProdLead(),caseReportUser.getProdMd(),caseReportUser.getProdQc(),caseReportUser.getClientType());
		System.out.println("caseReportId"+caseReportId);
		} else {
			// Client Type
			CaseReportUser caseReportUser = new CaseReportUser();
			caseReportUser.setCaseId(caseVO.getId());

			AppList appList = this.appListRepository.findByName("Client Type");
			List<AppItem> appItems = this.appItemRepository.findByListName(appList.getId());
			for (AppItem appItem : appItems) {
				if (appItem.getShortName().equalsIgnoreCase("EC")) {
					caseReportUser.setClientType(appItem.getId());
				}
			}

			//CaseReportUserList.add(caseReportUser);
			//this.caseReportUserService.saveCaseReportUser(CaseReportUserList);
			//call Procedure to savae Case Report USer Details
			Long caseReportId  = this.caseReportUserRepository.save_case_report_users(null, "INSERT",null,null,caseReportUser.getOptLockVersion(),'N',userVO.getId(),userVO.getId(),caseReportUser.getCaseId(),caseReportUser.getProdUser(),caseReportUser.getProdLead(),caseReportUser.getProdMd(),caseReportUser.getProdQc(),caseReportUser.getClientType());
			System.out.println("caseReportId"+caseReportId);
		}
		caseVO.setId(appCase.getId()); // Mandatory line
	}catch (Exception e) {
		LOGGER.error(CLASS_NAME, "SaveNewCase", e);
		System.out.println(e);
	}
		return caseVO;
	}
	
	@Override
	@Transactional(readOnly = true)
	public Case getCase(Long caseId) {

		Case appCase = new Case();
		try {
			appCase = this.caseRepository.getCaseById(caseId);
		} catch (Exception e) {
			appCase = null;
			LOGGER.error(CLASS_NAME, "getCase - Error", e);
		}
		return appCase;

	}

	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Nov 21, 2018 - 12:26:53 PM
	 * 
	 * @Author : Karthi
	 * 
	 * @Description : Its to update object from app UI screen field
	 * 
	 * @Tags :
	 * @param obj
	 *            - refer obj as entityClass
	 * @param propertyClass
	 *            - to get the name from propertyClass
	 * @param appUIScreenFieldVO
	 *            - get required field by path variable appUIScreenFieldVO
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 * @throws NoSuchMethodException
	 * @Git_Config : name email
	 * 
	 */
	private void updateObjectFromAppUIScreenFieldVOValues(Object obj, Class<?> propertyClass,
			AppUIScreenFieldVO appUIScreenFieldVO)
			throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
		if (propertyClass != null) {
			String propertyClassName = propertyClass.getName();
			if (propertyClassName.equals(Character.class.getName())) {
				PropertyUtils.setProperty(obj, appUIScreenFieldVO.getDbFieldName(),
						appUIScreenFieldVO.isBooleanValue() ? AppConstants.YES : AppConstants.NO);
			} else if (propertyClassName.equals(Integer.class.getName())
					&& appUIScreenFieldVO.getDbFieldName().endsWith(AppConstants.COLUMN_NAME_HOURS)) {
				if (appUIScreenFieldVO.getHours() == null) {
					appUIScreenFieldVO.setHours(0);
				}
				if (appUIScreenFieldVO.getMinutes() == null) {
					appUIScreenFieldVO.setMinutes(0);
				}
				PropertyUtils.setProperty(obj, appUIScreenFieldVO.getDbFieldName(),
						CommonUtils.getTotalHoursFromHoursAndMinutes(appUIScreenFieldVO.getHours(),
								appUIScreenFieldVO.getMinutes()));
			} else if (propertyClassName.equals(Integer.class.getName())) {
				PropertyUtils.setProperty(obj, appUIScreenFieldVO.getDbFieldName(),
						CommonUtils.stringToInteger(appUIScreenFieldVO.getValue()));
			} else if (propertyClassName.equals(Float.class.getName())) {
				PropertyUtils.setProperty(obj, appUIScreenFieldVO.getDbFieldName(),
						CommonUtils.stringToFloat(appUIScreenFieldVO.getValue()));
			} else if (propertyClassName.equals(Calendar.class.getName()) || propertyClassName.equals(Date.class.getName())) {
/*				PropertyUtils.setProperty(obj, appUIScreenFieldVO.getDbFieldName(),
						CommonUtils.stringToCalendar(appUIScreenFieldVO.getValue()));*/
				PropertyUtils.setProperty(obj, appUIScreenFieldVO.getDbFieldName(),
						CommonUtils.stringToCalendarINDateFormat(appUIScreenFieldVO.getValue()));
			} else if (propertyClassName.equals(Account.class.getName())) {
				this.updateObjectFromAccountField(obj, appUIScreenFieldVO);
			} else if (propertyClassName.equals(User.class.getName())) {
				this.updateObjectFromUserField(obj, appUIScreenFieldVO);
			} else if (propertyClassName.equals(AppItem.class.getName())) {
				this.updateObjectFromAppitemField(obj, appUIScreenFieldVO);
			} else {
				PropertyUtils.setProperty(obj, appUIScreenFieldVO.getDbFieldName(), appUIScreenFieldVO.getValue());
			}
		}
	}

	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Nov 21, 2018 - 12:26:53 PM
	 * 
	 * @Author : Karthi
	 * 
	 * @Description : Its to update object in accounts field
	 * 
	 * @Tags :
	 * @param obj
	 *            - refers obj as entityClass
	 * @param appUIScreenFieldVO
	 *            - get required field by path variable appUIScreenFieldVO
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 * @throws NoSuchMethodException
	 * @Git_Config : name email
	 * 
	 */
	private void updateObjectFromAccountField(Object obj, AppUIScreenFieldVO appUIScreenFieldVO)
			throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
		if (StringUtils.isNotEmpty(appUIScreenFieldVO.getValue())) {
			Long accountId = Long.valueOf(appUIScreenFieldVO.getValue());
			Account account = this.cacheService.findByAccountId(accountId);
			PropertyUtils.setProperty(obj, appUIScreenFieldVO.getDbFieldName(), account);
		} else {
			PropertyUtils.setProperty(obj, appUIScreenFieldVO.getDbFieldName(), null);
		}
	}

	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Nov 21, 2018 - 12:26:53 PM
	 * 
	 * @Author : Karthi
	 * 
	 * @Description : Its to update obj from user Field
	 * 
	 * @Tags :
	 * @param obj
	 *            - refer obj as entityClass
	 * @param appUIScreenFieldVO
	 *            - get required field by path variable appUIScreenFieldVO
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 * @throws NoSuchMethodException
	 * @Git_Config : name email
	 * 
	 */
	private void updateObjectFromUserField(Object obj, AppUIScreenFieldVO appUIScreenFieldVO)
			throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
		if (StringUtils.isNotEmpty(appUIScreenFieldVO.getValue())) {
			Long userId = Long.valueOf(appUIScreenFieldVO.getValue());
			User user = this.userRepository.findOne(userId);
			PropertyUtils.setProperty(obj, appUIScreenFieldVO.getDbFieldName(), user);
		} else {
			PropertyUtils.setProperty(obj, appUIScreenFieldVO.getDbFieldName(), null);
		}
	}

	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Nov 21, 2018 - 12:26:53 PM
	 * 
	 * @Author : Karthi
	 * 
	 * @Description : Its to update obj from appItem
	 * 
	 * @Tags :
	 * @param obj
	 *            - refer obj as entityClass
	 * @param appUIScreenFieldVO
	 *            - get required field by path variable appUIScreenFieldVO
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 * @throws NoSuchMethodException
	 * @Git_Config : name email
	 * 
	 */
	private void updateObjectFromAppitemField(Object obj, AppUIScreenFieldVO appUIScreenFieldVO)
			throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
		if (StringUtils.isNotEmpty(appUIScreenFieldVO.getValue())) {
			try {
				AppList appList = this.appListRepository
						.findByName(this.applicationProperties.getProperty(AppConstants.SER_REQ_APPROVE_STATUS_LIST));
				if (appList != null) {
					AppItem appItem = this.appItemRepository.findByLongName(appUIScreenFieldVO.getValue(),
							appList.getId());
					PropertyUtils.setProperty(obj, appUIScreenFieldVO.getDbFieldName(), appItem);
				} else {
					PropertyUtils.setProperty(obj, appUIScreenFieldVO.getDbFieldName(), null);
				}
			} catch (Exception e) {
				PropertyUtils.setProperty(obj, appUIScreenFieldVO.getDbFieldName(), null);
			}
		} else {
			PropertyUtils.setProperty(obj, appUIScreenFieldVO.getDbFieldName(), null);
		}
	}

	/* Change Prod Status based on CS Status */
	private void modifyProdStatus(Long caseId) {
		try {
			Production existProduction = this.productionRepository.getProductionByCaseId(AppConstants.NO, caseId);
			if (existProduction != null) {
				String listName = this.applicationProperties.getProperty(AppConstants.PRODUCTION_NEW_STATUS);
				AppList prodStatusAppList = this.cacheService.findByAppListName(AppList.PRODUCTION_STATUS);

				AppItem appItem = this.appItemRepository.findByLongName(listName, prodStatusAppList.getId());
				productionRepository.updateProdStatus(existProduction.getId(), appItem.getId());
			}
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "modifyProdStatus", e);
		}
	}

	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Nov 21, 2018 - 12:26:53 PM
	 * 
	 * @Author : Karthi
	 * 
	 * @Description : Its to update case Date
	 * 
	 * @Tags :
	 * @param appCase
	 *            - update by using appCase
	 * @param presentCsStatus
	 *            - update by using present CS status
	 * @Git_Config : name email
	 * 
	 */
	private void updateCaseDateFields(Case appCase, String presentCsStatus) {
		Calendar today = Calendar.getInstance();
		if (StringUtils.equals(appCase.getCsStatus(), presentCsStatus)) {
			if (appCase.getFileReceivedDate() == null) {
				appCase.setFileReceivedDate(today);
			}
			// If change in status then update the date.
			return;
		}

		List<StatusFlowRef> statusFlowRefs = this.cacheService.findByObjType(StatusFlowRef.OBJ_TYPE_CASE,
				AppConstants.NO);
		StatusFlowRef statusFlowRef = statusFlowRefs.get(1);
		if (appCase.getCsStatus().equals(statusFlowRef.getCustomerSupportStatus())) {
			// New Status Update File Received date and expedited delivery date
			if (appCase.getFileReceivedDate() == null) {
				appCase.setFileReceivedDate(today);
			}
			if (appCase.getExpeditedRequest() == AppConstants.YES) {
				Calendar expeditedDate = Calendar.getInstance();
				// add 13 days to the calendar
				expeditedDate.add(Calendar.DATE, 13);
				if (expeditedDate.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY) {
					// if expedited date falls on Saturday, make it as Monday.
					expeditedDate.add(Calendar.DATE, 2);
				}
				if (expeditedDate.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY) {
					// if expedited date falls on Sunday, make it as Monday.
					expeditedDate.add(Calendar.DATE, 1);
				}
				appCase.setExpeditedDeliveryDate(expeditedDate);
			}
		} else if (appCase.getCsStatus().equals(StatusFlowRef.CS_STATUS_FILE_DELIVERY)) {
			appCase.setFileDeliveryDate(today);
		}
	}

	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see com.trivent.service.CaseService#getNewCase()
	 * 
	 * @DateAndTime : Nov 21, 2018 - 12:26:53 PM
	 * 
	 * @Author : Karthi
	 * 
	 * @Description : Its to get new case
	 * 
	 * @Tags :
	 * 
	 * @return CaseVO
	 * 
	 * @throws TriventException
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override
	@Transactional(readOnly = true)
	public CaseVO getNewCase(UserVO userVO) throws TriventException {
		Case appCase = new Case();

		//AppDBTable appdbTable = this.appDBTableRepository.findByNameTable("Case");
		String screenType = AppConstants.SCREEN_TYPE_ADD;
//		return this.getCaseVO(appdbTable.getId(), screenType, appCase,userVO);
		return this.getCaseVO(new Long(12), screenType, appCase,userVO);
		

	}

	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Nov 21, 2018 - 12:26:52 PM
	 * 
	 * @Author : Karthi
	 * 
	 * @Description : Its to get CaseVO
	 * 
	 * @Tags :
	 * @param screenName
	 *            - get by using screenName
	 * @param screenType
	 *            - get by using screenType
	 * @param appCase
	 *            - get by using appCase
	 * @return CaseVO - caseVO
	 * @throws TriventException
	 * @Git_Config : name email
	 * 
	 */
	@Transactional(readOnly = true)
	private CaseVO getCaseVO(Long screenName, String screenType, Case appCase, UserVO userVO) throws TriventException {
		User loginUser = this.userService.getCurrentUser(userVO);
		List<Account> accounts = null;
		List<Contact> contacts = null;
		User caseClient = null;
		if (loginUser.getType().equalsIgnoreCase(AppConstants.TYPE_TRIVENT)) {
			accounts = this.filterUtils.hasAccountFilter(loginUser);
		} else if (loginUser.getType().equalsIgnoreCase(AppConstants.TYPE_CLIENT)) {
			accounts = new ArrayList<>(1);
			accounts.add(this.cacheService.findByAccountId(loginUser.getAccount().getId()));
			caseClient = loginUser;
			this.checkUserHasAccess(appCase, loginUser);
		}
		if (!appCase.isNew()) {
			caseClient = appCase.getClient();
		}
		if (caseClient != null) {
			Character isDeleted = AppConstants.NO;
			contacts = this.contactRepository.listContacts(Contact.ENTITY_USER, caseClient.getId(), isDeleted);
		}

		AppList caseServiceList = this.cacheService.findByAppListName(AppList.CASE_SERVICES);
		List<AppItem> caseServiceItems = this.cacheService.findByListId(caseServiceList.getId());
		List<AppItem> updatedCaseServiceItems = new ArrayList<>();

		List<AppSubItem> caseServiceSubItems = null;

		List<Partner> partnerListUser = this.filterUtils.hasPartnerFilter(loginUser);
		List<AppItemVO> caseServicesVOs = new ArrayList<>(caseServiceItems.size());
		Partner partner = this.partnerService.getCurrentSessionPartner();
		// AppItem populate by Partners
		for (AppItem caseServiceItem : caseServiceItems) {
			if (caseServiceItem != null && (StringUtils.isEmpty(caseServiceItem.getPartner())
					|| StringUtils.isBlank(caseServiceItem.getPartner()))) {
				updatedCaseServiceItems.add(caseServiceItem);
			} else {
				boolean isExit = false;
				String[] partnerArray = caseServiceItem.getPartner().split(",");
				for (Partner userPartner : partnerListUser) {
					for (String partnerAppSub : partnerArray) {
						if (userPartner.getId() == Integer.parseInt(partnerAppSub)) {
							updatedCaseServiceItems.add(caseServiceItem);
							isExit = true;
							break;
						}
					}
					if (isExit) {
						break;
					}
				}
			}
		}
		for (AppItem caseServiceItem : updatedCaseServiceItems) {
			List<AppSubItem> updatedCaseServiceSubItems = new ArrayList<>();
			caseServiceSubItems = cacheService.findByItemId(caseServiceItem.getId());
			for (AppSubItem appSubItem : caseServiceSubItems) {
				if (appSubItem != null && (StringUtils.isEmpty(appSubItem.getPartner())
						|| StringUtils.isBlank(appSubItem.getPartner()))) {
					/*
					 *
					 * Begin user account id update to service link on 17-01-2018 Aalam 0025 Service
					 * Link get From AppServiceDesc Table
					 *
					 */
					AppServiceDesc caseServiceLink = this.appServiceDescRepository.findBySubItemId(appSubItem, partner,
							AppConstants.NO);
					if (caseServiceLink != null) {
						appSubItem.setServiceLink(caseServiceLink.getServiceLink());
						appSubItem.setToolTip(caseServiceLink.getToolTip());
					} else {
						appSubItem.setServiceLink(null);
					}
					updatedCaseServiceSubItems.add(appSubItem);
				} else {
					boolean isExit = false;
					String[] partnerArray = appSubItem.getPartner().split(",");
					for (Partner userPartner : partnerListUser) {
						for (String partnerAppSub : partnerArray) {
							if (userPartner.getId() == Integer.parseInt(partnerAppSub)) {
								/*
								 *
								 * Begin user account id update to service link on 17-01-2018 by Aalam 0025
								 * Service Link get From AppServiceDesc Table
								 *
								 */
								AppServiceDesc caseServiceLink = this.appServiceDescRepository
										.findBySubItemId(appSubItem, partner, AppConstants.NO);
								if (caseServiceLink != null) {
									appSubItem.setServiceLink(caseServiceLink.getServiceLink());
									appSubItem.setToolTip(caseServiceLink.getToolTip());
								} else {
									appSubItem.setServiceLink(null);
								}
								updatedCaseServiceSubItems.add(appSubItem);
								isExit = true;
								break;
							}
						}
						if (isExit) {
							break;
						}
					}
				}
			}
			caseServicesVOs.add(new AppItemVO(caseServiceItem, caseServiceList.getId(), updatedCaseServiceSubItems));
		}

		AppList caseTypeList = this.cacheService.findByAppListName(AppList.CASE_TYPES);
		List<AppItem> caseTypeItems = this.cacheService.findByListId(caseTypeList.getId());
		List<AppSubItem> caseSubTypeItems = null;
		List<AppItem> updatedCaseTypesItems = new ArrayList<>();
		List<AppItemVO> caseTypeVOs = new ArrayList<>(caseTypeItems.size());

		for (AppItem caseTypeItem : caseTypeItems) {
			if (caseTypeItem != null && (StringUtils.isEmpty(caseTypeItem.getPartner())
					|| StringUtils.isBlank(caseTypeItem.getPartner()))) {
				updatedCaseTypesItems.add(caseTypeItem);
			} else {
				boolean isExit = false;
				String[] partnerArray = caseTypeItem.getPartner().split(",");
				for (Partner userPartner : partnerListUser) {
					for (String partnerAppSub : partnerArray) {
						if (userPartner.getId() == Integer.parseInt(partnerAppSub)) {
							updatedCaseTypesItems.add(caseTypeItem);
							isExit = true;
							break;
						}
					}
					if (isExit) {
						break;
					}
				}
			}
		}
		for (AppItem caseTypeItem : updatedCaseTypesItems) {
			List<AppSubItem> updatedCaseTypesSubItems = new ArrayList<>();
			caseSubTypeItems = this.cacheService.findByItemId(caseTypeItem.getId());
			for (AppSubItem appSubItem : caseSubTypeItems) {
				if (appSubItem != null && (StringUtils.isEmpty(appSubItem.getPartner())
						|| StringUtils.isBlank(appSubItem.getPartner()))) {
					updatedCaseTypesSubItems.add(appSubItem);
				} else {
					boolean isExit = false;
					String[] partnerArray = appSubItem.getPartner().split(",");
					for (Partner userPartner : partnerListUser) {
						for (String partnerAppSub : partnerArray) {
							if (userPartner.getId() == Integer.parseInt(partnerAppSub)) {
								updatedCaseTypesSubItems.add(appSubItem);
								isExit = true;
								break;
							}
						}
						if (isExit) {
							break;
						}
					}
				}
			}
			caseTypeVOs.add(new AppItemVO(caseTypeItem, caseServiceList.getId(), updatedCaseTypesSubItems));
		}

		AppUIScreen appUIScreen = this.cacheService.findByScreenNameTypeRole(screenName, screenType,
				loginUser.getRole().getId());
		if (appUIScreen == null) {
			throw new TriventException(AppConstants.MSG_SCREEN_NOT_CONFIGURED);
		}
		List<AppUIScreenField> appUIScreenFields = this.cacheService.findFieldsByAppUIScreenId(appUIScreen.getId());

		// Get all possible csStatus for object type Case
		List<StatusFlowRef> statusFlowRefs = this.cacheService.findByObjType(StatusFlowRef.OBJ_TYPE_CASE,
				AppConstants.NO);

		CaseVO caseVO = new CaseVO(appCase, appUIScreenFields, caseServicesVOs, caseTypeVOs);
		try {
			List<CaseReportUser> CaseReportUserList = this.caseReportUserService.getCaseReportUser(appCase.getId());
			for (CaseReportUser caseReportUser : CaseReportUserList) {
				caseVO.setLsProdStaff(caseReportUser.getProdUser());
				caseVO.setLsProdLead(caseReportUser.getProdLead());
				caseVO.setLsMD(caseReportUser.getProdMd());
				caseVO.setLsQCReviewer(caseReportUser.getProdQc());
			}
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "caseReportUserService.getCaseReportUser", e);
		}

		if (loginUser.getType().equalsIgnoreCase(AppConstants.TYPE_TRIVENT)) {
			User loginUserRole = this.userService.getCurrentUser(userVO);
			if ((loginUserRole != null) && (loginUserRole.getRole() != null)) {
				Role role = this.roleRepository.findOne(loginUserRole.getRole().getId());
				if (role != null) {
					Capability capability = this.capabilityRepository.findByName(Capability.ACCOUNT_NAME_WITH_CODE);
					if (capability != null) {
						Permission permission = this.permissionRepository.getByCapabilityId(role.getId(),
								capability.getId());
						if (permission != null) {
							Character isVisible = permission.getVisible();
							if (isVisible.equals(AppConstants.YES)) {
								caseVO.populate(contacts, caseClient, accounts, statusFlowRefs, isVisible);
							} else {
								caseVO.populate(contacts, caseClient, accounts, statusFlowRefs, isVisible);
							}
						} else {
							caseVO.populate(contacts, caseClient, accounts, statusFlowRefs, AppConstants.NO);
						}
					}
				} else {
					caseVO.populate(contacts, caseClient, accounts, statusFlowRefs, AppConstants.NO);
				}
			} else {
				caseVO.populate(contacts, caseClient, accounts, statusFlowRefs, AppConstants.NO);
			}
		} else if (loginUser.getType().equalsIgnoreCase(AppConstants.TYPE_CLIENT)) {
			caseVO.populate(contacts, caseClient, accounts, statusFlowRefs, AppConstants.NO);
		}

		this.updateAppUIScreenFieldVOValues(appCase, caseVO.getAppUIScreenFieldVOs());
		// Get Case Contacts from caseContact entity
		String caseContactUserIds = "";
		List<CaseContacts> listCaseContacts = this.caseContactsRepository.listCaseContactsByCaseID(AppConstants.NO,
				appCase.getId());
		for (CaseContacts caseContact : listCaseContacts) {

			if (StringUtils.isEmpty(caseContact.getContactType()) && (caseContact.getUserid() != null)) {
				List<Contact> listContact = this.contactRepository.getContactbyEntity(Contact.ENTITY_USER,
						appCase.getClient().getId(), caseContact.getUserid().getId());
				if (listContact.size() > 0) {
					Contact contact = listContact.get(0);
					caseContactUserIds = (!caseContactUserIds.equals("")) ? caseContactUserIds + "," + contact.getId()
							: contact.getId().toString();
				}
			} else {
				if (caseContact.getContactId() != null) {
					caseContactUserIds = (!caseContactUserIds.equals(""))
							? caseContactUserIds + "," + caseContact.getContactId()
							: caseContact.getContactId().toString();
				}

			}
		}

		// Open ParentCase
		if (appCase.getParentCase() == null)
			caseVO.setStrparentCaseEncryId(null);
		else
			caseVO.setStrparentCaseEncryId(appCase.getParentCase().getEncryptedId());

		caseVO.setCaseContactUserIds(caseContactUserIds);
		return caseVO;
	}

	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Nov 21, 2018 - 12:26:53 PM
	 * 
	 * @Author : Karthi
	 * 
	 * @Description : Its to update object from app UI screen field
	 * 
	 * @Tags :
	 * @param obj
	 *            - refer obj as entityClass
	 * @param appUIScreenFieldVOs
	 *            - get required field as path variable appUIScreenFieldVOs
	 * @Git_Config : name email
	 * 
	 */
	private void updateObjectFromAppUIScreenFieldVOValues(Object obj, List<AppUIScreenFieldVO> appUIScreenFieldVOs) {
		Class<?> propertyClass = null;
		for (AppUIScreenFieldVO appUIScreenFieldVO : appUIScreenFieldVOs) {
			try {
				propertyClass = PropertyUtils.getPropertyType(obj, appUIScreenFieldVO.getDbFieldName());
				this.updateObjectFromAppUIScreenFieldVOValues(obj, propertyClass, appUIScreenFieldVO);
			} catch (Exception ex) {
				LOGGER.error(CLASS_NAME, "updateObjectFromAppUIScreenFieldVOValues", ex);
			}
		}
	}

	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Nov 21, 2018 - 12:26:53 PM
	 * 
	 * @Author : Karthi
	 * 
	 * @Description : Its to update app UI screen field VO
	 * 
	 * @Tags :
	 * @param propertyClass
	 *            - update by using propertyClass
	 * @param objValue
	 *            - refers objValue for class
	 * @param appUIScreenFieldVO
	 *            - get required field by path variable appUIScreenFieldVO
	 * @Git_Config : name email
	 * 
	 */
	private void updateAppUIScreenFieldVOValues(Class<?> propertyClass, Object objValue,
			AppUIScreenFieldVO appUIScreenFieldVO) {
		String propertyClassName = propertyClass.getName();

		if (propertyClassName.equals(Character.class.getName())) {
			Character value = (Character) objValue;
			appUIScreenFieldVO.setBooleanValue(value == AppConstants.YES);
		} else if (propertyClassName.equals(Integer.class.getName())
				&& appUIScreenFieldVO.getDbFieldName().endsWith(AppConstants.COLUMN_NAME_HOURS)) {
			Integer totalHours = (Integer) objValue;
			appUIScreenFieldVO.setHours(CommonUtils.getHourPartofTotalHours(totalHours));
			appUIScreenFieldVO.setMinutes(CommonUtils.getMinutesPartofTotalHours(totalHours));
		} else if (propertyClassName.equals(Calendar.class.getName())) {
			appUIScreenFieldVO.setValue(CommonUtils.calendarToString((Calendar) objValue));
		} else if (propertyClassName.equals(Account.class.getName())) {
			this.updateAppUIScreenAccountField(objValue, appUIScreenFieldVO);
		} else if (propertyClassName.equals(User.class.getName())) {
			this.updateAppUIScreenUserField(objValue, appUIScreenFieldVO);
		} else if (propertyClassName.equals(AppItem.class.getName())) {
			this.updateAppUIScreenAppItemField(objValue, appUIScreenFieldVO);
		} else if (objValue != null) {
			String value = String.valueOf(objValue);
			appUIScreenFieldVO.setValue(value);
		}
		if (StringUtils.isNotEmpty(appUIScreenFieldVO.getListName())) {
			this.updateAppUIScreenListField(appUIScreenFieldVO);
		}
	}

	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Nov 21, 2018 - 12:26:53 PM
	 * 
	 * @Author : Karthi
	 * 
	 * @Description : Its to update app UI screen for account
	 * 
	 * @Tags :
	 * @param objValue
	 *            - refers objValue in accounts
	 * @param appUIScreenFieldVO
	 *            - get required field by path variable appUIScreenFieldVO
	 * @Git_Config : name email
	 * 
	 */
	private void updateAppUIScreenAccountField(Object objValue, AppUIScreenFieldVO appUIScreenFieldVO) {
		Account account = (Account) objValue;
		if (account != null) {
			if (appUIScreenFieldVO.getAttributeUIColumn() > 10) {
				// Header Part - Read Only, So populate the name.
				appUIScreenFieldVO.setValue(account.getName());
			} else {
				appUIScreenFieldVO.setValue(String.valueOf(account.getId()));
			}
		}
	}

	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Nov 21, 2018 - 12:26:53 PM
	 * 
	 * @Author : Karthi
	 * 
	 * @Description : Its to update app UI screen User
	 * 
	 * @Tags :
	 * @param objValue
	 *            - refer objValue in user
	 * @param appUIScreenFieldVO
	 *            - get required field by path variable appUIScreenFieldVO
	 * @Git_Config : name email
	 * 
	 */
	private void updateAppUIScreenUserField(Object objValue, AppUIScreenFieldVO appUIScreenFieldVO) {
		User user = (User) objValue;
		if (user != null) {
			if (appUIScreenFieldVO.getAttributeUIColumn() > 10) {
				// Header Part - Read Only, So populate the name.
				appUIScreenFieldVO.setValue(CommonUtils.getFullDisplayName(user.getUserProfile()));
			} else {
				appUIScreenFieldVO.setValue(String.valueOf(user.getId()));
			}
		}
	}

	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Nov 21, 2018 - 12:26:53 PM
	 * 
	 * @Author : Karthi
	 * 
	 * @Description : Its to update app UI screen for app Item
	 * 
	 * @Tags :
	 * @param objValue
	 *            - refer objValue in appItem
	 * @param appUIScreenFieldVO
	 *            - get required field by path variable appUIScreenFieldVO
	 * @Git_Config : name email
	 * 
	 */
	private void updateAppUIScreenAppItemField(Object objValue, AppUIScreenFieldVO appUIScreenFieldVO) {
		AppItem appItem = (AppItem) objValue;
		if (appItem != null) {
			appUIScreenFieldVO.setValue(appItem.getLongName());
		}
	}

	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Nov 21, 2018 - 12:26:53 PM
	 * 
	 * @Author : Karthi
	 * 
	 * @Description : Its to update app UI screen list
	 * 
	 * @Tags :
	 * @param appUIScreenFieldVO
	 *            - get required field by path variable appUIScreenFieldVO
	 * @Git_Config : name email
	 * 
	 */
	private void updateAppUIScreenListField(AppUIScreenFieldVO appUIScreenFieldVO) {
		AppList appList = this.cacheService.findByAppListName(appUIScreenFieldVO.getListName());
		Map<String, String> listItemMap = new LinkedHashMap<>();
		List<AppItem> appItems = this.cacheService.findByListId(appList.getId());
		listItemMap.put(AppConstants.EMPTY_STRING, AppConstants.CASE_FILTER_ANY);
		for (AppItem appItem : appItems) {
			listItemMap.put(appItem.getShortName(), appItem.getLongName());
		}
		appUIScreenFieldVO.setListItemMap(listItemMap);
	}

	@Override
	public CaseVO getCaseVO(Case appCase,UserVO userVO) throws TriventException {
		AppDBTable appdbTable = this.appDBTableRepository.findByName("Case");
		String screenType = AppConstants.SCREEN_TYPE_DETAIL;
		return this.getCaseVO(appdbTable.getId(), screenType, appCase,userVO);
	}

	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Nov 21, 2018 - 12:26:52 PM
	 * 
	 * @Author : Karthi
	 * 
	 * @Description : Its to check user has access
	 * 
	 * @Tags :
	 * @param appCase
	 *            - check by using appCase
	 * @param loginUser
	 *            - to get loginUser
	 * @throws TriventException
	 * @Git_Config : name email
	 * 
	 */
	private void checkUserHasAccess(Case appCase, User loginUser) throws TriventException {
		if (!appCase.isNew() && (appCase.getAccount().getId().longValue() != loginUser.getAccount().getId())) {
			// Access denied.
			LOGGER.debug(CLASS_NAME, METHOD_GET_CASE, "User [{}] trying to access account [{}]. Access denied.",
					loginUser.getLoginId(), appCase.getAccount().getName());
			throw new TriventException("Access denied to this case.");
		}
	}

	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Nov 21, 2018 - 12:26:53 PM
	 * 
	 * @Author : Karthi
	 * 
	 * @Description : Its to update app UI screen field VO
	 * 
	 * @Tags :
	 * @param obj
	 *            -refer obj in propertyClass
	 * @param appUIScreenFieldVOs
	 *            - get required field by path variable appUIScreenFieldVOs
	 * @Git_Config : name email
	 * 
	 */
	private void updateAppUIScreenFieldVOValues(Object obj, List<AppUIScreenFieldVO> appUIScreenFieldVOs) {
		Class<?> propertyClass = null;
		Object objValue = null;
		for (AppUIScreenFieldVO appUIScreenFieldVO : appUIScreenFieldVOs) {
			try {
				propertyClass = PropertyUtils.getPropertyType(obj, appUIScreenFieldVO.getDbFieldName());
				objValue = PropertyUtils.getProperty(obj, appUIScreenFieldVO.getDbFieldName());
				this.updateAppUIScreenFieldVOValues(propertyClass, objValue, appUIScreenFieldVO);
			} catch (Exception ex) {
				LOGGER.error(CLASS_NAME, "updateAppUIScreenFieldVOValues", ex);
			}
		}
	}

	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Nov 21, 2018 - 12:26:53 PM
	 * 
	 * @Author : Karthi
	 * 
	 * @Description : Its to save caseContact
	 * 
	 * @Tags :
	 * @param caseContactIds
	 *            - save by caseContactIds
	 * @param caseId
	 *            - save by caseId
	 * @param userVO 
	 * @return
	 * @Git_Config : name email
	 * 
	 */
	@SuppressWarnings("unused")
	@Transactional(readOnly = false)
	private boolean saveCaseContacts(String caseContactIds, Long caseId, UserVO userVO) {
		try {
			if (!StringUtils.isEmpty(caseContactIds)) {
				String[] arrCaseContactIds = caseContactIds.split(",");
				Case appCase = new Case();
				String contactName = null;
				Set<String> caseContactsList = new HashSet<String>();
				// update in case contact repos for sub cases if changes done in parent case
				try {
					List<Case> SubCases = caseRepository.findByParentId(caseId);
					if (!SubCases.isEmpty()) {
						for (Case cases : SubCases) {
							Long subCaseId = cases.getId();
							//this.caseContactsRepository.updateCaseContactsbyCaseID(AppConstants.YES, subCaseId);
							String updateColumnNew = "is_deleted='Y'";
							Long caseContactIdNew = this.caseContactsRepository.save_case_contacts_by_case_id(	null,"UPDATE",updateColumnNew,subCaseId,null,null,null,null,userVO.getId(),null,userVO.getId(),null,'N',null,null);
							for (String strCaseContactIds : arrCaseContactIds) {
								Long contactId = Long.parseLong(strCaseContactIds);
								Contact contact = this.contactRepository.findOne(contactId);
								appCase = this.getCase(subCaseId);
								List<CaseContacts> existCaseContacts = this.caseContactsRepository
										.existCaseContactbyEntity(AppConstants.YES, contactId, subCaseId);

								if (existCaseContacts.size() > 0) {
									for (CaseContacts caseContactOne : existCaseContacts) {
										//this.caseContactsRepository.updateCaseContactsbyId(AppConstants.NO, appCase,caseContactOne.getId());
										String updateColumn = "is_deleted='N'";
										Long caseContactId = this.caseContactsRepository.update_casecontacts_by_caseid_contactid(caseContactOne.getId(),"UPDATE",updateColumn,appCase.getId(),null,null,null,null,userVO.getId(),null,userVO.getId(),null,'N',null,null);

										caseContactsList.add(caseContactOne.getName());
										contactName = String.join(",", caseContactsList);

										appCase.setContactName(contactName);
									}
									continue;
								}

								List<Case> clientCases = caseRepository.findByParentId(caseId);
								if (!clientCases.isEmpty()) {
									for (Case caseID : clientCases) {
										Long subCaseIdOne = caseID.getId();
										Case caseEntity = this.getCase(subCaseIdOne);
										CaseContacts caseContact = new CaseContacts();
										caseContact.setCaseId(caseEntity);
										if (contact != null) {
											if (contact.getUserId() != null) {
												User conUser = this.userRepository.findOne(contact.getUserId());
												if (conUser != null) {
													caseContact.setUserId(conUser);
												}
											}
											caseContact.setEmailId(contact.getEmail());
											caseContact.setName(contact.getFirstName() + " " + contact.getLastName());
											caseContact.setContactId(contact.getId());
											caseContact.setContactType(contact.getContactType());

											//caseContact = this.caseContactsRepository.save(caseContact);
											
											Long caseContactId = this.caseContactsRepository.save_case_contacts(null, "INSERT", null,caseEntity.getId(),null,caseContact.getName(),caseContact.getEmailId(),null,userVO.getId(),null,userVO.getId(),caseContact.getOptLockVersion(), 'N',caseContact.getContactId(),caseContact.getContactType());	
											System.out.println("caseContactId::"+caseContactId);

											caseContactsList.add(contact.getFirstName() + " " + contact.getLastName());
											contactName = String.join(",", caseContactsList);

											appCase.setContactName(contactName);
										}
									}
								}
							}
						}
					}
				} catch (Exception e) {
					LOGGER.error(CLASS_NAME, "saveCaseContacts", e);
				}

				// to update parent and sub case contacts as yes
				if (caseId != null) {
					Case isPrnt = caseRepository.findOne(caseId);
					Case prntCase = isPrnt.getParentCase();
					if (prntCase != null) {
						Long prntCaseID = prntCase.getId();
						//this.caseContactsRepository.updateCaseContactsbyCaseID(AppConstants.YES, prntCaseID);
						String updateColumnNew = "is_deleted='Y'";
						Long caseContactIdNew = this.caseContactsRepository.save_case_contacts_by_case_id(	null,"UPDATE",updateColumnNew,prntCaseID,null,null,null,null,userVO.getId(),null,userVO.getId(),null,'N',null,null);
						List<Case> subCases = caseRepository.findByParentId(prntCase.getId());
						for (Case subCase : subCases) {
							Long caseId1 = subCase.getId();
							//this.caseContactsRepository.updateCaseContactsbyCaseID(AppConstants.YES, caseId1);
							String updateColumn = "is_deleted='Y'";
							Long caseContactId = this.caseContactsRepository.save_case_contacts_by_case_id(	null,"UPDATE",updateColumn,	caseId1,null,null,null,	null,userVO.getId(),null,userVO.getId(),null,'N',null,null);							
						}
					} else {
						//ToDo::::::::
					//	this.caseContactsRepository.updateCaseContactsbyCaseID(AppConstants.YES, caseId);	
						//caseContact = this.caseContactsRepository.save(caseContact);
						String updateColumn = "is_deleted='Y'";
						Long caseContactId = this.caseContactsRepository.save_case_contacts_by_case_id(	null,"UPDATE",updateColumn,	caseId,	null,null,null,	null,userVO.getId(),null,userVO.getId(),null,'N',null,null);
						System.out.println("caseContactId::"+caseContactId);
					}

				}
				for (String strCaseContactIds : arrCaseContactIds) {
					Long contactId = Long.parseLong(strCaseContactIds);
					Contact contact = this.contactRepository.findOne(contactId);
					appCase = this.getCase(caseId);

					if (caseId != null) {
						Case isPrnt = caseRepository.findOne(caseId);
						Case prntCase = isPrnt.getParentCase();
						if (isPrnt.getParentCase() == null) {
							try {
								// update in case contact repos for parent cases if changes done in parent case
								List<CaseContacts> existCaseContacts = this.caseContactsRepository
										.existCaseContactbyEntity(AppConstants.YES, contactId, caseId);

								if (existCaseContacts.size() > 0) {
									for (CaseContacts caseContactOne : existCaseContacts) {
										//this.caseContactsRepository.updateCaseContactsbyId(AppConstants.NO, appCase,caseContactOne.getId());
										String updateColumn = "is_deleted='N'";
										Long caseContactId = this.caseContactsRepository.update_casecontacts_by_caseid_contactid(caseContactOne.getId(),"UPDATE",updateColumn,appCase.getId(),null,null,null,null,userVO.getId(),null,userVO.getId(),null,'N',null,null);
										
										caseContactsList.add(caseContactOne.getName());
										contactName = String.join(",", caseContactsList);

										appCase.setContactName(contactName);
									}
									continue;
								}
								Case caseEntity = this.getCase(caseId);
								CaseContacts caseContact = new CaseContacts();
								caseContact.setCaseId(caseEntity);
								if (contact != null) {
									if (contact.getUserId() != null) {
										User conUser = this.userRepository.findOne(contact.getUserId());
										if (conUser != null) {
											caseContact.setUserId(conUser);
										}
									}
									caseContact.setEmailId(contact.getEmail());
									caseContact.setName(contact.getFirstName() + " " + contact.getLastName());
									caseContact.setContactId(contact.getId());
									caseContact.setContactType(contact.getContactType());

									//caseContact = this.caseContactsRepository.save(caseContact);
									Long caseContactId = this.caseContactsRepository.save_case_contacts(null, "INSERT", null,caseEntity.getId(),null,caseContact.getName(),caseContact.getEmailId(),null,userVO.getId(),null,userVO.getId(),caseContact.getOptLockVersion(),'N',caseContact.getContactId(),caseContact.getContactType());
									System.out.println("caseContactId::"+caseContactId);
									
									caseContactsList.add(contact.getFirstName() + " " + contact.getLastName());
									contactName = String.join(",", caseContactsList);

									appCase.setContactName(contactName);
								}
							} catch (Exception e) {
								LOGGER.error(CLASS_NAME, "saveCaseContacts", e);
							}

						}

						else {
							//// update in case contact repos if changes done in any one of sub case
							List<Case> subCases = caseRepository.findByParentId(prntCase.getId());
							if (subCases.size() > 0) {

								for (Case subCase : subCases) {
									try {
										Long caseId1 = subCase.getId();
										appCase = this.getCase(caseId1);
										List<CaseContacts> existCaseContacts = this.caseContactsRepository
												.existCaseContactbyEntity(AppConstants.YES, contactId, caseId1);

										if (existCaseContacts.size() > 0) {
											for (CaseContacts caseContactOne : existCaseContacts) {
												//this.caseContactsRepository.updateCaseContactsbyId(AppConstants.NO,appCase, caseContactOne.getId());
												String updateColumn = "is_deleted='N'";
												@SuppressWarnings("unused")
												Long caseContactId = this.caseContactsRepository.update_casecontacts_by_caseid_contactid(caseContactOne.getId(),"UPDATE",updateColumn,appCase.getId(),null,null,null,null,userVO.getId(),null,userVO.getId(),null,'N',null,null);
												
												caseContactsList.add(caseContactOne.getName());
												contactName = String.join(",", caseContactsList);

												appCase.setContactName(contactName);
											}
											continue;
										}
										Case caseEntity = this.getCase(caseId1);
										CaseContacts caseContact = new CaseContacts();
										caseContact.setCaseId(caseEntity);
										if (contact != null) {
											if (contact.getUserId() != null) {
												User conUser = this.userRepository.findOne(contact.getUserId());
												if (conUser != null) {
													caseContact.setUserId(conUser);
												}
											}
											caseContact.setEmailId(contact.getEmail());
											caseContact.setName(contact.getFirstName() + " " + contact.getLastName());
											caseContact.setContactId(contact.getId());
											caseContact.setContactType(contact.getContactType());

											//caseContact = this.caseContactsRepository.save(caseContact);
										    Long caseContactId	= this.caseContactsRepository.save_case_contacts(null, "INSERT",null,caseEntity.getId(),null,caseContact.getName(),caseContact.getEmailId(),null,userVO.getId(),null,userVO.getId(),caseContact.getOptLockVersion(),'N',caseContact.getContactId(),caseContact.getContactType());
											System.out.println("caseContactId"+caseContactId);
											
											caseContactsList.add(contact.getFirstName() + " " + contact.getLastName());
											contactName = String.join(",", caseContactsList);

											appCase.setContactName(contactName);
										}
									} catch (Exception e) {
										LOGGER.error(CLASS_NAME, "saveCaseContacts", e);
									}
								}
							}
							Long prntCaseID = prntCase.getId();
							appCase = this.getCase(prntCaseID);
							try {
								List<CaseContacts> existCaseContacts = this.caseContactsRepository
										.existCaseContactbyEntity(AppConstants.YES, contactId, prntCaseID);

								if (existCaseContacts.size() > 0) {
									for (CaseContacts caseContactOne : existCaseContacts) {
										//this.caseContactsRepository.updateCaseContactsbyId(AppConstants.NO, appCase,caseContactOne.getId());
										String updateColumn = "is_deleted='N'";
										Long caseContactId = this.caseContactsRepository.update_casecontacts_by_caseid_contactid(caseContactOne.getId(),"UPDATE",updateColumn,appCase.getId(),null,null,null,null,userVO.getId(),null,userVO.getId(),null,'N',null,null);
										
										caseContactsList.add(caseContactOne.getName());
										contactName = String.join(",", caseContactsList);

										appCase.setContactName(contactName);
									}
									continue;
								}
								Case caseEntity = this.getCase(prntCaseID);
								CaseContacts caseContact = new CaseContacts();
								caseContact.setCaseId(caseEntity);
								if (contact != null) {
									if (contact.getUserId() != null) {
										User conUser = this.userRepository.findOne(contact.getUserId());
										if (conUser != null) {
											caseContact.setUserId(conUser);
										}
									}
									caseContact.setEmailId(contact.getEmail());
									caseContact.setName(contact.getFirstName() + " " + contact.getLastName());
									caseContact.setContactId(contact.getId());
									caseContact.setContactType(contact.getContactType());

									//caseContact = this.caseContactsRepository.save(caseContact);
									Long caseContactId = this.caseContactsRepository.save_case_contacts(null, "INSERT", null,caseEntity.getId(),null,caseContact.getName(),caseContact.getEmailId(),null,userVO.getId(),null,userVO.getId(),caseContact.getOptLockVersion(),'N',caseContact.getContactId(),caseContact.getContactType());
									System.out.println("caseContactId"+caseContactId);
									caseContactsList.add(contact.getFirstName() + " " + contact.getLastName());
									contactName = String.join(",", caseContactsList);

									appCase.setContactName(contactName);
								}
							} catch (Exception e) {
								LOGGER.error(CLASS_NAME, "saveCaseContacts", e);
							}

						}
					}
				}

				if (caseId != null) {
					Case isPrnt = caseRepository.findOne(caseId);/*
																	 * Updating Case Contacts in Child Cases , If
																	 * modified in Parent to save in case repos
																	 */
					if (isPrnt.getParentCase() == null) {
						//List<Case> clientCase = this.caseRepository.findByParentCaseClient(new Long(4999));
						//List<Object[]>  clientCasesObj = caseRepository.getCaseListByParentCaseId(caseId);
						List<Case> clientCases = new ArrayList<>();
						if (!clientCases.isEmpty()) {
							for (Case cases : clientCases) {
								Long subCaseId = cases.getId();
								Case contactOne = caseRepository.findOne(subCaseId);
								if (contactOne != null) {
									contactOne.setContactName(contactName);
									//caseRepository.save(contactOne);									
									//this.caseRepository.updateCaseContatcNameByCaseID(contactOne.getId(),contactOne.getContactName());
									String Column_Update = "case_contact_name='"+contactOne.getContactName()+"'";
									//Procedure to Save Case Details		
									Long updateCaseId = this.UpdateCaseDetailusingProcedure(contactOne.getId(), "UPDATE", Column_Update, userVO.getId(),(contactOne.getOptLockVersion()!=null) ? contactOne.getOptLockVersion() : 0);
								}
							}
						}
						isPrnt = caseRepository.findOne(caseId);
						//BeanUtils.copyProperties(appCase, isPrnt);
						//this.caseRepository.updateCaseContatcNameByCaseID(isPrnt.getId(),isPrnt.getContactName());
						//Procedure to Save Case Details		
						String Column_Update = "case_contact_name='"+isPrnt.getContactName()+"'";						
						//Procedure to Save Case Details	
						Long updateCaseId = this.UpdateCaseDetailusingProcedure(isPrnt.getId(), "UPDATE", Column_Update, userVO.getId(),(isPrnt.getOptLockVersion()!=null) ? isPrnt.getOptLockVersion() : 0);
						//caseRepository.save(isPrnt);
						return true;
					} else {/*
							 * Updating Case Contacts in Child Cases as well as Parent , if modified from
							 * any SubCase to save in case repos
							 */
						Case prntCase = isPrnt.getParentCase();
						if (prntCase != null) {
							List<Case> subCases = caseRepository.findByParentId(prntCase.getId());
							if (subCases.size() > 0) {
								for (Case subCase : subCases) {
									Long subCaseId = subCase.getId();
									Case contactOne = caseRepository.findOne(subCaseId);
									if (contactOne != null) {
										contactOne.setContactName(contactName);
										//caseRepository.save(contactOne);
										String Column_Update = "case_contact_name='"+contactOne.getContactName()+"'";	
										Long updateCaseId = this.UpdateCaseDetailusingProcedure(contactOne.getId(), "UPDATE", Column_Update, userVO.getId(),(isPrnt.getOptLockVersion()!=null) ? isPrnt.getOptLockVersion() : 0);
									}
								}
							}
							Long prntCaseID = prntCase.getId();
							Case contactOne = caseRepository.findOne(prntCaseID);
							if (contactOne != null) {
								contactOne.setContactName(contactName);
								//caseRepository.save(contactOne);
								String Column_Update = "case_contact_name='"+contactOne.getContactName()+"'";	
								Long updateCaseId = this.UpdateCaseDetailusingProcedure(contactOne.getId(), "UPDATE", Column_Update, userVO.getId(),(contactOne.getOptLockVersion()!=null) ? contactOne.getOptLockVersion() : 0);
								return true;
							}
						}
					}
				}

			}
		} catch (Exception ex) {
			LOGGER.error(CLASS_NAME, "saveCaseContacts", ex);
			return false;
		}
		return false;
	}

	@Override
	@Transactional(readOnly = true)
	public List<RowVO> listCases(ScreenListFilterVO screenListFilterVO, String type, String fromDate, String toDate,
			String pCode, String accountId, String caseStatus, UserVO userVO)
			throws TriventException, java.text.ParseException {

		// AppDBTable appdbTable = this.appDBTableRepository.findByName("Case");
		String screenType = AppConstants.SCREEN_TYPE_LIST;

		List<Case> clientCases = null;
		if (StringUtils.isNotBlank(accountId) && StringUtils.isNotEmpty(accountId)) {
			Account account = this.accountRepository.findById(new Long(accountId));
			List<Account> accountList = new ArrayList<Account>();
			accountList.add(account);
			clientCases = this.getCaseList(screenListFilterVO, type, fromDate, toDate, pCode, accountList, caseStatus,
					userVO);
		} else {
			clientCases = this.getCaseList(screenListFilterVO, type, fromDate, toDate, pCode, null, caseStatus, userVO);
		}

		List<RowVO> updatedRowVOs = new ArrayList<>();
		List<RowVO> rowVOs = this.filterUtils.listScreenDetails(new Long(12), screenType, clientCases);

		List<Long> lllCaseId = rowVOs.stream().parallel().filter(p -> p.getId() != null).sequential()
				.map(p -> new Long(p.getId())).collect(Collectors.toCollection(ArrayList::new));
		List<RowVO> rowVOsReturn = new ArrayList<RowVO>();
		if (lllCaseId != null && !lllCaseId.isEmpty() && lllCaseId.size() > 0) {
			List<Object[]> caseDetails = this.reportRepository.ListCaseDetails(lllCaseId);
			List<Object[]> caseDetailLabels = this.reportRepository.ListCaseDetailLabels(lllCaseId);
			if ((caseDetails != null && !caseDetails.isEmpty() && caseDetails.size() > 0)
					|| (caseDetailLabels != null && !caseDetailLabels.isEmpty() && caseDetailLabels.size() > 0)) {

				for (RowVO rowVO : rowVOs) {
					if (rowVO.getId() == null) {
						rowVOsReturn.add(rowVO);
						continue;
					}
					final Long rowId = rowVO.getId();
					List<Object[]> caseUpdate = caseDetails.stream().parallel().filter(
							p -> p != null && p[0] != null && p[0].toString().equalsIgnoreCase(rowId.toString()))
							.map(p -> p).collect(Collectors.toCollection(ArrayList::new));

					Map<String, String> caseFlagMap = rowVO.getValueMap();
					if (caseFlagMap == null || caseFlagMap.isEmpty() || caseFlagMap.size() == 0) {
						caseFlagMap = new HashMap<>();
					}

					if (caseUpdate != null && !caseUpdate.isEmpty() && caseUpdate.size() > 0) {

						Object[] objCaseDetail = caseUpdate.get(0);

						String clientReqnSpecification = (objCaseDetail != null && objCaseDetail[2] != null
								&& StringUtils.isNotEmpty(objCaseDetail[2].toString())
								&& StringUtils.isNotBlank(objCaseDetail[2].toString())
								&& new Long(objCaseDetail[2].toString()) > 0) ? "Y" : "N";
						caseFlagMap.put("clientReqnSpecification", clientReqnSpecification);
						caseFlagMap.put("clientReqId",
								clientReqnSpecification == "Y" ? objCaseDetail[2].toString() : "");

						String caseTasksMap = (objCaseDetail != null && objCaseDetail[3] != null
								&& StringUtils.isNotEmpty(objCaseDetail[3].toString())
								&& StringUtils.isNotBlank(objCaseDetail[3].toString())
								&& new Long(objCaseDetail[3].toString()) > 0) ? "Y" : "N";
						caseFlagMap.put("caseTasksMap", caseTasksMap);

						String prodTasks = (objCaseDetail != null && objCaseDetail[4] != null
								&& StringUtils.isNotEmpty(objCaseDetail[4].toString())
								&& StringUtils.isNotBlank(objCaseDetail[4].toString())
								&& new Long(objCaseDetail[4].toString()) > 0) ? "Y" : "N";
						caseFlagMap.put("prodTasks", prodTasks);

						caseFlagMap.put("accountManager",
								(objCaseDetail != null && objCaseDetail[6] != null
										&& StringUtils.isNotEmpty(objCaseDetail[6].toString())
										&& StringUtils.isNotBlank(objCaseDetail[6].toString()))
												? objCaseDetail[6].toString()
												: "");
						caseFlagMap.put("createdBy",
								(objCaseDetail != null && objCaseDetail[5] != null
										&& StringUtils.isNotEmpty(objCaseDetail[5].toString())
										&& StringUtils.isNotBlank(objCaseDetail[5].toString()))
												? objCaseDetail[5].toString()
												: "");

					}
					List<Object[]> caseLabelUpdate = caseDetailLabels.stream().parallel().filter(
							p -> p != null && p[0] != null && p[0].toString().equalsIgnoreCase(rowId.toString()))
							.map(p -> p).collect(Collectors.toCollection(ArrayList::new));
					if (caseLabelUpdate != null && !caseLabelUpdate.isEmpty() && caseLabelUpdate.size() > 0) {
						Object[] objCaseDetailLabel = caseLabelUpdate.get(0);

						Map<String, String> labelMap = new LinkedHashMap<>();
						Map<String, Map<String, String>> labelNamesMap = new LinkedHashMap<>();
						List<String> llcaseLabelList = Arrays.stream(objCaseDetailLabel[1].toString().split("`~`"))
								.collect(Collectors.toCollection(ArrayList::new));

						for (String lstrcaseLabelList : llcaseLabelList) {

							if (lstrcaseLabelList.indexOf("``~") >= 0) {
								String[] lstrcaseLabelArray = lstrcaseLabelList.split("``~");
								labelMap.put(lstrcaseLabelArray[0],
										lstrcaseLabelArray[1].endsWith(",")
												? lstrcaseLabelArray[1].substring(0, lstrcaseLabelArray[1].length() - 1)
												: lstrcaseLabelArray[1]);
							}

						}
						labelNamesMap.put(objCaseDetailLabel[0].toString(), labelMap);
						rowVO.setValueMap1(labelNamesMap);
					}
					rowVOsReturn.add(rowVO);

				}

			}
		}

		updatedRowVOs.addAll(rowVOsReturn);

		return updatedRowVOs;
	}

	@SuppressWarnings("deprecation")
	@Override
	@Transactional(readOnly = true)
	public List<Case> getCaseList(ScreenListFilterVO screenListFilterVO, String type, String fromDate, String toDate,
			String pCode, List<Account> listAccount, String caseStatus, UserVO userVO)
			throws TriventException, java.text.ParseException {
		User loginUser = this.userService.getCurrentUser(userVO);
		// this.appDBTableRepository.findByName("Case");
		List<Case> clientCases = null;
		if (loginUser.getType().equals(AppConstants.TYPE_CLIENT)
				&& !screenListFilterVO.getSelectedViewType().equals(AppUIScreenView.VIEW_CLIENT)) {
			LOGGER.warn(CLASS_NAME, "getCaseList",
					"Invalid UI View Configured. Client should view only cases created by him.");
			return new ArrayList<>(1);
		}

		Specification<Case> specification = null;
		// Case isDeleted
		Specifications<Case> specifications = Specifications
				.where(this.caseGSpecifications.dataTypeCharacter("deleted", AppConstants.NO));
		if (listAccount == null || listAccount.size() == 0) {
			listAccount = this.filterUtils.hasAccountFilter(loginUser);
		}
		if (listAccount.size() > 0) {
			specification = this.caseGSpecifications.dataTypeAccount("account", listAccount);
			specifications = specifications.and(specification);
		}

		// added for case list based on role cs Status
		if (loginUser != null && screenListFilterVO.isScreenFieldFilterOne()) {
			Role role = roleRepository.getOne(loginUser.getRole().getId());
			List<String> csStatus = new ArrayList<String>();
			if (role.getCaseCsStatus() != null) {
				for (String roleCSStatus : role.getCaseCsStatus().split(",")) {
					csStatus.add(roleCSStatus);
				}
			}
			if (!csStatus.isEmpty()) {
				specification = this.caseGSpecifications.dataTypeStringList("csStatus", csStatus);
				specifications = specifications.and(specification);
			}
		}

		if ((pCode != null) && (pCode != "")) {
			List<Account> accounts = this.accountRepository.findAccountByPartnerId(Long.parseLong(pCode),
					AppConstants.NO);
			if (accounts.size() > 0) {
				Specification<Case> specificationnew = this.caseGSpecifications.dataTypeAccount("account", accounts);
				specifications = specifications.and(specificationnew);
			}
		}

		if ((type != null) && (fromDate == null) && (toDate == null)) {
			Date date = new Date();

			Specifications<Case> specificationNew = Specifications

					.where(this.caseGSpecifications.dataTypeLessThanDate("cf_1_Date", date));
			specification = this.caseGSpecifications.dataTypeLessThanDate("expeditedDeliveryDate", date);
			specificationNew = specificationNew.or(specification);
			specifications = specifications.and(specificationNew);

			try // Check with the status in configurable option on 23 Aug 2017
			{
				List<String> strConfigDatas = new ArrayList<>();
				strConfigDatas.add(
						this.applicationProperties.getProperty("application.configuration.dashboarg.csstatus.overdue"));

				List<AppConfigDataVO> appConfigDataVOList = this.appConfigDataService
						.getAppConfigDataVOList(strConfigDatas);

				List<Long> appItemIds = new ArrayList<>();
				for (final AppConfigDataVO appConfigDataVO : appConfigDataVOList) {

					String[] strIds = appConfigDataVO.getDataValue().split(",");
					for (String strId : strIds) {
						if (NumberUtils.isNumber(strId)) {
							appItemIds.add(new Long(strId));
						}
					}
				}
				if (appItemIds.size() > 0) {

					Specification<AppItem> specificationAppItem = null;

					Specifications<AppItem> specificationsAppItem = Specifications
							.where(this.appItemGenericSpecifications.dataTypeLongList("id", appItemIds));

					specificationAppItem = specificationsAppItem;
					List<String> strCSStatus = new ArrayList<>();
					List<AppItem> appItemList = this.appItemRepository.findAll(specificationAppItem);
					for (AppItem appItem : appItemList) {
						strCSStatus.add(appItem.getLongName());
					}

					Specification<Case> specificationnew = this.caseGSpecifications.dataTypeStringList("csStatus",
							strCSStatus);
					specifications = specifications.and(specificationnew);
				}

			} catch (Exception e) {
				LOGGER.error(CLASS_NAME, "over due cases based on status configure", e);
			}
			Specification<Case> specificationsNew = this.caseGSpecifications.dataTypeString("type", type);
			specifications = specifications.and(specificationsNew);
		}
		if ((type != null) && (fromDate != null) && (toDate != null)) {
			java.util.Date date = new java.util.Date();
			date.setHours(0);
			date.setMinutes(0);
			date.setSeconds(0);
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss zzz");
			try {
				String fdate = formatter.format(new Date(fromDate));
				Date dfdate = formatter.parse(fdate);
				dfdate.setHours(0);
				dfdate.setMinutes(0);
				dfdate.setSeconds(0);
				String tdate = formatter.format(new Date(toDate));
				Date dtdate = formatter.parse(tdate);
				dtdate.setHours(23);
				dtdate.setMinutes(59);
				dtdate.setSeconds(59);

				Specifications<Case> specificationsNew = Specifications
						.where(this.caseGSpecifications.dataTypeDate("cf_1_Date", dfdate, dtdate));
				specificationsNew = specificationsNew
						.and(this.caseGSpecifications.dataTypeLessThanDate("cf_1_Date", date));
				Specifications<Case> specificationsNew2 = Specifications
						.where(this.caseGSpecifications.dataTypeDate("expeditedDeliveryDate", dfdate, dtdate));
				specificationsNew2 = specificationsNew2
						.and(this.caseGSpecifications.dataTypeLessThanDate("expeditedDeliveryDate", date));

				specificationsNew = specificationsNew.or(specificationsNew2);
				specifications = specifications.and(specificationsNew);

				try // Check with the status in configurable option on 23 Aug 2017
				{

					List<String> strConfigDatas = new ArrayList<>();
					strConfigDatas.add(this.applicationProperties
							.getProperty("application.configuration.dashboarg.csstatus.overdue"));

					List<AppConfigDataVO> appConfigDataVOList = this.appConfigDataService
							.getAppConfigDataVOList(strConfigDatas);

					List<Long> appItemIds = new ArrayList<>();
					for (final AppConfigDataVO appConfigDataVO : appConfigDataVOList) {

						String[] strIds = appConfigDataVO.getDataValue().split(",");
						for (String strId : strIds) {
							if (NumberUtils.isNumber(strId)) {
								appItemIds.add(new Long(strId));
							}
						}

					}

					if (appItemIds.size() > 0) {

						Specification<AppItem> specificationAppItem = null;

						Specifications<AppItem> specificationsAppItem = Specifications
								.where(this.appItemGenericSpecifications.dataTypeLongList("id", appItemIds));

						specificationAppItem = specificationsAppItem;
						List<String> strCSStatus = new ArrayList<>();
						List<AppItem> appItemList = this.appItemRepository.findAll(specificationAppItem);
						for (AppItem appItem : appItemList) {
							strCSStatus.add(appItem.getLongName());
						}

						Specification<Case> specificationnew = this.caseGSpecifications.dataTypeStringList("csStatus",
								strCSStatus);
						specifications = specifications.and(specificationnew);
					}
					Specification<Case> specificationsNew3 = this.caseGSpecifications.dataTypeString("type", type);
					specifications = specifications.and(specificationsNew3);
				} catch (Exception e) {
					LOGGER.error(CLASS_NAME, "over due cases based on status configure", e);
				}
				Specification<Case> specification3 = this.caseGSpecifications.dataTypeString("type", type);
				specifications = specifications.and(specification3);

			} catch (ParseException ex) {
				LOGGER.error(CLASS_NAME, "dateFilter", ex);
			}
		}

		else {
			if ((fromDate != null) && (toDate != null)) {

				try {
					DateFormat formatter = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy");
					String fdate = formatter.format(new Date(fromDate));
					Date dfdate = formatter.parse(fdate);
					dfdate.setHours(0);
					dfdate.setMinutes(0);
					dfdate.setSeconds(0);
					String tdate = formatter.format(new Date(toDate));
					Date dtdate = formatter.parse(tdate);
					dtdate.setHours(23);
					dtdate.setMinutes(59);
					dtdate.setSeconds(59);

					Specifications<Case> specificationsNew2 = Specifications
							.where(this.caseGSpecifications.dataTypeDate("fileReceivedDate", dfdate, dtdate));

					specifications = specifications.and(specificationsNew2);
				} catch (ParseException ex) {
					LOGGER.error(CLASS_NAME, "dateFilter", ex);
				}

			} else if ((fromDate == null) && (toDate != null)) {

				try {
					DateFormat formatter = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy");
					String tdate = formatter.format(new Date(toDate));
					Date dtdate = formatter.parse(tdate);
					dtdate.setHours(23);
					dtdate.setMinutes(59);
					dtdate.setSeconds(59);

					Specifications<Case> specificationsNew2 = Specifications
							.where(this.caseGSpecifications.dataTypeDate("fileReceivedDate", dtdate));

					specifications = specifications.and(specificationsNew2);
				} catch (ParseException ex) {
					LOGGER.error(CLASS_NAME, "dateFilter", ex);
				}

			} else if ((fromDate != null) && (toDate == null)) {

				try {
					DateFormat formatter = new SimpleDateFormat("E MMM dd HH:mm:ss Z yyyy");
					String fdate = formatter.format(new Date(fromDate));
					Date dfdate = formatter.parse(fdate);
					dfdate.setHours(0);
					dfdate.setMinutes(0);
					dfdate.setSeconds(0);

					Specifications<Case> specificationsNew2 = Specifications
							.where(this.caseGSpecifications.dataTypeDate("fileReceivedDate", dfdate));

					specifications = specifications.and(specificationsNew2);
				} catch (ParseException ex) {
					LOGGER.error(CLASS_NAME, "dateFilter", ex);
				}

			}
		}

		if ((caseStatus != null) && (caseStatus != "")) {

			if (caseStatus.equalsIgnoreCase("Delivered")) {
				List<String> strCSStatus = this.statusForFileDeliveredCase();
				// String strCSStatus = "File Delivery";
				Specifications<Case> specificationpendingCase = Specifications
						.where(this.caseGSpecifications.dataTypeStringList("csStatus", strCSStatus));
				specificationpendingCase = specificationpendingCase
						.and(this.caseGSpecifications.dataTypeCaseDeleted("deleted", AppConstants.NO));

				specifications = specifications.and(specificationpendingCase);
			}
			if (caseStatus.equalsIgnoreCase("pendingCase")) {
				List<String> strCSStatus = this.statusForFileDeliveredCase();
				Specifications<Case> specificationpendingCase = Specifications
						.where(this.caseGSpecifications.dataTypeStringNotList("csStatus", strCSStatus));
				specificationpendingCase = specificationpendingCase
						.and(this.caseGSpecifications.dataTypeCaseDeleted("deleted", AppConstants.NO));

				specifications = specifications.and(specificationpendingCase);
			}
			if (caseStatus.equalsIgnoreCase("Closed")) {
				String strCSStatus = "Closed";
				Specifications<Case> specificationpendingCase = Specifications
						.where(this.caseGSpecifications.dataTypeString("csStatus", strCSStatus));
				specificationpendingCase = specificationpendingCase
						.and(this.caseGSpecifications.dataTypeCaseDeleted("deleted", AppConstants.NO));

				specifications = specifications.and(specificationpendingCase);
			}

		}

		specifications = this.filterUtils.populateCaseViewSpecifications(screenListFilterVO, loginUser, specifications,
				true);

		specifications = this.filterUtils.populateCaseFilterSpecifications(screenListFilterVO, specifications);

		// Convert the list of specifications to single specification
		specification = specifications;
		/* To hide sub Case for Client */
		if (loginUser.getType().equalsIgnoreCase("Client")) {
			Specifications<Case> specificationParentCaseNull = Specifications
					.where(this.caseGSpecifications.dataTypeParentNull("parentCase"));
			specification = specifications.and(specificationParentCaseNull);
		}

		Page<Case> requestedPage = this.caseRepository.findAll(specification,
				this.filterUtils.constructPageSpecification(screenListFilterVO));

		if (screenListFilterVO.getPageNo() > requestedPage.getTotalPages()) {
			// Reset the page no, if any other filter has been changed.
			screenListFilterVO.setPageNo(1);
			requestedPage = this.caseRepository.findAll(specification,
					this.filterUtils.constructPageSpecification(screenListFilterVO));
		}

		// Pagination Items
		clientCases = requestedPage.getContent();

		// Pagination Values
		screenListFilterVO.setTotalPages(requestedPage.getTotalPages());
		screenListFilterVO.setCurrentRecords(requestedPage.getNumberOfElements());
		screenListFilterVO.setTotalRecords(requestedPage.getTotalElements());

		return clientCases;
	}

	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see com.trivent.service.CaseService#checkClientStatus
	 * 
	 * @DateAndTime : Jun 15, 2018 - 02:24:53 PM
	 * 
	 * @Author : Kavipriyaa
	 * 
	 * @Description : Its to upadte Client status by the latest sub case CS status
	 * 
	 * @Tags :
	 * 
	 * @return childCaseDeatils
	 * 
	 * @throws TriventException
	 * 
	 * @Git_Config : name email
	 * 
	 */

	@Override
	public Case updateClientStausByChildCase(Long caseId) {
		Case parentCaseDeatils = this.getCase(caseId);
		Case childCaseDeatils = new Case();
		final String clientStaus = this.checkClientStatus();
		List<Case> subCaseList = this.caseRepository.findByParentIdOrderBy(caseId);
		if (subCaseList != null) {
			Optional<Case> subCase = subCaseList.stream().filter(new Predicate<Case>() {
				@Override
				public boolean test(Case caseNew) {
					return (!caseNew.getCsStatus().equalsIgnoreCase(clientStaus));
				}
			}).findFirst();
			if (subCase.isPresent()) {
				Case subCaseDetail = subCase.get();
				childCaseDeatils = subCaseDetail;
			} else {
				childCaseDeatils = parentCaseDeatils;
			}
		}
		return childCaseDeatils;
	}

	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see com.trivent.service.CaseService#checkClientStatus
	 * 
	 * @DateAndTime : Jun 15, 2018 - 02:24:53 PM
	 * 
	 * @Author : Kavipriyaa
	 * 
	 * @Description : Its to check the client status from application properties
	 * 
	 * @Tags :
	 * 
	 * @return clientStaus
	 * 
	 * @throws TriventException
	 * 
	 * @Git_Config : name email
	 * 
	 */

	public String checkClientStatus() {
		String clientStaus = "";
		List<String> strConfigDatas = new ArrayList<>();
		strConfigDatas.add(this.applicationProperties
				.getProperty("application.configuration.case.csstatus.clientStatusBasedOnSubCase"));
		List<AppConfigDataVO> appConfigDataVOList = this.appConfigDataService.getAppConfigDataVOList(strConfigDatas);
		List<Long> appItemIds = new ArrayList<>();

		for (final AppConfigDataVO appConfigDataVO : appConfigDataVOList) {
			appItemIds = new ArrayList<>();
			if (appConfigDataVO.getName().equalsIgnoreCase(this.applicationProperties
					.getProperty("application.configuration.case.csstatus.clientStatusBasedOnSubCase"))) {
				if (appConfigDataVO.getDataValue() != null && StringUtils.isNotBlank(appConfigDataVO.getDataValue())
						&& StringUtils.isNotEmpty(appConfigDataVO.getDataValue())) {
					String[] strIds = appConfigDataVO.getDataValue().split(",");
					for (String strId : strIds) {
						if (NumberUtils.isNumber(strId)) {
							appItemIds.add(new Long(strId));
						}
					}
					if (appItemIds.size() > 0) {

						Specification<AppItem> specificationAppItem = null;

						Specifications<AppItem> specificationsAppItem = Specifications
								.where(this.appItemGSpecifications.dataTypeLongList("id", appItemIds));

						specificationAppItem = specificationsAppItem;

						List<AppItem> appItemList = this.appItemRepository.findAll(specificationAppItem);
						for (AppItem appItem : appItemList) {
							clientStaus = appItem.getLongName();
							break;
						}
					}
				} else {
					return clientStaus;
				}

			}
		}

		return clientStaus;
	}

	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.CaseService#statusForFileDeliveredCase
	 * 
	 * @DateAndTime : Jul 18, 2018 - 02:24:53 PM
	 * 
	 * @Author : Kavipriyaa
	 * 
	 * @Description : Its to get account summary based on the status
	 * 
	 * @Tags :
	 * 
	 * @return satus
	 * 
	 * 
	 * @Git_Config : name email
	 * 
	 */
	public List<String> statusForFileDeliveredCase() {
		List<String> csStatus = new ArrayList<>();
		List<String> strConfigDatas = new ArrayList<>();
		strConfigDatas
				.add(this.applicationProperties.getProperty("application.configuration.case.csstatus.accountSummary"));
		List<AppConfigDataVO> appConfigDataVOList = this.appConfigDataService.getAppConfigDataVOList(strConfigDatas);
		List<Long> appItemIds = new ArrayList<>();
		for (final AppConfigDataVO appConfigDataVO : appConfigDataVOList) {
			appItemIds = new ArrayList<>();
			if (appConfigDataVO.getName().equalsIgnoreCase(
					this.applicationProperties.getProperty("application.configuration.case.csstatus.accountSummary"))) {
				if (appConfigDataVO.getDataValue() != null && StringUtils.isNotBlank(appConfigDataVO.getDataValue())
						&& StringUtils.isNotEmpty(appConfigDataVO.getDataValue())) {
					String[] strIds = appConfigDataVO.getDataValue().split(",");
					for (String strId : strIds) {
						if (NumberUtils.isNumber(strId)) {
							appItemIds.add(new Long(strId));
						}
					}
					if (appItemIds.size() > 0) {

						Specification<AppItem> specificationAppItem = null;

						Specifications<AppItem> specificationsAppItem = Specifications
								.where(this.appItemGSpecifications.dataTypeLongList("id", appItemIds));

						specificationAppItem = specificationsAppItem;

						List<AppItem> appItemList = this.appItemRepository.findAll(specificationAppItem);
						for (AppItem appItem : appItemList) {
							csStatus.add(appItem.getLongName());

						}
					}
				} else {
					String defaultStatus = "File Delivery";
					csStatus.add(defaultStatus);
				}
			}
		}
		return csStatus;
	}

	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.CaseService#getAssignedToCaseList(java.lang.String)
	 * 
	 * @DateAndTime : Feb 7, 2018 - 12:26:52 PM
	 * 
	 * @Author : Ramya
	 * 
	 * @Description : Its to get assigned case list
	 * 
	 * @Tags :
	 * 
	 * @param caseIds - get case by caseId
	 * 
	 * @return List - caseList
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override
	@Transactional
	public List<Case> getAssignedToCaseList(String caseIds) {
		String[] arCaseIds = caseIds.split(",");
		List<Case> caseList = new ArrayList<>();
		for (String arCaseId : arCaseIds) {
			Long caseId = Long.parseLong(arCaseId);
			Case appCase = this.getCase(caseId);
			caseList.add(appCase);
		}
		return caseList;
	}

	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.CaseService#getDefaultScreenListFilterVO()
	 * 
	 * @DateAndTime : Feb 7, 2018 - 12:26:53 PM
	 * 
	 * @Author : Ramya
	 * 
	 * @Description : Its to get the default screen list filter
	 * 
	 * @Tags :
	 * 
	 * @return ScreenListFilterVO - call another method
	 * 
	 * @throws TriventException
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override
	@Transactional(readOnly = true)
	public ScreenListFilterVO getDefaultScreenListFilterVO() throws TriventException {
		// AppDBTable appdbTable = this.appDBTableRepository.findByName("Case");
		String screenType = AppConstants.SCREEN_TYPE_LIST;
		return this.filterUtils.populateScreenListFilterVO(new Long(12), screenType);
	}



	@Override
	@Transactional(readOnly = true)
	public CaseDetailsVO getCaseDetailsVO(Long caseId,UserVO userVO) throws TriventException {
		Case appCase = this.getCase(caseId);
		CaseDetailsVO caseDetailsVO = new CaseDetailsVO();
		if (this.checkNewCase(appCase)) {
			caseDetailsVO.setNewCaseRedirect(true);
			caseDetailsVO.setCaseVO(this.getCaseVO(appCase));
			return caseDetailsVO;
		}

		caseDetailsVO.setCaseVO(this.getCaseVO(appCase));
		//caseDetailsVO.setCaseFileVOs(this.caseFileService.getCaseFiles(appCase));
		//caseDetailsVO.setCasesQueriesRowVO(this.caseQueryService.listCasesQueryByCaseId(caseId));
		//caseDetailsVO.setCaseResultFileVOs(this.caseFileService.getCaseResultFiles(appCase));
		/**List<AppAuditLog> appAuditLogVO = this.appAuditLogRepository.getlistAppAuditLogs(appCase.getId(), "Case");
		List<AppAuditLogHistoryVO> appAuditLogHistoryVOs = new ArrayList<>();
		for (AppAuditLog appAuditLog : appAuditLogVO) {
			AppAuditLogHistoryVO appAuditLogHistoryVO = new AppAuditLogHistoryVO(appAuditLog);
			this.appAuditLogDetailRepository.getlistAppAuditLogDetails(appAuditLog);
			appAuditLogHistoryVO
					.setAppAuditLogDetails(this.appAuditLogDetailRepository.getlistAppAuditLogDetails(appAuditLog));
			appAuditLogHistoryVOs.add(appAuditLogHistoryVO);
		}**/

		//caseDetailsVO.setAppAuditlog(appAuditLogHistoryVOs);

		caseDetailsVO.getCaseVO().setproductionCompletePercentage("0");
		caseDetailsVO.getCaseVO().setproductionStatus("-");
		Production production = this.productionService.getProductionByCase(appCase.getId());
		if (production != null) {
			caseDetailsVO.getCaseVO()
					.setproductionCompletePercentage(Integer.toString(production.getCompleteProcess()));
			AppList productionStatusAppList = this.appListRepository.getListByName("Production Status");
			if (productionStatusAppList != null) {
				AppItem appItemname = this.appItemRepository.findOne(production.getProductionStatus());
				if (appItemname != null) {
					caseDetailsVO.getCaseVO().setproductionStatus(appItemname.getLongName());
				}
			}

		}

		User loginUser = this.userService.getCurrentUser(userVO);
		if (loginUser.getRole().getType().equals(Role.ROLE_TYPE_CS_ROLES)) {
			List<CaseLabels> caseLabels = this.caseLabelsRepository.findLabelsByCaseID(caseId, AppConstants.NO);
			String tempCaseLabel = "";
			CaseVO newCaseVO = caseDetailsVO.getCaseVO();
			for (CaseLabels caseLabel : caseLabels) {
				if (tempCaseLabel.equals("")) {
					tempCaseLabel = caseLabel.getAppLabelId().toString();
				} else {
					tempCaseLabel += "," + caseLabel.getAppLabelId().toString();
				}
			}

			newCaseVO.setTitle(tempCaseLabel);
			caseDetailsVO.setCaseVO(newCaseVO);
			caseDetailsVO.setTitle(tempCaseLabel);

		}

		// ClientType
		try {
			List<CaseReportUser> CaseReportUserList = this.caseReportUserService.getCaseReportUser(appCase.getId());
			if (!CaseReportUserList.isEmpty()) {
				for (CaseReportUser CaseReportUserNew : CaseReportUserList) {
					if (CaseReportUserNew.getClientType() != null
							&& StringUtils.isNotBlank(CaseReportUserNew.getClientType().toString())) {
						caseDetailsVO.getCaseVO().setClientType(CaseReportUserNew.getClientType().toString());
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "caseReportUserService.getCaseReportUser", e);
		}

		return caseDetailsVO;
	}
	


	private CaseVO getCaseVO(Case appCase) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	@Transactional(readOnly = true)
	public boolean checkNewCase(Case appCase) {
		// Get all possible csStatus for object type Case
		List<StatusFlowRef> statusFlowRefs = this.cacheService.findByObjType(StatusFlowRef.OBJ_TYPE_CASE,
				AppConstants.NO);
		StatusFlowRef statusFlowRef = statusFlowRefs.get(0);
		if (statusFlowRef.getCustomerSupportStatus().equals(appCase.getCsStatus())) {
			// Redirect to New Case file upload page.
			return true;
		}
		return false;
	}
	

	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.CaseService#getCaseByName(java.lang.String)
	 * 
	 * @DateAndTime : Feb 7, 2018 - 12:26:52 PM
	 * 
	 * @Author : Seetha
	 * 
	 * @Description : Its to get case by name
	 * 
	 * @Tags :
	 * 
	 * @param searchText - search string
	 * 
	 * @return List - caseList
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override
	@Transactional(readOnly = true)
	public List<Case> getCaseByName(String searchText) {

		List<Case> caseList = new ArrayList<>();
		try {

			if (searchText != null && !searchText.isEmpty()) {
				Specification<Case> specification = null;
				Specifications<Case> specifications = Specifications
						.where(this.caseGSpecifications.dataTypeCharacter("deleted", AppConstants.NO));

				specification = this.caseGSpecifications.dataTypeString("name", searchText);
				specifications = specifications.and(specification);

				specification = specifications;
				caseList = this.caseRepository.findAll(specification);
			} else {
				LOGGER.warn(CLASS_NAME, "getCaseByName", "searchText String is empty");
			}

		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "getCaseByName", e);
		} finally {

		}
		return caseList;

	}

	@Override
	public Long UpdateCaseDetailusingProcedure(Long caseId, String action, String columnToUpdate,Long modifiedId,Integer optVersion) {
		Long appCaseID = null;
		try {
			 appCaseID = this.caseRepository.save_cases(
					 caseId,"UPDATE",columnToUpdate,modifiedId,null,null,null,null,null,null,optVersion,null,null,null,null,null,null,
					null,null,null,	null,null,null,null,0,0,0,0,0,0,0,0,null,null,null,null,null,null, 
					null,null,null,	null,null,	null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null, 
					null,null,null,	null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,
					null,null,null,null,null,null,null,null,null,null,null,null);			
		}catch (Exception e) {
			LOGGER.error(CLASS_NAME, "UpdateCaseDetailusingProcedure", e);
		}
		return appCaseID;
	}

	@Override
	public Long inserCaseDetailsUsingProcedure(String Action, Case appCase, UserVO userVO) {
		Long appCaseID = null;
		try {
			/* appCaseID = this.caseRepository.save_cases(
					null,
					"INSERT",
					appCase.getDelayReasons(), 
					new Long(userVO.getId()), 
					new Long(userVO.getId()), 
					appCase.getAccount().getId(), 
					(appCase.getClient()!=null) ? appCase.getClient().getUserProfile().getId() : null, 
					appCase.getName(),
					appCase.getIsFileDownloaded(), 
					appCase.getType(), 
					appCase.getOptLockVersion(), 
					(appCase.getAssignedTo()!=null) ? appCase.getAssignedTo().getUserProfile().getId() : null,
					(appCase.getJob()!=null) ? appCase.getJob().getId() : null,
					(appCase.getParentCase()!=null) ? appCase.getParentCase().getId() : null, 
					appCase.getPageCount(), 
					new Long(appCase.getApprovedHours()), 
					new Long(appCase.getDeviationHours()),
					new Long(appCase.getDiscountHours()), 
					new Long(appCase.getEstimateHours()) , 
					new Long(appCase.getIndirectHours()), 
					new Long(appCase.getInvoiceHours()), 
					new Long(appCase.getProductionHours()),								
					(appCase.getProductionStatus()!=null) ? appCase.getProductionStatus().getId() : 0,
					(appCase.getBalanceDue()!=null) ? appCase.getBalanceDue() : null,
					(appCase.getDepsumPages()!=null) ? appCase.getDepsumPages() : 0, 
					(appCase.getDownloadCount()!=null) ? appCase.getDownloadCount() : 0,
					(appCase.getCf_1_Hours()!=null) ? appCase.getCf_1_Hours() : 0,
				    (appCase.getCf_2_Hours()!=null) ? appCase.getCf_2_Hours() : 0,
				    (appCase.getCf_3_Hours()!=null) ? appCase.getCf_3_Hours() : 0,
				    (appCase.getCf_1_Number()!=null) ? appCase.getCf_1_Number()  : 0,
					(appCase.getCf_2_Number()!=null) ? appCase.getCf_2_Number() : 0, 
					(appCase.getCf_3_Number()!=null) ? appCase.getCf_3_Number() : 0, 
					(appCase.getCf_1_LongText()!=null) ? appCase.getCf_1_LongText() : null , 
					(appCase.getCf_2_LongText()!=null) ? appCase.getCf_2_LongText() : null, 
					(appCase.getCf_3_LongText()!=null) ? appCase.getCf_3_LongText() : null,
					(appCase.getClientPriority()!=null) ? appCase.getClientPriority() : null, 
					(appCase.getClientStatus()!=null) ? appCase.getClientStatus() : null, 
					(appCase.getCsPriority()!=null) ? appCase.getCsPriority() : null, 
					(appCase.getCsStatus()!=null) ? appCase.getCsStatus() : null, 
					"" prefix_case_id,
					(appCase.getSubType()!=null) ? appCase.getSubType() : null , 
					(appCase.getExpeditedDeliveryDate() !=null) ? appCase.getExpeditedDeliveryDate() : nullexpedited_date,
					(appCase.getCaseCode()!=null) ? appCase.getCaseCode()  : null,
					(appCase.getServiceRequestedShortCode()!=null) ? appCase.getServiceRequestedShortCode() : null,
					(appCase.getCf_1_Text()!=null) ? appCase.getCf_1_Text()  : null, 
					(appCase.getCf_2_Text() !=null) ? appCase.getCf_2_Text() : null, 
					(appCase.getCf_3_Text()!=null) ? appCase.getCf_3_Text() : null,
					(appCase.getIsDemand() !=null) ? appCase.getIsDemand().toString() : null, 
					(appCase.getIsCustomerDownload()!=null) ? appCase.getIsCustomerDownload().toString() : null, 
					(appCase.getDeleted()!=null) ? appCase.getDeleted() : 'N',
					(appCase.getExpeditedRequest()!=null) ? appCase.getExpeditedRequest() : null,
					(appCase.getEstimateRequest()!=null) ? appCase.getEstimateRequest() : null,
					(appCase.getBatesReference()!=null) ? appCase.getBatesReference() : null,
					(appCase.getIsInvoiced()!=null) ? appCase.getIsInvoiced() : null,
					(appCase.getPdfReference()!=null) ? appCase.getPdfReference() : null, 
					(appCase.getCf_1_YesNo()!=null) ? appCase.getCf_1_YesNo() : null, 
					(appCase.getCf_2_YesNo()!=null) ? appCase.getCf_2_YesNo() : null ,
					(appCase.getCf_3_YesNo()!=null) ? appCase.getCf_3_YesNo() : null,
					null, 
					null, 
					(appCase.getExpeditedDeliveryDate()!=null) ? new DateTime(appCase.getExpeditedDeliveryDate().getTime()) : null,
					(appCase.getFileDeliveryDate()!=null) ? new DateTime(appCase.getFileDeliveryDate().getTime()) : null,
					(appCase.getFileMigrationDate()!=null) ? new DateTime(appCase.getFileMigrationDate()) : null,
					(appCase.getFileReceivedDate()!=null) ? new DateTime(appCase.getFileReceivedDate()) : null, 
					(appCase.getProdDeliveryDate()!=null) ? new DateTime(appCase.getProdDeliveryDate()) : null, 
					(appCase.getProdEndDate()!=null) ? new DateTime(appCase.getProdEndDate()) : null, 
					(appCase.getProdStartDate()!=null) ? new DateTime(appCase.getProdStartDate()) : null,
					(appCase.getDateOfClarrification()!=null) ? new DateTime(appCase.getDateOfClarrification()) : null,
					(appCase.getEstApprovedDate()!=null) ? new DateTime(appCase.getEstApprovedDate()) : null ,
					(appCase.getEstProvisionDate()!=null) ? new DateTime(appCase.getEstProvisionDate()) : null,
					(appCase.getAddRecordDate()!=null) ? new DateTime(appCase.getAddRecordDate()) : null, 
					(appCase.getCsEstimateSendDate()!=null) ? new DateTime(appCase.getCsEstimateSendDate()) : null ,
					(appCase.getProductionEstimateSendDate()!=null) ? new DateTime(appCase.getProductionEstimateSendDate()) : null,
					(appCase.getEstimateApprovalReceivedDate()!=null) ? new DateTime(appCase.getEstimateApprovalReceivedDate()) : null, 
					(appCase.getRevisedEstiamteSendDate()!=null) ? new DateTime(appCase.getRevisedEstiamteSendDate()) : null, 
					(appCase.getCsDeliveryDate()!=null) ? new DateTime(appCase.getCsDeliveryDate()) : null,
					(appCase.getDownloadedDateTime()!=null) ? new DateTime(appCase.getDownloadedDateTime()) : null,
					(appCase.getCf_1_Date()!=null) ? new DateTime(appCase.getCf_1_Date()) : null , 
					(appCase.getCf_2_Date()!=null) ? new DateTime(appCase.getCf_2_Date()) : null ,
					(appCase.getCf_3_Date()!=null) ? new DateTime(appCase.getCf_3_Date()) : null ,
					(appCase.getCf_4_Date()!=null) ? new DateTime(appCase.getCf_4_Date()) : null ,
					(appCase.getCf_5_Date()!=null) ? new DateTime(appCase.getCf_5_Date()) : null ,
					(appCase.getCf_6_Date()!=null) ? new DateTime(appCase.getCf_6_Date()) : null ,
					(appCase.getCf_7_Date()!=null) ? new DateTime(appCase.getCf_7_Date()) : null ,
					(appCase.getCf_8_Date()!=null) ? new DateTime(appCase.getCf_8_Date()) : null ,
				    (appCase.getCaseOverview()!=null) ? appCase.getCaseOverview() : null, 
				    (appCase.getClientNotes()!=null) ? appCase.getClientNotes() : null,
					(appCase.getCsNotes()!=null) ? appCase.getCsNotes() : null,
					(appCase.getExpeditedRequestReason()!=null) ? appCase.getExpeditedRequestReason() : null,
					(appCase.getEmailId()!=null) ? appCase.getEmailId() : null,
					(appCase.getContactName()!=null) ? appCase.getContactName() : null, 
					(appCase.getDescription()!=null) ? appCase.getDescription() : null);*/		
			 		System.out.println("appCaseID"+appCaseID);
		}catch(Exception e){
			LOGGER.error(CLASS_NAME, "inserCaseDetailsUsingProcedure", e);
		}
		return null;
	}

	
	@Override
	@Transactional
	public List<AppItemVO> getCaseType(HttpServletRequest request) {
		List<AppItem> appItemL = new ArrayList<AppItem>();
		List<AppItemVO> appItemVOlist = new ArrayList<AppItemVO>();
		try {
			AppList caseTypeList = this.cacheService.findByAppListName(AppList.CASE_TYPES);
			appItemL = this.cacheService.findByListId(caseTypeList.getId());
			appItemL.forEach(appItems -> {
				AppItemVO appItemVO = new AppItemVO();
				appItemVO.setId(appItems.getId());
				appItemVO.setLongName(appItems.getLongName());
				appItemVOlist.add(appItemVO);
			});
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "getCaseType", e);
		}
		return appItemVOlist;
	}

	@Override
	@Transactional
	public List<AppSubItemVO> getCaseSubType(HttpServletRequest request, Long caseTypeId) {
		List<AppSubItem> caseSubTypeItems = new ArrayList<AppSubItem>();
		List<AppSubItemVO> appSubItemVOlist = new ArrayList<AppSubItemVO>();
		try {
			caseSubTypeItems = this.cacheService.findByItemId(caseTypeId);
			caseSubTypeItems.forEach(appSubItems -> {
				AppSubItemVO appSubItemVO = new AppSubItemVO();
				appSubItemVO.setId(appSubItems.getId());
				appSubItemVO.setLongName(appSubItems.getLongName());
				appSubItemVOlist.add(appSubItemVO);
			});
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "getCaseSubType", e);
		}
		return appSubItemVOlist;
	}

	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.CaseService#sendAssignedToEmailAlert(com.trivent.entity.
	 * User, com.trivent.entity.Case, com.trivent.entity.CaseTask,
	 * com.trivent.entity.CaseQuery, java.lang.String)
	 * 
	 * @DateAndTime : Feb 7, 2018 - 12:26:53 PM
	 * 
	 * @Author : Ramya
	 * 
	 * @Description : Its to send email alert for assigned User
	 * 
	 * @Tags :
	 * 
	 * @param assignedUser - send by using assignedUser
	 * 
	 * @param appCase - send by using appCase
	 * 
	 * @param caseTsk - send by using caseTask
	 * 
	 * @param caseQry - send by using caseQry
	 * 
	 * @param assignedToType - send by using assignedToType
	 * 
	 * @Git_Config : name email
	 * 
	 */
	public void sendAssignedToEmailAlert(User assignedUser, Case appCase, CaseTask caseTsk, CaseQuery caseQry,
			String assignedToType, UserVO userVO) {
		User loginUser = this.userService.getCurrentUser(userVO);
		loginUser = this.userRepository.findCustomerById(loginUser.getId());
		if (assignedUser != null && assignedUser.getId() != null) {
			assignedUser = this.userRepository.findCustomerById(assignedUser.getId());
		}
		if (appCase != null && appCase.getId() != null) {
			appCase = this.getCase(appCase.getId());
		}
		if (caseTsk != null && caseTsk.getId() != null) {
			caseTsk = this.caseTaskRepository.findAllByTaskId(caseTsk.getId());
		}

		if (StringUtils.equalsIgnoreCase(assignedToType, "case")) {
			User client = appCase.getClient();
			EmailTemplate assignedCaseTemplate = this.emailTemplateService.findEmailTemplateByCode(
					this.applicationProperties.getProperty(AppConstants.assignedToTemplateCodeForCase), "");
			if ((assignedCaseTemplate == null) || (assignedCaseTemplate.getCreatedDate() == null)) {
				LOGGER.debug(CLASS_NAME, "sendAssignedToEmailAlert", "Assigned email template not configured.");
				return;
			} else {
				String toEmailIds = assignedUser.getLoginId();
				if (StringUtils.isNotBlank(assignedCaseTemplate.getIntEmailToList())
						&& StringUtils.isNotEmpty(assignedCaseTemplate.getIntEmailToList())) {
					toEmailIds = toEmailIds + "," + assignedCaseTemplate.getIntEmailToList();
				}
				String ccEmailIds = assignedCaseTemplate.getIntEmailCcList();
				String messageSubject = assignedCaseTemplate.getSubject();
				String messageBody = assignedCaseTemplate.getMessage();
				String bccEmailIds = assignedCaseTemplate.getIntEmailBccList();

				// Values to replace in email template
				Map<String, Object> emailValueMap = new HashMap<>();
				if (appCase != null) {
					if (appCase.getAccount() != null) {
						emailValueMap.put("ACCOUNT_CODE", appCase.getAccount().getAccountCode());
					} else {
						emailValueMap.put("ACCOUNT_CODE", "");
					}
					emailValueMap.put("CASE_NAME", appCase.getName());
				}
				if (assignedUser.getRole().getType().equalsIgnoreCase(Role.ROLE_CUSTOMER)) {
					emailValueMap.put("CLIENT_NAME", assignedUser.getUserProfile().getFirstName());
				} else {
					emailValueMap.put("CLIENT_NAME", assignedUser.getUserProfile().getFirstName() + " "
							+ assignedUser.getUserProfile().getLastName());
				}
				emailValueMap.put("LOGIN_NAME",
						loginUser.getUserProfile().getFirstName() + " " + loginUser.getUserProfile().getLastName());
				// Partner Signature in Email - Start
				emailValueMap.put("LOGIN_NAME",
						loginUser.getUserProfile().getFirstName() + " " + loginUser.getUserProfile().getLastName());
				emailValueMap.put("PARTNER_NAME", client.getAccount().getPartner().getName());
				emailValueMap.put("PARTNER_ADDRESS",
						client.getAccount().getPartner().getAddress1() + ", "
								+ client.getAccount().getPartner().getAddress2() + ", "
								+ client.getAccount().getPartner().getCity() + ", "
								+ client.getAccount().getPartner().getState() + ", "
								+ client.getAccount().getPartner().getZipCode());
				emailValueMap.put("PARTNER_EMAIL", client.getAccount().getPartner().getEmail());
				String clientPartnerCode = this.emailInternalTo;
				// Partner Signature in Email - End

				EmailQueue emailQueue = new EmailQueue(toEmailIds, ccEmailIds, messageSubject, messageBody);
				emailQueue.populate(assignedUser, appCase.getAccount(), appCase, emailValueMap);
				if (!StringUtils.isEmpty(bccEmailIds)) {
					emailQueue.setBccEmailIds(bccEmailIds);
				}
				emailQueue.setEmailOutBeanPrefix(this.emailInternalTo);
				emailQueue.setEmailOutBeanPrefix(clientPartnerCode);
				if (this.appConfigService.getCustomerMailPermission(emailQueue, AppConstants.APP_CONFIG_CASE_MAIL,
						userVO)) // Added
				// for Customer mail send configuration on 17 June 2017
				{
					this.emailService.queueEmail(emailQueue, userVO);
				}

			}
		} else if (StringUtils.equalsIgnoreCase(assignedToType, "caseTask")) {
			// List<EmailTemplate> assignedCaseTemplate = this.templateRepository
			// .findByCode(this.applicationProperties.getProperty(AppConstants.assignedToTemplateCodeForCaseTask));
			EmailTemplate assignedCaseTemplate = this.emailTemplateService.findEmailTemplateByCode(
					this.applicationProperties.getProperty(AppConstants.assignedToTemplateCodeForCaseTask),
					caseTsk.getPartnerCode());
			if ((assignedCaseTemplate == null)) {
				LOGGER.debug(CLASS_NAME, METHOD_SAVE_CASE, "Assigned email template not configured.");
				return;
			} else {
				String toEmailIds = assignedUser.getLoginId();
				if (StringUtils.isNotBlank(assignedCaseTemplate.getIntEmailToList())
						&& StringUtils.isNotEmpty(assignedCaseTemplate.getIntEmailToList())) {
					toEmailIds = toEmailIds + "," + assignedCaseTemplate.getIntEmailToList();
				}
				String ccEmailIds = assignedCaseTemplate.getIntEmailCcList();
				String messageSubject = assignedCaseTemplate.getSubject();
				String messageBody = assignedCaseTemplate.getMessage();
				String bccEmailIds = assignedCaseTemplate.getIntEmailBccList();

				// Values to replace in email template
				Map<String, Object> emailValueMap = new HashMap<>();

				if (appCase != null && appCase.getAccount() != null)
					emailValueMap.put("ACCOUNT_CODE", appCase.getAccount().getAccountCode());
				else if (caseQry != null && caseTsk.getAccount() != null)
					emailValueMap.put("ACCOUNT_CODE", caseTsk.getAccount().getAccountCode());
				else
					emailValueMap.put("ACCOUNT_CODE", "");
				if (appCase != null)
					emailValueMap.put("CASE_NAME", appCase.getName());
				else
					emailValueMap.put("CASE_NAME", "");

				emailValueMap.put("CASE_TASK", caseTsk.getName());
				if (assignedUser.getRole().getType().equalsIgnoreCase(Role.ROLE_CUSTOMER)) {
					emailValueMap.put("CLIENT_NAME", assignedUser.getUserProfile().getFirstName());
				} else {
					emailValueMap.put("CLIENT_NAME", assignedUser.getUserProfile().getFirstName() + " "
							+ assignedUser.getUserProfile().getLastName());
				}
				emailValueMap.put("LOGIN_NAME",
						loginUser.getUserProfile().getFirstName() + " " + loginUser.getUserProfile().getLastName());
				String clientPartnerCode = this.emailInternalTo;
				// Partner Signature in Email - End

				EmailQueue emailQueue = new EmailQueue(toEmailIds, ccEmailIds, messageSubject, messageBody);
				emailQueue.populate(assignedUser, assignedUser.getAccount(), appCase, emailValueMap);
				emailQueue.setEmailOutBeanPrefix(clientPartnerCode);
				if (!StringUtils.isEmpty(bccEmailIds)) {
					emailQueue.setBccEmailIds(bccEmailIds);
				}
				if (this.appConfigService.getCustomerMailPermission(emailQueue, AppConstants.APP_CONFIG_OTHER_MAIL,
						userVO)) // Added
				// for Customer mail send configuration on 17 June 2017
				{
					this.emailService.queueEmail(emailQueue, userVO);
				}
			}
		} else if (StringUtils.equalsIgnoreCase(assignedToType, "caseQuery")) {
			// List<EmailTemplate> assignedCaseTemplate =
			// this.templateRepository.findByCode(
			// this.applicationProperties.getProperty(AppConstants.assignedToTemplateCodeForCaseQuery));
			// String lsPartnerCode = appCase.getAccount().getPartner().getPartnerCode();
			String lsPartnerCode = "";
			if (appCase == null) {
				if (StringUtils.isNotEmpty(caseQry.getQuerySubject())
						&& StringUtils.isNotBlank(caseQry.getQuerySubject())) {
					lsPartnerCode = caseQry.getQuerySubject().substring(1, 3);
				}
				// lsPartnerCode = caseQry.getAccount().getPartner().getPartnerCode();
			} else {
				lsPartnerCode = appCase.getAccount().getPartner().getPartnerCode();
			}
			EmailTemplate assignedCaseTemplate = this.emailTemplateService.findEmailTemplateByCode(
					this.applicationProperties.getProperty(AppConstants.assignedToTemplateCodeForCaseQuery),
					lsPartnerCode);
			if ((assignedCaseTemplate == null)) {
				LOGGER.debug(CLASS_NAME, "", "Assigned email template not configured.");
				return;
			} else {
				String toEmailIds = assignedUser.getLoginId();
				if (StringUtils.isNotBlank(assignedCaseTemplate.getIntEmailToList())
						&& StringUtils.isNotEmpty(assignedCaseTemplate.getIntEmailToList())) {
					toEmailIds = toEmailIds + "," + assignedCaseTemplate.getIntEmailToList();
				}
				String ccEmailIds = assignedCaseTemplate.getIntEmailCcList();
				String messageSubject = assignedCaseTemplate.getSubject();
				String messageBody = assignedCaseTemplate.getMessage();
				String bccEmailIds = assignedCaseTemplate.getIntEmailBccList();

				// Values to replace in email template
				Map<String, Object> emailValueMap = new HashMap<>();
				// emailValueMap.put("ACCOUNT_CODE", appCase.getAccount().getAccountCode());
				// emailValueMap.put("CASE_NAME", appCase.getName());

				if (appCase != null && appCase.getAccount() != null)
					emailValueMap.put("ACCOUNT_CODE", appCase.getAccount().getAccountCode());
				else if (caseQry != null && caseQry.getAccount() != null)
					emailValueMap.put("ACCOUNT_CODE", caseQry.getAccount().getAccountCode());
				else
					emailValueMap.put("ACCOUNT_CODE", "");
				if (appCase != null)
					emailValueMap.put("CASE_NAME", appCase.getName());
				else
					emailValueMap.put("CASE_NAME", "");

				emailValueMap.put("CASE_QUERY_SUBJECT", caseQry.getQuerySubject());
				if (assignedUser.getRole().getType().equalsIgnoreCase(Role.ROLE_CUSTOMER)) {
					emailValueMap.put("CLIENT_NAME", assignedUser.getUserProfile().getFirstName());
				} else {
					emailValueMap.put("CLIENT_NAME", assignedUser.getUserProfile().getFirstName() + " "
							+ assignedUser.getUserProfile().getLastName());
				}

				emailValueMap.put("LOGIN_NAME",
						loginUser.getUserProfile().getFirstName() + " " + loginUser.getUserProfile().getLastName());
				// Partner Signature in Email - Start
				String clientPartnerCode = this.emailInternalTo;
				// Partner Signature in Email - End
				EmailQueue emailQueue = new EmailQueue(toEmailIds, ccEmailIds, messageSubject, messageBody);
				emailQueue.populate(assignedUser, assignedUser.getAccount(), appCase, emailValueMap);
				emailQueue.setEmailOutBeanPrefix(clientPartnerCode);
				if (!StringUtils.isEmpty(bccEmailIds)) {
					emailQueue.setBccEmailIds(bccEmailIds);
				}
				if (this.appConfigService.getCustomerMailPermission(emailQueue, AppConstants.APP_CONFIG_QUERY_MAIL,
						userVO)) // Added
				// for Customer mail send configuration on 17 June 2017
				{
					this.emailService.queueEmail(emailQueue, userVO);
				}
			}
		}
	}

	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.CaseService#getCaseListByCaseIds(java.util.List)
	 * 
	 * @DateAndTime : Feb 7, 2018 - 12:26:52 PM
	 * 
	 * @Author : Ramya
	 * 
	 * @Description : Its to get case List by case Id
	 * 
	 * @Tags :
	 * 
	 * @param strCaseIds - get case by strCaseIds
	 * 
	 * @return List - caseList
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override
	@Transactional(readOnly = true)
	public List<Case> getCaseListByCaseIds(List<Long> strCaseIds) {

		List<Case> caseList = new ArrayList<>();
		try {

			if (strCaseIds.size() > 0) {
				Specification<Case> specification = null;
				Specifications<Case> specifications = Specifications
						.where(this.caseGSpecifications.dataTypeCharacter("deleted", AppConstants.NO));
				specification = this.caseGSpecifications.dataTypeLongList("id", strCaseIds);
				specifications = specifications.and(specification);
				specification = specifications;
				caseList = this.caseRepository.findAll(specification);
			} else {
				LOGGER.warn(CLASS_NAME, "getUserListByCaseIds", "strCaseIds size is 0 or empty");
			}

		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "getUserListByCaseIds", e);
		} finally {

		}
		return caseList;

	}

	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.CaseService#getCaseContactsByCase(java.util.List)
	 * 
	 * @DateAndTime : Feb 7, 2018 - 12:26:52 PM
	 * 
	 * @Author : Ramya
	 * 
	 * @Description : Its to get caseContacts by cases
	 * 
	 * @Tags :
	 * 
	 * @param caseList - get case contacts by caseList
	 * 
	 * @return List - caseContactsList
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override
	@Transactional(readOnly = true)
	public List<CaseContacts> getCaseContactsByCase(List<Case> caseList) {

		List<CaseContacts> caseContactsList = new ArrayList<>();
		try {

			if ((caseList != null) && (caseList.size() > 0)) {

				Specification<CaseContacts> specification = null;
				Specifications<CaseContacts> specifications = Specifications
						.where(this.caseContactsGSpecifications.dataTypeCharacter("deleted", AppConstants.NO));
				specification = this.caseContactsGSpecifications.dataTypeCaseList("caseId", caseList);
				specifications = specifications.and(specification);
				specification = specifications;

				caseContactsList = this.caseContactsRepository.findAll(specification);

			} else {
				LOGGER.warn(CLASS_NAME, "getCaseContactsByCase", "caseList size 0 or caseList is empty");
			}

		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "getCaseContactsByCase", e);
		} finally {

		}
		return caseContactsList;

	}

	@Override
	@Transactional
	public List<Case> findCasesListFromHeader(String psString, UserVO userVO) throws ParseException {
		List<Case> caseList = new ArrayList<>();
		ScreenListFilterVO screenListFilterVO = new ScreenListFilterVO();

		List<AppUIScreenFilterVO> appUIScreenFilterVOList = new ArrayList<>();
		AppUIScreenFilterVO appUIScreenFilterVO = new AppUIScreenFilterVO();
		appUIScreenFilterVO.setValue(Character.toString(AppConstants.NO));
		appUIScreenFilterVO.setDbFieldName("deleted");
		appUIScreenFilterVO.setFilterDataType("Character");
		appUIScreenFilterVOList.add(appUIScreenFilterVO);
		appUIScreenFilterVO = new AppUIScreenFilterVO();
		appUIScreenFilterVO.setValue(psString);
		appUIScreenFilterVO.setDbFieldName("name");
		appUIScreenFilterVO.setFilterDataType("String");
		appUIScreenFilterVOList.add(appUIScreenFilterVO);
		screenListFilterVO.setAppUIScreenFilterVOs(appUIScreenFilterVOList);
		User loginUser = userRepository.findOne(userVO.getId());
		if (!loginUser.getType().equals(AppConstants.TYPE_CLIENT)) {
			screenListFilterVO.setSelectedViewType(AppUIScreenView.VIEW_ALL);
		} else {
			screenListFilterVO.setSelectedViewType(AppUIScreenView.VIEW_CLIENT);
		}
		try {
			caseList = this.getCaseList(screenListFilterVO, null, null, null, null, null, null, userVO);
		} catch (TriventException e) {
			caseList = new ArrayList<>();
		}

		return caseList;

	}
	
	@Override
	@Transactional(readOnly = true)
	public List<DropDownVO> getCommunicationSubType(HttpServletRequest request,String queryItemId) {
		List<DropDownVO> listNew = new ArrayList<>();
		try {
			if (StringUtils.isNotBlank(queryItemId) && StringUtils.isNotEmpty(queryItemId)) {
				String queryItem_Id[] = queryItemId.split(",");
				for (String itemId : queryItem_Id) {
					if (itemId != null && StringUtils.isNotEmpty(itemId) && !itemId.equalsIgnoreCase("null")
							&& !itemId.equalsIgnoreCase("undefined")) {
						List<AppSubItem> appSubITems = this.appSubItemRepository.FindSubITems(Long.parseLong(itemId));
						if (appSubITems.size() > 0) {
							for (AppSubItem queryCommTypeItem : appSubITems) {
								DropDownVO dropDownVO= new DropDownVO();
								dropDownVO.setText(queryCommTypeItem.getLongName());
								dropDownVO.setValue(queryCommTypeItem.getId());
								listNew.add(dropDownVO);								
							}
						}
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "getQuerySubTypes", e);
		}
		return listNew;
	}
	@Override
	@Transactional
	public List<DropDownVO> getAppLabelNames() {
		List<DropDownVO> listNew = new ArrayList<>();
		try {
		List<AppLabels> tempLabelNames = this.appLabelsRepository.findLabelNames(AppConstants.NO);
		if(tempLabelNames.size()>0) {
		tempLabelNames.forEach(u->{
			DropDownVO dropDownVO= new DropDownVO();
			dropDownVO.setText(u.getTitle());
			dropDownVO.setValue(u.getId());
			listNew.add(dropDownVO);
	        });
		}
	} catch (Exception e) {
		LOGGER.error(CLASS_NAME, "Method : getAppLabelNames", e.getMessage());
	}
		return listNew;
	}

	@Override
	public List<DropDownVO> getClientType() {
		List<DropDownVO> listNew = new ArrayList<>();
		try {
		AppList appList = this.appListRepository.findByName("Client Type");
		List<AppItem> appItems = this.appItemRepository.findByListName(appList.getId());
		if(appItems.size()>0) {
			appItems.forEach(u->{
				DropDownVO dropDownVO= new DropDownVO();
				dropDownVO.setText(u.getLongName());
				dropDownVO.setValue(u.getId());
				listNew.add(dropDownVO);
		});
		}
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "Method : getClientType", e.getMessage());
		}
		return listNew;
	}

}