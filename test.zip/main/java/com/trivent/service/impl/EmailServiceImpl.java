package com.trivent.service.impl;

import java.io.StringWriter;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

import com.trivent.constants.AppConstants;
import com.trivent.dto.UserVO;
import com.trivent.logging.LogManager;
import com.trivent.logging.Logger;
import com.trivent.models.Case;
import com.trivent.models.Contact;
import com.trivent.models.EmailQueue;
import com.trivent.models.Role;
import com.trivent.models.User;
import com.trivent.models.UserProfile;
import com.trivent.repository.ContactRepository;
import com.trivent.repository.UserProfileRepository;
import com.trivent.repository.UserRepository;
import com.trivent.service.CacheService;
import com.trivent.service.EmailQueueService;
import com.trivent.service.EmailService;
import com.trivent.service.UserService;
import com.trivent.utils.CommonUtils;

/**
 * @FileName : EmailServiceImpl.java
 * @ClassName : EmailServiceImpl
 * @DateAndTime : Feb 6, 2018 - 3:49:34 PM
 * 
 * @Author : Ramya
 * 
 * @Description : Its to list the case Queries,send email,save email
 * @Tags :
 * @Git_Config : name email
 * 
 */
/**
 * @author Ramya
 *
 */
@Service
public class EmailServiceImpl implements EmailService {

	private static final Logger LOGGER = LogManager.getLogger();

	private static final String CLASS_NAME = EmailServiceImpl.class.getName();

	@SuppressWarnings("unused")
	private static final String METHOD_SEND_MAIL = "sendEmail";

	private static final String METHOD_QUEUE_MAIL = "queueEmail";

	@Autowired
	private EmailQueueService emailQueueService;

	@Autowired
	private CacheService cacheService;

	/*@Value("${jms.queue.emails}")
	private String emailQueueDestination;*/

	@Value("${email.save.to.this.location}")
	private String emailSaveLoc;

	@SuppressWarnings("unused")
	@Autowired
	private JmsTemplate jmsTemplate;

	// @Value("${email.from}")
	// private String emailFrom;

	@Autowired
	private ContactRepository contactsRepository;

	@Autowired
	private UserService userService;

	@Value("${email.internal.employee.code}")
	private String emailInternalTo;

	@Autowired
	private UserProfileRepository userProfileRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private EmailService emailService;

	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.EmailService#queueEmail(com.trivent.entity.EmailQueue)
	 * 
	 * @DateAndTime : Feb 6, 2018 - 3:49:34 PM
	 * 
	 * @Author : Ramya
	 * 
	 * @Description : Its to Merge data and template in email queue
	 * 
	 * @Tags :
	 * 
	 * @param emailQueue - subject and body send as parameter in email Queue
	 * 
	 * @return EmailQueue - updatedEmailQueue
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override
	public EmailQueue queueEmail(EmailQueue emailQueue,UserVO userVO) {
		this.emailService.inactiveClientsEmailNotifications(emailQueue);
		/**
		 * Merge data and template
		 */
		String NoEmail = "False";
		String to = "False";
		String Cc = "False";
		String Bcc = "False";
		String to1 = "False";
		String Cc1 = "False";
		String contactname = "False";
		VelocityContext context = new VelocityContext();

		for (Entry<String, Object> entry : emailQueue.getModelMap().entrySet()) {

			if (entry.getKey().equalsIgnoreCase("CLIENT_NAME")) {
				Case appCase = emailQueue.getAppCase();
				if (appCase != null) {
					if (!emailQueue.getAppCase().getClient().getStatus().equals(AppConstants.IN_ACTIVE_USERS)) {

					}
				}
				if (appCase != null) {
					if (emailQueue.getAppCase().getClient().getStatus().equals(AppConstants.IN_ACTIVE_USERS)) {
						String contactemail = emailQueue.getAppCase().getContactName();
						if (!contactemail.equals(null)) {
							contactemail = contactemail.replace(',', ';');
							String mailIdsList[] = contactemail.split(";");
							for (String mailId : mailIdsList) {
								entry.setValue(mailId);
								contactname = "True";
								if (entry.getValue() != null) {
									break;
								}
							}
						}
					}
				}

				if (appCase == null) {
					if (contactname.equals("False")) {
						String mailIds3 = emailQueue.getToEmailIds();
						if (mailIds3 != null && mailIds3 != "null" && !mailIds3.equals("")) {
							mailIds3 = mailIds3.replace(',', ';');
							String mailIdsList3[] = mailIds3.split(";");
							UserProfile userProfile = new UserProfile();
							for (String mailId : mailIdsList3) {
								User user = this.userRepository.findByLoginId(mailId);
								if (user != null) {
									if (user.getType().equalsIgnoreCase(User.USER_TYPE_CLIENT)
											&& (user.getStatus() != AppConstants.IN_ACTIVE_USERS)) {
										if (user != null) {
											userProfile = userProfileRepository.getProfileByUserID(user.getId());
											if (userProfile != null && userProfile.getId() != null) {
												entry.setValue(userProfile.getFirstName());
												to = "True";
												if (entry.getValue() != null) {
													break;
												}
											}

										}
									}
								}
							}

						}
					} else if (to.equals("False")) {
						String mailIds4 = emailQueue.getCcEmailIds();
						if (mailIds4 != null && mailIds4 != "null" && !mailIds4.equals("")) {
							mailIds4 = mailIds4.replace(',', ';');
							String mailIdsList4[] = mailIds4.split(";");
							UserProfile userProfile1 = new UserProfile();
							for (String mailId1 : mailIdsList4) {
								User user1 = this.userRepository.findByLoginId(mailId1);
								if (user1 != null) {
									if (user1.getType().equalsIgnoreCase(User.USER_TYPE_CLIENT)
											&& (user1.getStatus() != AppConstants.IN_ACTIVE_USERS)) {
										if (user1 != null) {
											userProfile1 = userProfileRepository.getProfileByUserID(user1.getId());
											if (userProfile1 != null && userProfile1.getId() != null) {
												entry.setValue(userProfile1.getFirstName());
												Cc = "True";
												if (entry.getValue() != null) {
													break;
												}
											}
										}

									}
								}

							}
						}

					} else if (to.equals("False") && Cc.equals("False")) {
						String mailIds4 = emailQueue.getBccEmailIds();
						if (mailIds4 != null && mailIds4 != "null" && !mailIds4.equals("")) {
							mailIds4 = mailIds4.replace(',', ';');
							String mailIdsList4[] = mailIds4.split(";");
							UserProfile userProfile1 = new UserProfile();
							for (String mailId1 : mailIdsList4) {
								User user1 = this.userRepository.findByLoginId(mailId1);
								if (user1 != null) {
									if (user1.getType().equalsIgnoreCase(User.USER_TYPE_CLIENT)
											&& (user1.getStatus() != AppConstants.IN_ACTIVE_USERS)) {
										if (user1 != null) {
											userProfile1 = userProfileRepository.getProfileByUserID(user1.getId());
											if (userProfile1 != null && userProfile1.getId() != null) {
												entry.setValue(userProfile1.getFirstName());
												Bcc = "True";
												if (entry.getValue() != null) {
													break;
												}
											}
										}
									}
								}
							}
						}

					} else if (to.equals("False") && Cc.equals("False") && Bcc.equals("False")) {
						String mailIds4 = emailQueue.getToEmailIds();
						if (mailIds4 != null && mailIds4 != "null" && !mailIds4.equals("")) {
							mailIds4 = mailIds4.replace(',', ';');
							String mailIdsList4[] = mailIds4.split(";");
							UserProfile userProfile1 = new UserProfile();
							for (String mailId1 : mailIdsList4) {
								User user1 = this.userRepository.findByLoginId(mailId1);
								if (user1 != null) {
									if (user1.getType().equalsIgnoreCase(User.USER_TYPE_TRIVENT)
											&& (user1.getStatus() != AppConstants.IN_ACTIVE_USERS)) {
										if (user1 != null) {
											userProfile1 = userProfileRepository.getProfileByUserID(user1.getId());
											if (userProfile1 != null && userProfile1.getId() != null) {
												entry.setValue(CommonUtils.getFullDisplayName(userProfile1));
												to1 = "True";
												if (entry.getValue() != null) {
													break;
												}
											}
										}
									}
								} else if (user1 == null) {
									Contact contact = this.contactsRepository
											.getContactbyEmailfornonportaluser(mailId1);
									if (contact != null) {
										String firstName = contact.getFirstName();
										String lastName = contact.getLastName();
										entry.setValue(firstName + " " + lastName);
										to1 = "True";
										if (entry.getValue() != null) {
											break;
										}
									}
								}
							}
						}
					} else if (to.equals("False") && Cc.equals("False") && Bcc.equals("False") && to1.equals("False")) {
						String mailIds4 = emailQueue.getCcEmailIds();
						if (mailIds4 != null && mailIds4 != "null" && !mailIds4.equals("")) {
							mailIds4 = mailIds4.replace(',', ';');
							String mailIdsList4[] = mailIds4.split(";");
							UserProfile userProfile1 = new UserProfile();
							for (String mailId1 : mailIdsList4) {
								User user1 = this.userRepository.findByLoginId(mailId1);
								if (user1 != null) {
									if (user1.getType().equalsIgnoreCase(User.USER_TYPE_TRIVENT)
											&& (user1.getStatus() != AppConstants.IN_ACTIVE_USERS)) {
										if (user1 != null) {
											userProfile1 = userProfileRepository.getProfileByUserID(user1.getId());
											if (userProfile1 != null && userProfile1.getId() != null) {
												entry.setValue(CommonUtils.getFullDisplayName(userProfile1));
												Cc1 = "True";
												if (entry.getValue() != null) {
													break;
												}
											}
										}
									}
								} else if (user1 == null) {
									Contact contact = this.contactsRepository
											.getContactbyEmailfornonportaluser(mailId1);
									if (contact != null) {
										String firstName = contact.getFirstName();
										String lastName = contact.getLastName();
										entry.setValue(firstName + " " + lastName);
										Cc1 = "True";
										if (entry.getValue() != null) {
											break;
										}
									}
								}
							}
						}
					} else if (to.equals("False") && Cc.equals("False") && Bcc.equals("False") && to1.equals("False")
							&& Cc1.equals("False")) {
						String mailIds4 = emailQueue.getBccEmailIds();
						if (mailIds4 != null && mailIds4 != "null" && !mailIds4.equals("")) {
							mailIds4 = mailIds4.replace(',', ';');
							String mailIdsList4[] = mailIds4.split(";");
							UserProfile userProfile1 = new UserProfile();
							for (String mailId1 : mailIdsList4) {
								User user1 = this.userRepository.findByLoginId(mailId1);
								if (user1 != null) {
									if (user1.getType().equalsIgnoreCase(User.USER_TYPE_TRIVENT)
											&& (user1.getStatus() != AppConstants.IN_ACTIVE_USERS)) {
										if (user1 != null) {
											userProfile1 = userProfileRepository.getProfileByUserID(user1.getId());
											if (userProfile1 != null && userProfile1.getId() != null) {
												entry.setValue(CommonUtils.getFullDisplayName(userProfile1));
												if (entry.getValue() != null) {
													break;
												}
											}
										}
									}
								} else if (user1 == null) {
									Contact contact = this.contactsRepository
											.getContactbyEmailfornonportaluser(mailId1);
									if (contact != null) {
										String firstName = contact.getFirstName();
										String lastName = contact.getLastName();
										entry.setValue(firstName + " " + lastName);
										Cc1 = "True";
										if (entry.getValue() != null) {
											break;
										}
									}
								}
							}
						}
					} else {
						entry.setValue("");
						NoEmail = "True";
					}

				}
			}

			else if (entry.getKey().equalsIgnoreCase("USER_NAME") || entry.getKey().equalsIgnoreCase("USER")) {
				String[] entryValue = entry.getValue().toString().split(",");
				if (entryValue.length > 0) {
					String entrySize = entryValue[0].toString();
					User mailUser = userService.getUserByMail(entrySize);
					UserProfile userProfile = new UserProfile();
					if (mailUser != null) {
						userProfile = userProfileRepository.getProfileByUserID(mailUser.getId());
					}
					if (userProfile != null && userProfile.getId() != null) {
						entry.setValue(CommonUtils.getFullDisplayName(userProfile));
					} else {
						Contact contact = this.contactsRepository.getContactbyEmailfornonportaluser(entrySize);
						if (contact != null) {
							String firstName = contact.getFirstName();
							String lastName = contact.getLastName();
							entry.setValue(firstName + " " + lastName);
						}

					}

				}
			}
			context.put(entry.getKey(), entry.getValue());
		}

		StringWriter stringWriter = new StringWriter();
		Velocity.evaluate(context, stringWriter, "TriventLog", emailQueue.getSubject());
		String subject = stringWriter.toString();

		stringWriter = new StringWriter();
		Velocity.evaluate(context, stringWriter, "TriventLog", emailQueue.getBody());
		String message = stringWriter.toString();

		// Update the values in email queue
		if (StringUtils.isNotBlank(subject) && StringUtils.isNotEmpty(subject)) {
			emailQueue.setSubject(CommonUtils.uniCodeToString(subject));
		}
		emailQueue.setBody(message);

		// Save EmailQueue and send it to the Queue. Queue Messages are read
		// only, hence we can't store the primary key
		// for retry attempts.
		User loginUser = this.userService.getCurrentUser(userVO);
		if (loginUser == null) {
			// Email Queue will be triggered from forgot password, etc., where
			// no logged in session.
			Role role = this.cacheService.findByRole(Role.ROLE_SUPER_ADMIN);
			@SuppressWarnings("unused")
			User adminUser = this.cacheService.findAdminUser(role.getId());
			///this.auditorAwareService.setGuestUser(adminUser);
		}
		if (StringUtils.isEmpty(emailQueue.getToEmailIds()) || StringUtils.isBlank(emailQueue.getToEmailIds())) {
			if (!NoEmail.equals("True")) {
				emailQueue.setStatus(EmailQueue.STATUS_RECIPIENT);
				EmailQueue updatedEmailQueue = this.emailQueueService.saveEmailQueue(emailQueue);
				return updatedEmailQueue;
			}
		}
		EmailQueue updatedEmailQueue = null;
		if (!NoEmail.equals("True")) {
			updatedEmailQueue = this.emailQueueService.saveEmailQueue(emailQueue);
			/*if (this.auditorAwareService.getCurrentAuditor() == null) {
				this.auditorAwareService.setGuestUser(null);
			}
*/
			try {
				// Send only the email queue id
				//this.jmsTemplate.convertAndSend(this.emailQueueDestination, updatedEmailQueue.getId());
			} catch (Exception ex) {
				LOGGER.error(CLASS_NAME, METHOD_QUEUE_MAIL, ex);
			}
		}

		return updatedEmailQueue;

	}

	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.EmailService#queueEmailSave(com.trivent.entity.
	 * EmailQueue)
	 * 
	 * @DateAndTime : Feb 6, 2018 - 3:49:34 PM
	 * 
	 * @Author : Ramya
	 * 
	 * @Description : Its to save emailQueue
	 * 
	 * @Tags :
	 * 
	 * @param emailQueue - save data in emailQueue by parameter subject,body.
	 * 
	 * @return EmailQueue - updatedEmailQueue
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override
	public EmailQueue queueEmailSave(EmailQueue emailQueue,UserVO userVO) {

		/**
		 * Merge data and template
		 */
		String NoEmail = "False";
		String to = "False";
		String Cc = "False";
		String Bcc = "False";
		String to1 = "False";
		String Cc1 = "False";
		String contactname = "False";
		VelocityContext context = new VelocityContext();
		for (Entry<String, Object> entry : emailQueue.getModelMap().entrySet()) {
			if (entry.getKey().equalsIgnoreCase("CLIENT_NAME")) {
				Case appCase = emailQueue.getAppCase();
				if (appCase != null) {
					if (!emailQueue.getAppCase().getClient().getStatus().equals(AppConstants.IN_ACTIVE_USERS)) {

					}
				}
				if (appCase != null) {
					if (emailQueue.getAppCase().getClient().getStatus().equals(AppConstants.IN_ACTIVE_USERS)) {
						String contactemail = emailQueue.getAppCase().getContactName();
						if (!contactemail.equals(null)) {
							contactemail = contactemail.replace(',', ';');
							String mailIdsList[] = contactemail.split(";");
							for (String mailId : mailIdsList) {
								entry.setValue(mailId);
								contactname = "True";
								if (entry.getValue() != null) {
									break;
								}
							}
						}
					}
				}

				if (appCase == null) {
					if (contactname.equals("False")) {
						String mailIds3 = emailQueue.getToEmailIds();
						if (mailIds3 != null && mailIds3 != "null" && !mailIds3.equals("")) {
							mailIds3 = mailIds3.replace(',', ';');
							String mailIdsList3[] = mailIds3.split(";");
							UserProfile userProfile = new UserProfile();
							for (String mailId : mailIdsList3) {
								User user = this.userRepository.findByLoginId(mailId);
								if (user != null) {
									if (user.getType().equalsIgnoreCase(User.USER_TYPE_CLIENT)
											&& (user.getStatus() != AppConstants.IN_ACTIVE_USERS)) {
										if (user != null) {
											userProfile = userProfileRepository.getProfileByUserID(user.getId());
											if (userProfile != null && userProfile.getId() != null) {
												entry.setValue(userProfile.getFirstName());
												to = "True";
												if (entry.getValue() != null) {
													break;
												}
											}

										}
									}
								}
							}

						}
					} else if (to.equals("False")) {
						String mailIds4 = emailQueue.getCcEmailIds();
						if (mailIds4 != null && mailIds4 != "null" && !mailIds4.equals("")) {
							mailIds4 = mailIds4.replace(',', ';');
							String mailIdsList4[] = mailIds4.split(";");
							UserProfile userProfile1 = new UserProfile();
							for (String mailId1 : mailIdsList4) {
								User user1 = this.userRepository.findByLoginId(mailId1);
								if (user1 != null) {
									if (user1.getType().equalsIgnoreCase(User.USER_TYPE_CLIENT)
											&& (user1.getStatus() != AppConstants.IN_ACTIVE_USERS)) {
										if (user1 != null) {
											userProfile1 = userProfileRepository.getProfileByUserID(user1.getId());
											if (userProfile1 != null && userProfile1.getId() != null) {
												entry.setValue(userProfile1.getFirstName());
												Cc = "True";
												if (entry.getValue() != null) {
													break;
												}
											}
										}

									}
								}

							}
						}

					} else if (to.equals("False") && Cc.equals("False")) {
						String mailIds4 = emailQueue.getBccEmailIds();
						if (mailIds4 != null && mailIds4 != "null" && !mailIds4.equals("")) {
							mailIds4 = mailIds4.replace(',', ';');
							String mailIdsList4[] = mailIds4.split(";");
							UserProfile userProfile1 = new UserProfile();
							for (String mailId1 : mailIdsList4) {
								User user1 = this.userRepository.findByLoginId(mailId1);
								if (user1 != null) {
									if (user1.getType().equalsIgnoreCase(User.USER_TYPE_CLIENT)
											&& (user1.getStatus() != AppConstants.IN_ACTIVE_USERS)) {
										if (user1 != null) {
											userProfile1 = userProfileRepository.getProfileByUserID(user1.getId());
											if (userProfile1 != null && userProfile1.getId() != null) {
												entry.setValue(userProfile1.getFirstName());
												Bcc = "True";
												if (entry.getValue() != null) {
													break;
												}
											}
										}
									}
								}
							}
						}

					} else if (to.equals("False") && Cc.equals("False") && Bcc.equals("False")) {
						String mailIds4 = emailQueue.getToEmailIds();
						if (mailIds4 != null && mailIds4 != "null" && !mailIds4.equals("")) {
							mailIds4 = mailIds4.replace(',', ';');
							String mailIdsList4[] = mailIds4.split(";");
							UserProfile userProfile1 = new UserProfile();
							for (String mailId1 : mailIdsList4) {
								User user1 = this.userRepository.findByLoginId(mailId1);
								if (user1 != null) {
									if (user1.getType().equalsIgnoreCase(User.USER_TYPE_TRIVENT)
											&& (user1.getStatus() != AppConstants.IN_ACTIVE_USERS)) {
										if (user1 != null) {
											userProfile1 = userProfileRepository.getProfileByUserID(user1.getId());
											if (userProfile1 != null && userProfile1.getId() != null) {
												entry.setValue(CommonUtils.getFullDisplayName(userProfile1));
												to1 = "True";
												if (entry.getValue() != null) {
													break;
												}
											}
										}
									}
								} else if (user1 == null) {
									Contact contact = this.contactsRepository
											.getContactbyEmailfornonportaluser(mailId1);
									if (contact != null) {
										String firstName = contact.getFirstName();
										String lastName = contact.getLastName();
										entry.setValue(firstName + " " + lastName);
										to1 = "True";
										if (entry.getValue() != null) {
											break;
										}
									}
								}
							}
						}
					} else if (to.equals("False") && Cc.equals("False") && Bcc.equals("False") && to1.equals("False")) {
						String mailIds4 = emailQueue.getCcEmailIds();
						if (mailIds4 != null && mailIds4 != "null" && !mailIds4.equals("")) {
							mailIds4 = mailIds4.replace(',', ';');
							String mailIdsList4[] = mailIds4.split(";");
							UserProfile userProfile1 = new UserProfile();
							for (String mailId1 : mailIdsList4) {
								User user1 = this.userRepository.findByLoginId(mailId1);
								if (user1 != null) {
									if (user1.getType().equalsIgnoreCase(User.USER_TYPE_TRIVENT)
											&& (user1.getStatus() != AppConstants.IN_ACTIVE_USERS)) {
										if (user1 != null) {
											userProfile1 = userProfileRepository.getProfileByUserID(user1.getId());
											if (userProfile1 != null && userProfile1.getId() != null) {
												entry.setValue(CommonUtils.getFullDisplayName(userProfile1));
												Cc1 = "True";
												if (entry.getValue() != null) {
													break;
												}
											}
										}
									}
								} else if (user1 == null) {
									Contact contact = this.contactsRepository
											.getContactbyEmailfornonportaluser(mailId1);
									if (contact != null) {
										String firstName = contact.getFirstName();
										String lastName = contact.getLastName();
										entry.setValue(firstName + " " + lastName);
										Cc1 = "True";
										if (entry.getValue() != null) {
											break;
										}
									}
								}
							}
						}
					} else if (to.equals("False") && Cc.equals("False") && Bcc.equals("False") && to1.equals("False")
							&& Cc1.equals("False")) {
						String mailIds4 = emailQueue.getBccEmailIds();
						if (mailIds4 != null && mailIds4 != "null" && !mailIds4.equals("")) {
							mailIds4 = mailIds4.replace(',', ';');
							String mailIdsList4[] = mailIds4.split(";");
							UserProfile userProfile1 = new UserProfile();
							for (String mailId1 : mailIdsList4) {
								User user1 = this.userRepository.findByLoginId(mailId1);
								if (user1 != null) {
									if (user1.getType().equalsIgnoreCase(User.USER_TYPE_TRIVENT)
											&& (user1.getStatus() != AppConstants.IN_ACTIVE_USERS)) {
										if (user1 != null) {
											userProfile1 = userProfileRepository.getProfileByUserID(user1.getId());
											if (userProfile1 != null && userProfile1.getId() != null) {
												entry.setValue(CommonUtils.getFullDisplayName(userProfile1));
												if (entry.getValue() != null) {
													break;
												}
											}
										}
									}
								} else if (user1 == null) {
									Contact contact = this.contactsRepository
											.getContactbyEmailfornonportaluser(mailId1);
									if (contact != null) {
										String firstName = contact.getFirstName();
										String lastName = contact.getLastName();
										entry.setValue(firstName + " " + lastName);
										Cc1 = "True";
										if (entry.getValue() != null) {
											break;
										}
									}
								}
							}
						}
					} else {
						entry.setValue("");
						NoEmail = "True";
					}

				}
			} else if (entry.getKey().equalsIgnoreCase("USER_NAME") || entry.getKey().equalsIgnoreCase("USER")) {
				String[] entryValue = entry.getValue().toString().split(",");
				if (entryValue.length > 0) {
					String entrySize = entryValue[0].toString();
					User mailUser = userService.getUserByMail(entrySize);
					if (mailUser != null) {
						entry.setValue(CommonUtils.getFullDisplayName(mailUser.getUserProfile()));
					} else {
						Contact contact = this.contactsRepository.getContactbyEmailfornonportaluser(entrySize);
						if (contact != null) {
							String firstName = contact.getFirstName();
							String lastName = contact.getLastName();
							entry.setValue(firstName + " " + lastName);
						}

					}
				}
			}
			context.put(entry.getKey(), entry.getValue());

		}
		StringWriter stringWriter = new StringWriter();
		Velocity.evaluate(context, stringWriter, "TriventLog", emailQueue.getSubject());
		String subject = stringWriter.toString();

		stringWriter = new StringWriter();
		Velocity.evaluate(context, stringWriter, "TriventLog", emailQueue.getBody());
		String message = stringWriter.toString();

		// Update the values in email queue
		emailQueue.setSubject(subject);
		emailQueue.setBody(message);

		// Save EmailQueue and send it to the Queue. Queue Messages are read
		// only, hence we can't store the primary key
		// for retry attempts.
		User loginUser = this.userService.getCurrentUser(userVO);
		if (loginUser == null) {
			// Email Queue will be triggered from forgot password, etc., where
			// no logged in session.
			Role role = this.cacheService.findByRole(Role.ROLE_SUPER_ADMIN);
			@SuppressWarnings("unused")
			User adminUser = this.cacheService.findAdminUser(role.getId());
			//this.auditorAwareService.setGuestUser(adminUser);
		}
		EmailQueue updatedEmailQueue = null;
		if (!NoEmail.equals("True")) {
			//updatedEmailQueue = this.emailQueueService.saveEmailQueue(emailQueue);
			//if (this.auditorAwareService.getCurrentAuditor() == null) {
			//	this.auditorAwareService.setGuestUser(null);
			//}
		}

		return updatedEmailQueue;
	}
	
	// To check the client status
	@Override
	public EmailQueue inactiveClientsEmailNotifications(EmailQueue emailQueue) {
		String mailIds = StringUtils.EMPTY;
		mailIds = emailQueue.getToEmailIds();
		if (mailIds != null) {
			mailIds = mailIds.replace(',', ';');
			String mailIdsList[] = mailIds.split(";");
			String str = "";
			int index = 0;

			for (String mailId : mailIdsList) {
				User user = this.userRepository.findByLoginId(mailId);
				if (user == null) {
					if (index == 0) {
						str = str + mailId;
						index++;
					} else {
						str = str + "," + mailId;
					}
					emailQueue.setToEmailIds(str);
				} else if (user.getStatus() != AppConstants.IN_ACTIVE_USERS) {
					if (index == 0) {
						str = str + mailId;
						index++;
					} else {
						str = str + "," + mailId;
					}
					emailQueue.setToEmailIds(str);
				} else {
					emailQueue.setToEmailIds(str);
				}
			}
		}
		String mailIds1 = StringUtils.EMPTY;
		mailIds1 = emailQueue.getCcEmailIds();
		if (mailIds1 != null) {
			mailIds1 = mailIds1.replace(',', ';');
			String mailIdsList1[] = mailIds1.split(";");
			String str2 = "";
			int index2 = 0;
			for (String mailId : mailIdsList1) {
				User user = this.userRepository.findByLoginId(mailId);
				if (user == null) {
					if (index2 == 0) {
						str2 = str2 + mailId;
						index2++;
					} else {
						str2 = str2 + "," + mailId;
					}
					emailQueue.setCcEmailIds(str2);
				} else if (user.getStatus() != AppConstants.IN_ACTIVE_USERS) {
					if (index2 == 0) {
						str2 = str2 + mailId;
						index2++;
					} else {
						str2 = str2 + "," + mailId;
					}
					emailQueue.setCcEmailIds(str2);
				} else {
					emailQueue.setCcEmailIds(str2);
				}
			}
		}
		String mailIds2 = StringUtils.EMPTY;
		mailIds2 = emailQueue.getBccEmailIds();
		if (mailIds2 != null) {
			mailIds2 = mailIds2.replace(',', ';');
			String mailIdsList2[] = mailIds2.split(";");
			String str4 = "";
			int index4 = 0;
			for (String mailId : mailIdsList2) {
				User user = this.userRepository.findByLoginId(mailId);
				if (user == null) {
					if (index4 == 0) {
						str4 = str4 + mailId;
						index4++;
					} else {
						str4 = str4 + "," + mailId;
					}
					emailQueue.setBccEmailIds(str4);
				} else if (user.getStatus() != AppConstants.IN_ACTIVE_USERS) {
					if (index4 == 0) {
						str4 = str4 + mailId;
						index4++;
					} else {
						str4 = str4 + "," + mailId;
					}
					emailQueue.setBccEmailIds(str4);
				} else {
					emailQueue.setBccEmailIds(str4);
				}
			}
		}
		return emailQueue;
	}

	
}
