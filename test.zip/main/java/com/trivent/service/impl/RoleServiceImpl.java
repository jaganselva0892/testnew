package com.trivent.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.domain.Specifications;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.trivent.logging.LogManager;
import com.trivent.logging.Logger;
import com.trivent.models.Role;
import com.trivent.repository.RoleRepository;
import com.trivent.repository.specifications.GenericSpecifications;
import com.trivent.service.RoleService;

/**
 * @FileName : RoleServiceImpl.java
 * @ClassName : RoleServiceImpl
 * @DateAndTime : Feb 5, 2018 - 12:59:31 PM
 * 
 * @Author : Ramya
 * 
 * @Description : To delete,list,get,save roles and permissions
 * @Tags :
 * @Git_Config : name email
 * 
 */
@Service
public class RoleServiceImpl implements RoleService {

	private static final Logger LOGGER = LogManager.getLogger();

	private static final String CLASS_NAME = RoleServiceImpl.class.getName();

	@Autowired
	private RoleRepository roleRepository;

	@Autowired
	private GenericSpecifications<Role> roleGenericSpecifications;


	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.RoleService#getRoleList(java.lang.String)
	 * 
	 * @DateAndTime : Feb 5, 2018 - 12:59:31 PM
	 * 
	 * @Author : Ramya
	 * 
	 * @Description : To get role list
	 * 
	 * @Tags :
	 * 
	 * @param roleType - get list by using roleType
	 * 
	 * @return List - roleList
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override
	@Transactional(readOnly = true)
	public List<Role> getRoleList(String roleType) {

		List<Role> roleList = new ArrayList<>();
		try {
			Specification<Role> specification = null;
			Specifications<Role> specifications = Specifications
					.where(this.roleGenericSpecifications.dataTypeStringEqual("type", roleType));
			specification = specifications;
			roleList = this.roleRepository.findAll(specification);
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "getRoleList", e);
			roleList = new ArrayList<>();
		} finally {

		}
		return roleList;
	}

	
}
