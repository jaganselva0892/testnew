package com.trivent.service.impl;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.domain.Specifications;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.trivent.constants.AppConstants;
import com.trivent.dto.DropDownVO;
import com.trivent.dto.JwtUserDto;
import com.trivent.dto.UserVO;
import com.trivent.exceptions.JwtTokenMissingException;
import com.trivent.logging.LogManager;
import com.trivent.logging.Logger;
import com.trivent.models.Account;
import com.trivent.models.Capability;
import com.trivent.models.Permission;
import com.trivent.models.Role;
import com.trivent.models.User;
import com.trivent.models.UserAuth;
import com.trivent.models.UserProfile;
import com.trivent.repository.AccountRepository;
import com.trivent.repository.CapabilityRepository;
import com.trivent.repository.PermissionRepository;
import com.trivent.repository.RoleRepository;
import com.trivent.repository.UserAuthRepository;
import com.trivent.repository.UserRepository;
import com.trivent.repository.specifications.GenericSpecifications;
import com.trivent.service.RoleService;
import com.trivent.service.UserService;
import com.trivent.utils.CommonUtils;
import com.trivent.utils.JwtTokenValidator;

@Service("userService")
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;

	@Value("${jwt.header}")
	private String tokenHeader;

	@Value("${login_token_expiry_time}")
	private int loginTokenExpiryTime;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private UserAuthRepository userAuthRepository;

	@Autowired
	private JwtTokenValidator jwtTokenValidator;

	@Autowired
	private RoleService roleService;

	@Autowired
	private GenericSpecifications<User> genericSpecifications;

	@Autowired
	private AccountRepository accountRepository;

	@Autowired
	private UserService userService;
	
	@Autowired
	private CapabilityRepository capabilityRepository;

	@Autowired
	private PermissionRepository permissionRepository;
	
	@Autowired
	private RoleRepository roleRepository;

	private static final Logger LOGGER = LogManager.getLogger();
	private static final String CLASS_NAME = UserServiceImpl.class.getName();

	@Override
	public User login(String LoginId, String password, HttpServletResponse response, HttpServletRequest request) {
		User user = new User();
		try {
			user = this.getUserByMail(LoginId);
			if (user != null) {
				UserAuth userAuth = userAuthRepository.findByLoginId(LoginId);
				if (this.passwordEncoder.matches(password, user.getPassword())) {
					LOGGER.debug(CLASS_NAME, "Method: login", "User match with app user");
					JwtUserDto jwtUserDto = new JwtUserDto();
					jwtUserDto.setId(user.getId());
					jwtUserDto.setLoginId(LoginId);
					jwtUserDto.setUsername(LoginId);
					if (userAuth == null) {
						Long pnAuthID = userAuthRepository.createUserAuth(LoginId,
								jwtTokenValidator.generateToken(jwtUserDto), user.getId());
						userAuth = userAuthRepository.findOne(pnAuthID);
					} else {
						userAuthRepository.updateUserAuth(LoginId, jwtTokenValidator.generateToken(jwtUserDto),
								user.getId());
					}
					response.setHeader("Token", userAuth.gettoken());
					// password chk
				} else {
					user = null;
					LOGGER.debug(CLASS_NAME, "Method: login", "Password doesn't match");
				}
			} else {
				user = null;
				LOGGER.debug(CLASS_NAME, "Method: login", "User not found in the application");
			}
		} catch (Exception e) {
			user = null;
			LOGGER.error(CLASS_NAME, "Method : login - Error", e.getMessage());
		} finally {

		}
		return user;
	}

	@Override
	@Transactional(readOnly = true)
	public User getUserByMail(String loginId) {

		User user = new User();
		try {
			user = this.userRepository.findByLoginId(loginId);
		} catch (Exception e) {
			user = null;
			LOGGER.error(CLASS_NAME, " getUserByMail ", e);
		}
		return user;
	}

	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.UserService#getUserById(java.lang.Long)
	 * 
	 * @DateAndTime : Feb 3, 2018 - 10:25:24 AM
	 * 
	 * @Author : Ramya
	 * 
	 * @Description : To get user by userId
	 * 
	 * @Tags :
	 * 
	 * @param psUserId - get user by userId
	 * 
	 * @return User - user
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override
	@Transactional(readOnly = true)
	public User getUserById(Long psUserId) {

		User user = new User();
		try {
			user = this.userRepository.findCustomerById(psUserId);
		} catch (Exception e) {
			user = null;
			LOGGER.error(CLASS_NAME, " getUserById ", e);
		}
		return user;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.trivent.api.service.UserAPIService#getCurrentUser()
	 * 
	 * @DateAndTime : Sep 3, 2018 - 12:23:11 PM
	 * 
	 * @Author : Karthi
	 * 
	 * @Description : getCurrentUser list as JSON Data
	 * 
	 * @Tags :
	 * 
	 * @return User Entity
	 * 
	 * @Git_Config : name email
	 */
	@Override
	public User getCurrentUser(UserVO userVO) {

		String METHOD_NAME = "getCurrentUser";

		User user = new User();
		try {

			// User loginUser = this.auditorAwareService.getCurrentAuditor();
			// User loginUser = user;
			// loginUser.setLoginId("jagan.selvam@aalamsoft.com");
			if (userVO != null) {
				user = this.userRepository.findOne(userVO.getId());
			} else {
				user = userRepository.findOne(new Long(1673));
			}
			// user = this.userRepository.findByLoginId(loginUser.getLoginId());
		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, METHOD_NAME, e);
		}
		return user;

	}

	@Override
	public List<Object[]> getUserPermission(Long plgUserId, String pstrCapability) {
		String METHOD_NAME = "getUserPermission";

		List<Object[]> lsUserPermission = new ArrayList<>();
		try {

			/*
			 * lsUserPermission = this.userRepository.getListObjectNative(null,
			 * "SELECT p.is_visible, p.is_create, p.is_read, p.is_update, p.is_delete FROM users u  JOIN roles r ON u.role_id = r.role_id JOIN permissions p ON p.role_id = r.role_id JOIN capability c ON p.capability_id = c.capability_id WHERE c.name LIKE '"
			 * + pstrCapability + "' AND u.user_id = " + plgUserId, null, null);
			 */

		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, METHOD_NAME, e);
		}
		return lsUserPermission;
	}

	@Override
	@Transactional(readOnly = true)
	public List<User> getUserByIdNew(List<Long> psUserId) {

		List<User> usersList = new ArrayList<>();
		try {
			usersList = this.userRepository.findCustomerByIdNew(psUserId);
		} catch (Exception e) {
			usersList = null;
			LOGGER.error(CLASS_NAME, " getUserById ", e);
		}
		return usersList;
	}

	@Override
	public UserVO getUserDetails(HttpServletRequest request) {
		String header = request.getHeader(this.tokenHeader);
		String ipAddress = request.getHeader("X-FORWARDED-FOR");
		if (ipAddress == null) {
			ipAddress = request.getRemoteAddr();
		}
		if (header == null || !header.startsWith("Bearer ")) {
			throw new JwtTokenMissingException("No JWT token found in request headers");
		}

		String authToken = header.substring(7);
		UserAuth userAuth = userAuthRepository.findByTokenIP(authToken.trim(), AppConstants.NO);
		// UserAuth userAuth = userAuthRepository.findByLoginId(LoginId);
		User user = new User();
		UserVO userVO = new UserVO();
		if (userAuth != null) {
			user = userRepository.findOne(userAuth.getuserId());
			userVO = new UserVO(user);
		} else {
			userVO = null;
		}
		return userVO;

	}

	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.UserService#getUserByName(java.lang.String)
	 * 
	 * @DateAndTime : Feb 3, 2018 - 10:25:24 AM
	 * 
	 * @Author : Seetha
	 * 
	 * @Description : To get user by name
	 * 
	 * @Tags :
	 * 
	 * @param searchText - search string
	 * 
	 * @return List - userList
	 * 
	 * @Git_Config : name email
	 * 
	 */

	@SuppressWarnings("unused")
	@Override
	@Transactional(readOnly = true)
	public List<User> getUserByName(String searchText) {
		List<User> userList = new ArrayList<>();
		List<UserProfile> userProfileList = new ArrayList<UserProfile>();
		/*
		 * try { if (searchText != null && !searchText.isEmpty()) {
		 * Specifications<UserProfile> specification = Specifications
		 * .where(this.genericSpecificationsUserProfile.dataTypeCharacter("deleted",
		 * AppConstants.NO)); Specifications<UserProfile> specifications =
		 * Specifications.where(
		 * this.genericSpecificationsUserProfile.dataTypeCaseQueryLikePattern(
		 * "firstName", searchText)); specifications = specifications
		 * .or(this.genericSpecificationsUserProfile.dataTypeCaseQueryLikePattern(
		 * "lastName", searchText)); specification = specification.and(specifications);
		 * userProfileList = this.userProfileRepository.findAll(specification); if
		 * (userProfileList.size() > 0) { List<Long> lnUserId = new ArrayList<Long>();
		 * for (UserProfile userProfile : userProfileList) { Long user =
		 * userProfile.getUser().getId(); if (user != null) lnUserId.add(user); } if
		 * (lnUserId.size() > 0) { Specification<User> usersSpecification =
		 * genericSpecifications.dataTypeLongList("id", lnUserId); userList =
		 * userRepository.findAll(usersSpecification); } } return userList;
		 * 
		 * } else { LOGGER.warn(CLASS_NAME, "getUserByName",
		 * "searchText String is empty"); }
		 * 
		 * } catch (Exception e) { LOGGER.error(CLASS_NAME, "getUserByName", e); }
		 * finally {
		 * 
		 * }
		 */
		return userList;

	}

	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.UserService#getUserListByRoleType(java.lang.String)
	 * 
	 * @DateAndTime : Feb 3, 2018 - 10:25:24 AM
	 * 
	 * @Author : Ramya
	 * 
	 * @Description : To get userList by roleType
	 * 
	 * @Tags :
	 * 
	 * @param roleType - get list by roleType
	 * 
	 * @return List<User> - userList
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override
	@Transactional(readOnly = true)
	public List<User> getUserListByRoleType(String roleType) {

		List<User> userList = new ArrayList<>();
		try {

			if (StringUtils.isNotBlank(roleType) && StringUtils.isNotEmpty(roleType)) {
				List<Role> roleList = this.roleService.getRoleList(roleType);
				userList = this.getUserList(roleList);
			} else {
				LOGGER.warn(CLASS_NAME, "getUserListByRoleType", "roleType is empty");
			}

		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "getUserListByRoleType", e);
		} finally {

		}
		return userList;

	}

	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.UserService#getUserList(java.util.List)
	 * 
	 * @DateAndTime : Feb 3, 2018 - 10:25:24 AM
	 * 
	 * @Author : Ramya
	 * 
	 * @Description : To get user List
	 * 
	 * @Tags :
	 * 
	 * @param roleList - get list by roleList
	 * 
	 * @return List<User> - userList
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override
	@Transactional(readOnly = true)
	public List<User> getUserList(List<Role> roleList) {

		List<User> userList = new ArrayList<>();
		try {

			if (roleList.size() > 0) {
				Specification<User> specification = null;
				Specifications<User> specifications = Specifications
						.where(this.genericSpecifications.dataTypeCharacter("deleted", AppConstants.NO));
				specification = this.genericSpecifications.anyRole("role", roleList);
				specifications = specifications.and(specification);
				specification = specifications;
				userList = this.userRepository.findAll(specification);
			} else {
				LOGGER.warn(CLASS_NAME, "getUserList", "roleList size is 0 or empty");
			}

		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "getUserList", e);
		} finally {

		}
		return userList;

	}

	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.UserService#getUserListByLoginIds(java.util.List)
	 * 
	 * @DateAndTime : Feb 3, 2018 - 10:25:24 AM
	 * 
	 * @Author : Ramya
	 * 
	 * @Description : To get userList by loginId
	 * 
	 * @Tags :
	 * 
	 * @param strLoginIds - get list by loginId
	 * 
	 * @return List<User> - userList
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override
	@Transactional(readOnly = true)
	public List<User> getUserListByLoginIds(List<String> strLoginIds) {

		List<User> userList = new ArrayList<>();
		try {

			if (strLoginIds.size() > 0) {
				Specification<User> specification = null;
				Specifications<User> specifications = Specifications
						.where(this.genericSpecifications.dataTypeCharacter("deleted", AppConstants.NO));
				specification = this.genericSpecifications.dataTypeStringList("loginId", strLoginIds);
				specifications = specifications.and(specification);
				specification = specifications;
				userList = this.userRepository.findAll(specification);
			} else {
				LOGGER.warn(CLASS_NAME, "getUserListByLoginIds", "strLoginIds size is 0 or empty");
			}

		} catch (Exception e) {
			LOGGER.error(CLASS_NAME, "getUserListByLoginIds", e);
		} finally {

		}
		return userList;

		/*
		 * try { if (searchText != null && !searchText.isEmpty()) {
		 * Specifications<UserProfile> specification = Specifications
		 * .where(this.genericSpecificationsUserProfile.dataTypeCharacter("deleted",
		 * AppConstants.NO)); Specifications<UserProfile> specifications =
		 * Specifications.where(
		 * this.genericSpecificationsUserProfile.dataTypeCaseQueryLikePattern(
		 * "firstName", searchText)); specifications = specifications
		 * .or(this.genericSpecificationsUserProfile.dataTypeCaseQueryLikePattern(
		 * "lastName", searchText)); specification = specification.and(specifications);
		 * userProfileList = this.userProfileRepository.findAll(specification); if
		 * (userProfileList.size() > 0) { List<Long> lnUserId = new ArrayList<Long>();
		 * for (UserProfile userProfile : userProfileList) { Long user =
		 * userProfile.getUser().getId(); if (user != null) lnUserId.add(user); } if
		 * (lnUserId.size() > 0) { Specification<User> usersSpecification =
		 * genericSpecifications.dataTypeLongList("id", lnUserId); userList =
		 * userRepository.findAll(usersSpecification); } } return userList;
		 * 
		 * } else { LOGGER.warn(CLASS_NAME, "getUserByName",
		 * "searchText String is empty"); }
		 * 
		 * } catch (Exception e) { LOGGER.error(CLASS_NAME, "getUserByName", e); }
		 * finally {
		 * 
		 * }
		 * 
		 * return userList;
		 */

	}

	@Override
	@Transactional
	public Map<Long, String> getAccountClientUsers(Long accountId, UserVO userVO) {
		Map<Long, String> usersMap = new LinkedHashMap<>();
		try {
			User loginUser = this.userService.getCurrentUser(userVO);
			Account account = this.accountRepository.findOne(loginUser.getAccount().getId());
			if (account.getAccountType().equalsIgnoreCase(AppConstants.GUEST)) {
				usersMap.put(loginUser.getId(),
						loginUser.getUserProfile().getFirstName() + " " + loginUser.getUserProfile().getLastName());
			} else {
				List<User> users = this.userRepository.findUserByAccountId(accountId, AppConstants.NO);
				users.forEach(user -> {
					if (user.getStatus() != AppConstants.IN_ACTIVE_USERS) {
						usersMap.put(user.getId(),
								user.getUserProfile().getFirstName() + " " + user.getUserProfile().getLastName());
					}
				});
			}
		} catch (Exception e) {
			List<User> users = this.userRepository.findUserByAccountId(accountId, AppConstants.NO);
			users.forEach(user -> {
				if (user.getStatus() != AppConstants.IN_ACTIVE_USERS) {
					usersMap.put(user.getId(),
							user.getUserProfile().getFirstName() + " " + user.getUserProfile().getLastName());
				}
			});
			LOGGER.error(CLASS_NAME, "getAccountClientUsers", e);
		}
		return usersMap;
	}

	@Override
	@Transactional
	public List<UserVO> getUser(HttpServletRequest request) {

		List<UserVO> userVoLsit = new ArrayList<UserVO>();
		try {
			char isDeleted = AppConstants.NO;
			String header = request.getHeader(this.tokenHeader);
			String ipAddress = request.getHeader("X-FORWARDED-FOR");
			if (ipAddress == null) {
				ipAddress = request.getRemoteAddr();
			}
			if (header == null || !header.startsWith("Bearer ")) {
				throw new JwtTokenMissingException("No JWT token found in request headers");
			}
			String authToken = header.substring(7);
			UserAuth userAuth = userAuthRepository.findByTokenIP(authToken.trim(), AppConstants.NO);
			if (userAuth != null) {
				List<User> users = userRepository.getAllUsers(User.USER_TYPE_TRIVENT, isDeleted,
						AppConstants.IN_ACTIVE_USERS);
				users.forEach(user -> {
					UserVO userVO = new UserVO(user);
					userVoLsit.add(userVO);
				});
			} else {
				@SuppressWarnings("unused")
				UserVO userVO = null;
			}
		} catch (Exception ex) {
			LOGGER.error(CLASS_NAME, "getUser", ex);
		}
		return userVoLsit;
	}

	@SuppressWarnings("unused")
	@Override
	@Transactional(readOnly = true)
	public List<DropDownVO>  getClients(UserVO userVO, Long accountId) {
		char isDeleted = AppConstants.NO;
		String userType = User.USER_TYPE_CLIENT;
		List<User> clients = this.userRepository.listAccountUsers(accountId, userType, isDeleted);
		List<DropDownVO> listNew = new ArrayList<>(clients.size());
//		clients.forEach(u->{
//			DropDownVO dropDownVO= new DropDownVO();
//			dropDownVO.setText( CommonUtils.getFullDisplayName(u.getUserProfile()));
//			dropDownVO.setValue(u.getId());
//			listNew.add(dropDownVO);
//		});
		User loginUser = this.userService.getCurrentUser(userVO);
		if ((loginUser != null) && (loginUser.getRole() != null)) {
			Role role = this.roleRepository.findOne(loginUser.getRole().getId());
			if (role != null) {
				Capability capability = this.capabilityRepository.findByName(Capability.CLIENT_NAME_WITH_CODE);
				if (capability != null) {
					Permission permission = this.permissionRepository.getByCapabilityId(role.getId(),
							capability.getId());
					if (permission != null) {
						Character isVisible = permission.getVisible();
							clients.forEach(u->{
								DropDownVO dropDownVO= new DropDownVO();
							if (isVisible.equals(AppConstants.YES)) {
								dropDownVO.setText( CommonUtils.getFullDisplayName(u.getUserProfile())+ " " + "-" + " " + u.getUserProfile().getCustomerCode());
								dropDownVO.setValue(u.getId());
								listNew.add(dropDownVO);
								} else {
								dropDownVO.setText( CommonUtils.getFullDisplayName(u.getUserProfile()));
								dropDownVO.setValue(u.getId());
								listNew.add(dropDownVO);
							}
						});

					}
				}
			}
		}
		return listNew;
	}

}
