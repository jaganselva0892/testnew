package com.trivent.service.impl;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.ToIntFunction;


import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.domain.Specifications;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.trivent.constants.AppConstants;
import com.trivent.dto.AppUIScreenFilterVO;
import com.trivent.dto.RowVO;
import com.trivent.dto.ScreenListFilterVO;
import com.trivent.exceptions.TriventException;
import com.trivent.logging.LogManager;
import com.trivent.logging.Logger;
import com.trivent.models.Case;
import com.trivent.models.CaseResultFile;
import com.trivent.models.Role;
import com.trivent.models.User;
import com.trivent.repository.AppDBTableRepository;
import com.trivent.repository.CaseRepository;
import com.trivent.repository.CaseResultFileReprository;
import com.trivent.repository.specifications.GenericSpecifications;
import com.trivent.service.CaseResultFileService;
import com.trivent.service.UserService;
import com.trivent.utils.CommonUtils;
import com.trivent.utils.FilterUtils;

/**
 * @FileName : CaseFileServiceImpl.java
 * @ClassName : CaseFileServiceImpl
 * @DateAndTime : Feb 8, 2018 - 2:39:53 PM
 * 
 * @Author : Karthi
 * 
 * @Description : Its to get,list,delete,download,merge,save,update case files
 *              and case result files.
 * @Tags :
 * @Git_Config : name email
 * 
 */
@Service
public class CaseResultFileServiceImpl implements CaseResultFileService {

	@SuppressWarnings("unused")
	private static final Logger LOGGER = LogManager.getLogger();

	@SuppressWarnings("unused")
	private static final String CLASS_NAME = CaseResultFileServiceImpl.class.getName();

	@Autowired
	private CaseResultFileReprository caseResultFileRepository;

	@Autowired
	GenericSpecifications<CaseResultFile> caseResultFileGenericSpecifications;

	@Autowired
	private UserService userService;
	
	@Autowired
	private FilterUtils<CaseResultFile> filterUtils;
	
	@SuppressWarnings("unused")
	@Autowired
	private AppDBTableRepository appDBTableRepository;
	
	@Autowired
	private CaseRepository caseRepository;
	
	@Override
	@Transactional(readOnly = true)
	public ScreenListFilterVO getDefaultScreenListFilterVO() throws TriventException {
		//AppDBTable appdbTable = this.appDBTableRepository.findByName("CaseResultFile");
		String screenType = AppConstants.SCREEN_TYPE_LIST;
		//return this.filterUtils.populateScreenListFilterVO(appdbTable.getId(), screenType);
		return this.filterUtils.populateScreenListFilterVO(new Long(16), screenType);
	}
	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * com.trivent.service.CaseFileService#listCaseResultFilesByCaseId(java.lang.
	 * Long, com.trivent.dto.ScreenListFilterVO, java.lang.String)
	 * 
	 * @DateAndTime : Feb 8, 2018 - 2:39:54 PM
	 * 
	 * @Author : Ramya
	 * 
	 * @Description : Its to list case result files
	 * 
	 * @Tags :
	 * 
	 * @param caseId - get list by caseId
	 * 
	 * @param screenListFilterVO - get required field by path variable
	 * screenListFilterVO
	 * 
	 * @param psType - get list by type
	 * 
	 * @return List - updatedRowVOs
	 * 
	 * @throws TriventException
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override
	@Transactional(readOnly = true)
	public List<RowVO> listCaseResultFilesByCaseId(Long caseId, ScreenListFilterVO screenListFilterVO, String psType)
			throws TriventException, UnsupportedEncodingException, IllegalAccessException, InvocationTargetException {
		User loginUser = this.userService.getCurrentUser(null);
		//AppDBTable appdbTable = this.appDBTableRepository.findByName("CaseResultFile");
		ScreenListFilterVO screenListFilterVO1 = new ScreenListFilterVO();
		String screenType = AppConstants.SCREEN_TYPE_LIST;
		List<CaseResultFile> caseResultFiles = null;
		Specification<CaseResultFile> specification = null;

		Specifications<CaseResultFile> specifications = Specifications
				.where(this.caseResultFileGenericSpecifications.dataTypeCharacter("deleted", AppConstants.NO));

		if (StringUtils.isNotBlank(psType) && StringUtils.isNotEmpty(psType)) {

			switch (psType) {

			case AppConstants.ARCHIVAL_FTP_ACTION_BACKUP:
				specifications = specifications
						.and(this.caseResultFileGenericSpecifications.dataTypeCharacter("archived", AppConstants.YES));
				specifications = specifications
						.and(this.caseResultFileGenericSpecifications.dataTypeCharacter("backup", AppConstants.NO));
				specifications = specifications.and(this.caseResultFileGenericSpecifications
						.dataTypeStringEqual("curStatus", AppConstants.TRACE_SUCCESS));
				break;

			case AppConstants.ARCHIVAL_FTP_ACTION_ARCHIVE:
				specifications = specifications
						.and(this.caseResultFileGenericSpecifications.dataTypeCharacter("archived", AppConstants.NO));
				specifications = specifications
						.and(this.caseResultFileGenericSpecifications.dataTypeCharacter("backup", AppConstants.NO));
				specifications = specifications.and(this.caseResultFileGenericSpecifications
						.dataTypeStringEqual("curStatus", AppConstants.TRACE_SUCCESS));
				break;

			case AppConstants.ARCHIVAL_FTP_ACTION_REMOVE:
				specifications = specifications
						.and(this.caseResultFileGenericSpecifications.dataTypeCharacter("archived", AppConstants.YES));
				specifications = specifications
						.and(this.caseResultFileGenericSpecifications.dataTypeCharacter("backup", AppConstants.YES));
				specifications = specifications
						.and(this.caseResultFileGenericSpecifications.dataTypeCharacter("removeFile", AppConstants.NO));
				specifications = specifications.and(this.caseResultFileGenericSpecifications
						.dataTypeStringEqual("curStatus", AppConstants.TRACE_SUCCESS));
				break;

			default:
				break;

			}
			BeanUtils.copyProperties(screenListFilterVO, screenListFilterVO1);

		} else {
			//AppDBTable appdbTableCF = this.appDBTableRepository.findByName("CaseResultFile");
			String screenTypeCF = AppConstants.SCREEN_TYPE_LIST;
			//screenListFilterVO1 = this.filterUtils.populateScreenListFilterVO(appdbTableCF.getId(), screenTypeCF);
			screenListFilterVO1 = this.filterUtils.populateScreenListFilterVO(new Long(16), screenTypeCF);
		}

		/* To List Case Result files of sub case in Completed Files tab */

		if (caseId != null) {
			Case appCase = caseRepository.findOne(caseId);
			if (appCase != null) {
				if (loginUser.getRole().getType().equals(Role.ROLE_TYPE_CUSTOMER)) {
					if (appCase.getParentCase() == null) {
						List<Long> longCaseids = new ArrayList<>();
						List<Case> clientCases = caseRepository.findByParentId(caseId);
						for (Case cases : clientCases) {
							Long prntCaseId = cases.getId();
							longCaseids.add(prntCaseId);
						}
						longCaseids.add(caseId);
						if (longCaseids.size() > 0) {
							Specification<CaseResultFile> specificationNew = this.caseResultFileGenericSpecifications
									.dataTypeLongList("clientCase", longCaseids);
							specifications = specifications.and(specificationNew);
						}

					}
				} else {
					if (appCase.getParentCase() == null) {
						List<Long> longCaseids = new ArrayList<>();
						List<Case> clientCases = caseRepository.findByParentId(caseId);
						for (Case cases : clientCases) {
							Long prntCaseId = cases.getId();
							longCaseids.add(prntCaseId);
						}
						longCaseids.add(caseId);
						if (longCaseids.size() > 0) {
							Specification<CaseResultFile> specificationNew = this.caseResultFileGenericSpecifications
									.dataTypeLongList("clientCase", longCaseids);
							specifications = specifications.and(specificationNew);
						}
					} else {
						Specification<CaseResultFile> specificationNew = this.caseResultFileGenericSpecifications
								.dataTypeLong("clientCase", caseId);
						specifications = specifications.and(specificationNew);
					}
				}
			}
		}

		ScreenListFilterVO screenListFilterVONew = new ScreenListFilterVO();
		BeanUtils.copyProperties(screenListFilterVO1, screenListFilterVONew);
		if (screenListFilterVO.getAppUIScreenFilterVOs().size() > 0) {
			String fromCreatedDate = null;
			String toCreatedDate = null;
			String fromModifiedDate = null;
			String toModifiedDate = null;
			String[] _curStatus = null;
			String[] _pageCountSatus = null;
			for (AppUIScreenFilterVO appUIScreenFilterVO : screenListFilterVONew.getAppUIScreenFilterVOs()) {
				if (appUIScreenFilterVO.getDbFieldName().equalsIgnoreCase("createdDate")
						|| appUIScreenFilterVO.getDbFieldName().equalsIgnoreCase("tcreatedDate")) {
					if (appUIScreenFilterVO.getDbFieldName().equalsIgnoreCase("createdDate")) {
						fromCreatedDate = appUIScreenFilterVO.getValue();
					} else if (appUIScreenFilterVO.getDbFieldName().equalsIgnoreCase("tcreatedDate")) {
						toCreatedDate = appUIScreenFilterVO.getValue();
					}
					if (fromCreatedDate != null && toCreatedDate != null && !StringUtils.isEmpty(fromCreatedDate)
							&& !StringUtils.isEmpty(toCreatedDate)) {
						specification = caseResultFileGenericSpecifications.dataTypeCalendar("createdDate",
								CommonUtils.stringToCalendar(fromCreatedDate),
								CommonUtils.stringToCalendar(toCreatedDate));
						specifications = specifications.and(specification);

					}
				}
				if (appUIScreenFilterVO.getDbFieldName().equalsIgnoreCase("lastModifiedDate")
						|| appUIScreenFilterVO.getDbFieldName().equalsIgnoreCase("tmodifiedDate")) {
					if (appUIScreenFilterVO.getDbFieldName().equalsIgnoreCase("lastModifiedDate")) {
						fromModifiedDate = appUIScreenFilterVO.getValue();
					}
					if (appUIScreenFilterVO.getDbFieldName().equalsIgnoreCase("tmodifiedDate")) {
						toModifiedDate = appUIScreenFilterVO.getValue();
					}
					if (fromModifiedDate != null && toModifiedDate != null && !StringUtils.isEmpty(fromModifiedDate)
							&& !StringUtils.isEmpty(toModifiedDate)) {
						specification = caseResultFileGenericSpecifications.dataTypeCalendar("lastModifiedDate",
								CommonUtils.stringToCalendar(fromModifiedDate),
								CommonUtils.stringToCalendar(toModifiedDate));
						specifications = specifications.and(specification);
					}
				}

				if (appUIScreenFilterVO.getDbFieldName().equalsIgnoreCase("curStatus")
						|| appUIScreenFilterVO.getDbFieldName().equalsIgnoreCase("tcurStatus")) {
					if (appUIScreenFilterVO.getDbFieldName().equalsIgnoreCase("curStatus")) {
						_curStatus = appUIScreenFilterVO.getValue() != null ? appUIScreenFilterVO.getValue().split(",")
								: "".split(",");
						List<String> _str = new ArrayList<String>();
						for (String _curstatus : _curStatus)
							if (!_curstatus.isEmpty())
								_str.add(_curstatus);

						if (_str.size() != 0) {
							specification = caseResultFileGenericSpecifications.dataTypeStringList("curStatus", _str);
							specifications = specifications.and(specification);
						}
					}
				}

				if (appUIScreenFilterVO.getDbFieldName().equalsIgnoreCase("pageCountStatus")
						|| appUIScreenFilterVO.getDbFieldName().equalsIgnoreCase("tpageCountStatus")) {
					if (appUIScreenFilterVO.getDbFieldName().equalsIgnoreCase("pageCountStatus")) {
						_pageCountSatus = appUIScreenFilterVO.getValue() != null
								? appUIScreenFilterVO.getValue().split(",")
								: "".split(",");
						List<String> _str = new ArrayList<String>();
						for (String _curstatus : _pageCountSatus)
							if (!_curstatus.isEmpty())
								_str.add(_curstatus);

						if (_str.size() != 0) {
							specification = caseResultFileGenericSpecifications.dataTypeStringList("pageCountStatus",
									_str);
							specifications = specifications.and(specification);
						}
					}
				}

			}
			if (!StringUtils.isEmpty(fromCreatedDate) && !StringUtils.isEmpty(toCreatedDate)) {
				for (AppUIScreenFilterVO appUIScreenFilterVO : screenListFilterVONew.getAppUIScreenFilterVOs()) {
					if (appUIScreenFilterVO.getDbFieldName().equalsIgnoreCase("createdDate")) {
						appUIScreenFilterVO.setValue("");
					} else if (appUIScreenFilterVO.getDbFieldName().equalsIgnoreCase("tcreatedDate")) {
						appUIScreenFilterVO.setValue("");
						appUIScreenFilterVO.setDbFieldName("");
						appUIScreenFilterVO.setFilterName("");
					}
				}
			}
			if (!StringUtils.isEmpty(fromModifiedDate) && !StringUtils.isEmpty(toModifiedDate)) {
				for (AppUIScreenFilterVO appUIScreenFilterVO : screenListFilterVONew.getAppUIScreenFilterVOs()) {
					if (appUIScreenFilterVO.getDbFieldName().equalsIgnoreCase("lastModifiedDate")) {
						appUIScreenFilterVO.setValue("");
					} else if (appUIScreenFilterVO.getDbFieldName().equalsIgnoreCase("tmodifiedDate")) {
						appUIScreenFilterVO.setValue("");
						appUIScreenFilterVO.setDbFieldName("");
						appUIScreenFilterVO.setFilterName("");
					}
				}
			}

			if (_curStatus != null) {
				for (AppUIScreenFilterVO appUIScreenFilterVO : screenListFilterVONew.getAppUIScreenFilterVOs()) {
					if (appUIScreenFilterVO.getDbFieldName().equalsIgnoreCase("curStatus")) {
						appUIScreenFilterVO.setValue("");
					} else if (appUIScreenFilterVO.getDbFieldName().equalsIgnoreCase("curStatus")) {
						appUIScreenFilterVO.setValue("");
						appUIScreenFilterVO.setDbFieldName("");
						appUIScreenFilterVO.setFilterName("");
					}
				}
			}

			if (_pageCountSatus != null) {
				for (AppUIScreenFilterVO appUIScreenFilterVO : screenListFilterVONew.getAppUIScreenFilterVOs()) {
					if (appUIScreenFilterVO.getDbFieldName().equalsIgnoreCase("pageCountStatus")) {
						appUIScreenFilterVO.setValue("");
					} else if (appUIScreenFilterVO.getDbFieldName().equalsIgnoreCase("pageCountStatus")) {
						appUIScreenFilterVO.setValue("");
						appUIScreenFilterVO.setDbFieldName("");
						appUIScreenFilterVO.setFilterName("");
					}
				}
			}

		}

		specifications = this.filterUtils.populateCaseViewSpecifications(screenListFilterVO, loginUser,
				specifications, true);

		specifications = this.filterUtils.populateCaseFilterSpecifications(screenListFilterVO1,
				specifications);
		specification = specifications;
		Page<CaseResultFile> requestedPage = this.caseResultFileRepository.findAll(specification,
				this.filterUtils.constructPageSpecification(screenListFilterVO));
		if (screenListFilterVO.getPageNo() > requestedPage.getTotalPages()) {
			screenListFilterVO.setPageNo(1);
			screenListFilterVO1.setPageNo(1);
			requestedPage = this.caseResultFileRepository.findAll(specification,
					this.filterUtils.constructPageSpecification(screenListFilterVO1));
		}
		// For getting overall page count
		final List<CaseResultFile> caseResultsFiles = caseResultFileRepository.findAll(specification);
		final int sumofPageCount = caseResultsFiles.stream().mapToInt(new ToIntFunction<CaseResultFile>() {
			@Override
			public int applyAsInt(CaseResultFile o) {
				return ((o != null) && (o.getFilePageCount() != null)
						&& StringUtils.isNotBlank(o.getFilePageCount().toString())
						&& StringUtils.isNotEmpty(o.getFilePageCount().toString()) ? o.getFilePageCount() : 0);
			}
		}).sum();

		caseResultFiles = requestedPage.getContent();
		screenListFilterVO.setTotalPages(requestedPage.getTotalPages());
		screenListFilterVO.setCurrentRecords(requestedPage.getNumberOfElements());
		screenListFilterVO.setTotalRecords(requestedPage.getTotalElements());
		List<RowVO> updatedRowVOs = new ArrayList<>();
		//List<RowVO> rowVOs = this.filterUtils.listScreenDetails(appdbTable.getId(), screenType, caseResultFiles);
		List<RowVO> rowVOs = this.filterUtils.listScreenDetails(new Long(16), screenType, caseResultFiles);

		Case appCase = null;
		if (caseId != null) {
			appCase = this.caseRepository.findOne(caseId);
		}
		final Case appCase1 = appCase;
		rowVOs.forEach(new Consumer<RowVO>() {
			@Override
			public void accept(RowVO row) {
				if (row.getId() != null) {
					row.getValueMap().put("totalCaseFiles", String.valueOf(caseResultsFiles.size()));
					row.getValueMap().put("caseFilePageCount", String.valueOf(sumofPageCount));
					row.getValueMap().put("isCustomerDownloaded",
							(appCase1 != null) && (appCase1.getIsCustomerDownload() != null)
									? appCase1.getIsCustomerDownload().toString()
									: "N");
				}
				row.setValueMap(row.getValueMap());
			}
		});

		boolean repeatLoop = true;
		int loopIndex = 0;
		while (repeatLoop) {
			RowVO rowVO = rowVOs.get(loopIndex);
			Long resultFileId = rowVO.getId();
			if (resultFileId != null) {
				loopIndex += 1;
				rowVO = rowVOs.get(loopIndex);
			} else {
				repeatLoop = false;
				Map<String, String> caseDetailsMap = rowVO.getValueMap();
				if (caseId != null) {
					caseDetailsMap.put("caseId", caseId.toString());
				}
				String roleType = loginUser.getRole().getName();
				String roleName = (roleType == "Customer") ? "Y" : "N";
				caseDetailsMap.put("loginUserRole", roleName);
				caseDetailsMap.put("loginUser", loginUser.getId().toString());
				caseDetailsMap.put("isCustomerDownloaded",
						(appCase != null) && (appCase.getIsCustomerDownload() != null)
								? appCase.getIsCustomerDownload().toString()
								: "N");
				rowVO.setValueMap(caseDetailsMap);
				break;
			}
		}
		updatedRowVOs.addAll(rowVOs);

		return updatedRowVOs;

	}


}
