package com.trivent.service;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.util.List;

import org.springframework.stereotype.Service;

import com.trivent.dto.RowVO;
import com.trivent.dto.ScreenListFilterVO;
import com.trivent.exceptions.TriventException;

/**
 * @FileName : CaseFileService.java
 * @ClassName : CaseFileService
 * @DateAndTime : Feb 2, 2018 - 10:36:30 AM
 * 
 * @Author : karthi
 * 
 * @Description : The name,parameter and exceptions of the method caseFile are
 *              described and used to
 *              add,delete,download,merge,get,list,save,update caseFiles and
 *              caseResultFiles.
 * @Tags :
 * @Git_Config : name email
 * 
 */
@Service
public interface CaseResultFileService {

	List<RowVO> listCaseResultFilesByCaseId(Long caseId, ScreenListFilterVO screenListFilterVO, String psType)
			throws TriventException, UnsupportedEncodingException, IllegalAccessException, InvocationTargetException;

	ScreenListFilterVO getDefaultScreenListFilterVO() throws TriventException;
	
	

}
