package com.trivent.service;

import com.trivent.dto.ContactVO;
import com.trivent.dto.UserVO;
import com.trivent.dto.base.EncryptedId;

public interface ContactService {
	
	ContactVO getNewContact(Long entityId, String entity, String screen, EncryptedId caseId, UserVO userVO);

	ContactVO saveContacts(ContactVO contactVO, UserVO userVO);

	UserVO getUserDetails(Long userId);

	}
