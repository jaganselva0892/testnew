package com.trivent.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.trivent.models.Partner;

/**
 * @FileName 	:
 *				PartnerService.java
 * @ClassName 	:
 * 				PartnerService
 * @DateAndTime :
 *				Nov 21, 2018 - 1:50:55 PM
 * 
 * @Author 		:
 * 				Karthi
 * 
 * @Description : 
 * 				The name,parameter and exceptions of the method partner  are described and used to list,delete,get,save partner.
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Service
public interface PartnerService {

	Partner getCurrentSessionPartner();

	List<Partner> getPartnerListByPartnerCode(List<String> strPartnerCodes);
}
