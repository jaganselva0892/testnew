package com.trivent.service;


import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Component;

import com.trivent.dto.DropDownVO;
import com.trivent.dto.UserVO;
import com.trivent.models.Role;
import com.trivent.models.User;

@Component
public interface UserService {

	User login(String loginId, String password, HttpServletResponse response, HttpServletRequest request);
	
	User getUserById(Long psUserId);

	User getCurrentUser(UserVO userVO);

	List<Object[]> getUserPermission(Long plgUserId, String pstrCapability);

	List<User> getUserByIdNew(List<Long> psUserId);

	User getUserByMail(String loginId);
	
	/* Method to get the User Details */
	UserVO getUserDetails(HttpServletRequest request);

	List<User> getUserByName(String globalSearch);

	List<User> getUserListByRoleType(String roleType);

	List<User> getUserList(List<Role> roleList);

	List<User> getUserListByLoginIds(List<String> strLoginIds);

	Map<Long, String> getAccountClientUsers(Long accountId, UserVO userVO);

	List<UserVO> getUser(HttpServletRequest request);

	List<DropDownVO> getClients(UserVO userVO, Long accountId);

}
