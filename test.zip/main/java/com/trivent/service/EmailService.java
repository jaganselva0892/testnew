package com.trivent.service;

import org.springframework.stereotype.Service;

import com.trivent.dto.UserVO;
import com.trivent.models.EmailQueue;

/**
 * @FileName 	:
 *				EmailService.java
 * @ClassName 	:
 * 				EmailService
 * @DateAndTime :
 *				Feb 2, 2018 - 12:32:43 PM
 * 
 * @Author 		:
 * 				Ramya
 * 
 * @Description : 
 * 				The name,parameter of the method email  are described and used to send email,save email.
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Service
public interface EmailService {

	EmailQueue queueEmailSave(EmailQueue emailQueue, UserVO userVO);

	EmailQueue queueEmail(EmailQueue emailQueue, UserVO userVO);

	EmailQueue inactiveClientsEmailNotifications(EmailQueue emailQueue);

	}
