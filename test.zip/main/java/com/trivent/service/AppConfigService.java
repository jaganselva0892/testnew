package com.trivent.service;

import com.trivent.dto.UserVO;
import com.trivent.models.EmailQueue;

/**
 * @FileName : AppConfigService.java
 * @ClassName : AppConfigService
 * @DateAndTime : Feb 1, 2018 - 5:09:13 PM
 * 
 * @Author : Ramya
 * 
 * @Description : The name,parameter of the method appConfig are described and
 *              used to get appConfig and import data and list appConfig.
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
public interface AppConfigService {

	boolean getCustomerMailPermission(EmailQueue emailQueue, String emailType, UserVO userVO);

	
}
