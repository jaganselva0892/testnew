package com.trivent.service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.trivent.models.Account;
import com.trivent.models.AppItem;
import com.trivent.models.AppList;
import com.trivent.models.AppSubItem;
import com.trivent.models.AppUIScreen;
import com.trivent.models.AppUIScreenField;
import com.trivent.models.StatusFlowRef;
import com.trivent.models.Role;
import com.trivent.models.Team;
import com.trivent.models.User;
import com.trivent.models.AppUIScreenFilter;
import com.trivent.models.AppUIScreenView;
import com.trivent.models.Division;
import com.trivent.models.Partner;

/**
 * @FileName 	:
 *				CacheService.java
 * @ClassName 	:
 * 				CacheService
 * @DateAndTime :
 *				Nov 21, 2018 - 10:26:53 AM
 * 
 * @Author 		:
 * 				Karthi
 * 
 * @Description : 
 * 				The name,parameter of the method cache  are described and used to list,find,get,clear cache.
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Component
public interface CacheService {
	
	Account findByAccountId(Long accountId);
	
	AppList findByAppListName(String listName);
	
	List<StatusFlowRef> findByObjType(String objType, char isDeleted);
	
	List<AppSubItem> findByItemId(Long appItemId);
	
	List<AppItem> findByListId(Long appListId);
	
	AppUIScreen findByScreenNameTypeRole(Long screenName, String screenType, Long roleId);
	
	List<AppUIScreenField> findFieldsByAppUIScreenId(Long appUIScreenId);

	List<AppUIScreenFilter> findFiltersByAppUIScreenId(Long appUIScreenId);

	List<AppUIScreenView> findViewsByAppUIScreenId(Long appUIScreenId);

	Role findByRoleId(Long roleId);

	Team findByTeamId(Long teamId);

	Partner findByPartnerId(Long partnerId);

	User findByUserId(Long userId);

	Division findDivisionName(Long divisionId);

	Role findByRole(String roleName);

	User findAdminUser(Long roleId);

}
