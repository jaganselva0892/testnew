package com.trivent.service;

import org.springframework.stereotype.Service;

import com.trivent.models.EmailQueue;

/**
 * @FileName 	:
 *				EmailQueueService.java
 * @ClassName 	:
 * 				EmailQueueService
 * @DateAndTime :
 *				Feb 2, 2018 - 12:31:28 PM
 * 
 * @Author 		:
 * 				Ramya
 * 
 * @Description : 
 * 				The name,parameter and exceptions of the method emailQueue  are described and used to list,get,save,update,filter emailQueue.
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Service
public interface EmailQueueService {
	EmailQueue saveEmailQueue(EmailQueue emailQueue);

}
