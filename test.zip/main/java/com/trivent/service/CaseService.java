
package com.trivent.service;

import java.text.ParseException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;

import com.trivent.dto.AppItemVO;
import com.trivent.dto.AppSubItemVO;
import com.trivent.dto.CaseDetailsVO;
import com.trivent.dto.CaseVO;
import com.trivent.dto.DropDownVO;
import com.trivent.dto.RowVO;
import com.trivent.dto.ScreenListFilterVO;
import com.trivent.dto.UserVO;
import com.trivent.exceptions.TriventException;
import com.trivent.models.Account;
import com.trivent.models.Case;
import com.trivent.models.CaseContacts;
import com.trivent.models.CaseQuery;
import com.trivent.models.CaseTask;
import com.trivent.models.User;

/**
 * @FileName : CaseService.java
 * @ClassName : CaseService
 * @DateAndTime : Nov 21, 2018 - 12:15:27 PM
 * 
 * @Author : karthi
 * 
 * @Description : The name,parameter and exceptions of the method caseService
 *              are described and used to list,find,get,save,update caseService.
 * @Tags :
 * @Git_Config : name email
 * 
 */
@Service
public interface CaseService {

	CaseVO saveCase(CaseVO caseVO, UserVO userVO) throws TriventException;

	Case getCase(Long caseId);

	CaseVO getNewCase(UserVO userVO) throws TriventException;

	CaseVO getCaseVO(Case appCase, UserVO userVO) throws TriventException;

	List<RowVO> listCases(ScreenListFilterVO screenListFilterVO, String type, String fromDate, String toDate,
			String pCode, String accountId, String caseStatus, UserVO userVO) throws TriventException, ParseException;

	List<Case> getCaseList(ScreenListFilterVO screenListFilterVO, String type, String fromDate, String toDate,
			String pCode, List<Account> listAccount, String caseStatus, UserVO userVO)
			throws TriventException, ParseException;

	Case updateClientStausByChildCase(Long caseId);

	List<Case> getAssignedToCaseList(String caseIds);

	ScreenListFilterVO getDefaultScreenListFilterVO() throws TriventException;

	CaseDetailsVO getCaseDetailsVO(Long caseId, UserVO userVO) throws TriventException;

	boolean checkNewCase(Case appCase);

	List<Case> getCaseByName(String globalSearch);

	Long inserCaseDetailsUsingProcedure(String Action, Case caseDetails, UserVO userVO);

	Long UpdateCaseDetailusingProcedure(Long caseId, String action, String columnToUpdate, Long modifiedId,
			Integer optVersion);
	
	public void sendAssignedToEmailAlert(User assignedUser, Case appCase, CaseTask caseTsk, CaseQuery caseQry,
			String assignedToType,UserVO userVO);

	List<Case> getCaseListByCaseIds(List<Long> strCaseIds);

	List<CaseContacts> getCaseContactsByCase(List<Case> caseList);

	List<AppItemVO> getCaseType(HttpServletRequest request);

	List<AppSubItemVO> getCaseSubType(HttpServletRequest request, Long caseTypeId);

	List<Case> findCasesListFromHeader(String searchTerm, UserVO userVO) throws ParseException;

	List<DropDownVO> getCommunicationSubType(HttpServletRequest request, String commnTypeId);

	List<DropDownVO> getAppLabelNames();

	List<DropDownVO> getClientType();


}