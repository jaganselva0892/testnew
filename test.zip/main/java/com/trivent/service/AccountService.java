package com.trivent.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;

import com.trivent.dto.AccountVO;
import com.trivent.models.Account;

@Service
public interface AccountService {
	
	public List<Account> getAccountByName(String searchText);

	public List<AccountVO> getAccount(HttpServletRequest request, String partnerCode);
}
