package com.trivent.service;

import javax.servlet.http.HttpServletResponse;

import com.trivent.dto.CaseQueryResponseFilesVO;
import com.trivent.models.CaseQueryResponseFiles;

/**
 * @FileName 	:
 *				CaseQueryResponseFilesService.java
 * @ClassName 	:
 * 				CaseQueryResponseFilesService
 * @DateAndTime :
 *				Feb 2, 2018 - 10:45:49 AM
 * 
 * @Author 		:
 * 				Ramya
 * 
 * @Description : 
 * 				The name,parameter of the method caseQueryResponseFiles  are described and used to downloadAttachment,save caseQueryResponseFiles.
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public interface CaseQueryResponseFilesService {

	void downloadAttachmentFile(Long queryResFileId, HttpServletResponse response);

	public CaseQueryResponseFiles saveCaseQueryResponseFile(Long caseQueryResponseId,
			CaseQueryResponseFilesVO caseQueryResponseFilesVO);

}
