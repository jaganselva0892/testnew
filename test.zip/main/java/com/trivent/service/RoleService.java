package com.trivent.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.trivent.models.Role;

/**
 * @FileName 	:
 *				RoleService.java
 * @ClassName 	:
 * 				RoleService
 * @DateAndTime :
 *				Feb 2, 2018 - 2:50:43 PM
 * 
 * @Author 		:
 * 				Ramya
 * 
 * @Description : 
 * 				The name,parameter and exceptions of the method role  are described and used to list,delete,get,save role.
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Service
public interface RoleService {

	List<Role> getRoleList(String roleType);

	

}
