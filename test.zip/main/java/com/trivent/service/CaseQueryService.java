package com.trivent.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.joda.time.DateTime;
import org.springframework.stereotype.Service;

import com.trivent.dto.AppItemVO;
import com.trivent.dto.AppUIScreenFilterVO;
import com.trivent.dto.CaseQueryVO;
import com.trivent.dto.RowVO;
import com.trivent.dto.ScreenListFilterVO;
import com.trivent.dto.UserVO;
import com.trivent.exceptions.TriventException;

/**
 * @FileName : CaseQueryService.java
 * @ClassName : CaseQueryService
 * @DateAndTime : Feb 2, 2018 - 10:49:49 AM
 * 
 * @Author : Ramya
 * 
 * @Description : The name,parameter and exceptions of the method
 *              caseQueryService are described and used to
 *              list,find,get,filter,email,save,update caseQueryService.
 * @Tags :
 * @Git_Config : name email
 * 
 */
@Service
public interface CaseQueryService {

	DateTime updateCaseQueryModifiedDate(Long queryId);

	List<RowVO> listQueries(ScreenListFilterVO screenListFilterVO, String type, String fromDate, String toDate,
			String partner, UserVO userVO) throws TriventException;

	CaseQueryVO savecaseQuery(CaseQueryVO caseQueryVO, UserVO userVO);

	void emailForNewCaseQuery(CaseQueryVO caseQueryVO, UserVO userVO);

	ScreenListFilterVO getDefaultScreenListFilterVO() throws TriventException;

	AppUIScreenFilterVO populateQueryStatusMap();

	List<AppItemVO> getCommunicationType(HttpServletRequest request);

}
