package com.trivent.service;

import org.springframework.stereotype.Service;

import com.trivent.models.EmailTemplate;

/**
 * @FileName 	:
 *				EmailTemplateService.java
 * @ClassName 	:
 * 				EmailTemplateService
 * @DateAndTime :
 *				Feb 2, 2018 - 12:33:49 PM
 * 
 * @Author 		:
 * 				Ramya
 * 
 * @Description : 
 * 				The name,parameter of the method emailTemplate  are described and used to list,delete,get,find,save emailTemplate.
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
@Service
public interface EmailTemplateService {

	EmailTemplate findEmailTemplateByCode(String templateCode);

	String getPartnerEmails(EmailTemplate emailTemplate, String psType, String psValue, String partnerCode);

	EmailTemplate findEmailTemplateByCode(String templateCode, String psPartnerCode);

}
