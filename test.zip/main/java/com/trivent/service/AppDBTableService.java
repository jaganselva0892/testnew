package com.trivent.service;

import java.util.List;
import java.util.Map;

import com.trivent.dto.AppDBTableColumnVO;
import com.trivent.dto.AppDBTableVO;
import com.trivent.models.AppDBTable;

/**
 * @FileName 	:
 *				AppDBTableService.java
 * @ClassName 	:
 * 				AppDBTableService
 * @DateAndTime :
 *				Feb 1, 2018 - 5:40:42 PM
 * 
 * @Author 		:
 * 				Ramya
 * 
 * @Description : 
 *              The name,parameter  of the method appDBTable  are described and used to list,get,save appDBTable. 
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public interface AppDBTableService {

	AppDBTableVO getAppDBTable(Long appDBTableId);

	AppDBTableVO getAppDBTableByName(String appDBTableName);

	/********** App DB Table Columns **********/

	AppDBTableColumnVO getAppDBTableColumn(Long appDBTableColumnId);

	List<AppDBTableColumnVO> getAppDBTableColumnByName(Long appDBTableId, String appDBTableColName);

	List<AppDBTableColumnVO> getAppDBTableColumnByName(String appDBTableName, String appDBTableColName);

	Map<Long, String> getAppDbTableNames();

	List<AppDBTable> listAppDBTables();

	AppDBTableVO saveAppDBTable(AppDBTableVO appDBTableVO);

	AppDBTableColumnVO saveAppDBTableColumn(AppDBTableColumnVO appDBTableColumnVO);

	/********** Populate Meta Data **********/
	public void updateAppMetaData();

}
