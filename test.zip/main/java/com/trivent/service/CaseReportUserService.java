package com.trivent.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.trivent.models.CaseReportUser;

/**
 * @FileName : CaseReportUserService.java
 * @ClassName : CaseReportUserService
 * @DateAndTime : April 19, 2018 - 12:15:27 PM
 * 
 * @Author : Boopathi P S
 * 
 * @Description : The name,parameter and exceptions of the method CaseReportUserService
 *              are described and used to list,find,get,save,update CaseReportUserService.
 * @Tags :
 * @Git_Config : name email
 * 
 */
@Service
public interface CaseReportUserService {
	
	List<CaseReportUser> saveCaseReportUser(List<CaseReportUser> caseReportUser);
	
	List<CaseReportUser> getCaseReportUser(Long pnCaseId);
	
	List<CaseReportUser> getCaseReportUserByClienType(Long clientType, Long caseId);
	
}