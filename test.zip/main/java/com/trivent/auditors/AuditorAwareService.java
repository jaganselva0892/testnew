package com.trivent.auditors;

import org.springframework.data.domain.AuditorAware;
import org.springframework.stereotype.Component;

import com.trivent.models.User;

/**
 * @FileName : AuditorAwareService.java
 * @ClassName : AuditorAwareService
 * @DateAndTime : Feb 9, 2018 - 10:41:27 AM
 * 
 * @Author : kavipriya
 * 
 * @Description : Function to get current login and guest users details
 * 
 * @Tags :
 * @Git_Config : name email
 * 
 */
@Component
public class AuditorAwareService implements AuditorAware<User> {

	
	@SuppressWarnings("unused")
	private User guestUser = null;

	
	@SuppressWarnings("unused")
	private User adminUser = null;

	/*
	 * (non-Javadoc)[Overriding Method]
	 * 
	 * @OverridingMethod : @see
	 * org.springframework.data.domain.AuditorAware#getCurrentAuditor()
	 * 
	 * @DateAndTime : Feb 9, 2018 - 10:41:27 AM
	 * 
	 * @Author : kavipriya
	 * 
	 * @Description : Method to get current Auditor(User) based on role type
	 * 
	 * @Tags :
	 * 
	 * @return returns User.
	 * 
	 * @Git_Config : name email
	 * 
	 */
	@Override
	public User getCurrentAuditor() {
		User user = new User();
		return user;
	}

	/**
	 * [Methods]
	 * 
	 * @DateAndTime : Feb 9, 2018 - 10:41:27 AM
	 * 
	 * @Author : kavipriya
	 * 
	 * @Description : Method to set Guest user
	 * 
	 * @Tags :
	 * @param guestUser
	 *            inputs the guest user information
	 * @Git_Config : name email
	 * 
	 */
	public void setGuestUser(User guestUser) {
		this.guestUser = guestUser;
	}

}