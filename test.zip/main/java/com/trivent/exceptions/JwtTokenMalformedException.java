package com.trivent.exceptions;

/**
* FileName: JwtTokenMalformedException.java
* To get the Token Exception
* @author Jagan 0010
* @version 1.0
*/

import org.springframework.security.core.AuthenticationException;

public class JwtTokenMalformedException extends AuthenticationException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1686869439891755582L;

	public JwtTokenMalformedException(String msg) {
		super(msg);
	}
}
