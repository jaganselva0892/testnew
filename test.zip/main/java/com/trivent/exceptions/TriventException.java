package com.trivent.exceptions;

import com.trivent.logging.LogManager;
import com.trivent.logging.Logger;

/**
 * @FileName 	:
 *				TriventException.java
 * @ClassName 	:
 * 				TriventException
 * @DateAndTime :
 *				Feb 9, 2018 - 11:34:17 AM
 * 
 * @Author 		:
 * 				Ramya
 * 
 * @Description : 
 * 				The object thrown at run time for trivent
 * 				
 * @Tags 		: 
 * @Git_Config 	: 
 * 				name
 * 				email
 * 
 */
public class TriventException extends Exception {

  private static final long serialVersionUID = 3901288427653925165L;
  private static final Logger LOGGER = LogManager.getLogger();
  private static final String CLASS_NAME = TriventException.class.getName();

  private static final String METHOD_HANDLE_EXCEPTION = "handleException";

  public TriventException() {
    super();
  }

  public TriventException(String message) {
    super(message);
  }

  public TriventException(String message, Throwable cause) {
    super(message, cause);
  }

  public static void handleException(Exception ex) {
    LOGGER.error(CLASS_NAME, METHOD_HANDLE_EXCEPTION, ex);
  }

}
